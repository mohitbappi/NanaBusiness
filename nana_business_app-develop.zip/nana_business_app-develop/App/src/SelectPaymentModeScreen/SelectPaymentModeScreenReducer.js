import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import * as ActionTypes from './ActionType';

const initialState = {
	paymentModeIndex: 0,
	paymentMode: localeString(keyConstants.ONLINE_PAYMENT),
};

const SelectPaymentModeScreenReducer = (state = initialState, action = {}) => {
	if (action.type === ActionTypes.SET_PAYMENT_MODE) {
		return {
			...state,
			paymentModeIndex: action.payload.index,
			paymentMode: action.payload.value,
		};
	}
	return state;
};

export default SelectPaymentModeScreenReducer;
