import * as ActionTypes from './ActionType';

export const onSetPaymentMode = (value, index) => {
	return {
		type: ActionTypes.SET_PAYMENT_MODE,
		payload: { value, index },
	};
};

export default onSetPaymentMode;
