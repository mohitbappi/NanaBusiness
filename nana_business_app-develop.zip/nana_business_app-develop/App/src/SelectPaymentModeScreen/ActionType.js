export const SET_PAYMENT_MODE = 'set_payment_mode';

export default SET_PAYMENT_MODE;
