import React, { Component } from 'react';
import { View, FlatList } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import PaymentModeCard from '@PaymentModeCard/PaymentModeCard';
import * as SelectPaymentModeActions from './SelectPaymentModeScreenAction';
import { createStyleSheet } from './SelectPaymentModeScreenStyle';

class SelectPaymentModeScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			paymentOptions: [],
			selectedIndex: null,
		};
	}

	componentDidMount() {
		const { selectPaymentModeInfo } = this.props;
		const paymentOptions = [
			{
				icon: IMAGES.iconOnlinePayment,
				title: localeString(keyConstants.ONLINE_PAYMENT),
			},
			{
				icon: IMAGES.iconCOD,
				title: localeString(keyConstants.CASH_ON_DELIVERY),
			},
		];
		this.setState({
			paymentOptions,
			selectedIndex: selectPaymentModeInfo.paymentModeIndex,
		});
	}

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onSelectOption = index => {
		this.setState({
			selectedIndex: index,
		});
	};

	keyExtractor = (item, index) => index.toString();

	onSubmit = () => {
		const { selectPaymentModeActions, navigation } = this.props;
		const { paymentOptions, selectedIndex } = this.state;
		selectPaymentModeActions.onSetPaymentMode(
			paymentOptions[selectedIndex].title,
			selectedIndex,
		);
		navigation.goBack();
	};

	render() {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet();
		const { paymentOptions, selectedIndex } = this.state;
		return (
			<View style={styles.container}>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.PAYMENT_MODE)}
						hasIconBack
						onPressBack={this.onGoBack}
					/>
				</View>
				<FlatList
					data={paymentOptions}
					renderItem={({ item, index }) => {
						return (
							<PaymentModeCard
								isRTL={isRTL}
								PaymentModeIcon={item.icon}
								PaymentMode={item.title}
								onSelectOption={() => this.onSelectOption(index)}
								selectedIndex={selectedIndex}
								index={index}
							/>
						);
					}}
					keyExtractor={this.keyExtractor}
					showsVerticalScrollIndicator={false}
				/>
				<View style={styles.submitButton}>
					<ButtonComponent
						text={localeString(keyConstants.SUBMIT)}
						onPress={this.onSubmit}
					/>
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		selectPaymentModeInfo: state.SelectPaymentModeScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		selectPaymentModeActions: bindActionCreators({ ...SelectPaymentModeActions }, dispatch),
	};
};

SelectPaymentModeScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	selectPaymentModeInfo: PropTypes.object.isRequired,
	selectPaymentModeActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectPaymentModeScreen);
