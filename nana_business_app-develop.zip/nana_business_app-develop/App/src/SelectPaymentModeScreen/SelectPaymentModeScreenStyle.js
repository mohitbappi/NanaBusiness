import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import { normalScale, verticalScale, moderateScale } from '@device/normalize';

export const createStyleSheet = () => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(7),
			paddingBottom: verticalScale(8),
			borderRadius: moderateScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
		},
		submitButton: {
			paddingBottom: verticalScale(30),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
