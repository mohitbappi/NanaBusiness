import React, { Component } from 'react';
import { View, ScrollView, Keyboard } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import { createStyleSheet } from '@AddNewRetailerScreen/AddNewRetailerScreenStyle';
import Input from '@Input/Input';
import Spinner from '@Spinner/Spinner';
import { normalScale } from '@device/normalize';
import {
	nameMaxLength,
	toastShowTime,
	duplicateName,
	duplicateArabicName,
} from '@Constants/Constants';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import navigations from '@routes/navigations';
import SmallMapComponent from '@Components/SmallMapComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import AlertComponent from '@Util/AlertComponent';
import { constants } from './Constant';
import * as AddBranchActions from './AddNewBranchScreenAction';

class AddNewBranchScreen extends Component {
	constructor(props) {
		super(props);
		this.arabicBranchName = React.createRef(null);
		this.branchDetail = null;
		this.navigation = props.navigation;
		this.state = {
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		this.willFocusListener = this.navigation.addListener('focus', () => {
			// only set this.branchDetail variable if present in this.props.route.params.branchData
			const { addBranchActions, route } = this.props;
			if (!route?.params?.region && route.params && route.params.branchData) {
				this.branchDetail = route.params.branchData;
				const {
					name, // English branch name
					name_ar, // Arabic branch name
					address_one,
					address_two,
					latitude,
					longitude,
				} = this.branchDetail;
				addBranchActions.onChangeText(name, constants.branchName);
				addBranchActions.onChangeText(name_ar, constants.arabicBranchName);
				addBranchActions.onChangeText(address_one, constants.addressLine1);
				addBranchActions.onChangeText(address_two, constants.addressLine2);
				const region = {
					latitude: parseFloat(latitude),
					longitude: parseFloat(longitude),
					latitudeDelta: 0.005,
					longitudeDelta: 0.005,
				};
				route.params.region = region;
			}
		});
	}

	componentDidUpdate(prevProps) {
		const { addBranchInfo, route } = this.props;
		const { success, error, errorCode } = addBranchInfo;
		if (success && prevProps.addBranchInfo.success !== success) {
			this.navigation.navigate(navigations.BRANCHES_NAVIGATION);
			// deleting region & branchData after successfully adding/editing branch to reset valued to empty
			delete route.params.region;
			delete route.params.branchData;
		}
		if (error && prevProps.addBranchInfo.error !== error) {
			if (keyConstants.NULL_ZONE_BRANCH_UPDATE === errorCode.error) {
				// While editing the branch if selected address contains null zone the alert will come.
				const alertOptions = {
					message: localeString(keyConstants.NULL_ZONE_BRANCH_UPDATE),
					onPressYes: () => this.onPressSave('true'),
				};
				setTimeout(() => AlertComponent(alertOptions), 10);
			} else if (keyConstants[errorCode.error]) {
				let errorMessage = '';
				if (errorCode.error === duplicateName) {
					errorMessage = localeString(keyConstants.DUPLICATE_BRANCH_NAME);
				}
				if (errorCode.error === duplicateArabicName) {
					errorMessage = localeString(keyConstants.DUPLICATE_ARABIC_BRANCH_NAME);
				}
				this.showToast(errorMessage);
			} else {
				// Will show alert if api crashes.
				ErrorAlertComponent(errorCode, () => this.onPressSave('false'));
			}
		}
	}

	componentWillUnmount() {
		// Will reset the reducer.
		const { addBranchActions } = this.props;
		addBranchActions.onResetBranchState();
	}

	onGoBack = () => this.navigation.goBack();

	onChangeText = (text, field) => {
		const { addBranchActions } = this.props;
		addBranchActions.onChangeText(text, field);
	};

	onSelectLocation = () => {
		this.navigation.navigate(navigations.SELECT_LOCATION_NAVIGATION);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	showToast = message => {
		// Will show error as a toast.
		this.setState({
			toastMessage: message,
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({ isApiError: false });
		}, toastShowTime);
	};

	onPressSave = forceUpdate => {
		// Will call the api to add/edit the branch.
		const { addBranchActions, addBranchInfo, route, homeScreenInfo } = this.props;
		const { branchName, arabicBranchName, addressLine1, addressLine2 } = addBranchInfo;
		const { region } = route.params ? route.params : {};
		this.onDissmissKeyboard();
		const branchDetails = {
			name: branchName,
			address_one: addressLine1,
			latitude: region.latitude,
			longitude: region.longitude,
			name_ar: arabicBranchName,
		};
		if (addressLine2) {
			branchDetails.address_two = addressLine2;
		}
		if (this.branchDetail) {
			const { zoneId } = homeScreenInfo;
			branchDetails.current_zone_id = zoneId;
			branchDetails.force_update = forceUpdate;
			const queryParams = {
				id: this.branchDetail.id,
				branchDetails,
			};
			addBranchActions.onEditBranch(queryParams);
		} else {
			addBranchActions.onAddNewBranch(branchDetails);
		}
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const textRef = textInputRef;
		textRef.current = node;
	};

	render() {
		const { languageInfo, addBranchInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const { isApiError, toastMessage } = this.state;
		const styles = createStyleSheet(isRTL);
		const { loader, branchName, arabicBranchName, addressLine1, addressLine2 } = addBranchInfo;
		const { region } = route.params ? route.params : {};
		return (
			<KeyboardAwareScrollView
				contentContainerStyle={styles.container}
				keyboardShouldPersistTaps="handled">
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(
							route?.params?.branchData
								? keyConstants.EDIT_BRANCH
								: keyConstants.ADD_NEW_BRANCH,
						)}
						hasIconPin
					/>
				</View>
				<ScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					keyboardShouldPersistTaps="handled">
					<Input
						maxLength={nameMaxLength}
						value={branchName}
						width={normalScale(288)}
						label={`${localeString(keyConstants.ENGLISH_BRANCH_NAME)}*`}
						placeholder={localeString(keyConstants.ENGLISH_BRANCH_NAME)}
						blurOnSubmit
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => this.onChangeText(text, constants.branchName)}
						autoCapitalize="none"
						onSubmitEditing={() => this.onSubmitRef(this.arabicBranchName)}
					/>
					<Input
						maxLength={nameMaxLength}
						value={arabicBranchName}
						width={normalScale(288)}
						label={`${localeString(keyConstants.ARABIC_BRANCH_NAME)}*`}
						placeholder={localeString(keyConstants.BRANCH_NAME)}
						blurOnSubmit
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => this.onChangeText(text, constants.arabicBranchName)}
						autoCapitalize="none"
						refs={this.refCallback(this.arabicBranchName)}
					/>
					<SmallMapComponent
						region={region}
						isRTL={isRTL}
						addressLine1={addressLine1}
						addressLine2={addressLine2}
						onSelectLocation={this.onSelectLocation}
						onChangeText={this.onChangeText}
					/>
				</ScrollView>
				<View style={styles.buttonView}>
					<View style={styles.buttonContainerBack}>
						<ButtonComponent
							buttonStyle={styles.backButton}
							text={localeString(keyConstants.BACK)}
							textStyle={styles.backText}
							onPress={this.onGoBack}
						/>
					</View>
					<View style={styles.buttonContainerSubmit}>
						<ButtonComponent
							text={
								this.branchDetail
									? localeString(keyConstants.SUBMIT)
									: localeString(keyConstants.ADD_BRANCH)
							}
							onPress={() => this.onPressSave('false')}
							isButtonDisable={!(branchName && addressLine1 && arabicBranchName)}
						/>
					</View>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		addBranchInfo: state.AddNewBranchScreenReducer,
		homeScreenInfo: state.HomeScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		addBranchActions: bindActionCreators({ ...AddBranchActions }, dispatch),
	};
};

AddNewBranchScreen.propTypes = {
	addBranchInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	addBranchActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(AddNewBranchScreen);
