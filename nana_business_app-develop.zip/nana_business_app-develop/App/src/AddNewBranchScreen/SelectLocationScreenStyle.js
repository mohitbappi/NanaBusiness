import { StyleSheet } from 'react-native';
import { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		mapContainer: {
			flex: 1,
		},
		map: {
			flex: 1,
		},
		markerImage: {
			width: normalScale(56),
			height: verticalScale(69),
			zIndex: 3,
			position: 'absolute',
			marginTop: -verticalScale(37),
			marginLeft: -normalScale(22),
			left: '50%',
			top: '50%',
		},
		searchBarContainer: {
			zIndex: 3,
			flex: 1,
			paddingHorizontal: normalScale(10),
			paddingVertical: verticalScale(10),
			width: normalScale(280),
			position: 'absolute',
			left: normalScale(35),
			top: normalScale(0),
		},
		buttonSelectLocationStyle: {
			position: 'absolute',
			left: normalScale(30),
			right: normalScale(30),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(60),
		},
		backMapButton: {
			position: 'absolute',
			left: normalScale(20),
			top: normalScale(20),
		},
		iconGoBack: {
			height: verticalScale(12),
			width: normalScale(10),
			transform: rtlFunctions.getTransformOpposite(isRTL),
		},
	});
};

export default createStyleSheet;
