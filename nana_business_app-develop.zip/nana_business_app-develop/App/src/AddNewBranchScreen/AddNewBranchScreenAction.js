import { actions } from '@libapi/APIActionsBuilder';
import AddNewBranchService from '@Branch/AddNewBranchService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import EditBranchService from '@Branch/EditBranchService';
import * as ActionTypes from './ActionType';

export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_BRANCH_TEXT,
		payload: text,
		field,
	};
};

export const onResetBranchState = () => ({ type: ActionTypes.RESET_BRANCH_STATE });

/**
 * Action to add the new branch.
 * @param {object} branchDetails
 * @returns
 */

export const onAddNewBranch = branchDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ADD_BRANCH_SUCCESS,
		ActionTypes.ADD_BRANCH_FAILURE,
		ActionTypes.ADD_BRANCH_LOADER,
	);
	const addNewBranchService = new AddNewBranchService(dispatchedActions);
	addBasicInterceptors(addNewBranchService);
	addNewBranchService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(addNewBranchService.makeRequest(branchDetails));
};

/**
 * Action to edit the branch.
 * @param {object} branchDetails
 * @returns
 */

export const onEditBranch = branchDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.EDIT_BRANCH_SUCCESS,
		ActionTypes.EDIT_BRANCH_FAILURE,
		ActionTypes.EDIT_BRANCH_LOADER,
	);
	const editBranchService = new EditBranchService(dispatchedActions);
	addBasicInterceptors(editBranchService);
	editBranchService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(editBranchService.makeRequest(branchDetails));
};
