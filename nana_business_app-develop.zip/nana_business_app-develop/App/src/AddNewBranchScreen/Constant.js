export const constants = {
	branchName: 'branchName',
	arabicBranchName: 'arabicBranchName',
	addressLine2: 'addressLine2',
	addressLine1: 'addressLine1',
};

export default constants;
