export const ON_CHANGE_BRANCH_TEXT = 'on_change_branch_text';

export const ADD_BRANCH_SUCCESS = 'add_branch_success';
export const ADD_BRANCH_FAILURE = 'add_branch_failure';
export const ADD_BRANCH_LOADER = 'add_branch_loader';

export const RESET_BRANCH_STATE = 'reset_branch_state';

export const EDIT_BRANCH_SUCCESS = 'edit_branch_success';
export const EDIT_BRANCH_FAILURE = 'edit_branch_failure';
export const EDIT_BRANCH_LOADER = 'edit_branch_loader';
