import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Config from 'react-native-config';
import Geolocation from '@react-native-community/geolocation';
import { localeString } from '@assets/Localization';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import navigations from '@routes/navigations';
import {
	vendor,
	collector,
	mapMovementDuration,
	saudiLatitude,
	saudiLongitude,
} from '@Constants/Constants';
import vendorNavigations from '@routes/vendorNavigations';
import * as AddRetailerActions from '@AddNewRetailerScreen/AddNewRetailerScreenAction';
import collectorNavigations from '@routes/collectorNavigations';
import GooglePlacesAutoCompleteComponent from '@Components/GooglePlacesAutoCompleteComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import * as AddBranchActions from './AddNewBranchScreenAction';
import { createStyleSheet } from './SelectLocationScreenStyle';

class SelectLocationScreen extends Component {
	constructor(props) {
		super(props);
		this.mapView = React.createRef(null);
		this.languageInfo = props.languageInfo;
		this.state = {
			region: null,
			currentLocation: {
				latitude: parseFloat(saudiLatitude),
				longitude: parseFloat(saudiLongitude),
			},
		};
	}

	componentDidMount() {
		Geolocation.getCurrentPosition(info => {
			this.setState({
				region: {
					latitude: info.coords.latitude,
					longitude: info.coords.longitude,
					latitudeDelta: 0.005,
					longitudeDelta: 0.005,
				},
				currentLocation: {
					latitude: parseFloat(info.coords.latitude),
					longitude: parseFloat(info.coords.longitude),
				},
			});
		});
	}

	onSelectMapReady = () => {
		this.setState({});
	};

	onSelectRegionChange = region => {
		this.setState(
			{
				region,
			},
			() => this.fetchSelectAddress(),
		);
	};

	onSelectAddressSearch = location => {
		this.setState(
			{
				region: {
					latitude: parseFloat(location.lat),
					longitude: parseFloat(location.lng),
					latitudeDelta: 0.005,
					longitudeDelta: 0.005,
				},
			},
			() => {
				this.fetchSelectAddress();
				this.animateSelectMap();
			},
		);
	};

	animateSelectMap = () => {
		const { region } = this.state;
		const { latitude, longitude } = region;
		const temp_cordinate = {
			latitude,
			longitude,
		};
		this.mapView.animateCamera(
			{
				center: temp_cordinate,
			},
			mapMovementDuration,
		);
	};

	fetchSelectAddress = () => {
		const { region } = this.state;
		fetch(
			`https://maps.googleapis.com/maps/api/geocode/json?address=${region.latitude},${region.longitude}&key=${Config.GOOGLE_API_KEY}`,
		)
			.then(response => response.json())
			.then(responseJson => {
				const userLocation = responseJson.results[0].formatted_address;
				this.onChangeText(userLocation, 'addressLine1');
			});
	};

	onChangeText = (text, field) => {
		const { userDetails, addRetailerActions, addBranchActions } = this.props;
		const { role, roles } = userDetails.user;
		if (role === vendor || roles.includes(collector)) {
			addRetailerActions.onChangeText(text, field);
		} else {
			addBranchActions.onChangeText(text, field);
		}
	};

	onSubmit = () => {
		const { userDetails, navigation } = this.props;
		const { role, roles } = userDetails.user;
		const { region } = this.state;
		if (role === vendor) {
			navigation.navigate(vendorNavigations.ADD_NEW_RETAILER_NAVIGATION, {
				region,
			});
		} else if (roles.includes(collector)) {
			navigation.navigate(collectorNavigations.ADD_NEW_RETAILER_NAVIGATION, {
				region,
			});
		} else {
			navigation.navigate(navigations.ADD_NEW_BRANCH_NAVIGATION, {
				region,
			});
		}
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	render() {
		const { isRTL } = this.languageInfo;
		const styles = createStyleSheet(isRTL);
		const { currentLocation, region } = this.state;
		const { latitude, longitude } = currentLocation;
		const homePlace = {
			description: localeString(keyConstants.CURRENT_LOCATION),
			geometry: {
				location: {
					lat: latitude,
					lng: longitude,
				},
			},
		};
		return (
			<View style={styles.mapContainer}>
				{region && (
					<>
						<MapView
							provider={PROVIDER_GOOGLE}
							style={styles.map}
							ref={mapView => {
								this.mapView = mapView;
							}}
							initialRegion={region}
							showsUserLocation
							onMapReady={this.onSelectMapReady}
							zoomControlEnabled
							showsMyLocationButton
							onRegionChangeComplete={this.onSelectRegionChange}
						/>
						<ImageLoadComponent
							style={styles.markerImage}
							source={IMAGES.iconLocationPin}
						/>
					</>
				)}
				<View keyboardShouldPersistTaps="always" style={styles.searchBarContainer}>
					<GooglePlacesAutoCompleteComponent
						onSelectAddressSearch={this.onSelectAddressSearch}
						predefinedPlaces={[homePlace]}
					/>
				</View>
				<TouchableOpacity
					activeOpacity={0.8}
					style={styles.backMapButton}
					onPress={this.onGoBack}>
					<ImageLoadComponent source={IMAGES.iconRightArrow} style={styles.iconGoBack} />
				</TouchableOpacity>
				<ButtonComponent
					viewStyle={styles.buttonSelectLocationStyle}
					onPress={this.onSubmit}
					text={localeString(keyConstants.SELECT_LOCATION)}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		signUpInfo: state.SignUpScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		addBranchActions: bindActionCreators({ ...AddBranchActions }, dispatch),
		addRetailerActions: bindActionCreators({ ...AddRetailerActions }, dispatch),
	};
};

SelectLocationScreen.propTypes = {
	userDetails: PropTypes.object.isRequired,
	addRetailerActions: PropTypes.object.isRequired,
	addBranchActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectLocationScreen);
