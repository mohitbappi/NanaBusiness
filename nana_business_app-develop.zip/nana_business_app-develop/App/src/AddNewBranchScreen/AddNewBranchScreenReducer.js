import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	branchName: '',
	arabicBranchName: '',
	addressLine1: '',
	addressLine2: '',
	isEditBranch: false,
};

const AddNewBranchScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_BRANCH_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.RESET_BRANCH_STATE:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
				branchName: '',
				arabicBranchName: '',
				addressLine1: '',
				addressLine2: '',
				isEditBranch: false,
			};
		case ActionTypes.ADD_BRANCH_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isEditBranch: false,
			};
		case ActionTypes.EDIT_BRANCH_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isEditBranch: true,
			};
		case ActionTypes.ADD_BRANCH_LOADER:
		case ActionTypes.EDIT_BRANCH_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.ADD_BRANCH_FAILURE:
		case ActionTypes.EDIT_BRANCH_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default AddNewBranchScreenReducer;
