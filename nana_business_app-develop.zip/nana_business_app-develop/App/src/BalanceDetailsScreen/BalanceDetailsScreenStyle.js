import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			color: colors.lightWhite,
			alignSelf: 'center',
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			marginBottom: verticalScale(10),
			marginTop: verticalScale(5),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		bodyStyle: {
			fontSize: normalize(10),
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(2),
		},
		balanceView: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		dueAmountView: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		cardStyle: {
			backgroundColor: colors.orange,
		},
		progressBarStyle: {
			backgroundColor: colors.darkOrange,
		},
		noteStyle: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			paddingHorizontal: normalScale(16),
			marginBottom: verticalScale(6),
		},
		card: {
			paddingVertical: verticalScale(9),
			paddingHorizontal: normalScale(16),
			borderBottomColor: colors.greenShadow,
			borderBottomWidth: normalScale(1),
			borderRadius: moderateScale(8),
		},
		detailContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			flex: 1,
			alignItems: 'center',
		},
		innerContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			flex: 1,
			alignItems: 'center',
		},
		iconType: {
			height: normalScale(36),
			width: normalScale(36),
			marginRight: isRTL ? 0 : normalScale(7),
			marginLeft: isRTL ? normalScale(7) : 0,
		},
		id: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		totalAmount: {
			color: colors.green,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		normalAmount: {
			color: colors.blackGreyWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		dateContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			flex: 1,
			justifyContent: 'space-between',
			marginTop: verticalScale(12),
		},
		date: {
			color: colors.blackGreyWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(11),
		},
		status: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		failedText: {
			color: colors.red,
		},
		approvedText: {
			color: colors.darkBlue,
		},
		pendingText: {
			color: colors.darkOrange,
		},
	});
};

export default createStyleSheet;
