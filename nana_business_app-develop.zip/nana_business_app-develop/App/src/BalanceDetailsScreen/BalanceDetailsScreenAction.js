import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetBalanceDetailsService from '@BalanceDetails/GetBalanceDetailsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to get the wallet transactions and amount.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetBalanceDetails = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_BALANCE_DETAILS_SUCCESS,
		ActionTypes.GET_BALANCE_DETAILS_FAILURE,
		ActionTypes.GET_BALANCE_DETAILS_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getBalanceDetailsService = new GetBalanceDetailsService(dispatchedActions);
	addBasicInterceptors(getBalanceDetailsService);
	getBalanceDetailsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getBalanceDetailsService.makeRequest(props));
};

export default onGetBalanceDetails;
