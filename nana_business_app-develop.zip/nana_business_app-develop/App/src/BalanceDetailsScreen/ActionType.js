export const GET_BALANCE_DETAILS_SUCCESS = 'get_balance_details_success';
export const GET_BALANCE_DETAILS_FAILURE = 'get_balance_details_failure';
export const GET_BALANCE_DETAILS_LOADER = 'get_balance_details_loader';
