// import libraries
import React from 'react';
import { StyleSheet, Text, View, FlatList } from 'react-native';
import PropTypes from 'prop-types';

// import colors
import * as colors from '@assets/colors';

// import utils
import normalize, { normalScale, verticalScale, lineHeightScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants, plus } from '@Constants/Constants';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';

// import components
import Header from '@Header/Header';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
			paddingHorizontal: normalScale(16),
		},
		headerContainer: {
			marginBottom: verticalScale(10),
		},
		name: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			color: colors.pureBlack,
			lineHeight: lineHeightScale(18),
			marginBottom: verticalScale(8),
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
			marginRight: rtlFunctions.getMarginRight(isRTL, 8),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		innerContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		iconRightArrow: {
			height: normalScale(10),
			width: normalScale(12),
			transform: isRTL ? [{ rotate: '180deg' }] : [{ rotate: '360deg' }],
			marginTop: verticalScale(8),
		},
	});
};

const TAndCScreen = props => {
	const { route } = props;
	const { isRTL } = route?.params;
	const styles = createStyleSheet(isRTL);

	const getTnC = () => {
		return [
			`${localeString(keyConstants.UNBILLED_AMOUNT)}: ${localeString(
				keyConstants.BALANCE_DETAILS_TNC_FIRST,
			)}`,
			`${localeString(keyConstants.CONSUMED_AMOUNT)}: ${localeString(
				keyConstants.BALANCE_DETAILS_TNC_SECOND,
			)}`,
			`${localeString(keyConstants.BALANCE_DETAILS_TNC_THIRD)}`,
			`${localeString(keyConstants.BALANCE_DETAILS_TNC_FOURTH)}`,
			`${localeString(keyConstants.TOTAL_AMOUNT)} = ${localeString(
				keyConstants.AVAILABLE_BALANCE,
			)} ${plus} ${localeString(keyConstants.BILLED_AMOUNT)} ${plus} ${localeString(
				keyConstants.UNBILLED_AMOUNT,
			)}`,
		];
	};

	const onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = props;
		navigation.goBack();
	};

	const renderItem = ({ item }) => {
		return (
			<View style={styles.innerContainer}>
				<ImageLoadComponent source={IMAGES.iconRightArrow} style={styles.iconRightArrow} />
				<Text style={styles.name}>{item}</Text>
			</View>
		);
	};

	const keyExtractor = index => index.toString();

	return (
		<View style={styles.container}>
			<View style={styles.headerContainer}>
				<Header
					text={localeString(keyConstants.TERMS_AND_CONDITIONS)}
					onPressClose={onGoBack}
					hasIconClose
				/>
			</View>
			<FlatList
				data={getTnC()}
				renderItem={renderItem}
				keyExtractor={keyExtractor}
				showsVerticalScrollIndicator={false}
			/>
		</View>
	);
};

TAndCScreen.propTypes = {
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
};

export default TAndCScreen;
