import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	balanceDetails: [],
	count: 0,
	amountDataPoints: null,
};

const BalanceDetailsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_BALANCE_DETAILS_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				balanceDetails: isOverwriteExistingList
					? [...state.balanceDetails, ...action.payload.payments]
					: action.payload.payments,
				count: action.payload.count,
				amountDataPoints: action.payload.amounts_data_points, // Will contain total amount, total locked amount and total used amount
			};
		}
		case ActionTypes.GET_BALANCE_DETAILS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_BALANCE_DETAILS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default BalanceDetailsScreenReducer;
