// import libraries
import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import CreditLineInformation from '@CreditLineInformation/CreditLineInformation';
import DueAmountContainer from '@DueAmountContainer/DueAmountContainer';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToggleFeatureScreen from '@ToggleFeatureScreen/ToggleFeatureScreen';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import CardComponent from '@TransactionCard/CardComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

// import constants
import { localeString } from '@assets/Localization';
import {
	toastShowTime,
	fetchDataWithPagination,
	onlinePayment,
	paymentStatus,
	isToggleFeatureEnable,
	navigationType,
} from '@Constants/Constants';
import { keyConstants } from '@Constants/KeyConstants';
import navigations from '@routes/navigations';
import { constants } from '@RefreshControlComponent/Constants';
import { verticalScale } from '@device/normalize';

// import utils
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import BalanceDetailsActions from './BalanceDetailsScreenAction';

// import styles
import { createStyleSheet } from './BalanceDetailsScreenStyle';

class BalanceDetailsScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			isAddMoneyClicked: false, // Boolean to check Add Money clicked or noe.
			isApiError: false, // Boolean to show error
			toastMessage: '', // Will show error message
		};
		this.navigation = props.navigation;
	}

	componentDidMount() {
		this.willFocusListener = this.navigation.addListener('focus', () => {
			const { pullToRefreshActions, refreshControlComponentInfo } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.page = fetchDataWithPagination.page;
			this.limit = getScrollingIndex(scrollIndex);
			this.onLoadMore(false);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { balanceDetailsInfo, toggleFeaturesInfo } = this.props;
		const { success } = balanceDetailsInfo;
		const { isAddMoneyClicked } = this.state;
		const { success: toggleApiSuccess, toggleFeatures } = toggleFeaturesInfo;
		const { online_payment } = toggleFeatures; // Will return toggleFeatures key value pair.
		if (
			toggleApiSuccess &&
			isAddMoneyClicked &&
			prevProps.toggleFeaturesInfo.success !== success
		) {
			this.setState({
				isAddMoneyClicked: false,
			});
			if (online_payment) {
				// Will navigate to the online payment screen if user is authorized to use this functionality.
				this.navigation.navigate(navigations.ADD_MONEY_NAVIGATION, {
					type: navigationType.balance,
				});
			} else {
				// Will update the online payment value to false because user is not authorized.
				this.setState({
					toastMessage: localeString(keyConstants.NOT_AUTHORIZED),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			}
		}
		if (success && prevProps.balanceDetailsInfo.success !== success) {
			// Will hide bottom loader.
			const { pullToRefreshActions } = this.props;
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.page === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	componentWillUnmount() {
		this.resetScrollIndex();
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	getTransactionDetail = (transactionDetail, index) => {
		/*
			Will navigate to the transaction detail screen.
			Passing parameters are :-
			1. transactionDetail - Contains all the details of the transaction.
			2. date - Transaction date.
		*/
		this.itemListRef.onSetIndex(index);
		this.navigation.navigate(navigations.TRANSACTION_DETAIL_NAVIGATION, {
			transactionDetail,
			date: transactionDetail.created_at,
		});
	};

	keyExtractor = (item, index) => index.toString();

	onGoBack = () => {
		// Will go back to the previous screen.
		this.resetScrollIndex();
		this.navigation.goBack();
	};

	onOpenTnC = isRTL => {
		// Will navigate to the balance terms and conditions screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.BALANCE_TERMS_AND_CONDITION_NAVIGATION, { isRTL });
	};

	addMoney = () => {
		if (isToggleFeatureEnable) {
			// Will call toggle feature API.
			this.setState({
				isAddMoneyClicked: true,
			});
			this.toggleFeature.getToggleFeatures();
		} else {
			// Will navigate to online payment screen.
			this.navigation.navigate(navigations.ADD_MONEY_NAVIGATION, {
				type: navigationType.balance,
			});
		}
	};

	getUnbilledSummary = () => {
		// Will navigate to the unbilled summary screen.
		this.navigation.navigate(navigations.UNBILLED_SUMMARY_NAVIGATION);
	};

	listFooterComponent = () => {
		const { languageInfo, balanceDetailsInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { balanceDetails, count } = balanceDetailsInfo;
		const endReached = count === balanceDetails.length || count < balanceDetails.length;
		if (!endReached) {
			return <Loader size="small" isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { balanceDetailsInfo } = this.props;
		const { loader } = balanceDetailsInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onLoadMore(true);
		}
	};

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		// API call to fetch the balance details.
		const { onGetBalanceDetails } = this.props;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		onGetBalanceDetails(queryParams, isOverwriteExistingList);
	};

	onRefresh = () => {
		// Will call api while pull to refresh.
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
		this.page = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		this.onFetchData(false);
	};

	getLayout = (data, index) => ({
		length: verticalScale(57),
		offset: verticalScale(57) * index,
		index,
	});

	getId = item => {
		if (item.type === onlinePayment) {
			return item.reference_id;
		}
		if (item.is_advance_payment) {
			return item.pr_id;
		}
		return item.collection_request_id;
	};

	getStatus = status => {
		// Will return status name and style according to status.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case paymentStatus.failed:
				return { status: localeString(keyConstants.FAILED), style: styles.failedText };
			case paymentStatus.approved:
				return { status: localeString(keyConstants.APPROVED), style: styles.approvedText };
			default:
				return { status: localeString(keyConstants.PENDING), style: styles.pendingText };
		}
	};

	render() {
		const { bottomLoader, isAddMoneyClicked, isApiError, toastMessage } = this.state;
		const {
			isConnected,
			languageInfo,
			balanceDetailsInfo,
			toggleFeaturesInfo,
			refreshControlComponentInfo,
			configurableFileInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { remoteConfigData } = configurableFileInfo;
		const {
			loader,
			balanceDetails,
			count,
			amountDataPoints,
			error,
			errorCode,
		} = balanceDetailsInfo;
		const { total_advance, total_used, total_unbilled } = amountDataPoints || {};
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		// Will provide all the variables of the home screen reducer.
		const { toggleFeatures, loader: toggleApiLoader } = toggleFeaturesInfo;
		const { online_payment } = toggleFeatures; // Will return toggleFeatures key value pair.
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && <Loader size="large" />}
				{toggleApiLoader && isAddMoneyClicked && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.BALANCE_DETAILS)}
						onPressBack={this.onGoBack}
						hasIconBack
						hasHyperLink
						onPressHyperLink={() => this.onOpenTnC(isRTL)}
						hyperLinkTitle={localeString(keyConstants.TERMS_AND_CONDITIONS)}
					/>
				</View>
				{error ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<>
						<View style={styles.balanceView}>
							<CreditLineInformation // Component to show amount data points like available balance, used balance and consumed balance
								isRTL={isRTL}
								amount={total_advance - (total_used + total_unbilled)} // Available balance of the wallet
								usedAmount={total_used} // Total amount used to settle out the collection requests
								paidAmount={0}
								totalCreditAmount={total_advance} // Total amount of the wallet
								usedTitle={localeString(keyConstants.BILLED)}
								totalTitle={localeString(keyConstants.TOTAL_KEY)}
								cardStyle={styles.cardStyle}
								progressBarStyle={styles.progressBarStyle}
								hasHyperlink={remoteConfigData?.wallet?.addMoney && online_payment} // Will show hyperlink to add money into the wallet if this feature is enabled for the user.
								hyperlinkTitle={localeString(keyConstants.ADD_MONEY)}
								onPressHyperlink={this.addMoney} // Action to add money into the wallet
							/>
						</View>
						<TouchableOpacity
							activeOpacity={0.8}
							style={styles.dueAmountView}
							onPress={this.getUnbilledSummary}>
							<DueAmountContainer // Component to show locked amount which will be use to settle out the collection requests
								isRTL={isRTL}
								title={localeString(keyConstants.UNBILLED_AMOUNT)}
								amount={total_unbilled} // Total locked amount
							/>
						</TouchableOpacity>
						{balanceDetails.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
						) : (
							<FlatListComponent
								keyboardShouldPersistTaps="handled"
								data={balanceDetails}
								showsVerticalScrollIndicator={false}
								renderItem={({ item, index }) => {
									return (
										<CardComponent
											isRTL={isRTL}
											item={item}
											onPress={() => this.getTransactionDetail(item, index)}
											creditDebitType={item.is_advance_payment} // return true if transaction type is credit and false if debit.
											isShowTimeDate // Will show date and time.
											date={item.created_at}
										/>
									);
								}}
								keyExtractor={this.keyExtractor}
								onEndReached={() =>
									balanceDetails.length !== count && this.onEndReached()
								}
								ListFooterComponent={
									balanceDetails.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								onRefresh={this.onRefresh}
								componentType={constants.flatList}
								onRef={ref => {
									this.itemListRef = ref;
								}}
								getItemLayout={this.getLayout}
							/>
						)}
						<ToggleFeatureScreen
							navigation={this.navigation}
							onRef={ref => {
								this.toggleFeature = ref;
							}}
							isConnected={isConnected}
						/>
					</>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		balanceDetailsInfo: state.BalanceDetailsScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		isConnected: state.NoConnectionHandleReducer.isConnected,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		onGetBalanceDetails: bindActionCreators(BalanceDetailsActions, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

BalanceDetailsScreen.propTypes = {
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	isConnected: PropTypes.bool.isRequired,
	balanceDetailsInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	onGetBalanceDetails: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(BalanceDetailsScreen);
