import React, { Component } from 'react';
import { Platform } from 'react-native';
import WebView from 'react-native-webview';
import SafariView from 'react-native-safari-view';
import PropTypes from 'prop-types';
import Loader from '@Loader/Loader';
import { paymentStatus } from '@Constants/Constants';
import navigations from '@routes/navigations';

class PaymentScreen extends Component {
	componentDidMount() {
		const { route, navigation } = this.props;
		const { paymentDetail } = route.params;
		const { payment_url } = paymentDetail || {};
		if (Platform.OS === 'ios') {
			this.openSafariView(payment_url);
			SafariView.addEventListener('onDismiss', () => {
				this.onNavigate();
			});
		}
		this.willFocusListener = navigation.addListener('blur', () => {
			this.onGoBack();
		});
	}

	onGoBack = () => {
		this.onNavigate();
	};

	openSafariView = paymentUrl => {
		setTimeout(() => {
			SafariView.show({
				url: paymentUrl,
			});
		}, 100);
	};

	onNavigate = () => {
		const { route, navigation } = this.props;
		const { extraParams, type, paymentDetail } = route.params;
		navigation.navigate(navigations.PAYMENT_CONFIRMATION_NAVIGATION, {
			extraParams,
			type,
			paymentDetail,
		});
	};

	onLoad = () => {
		return <Loader />;
	};

	onNavigationStateChange = navState => {
		if (
			navState &&
			navState.url &&
			(navState.url.includes(paymentStatus.success) ||
				navState.url.includes(paymentStatus.failed) ||
				navState.url.includes('nana.business/payment'))
		) {
			this.onNavigate();
		}
	};

	render() {
		const { route } = this.props;
		const { paymentDetail } = route.params;
		const { payment_url } = paymentDetail || {};
		return Platform.OS === 'android' ? (
			<WebView
				source={{ uri: payment_url }}
				renderLoading={() => this.onLoad()}
				startInLoadingState
				onNavigationStateChange={this.onNavigationStateChange}
			/>
		) : null;
	}
}

PaymentScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default PaymentScreen;
