import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import UserListService from '@Users/UserListService';
import ApproveRejectUserRequestService from '@Users/ApproveRejectUserRequestService';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to call get user list api
 * @param {object} data
 * @param {boolean} isOverwriteExistingList
 */
export const getUserList = (data, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.USER_LIST_SUCCESS,
		ActionTypes.USER_LIST_FAILURE,
		ActionTypes.USER_LIST_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const userListService = new UserListService(dispatchedActions);
	addBasicInterceptors(userListService);
	userListService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(userListService.makeRequest(data));
};

/**
 * Action to call approve or reject user request api
 * @param {object} userDetails
 */
export const onApproveRejectUserRequest = userDetails => dispatch => {
	const dispatchedActions = new actions(
		ActionTypes.APPROVE_REJECT_USER_SUCCESS,
		ActionTypes.APPROVE_REJECT_USER_FAILURE,
		ActionTypes.APPROVE_REJECT_USER_LOADER,
	);
	const approveRejectUserRequestService = new ApproveRejectUserRequestService(dispatchedActions);
	addBasicInterceptors(approveRejectUserRequestService);
	approveRejectUserRequestService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(approveRejectUserRequestService.makeRequest(userDetails));
};

// Action to reset user list reducer
export const resetUserList = () => ({ type: ActionTypes.RESET_USER_LIST });
