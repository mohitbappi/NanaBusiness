import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		searchContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(5),
		},
		listContainer: {
			flex: 1,
			marginHorizontal: normalScale(16),
		},
		userInfoContainer: {
			borderBottomWidth: verticalScale(1),
			borderColor: colors.grey,
			justifyContent: 'center',
		},
		addContainerUserList: {
			position: 'absolute',
			bottom: 0,
			right: isRTL ? null : 0,
			left: isRTL ? 0 : null,
		},
		iconAddUserList: {
			height: normalScale(60),
			width: normalScale(60),
		},
		noDataTextUserList: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		scrollViewStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
