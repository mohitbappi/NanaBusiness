export const USER_LIST_SUCCESS = 'user_list_success';
export const USER_LIST_FAILURE = 'user_list_failure';
export const USER_LIST_LOADER = 'user_list_loader';
export const RESET_USER_LIST = 'reset_user_list';
export const APPROVE_REJECT_USER_SUCCESS = 'approve_reject_user_success';
export const APPROVE_REJECT_USER_FAILURE = 'approve_reject_user_failure';
export const APPROVE_REJECT_USER_LOADER = 'approve_reject_user_loader';
