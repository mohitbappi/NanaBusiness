import React, { Component } from 'react';
import { View, TouchableOpacity, ActivityIndicator, Text } from 'react-native';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Header from '@Header/Header';
import RectangleCard from '@RectangleCard/RectangleCard';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import IMAGES from '@Images/index';
import {
	toastShowTime,
	fetchDataWithPagination,
	customerAdmin,
	userStatus,
	languageConstants,
} from '@Constants/Constants';
import ToastComponent from '@ToastComponent/ToastComponent';
import * as colors from '@assets/colors';
import Spinner from '@Spinner/Spinner';
import ListEmpty from '@ListEmpty/ListEmpty';
import navigations from '@routes/navigations';
import * as UserDetailActions from '@UserDetailsScreen/UserDetailsScreenAction';
import Search from '@Search/Search';
import Loader from '@Loader/Loader';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import * as AddUserDetailsAction from '@AddUserDetailsScreen/AddUserDetailsScreenAction';
import { verticalScale } from '@device/normalize';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';
import * as UserListActions from './UserListAction';
import { createStyleSheet } from './UserListStyle';

class UserListScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			toastMessage: '',
			isApiError: false,
			bottomLoader: false,
			searchText: '',
		};
		this.limit = fetchDataWithPagination.limit;
		this.pageNo = fetchDataWithPagination.page;
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const {
				addUserDetailsInfo,
				addUserDetailsAction,
				pullToRefreshActions,
				refreshControlComponentInfo,
			} = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.pageNo = fetchDataWithPagination.page;
			this.limit = getScrollingIndex(scrollIndex);
			this.onLoadMore(false);
			const { isUserCreated, isUserEdited } = addUserDetailsInfo;
			if (isUserCreated || isUserEdited) {
				// Show toast message is user created or edited successfully
				addUserDetailsAction.onResetUserCreatedSuccess();
				this.setState({
					toastMessage: isUserEdited
						? localeString(keyConstants.USER_EDITED_SUCCESSFULLY) // if user edited
						: localeString(keyConstants.USER_CREATED_SUCCESSFULLY), // if user created
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
		this.willFocusListener = navigation.addListener('blur', () => {
			const { userListAction } = this.props;
			this.setState({
				toastMessage: '',
				isApiError: false,
				bottomLoader: false,
				searchText: '',
			});
			userListAction.resetUserList();
		});
	}

	componentDidUpdate(prevProps) {
		const { usersList, pullToRefreshActions, userDetailInfo, userDetailActions } = this.props;
		const { success, isGetUserList } = usersList;
		if (success && prevProps.usersList.success !== usersList.success) {
			// if user listing api return success
			if (isGetUserList) {
				this.setState(
					{
						bottomLoader: false,
					},
					() => {
						if (this.pageNo === 1 && this.itemListRef) {
							this.itemListRef.onScroll(1);
						}
					},
				);
			} else {
				this.setState(
					{
						isApiError: true,
					},
					() => {
						this.pageNo = fetchDataWithPagination.page;
						this.onLoadMore(false);
					},
				);
				setTimeout(() => {
					this.setState({
						toastMessage: '',
						isApiError: false,
					});
				}, toastShowTime);
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (
			userDetailInfo.success &&
			!userDetailInfo.isSetCustomerRole &&
			prevProps.userDetailInfo.success !== userDetailInfo.success
		) {
			// if activation mail sent successfully
			userDetailActions.onResetUserDetails();
			this.setState({
				toastMessage: `${localeString(keyConstants.MAIL_SENT_SUCCESSFULLY)}`,
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	}

	componentWillUnmount() {
		// reset user list reducer on unmounting screen
		const { userListAction } = this.props;
		userListAction.resetUserList();
		this.resetScrollIndex();
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	getUsers = isOverwriteExistingList => {
		// Call api to get user listing
		const { userListAction } = this.props;
		const queryParams = {};
		const { searchText } = this.state;
		queryParams.limit = this.limit;
		queryParams.page = this.pageNo;
		if (searchText) {
			queryParams.customer_name = searchText;
		}
		userListAction.getUserList(queryParams, isOverwriteExistingList);
	};

	getUserRole = name =>
		name === customerAdmin
			? localeString(keyConstants.CUSTOMER_ADMIN)
			: localeString(keyConstants.CUSTOMER);

	navigateTo = (userDetails, index) => {
		this.itemListRef.onSetIndex(index);
		const { navigation } = this.props;
		navigation.navigate(navigations.USER_DETAILS_NAVIGATION, { userDetails });
	};

	renderItem = ({ item, index }) => {
		// Render user list item component
		const { languageInfo, userDetails } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { role } = userDetails.user;
		return (
			<TouchableOpacity
				style={styles.userInfoContainer}
				disabled={item.status !== userStatus.approved}
				activeOpacity={0.8}
				onPress={() =>
					item.status === userStatus.approved && role === customerAdmin
						? this.navigateTo(item, index)
						: null
				}>
				<RectangleCard
					name={item.name}
					profilePic={item.profile_images && item.profile_images['x-small']}
					isUserTypeDetails
					userDetails={`${this.getUserRole(item.role)} | ${item.organization_name}`}
					status={item.is_active}
					hasIconShare={
						role === customerAdmin &&
						item.status === userStatus.approved &&
						(item.login_key === null || !item.login_key)
					}
					onPressShare={() => this.onSendActivationMail(item.id)}
					hasIconApproveReject={
						role === customerAdmin && item.status === userStatus.pending
					}
					onPressApprove={() =>
						this.onApproveRejectUserRequest(item.user_request_id, userStatus.approved)
					}
					onPressReject={() =>
						this.onApproveRejectUserRequest(item.user_request_id, userStatus.cancelled)
					}
				/>
			</TouchableOpacity>
		);
	};

	keyExtractor = (item, index) => index.toString();

	onPressClose = () => {
		this.resetScrollIndex();
		const { navigation } = this.props;
		navigation.goBack();
	};

	onSearch = text => {
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onLoadMore(false);
			},
		);
	};

	onSendActivationMail = id => {
		// Call api to send activation mail
		const { userDetailActions } = this.props;
		const queryParams = {
			id,
		};
		userDetailActions.onSendActivationMail(queryParams);
	};

	onApproveRejectUserRequest = (requestId, status) => {
		// Call api to approve or reject request
		const { languageInfo, userListAction } = this.props;
		const { isRTL } = languageInfo;
		const userDetails = {
			requestId,
			status,
			queryParams: {
				lang: isRTL ? languageConstants.ar : languageConstants.en,
			},
		};
		this.setState(
			{
				toastMessage:
					status === userStatus.approved
						? `${localeString(keyConstants.REQUEST_APPROVED)}`
						: `${localeString(keyConstants.REQUEST_REJECTED)}`,
			},
			() => {
				userListAction.onApproveRejectUserRequest(userDetails);
			},
		);
	};

	listFooterComponent = () => {
		const { languageInfo, usersList } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { data, count } = usersList;
		const endReached = count === data.length || count < data.length;
		if (!endReached) {
			return <ActivityIndicator size="large" color={colors.darkBlue} />;
		}
		return (
			<Text style={styles.noDataTextUserList}>
				{localeString(keyConstants.NO_MORE_USERS_FOUND)}
			</Text>
		);
	};

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		this.getUsers(isOverwriteExistingList);
	};

	onEndReached = () => {
		const { usersList } = this.props;
		const { loader } = usersList;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.pageNo += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onLoadMore(true);
		}
	};

	// Navigate to add new user screen
	onPressAdd = () => {
		this.resetScrollIndex();
		const { navigation } = this.props;
		navigation.navigate(navigations.ADD_USER_DETAILS_NAVIGATION);
	};

	onRefresh = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
		this.pageNo = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		this.onFetchData(false);
	};

	getLayout = (data, index) => ({
		// To Get length and offset for Scroll To Index Functionality
		length: verticalScale(60),
		offset: verticalScale(60) * index,
		index,
	});

	render() {
		const {
			languageInfo,
			userDetails,
			refreshControlComponentInfo,
			usersList,
			userDetailInfo,
		} = this.props;
		const { toastMessage, isApiError, bottomLoader, searchText } = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, data, count, error, errorCode, isGetUserList } = usersList;
		const { role } = userDetails.user;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === '' && (
					<Loader size="large" />
				)}
				{userDetailInfo.loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.USERS)}
						hasIconClose
						hasIconTeam
						onPressClose={this.onPressClose}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasSearchIcon
						placeholder={localeString(keyConstants.SEARCH_BY_CUSTOMER)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
					/>
				</View>
				{error && isGetUserList ? (
					<ErrorComponent // Error component if api fails.
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<>
						<View style={styles.listContainer}>
							<FlatListComponent
								data={data}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								onEndReached={() => data.length !== count && this.onEndReached()}
								ListFooterComponent={
									data.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								ListEmptyComponent={() => (
									<ListEmpty text={localeString(keyConstants.NO_USERS_FOUND)} />
								)}
								contentContainerStyle={
									data.length === 0 ? styles.scrollViewStyle : null
								}
								onRefresh={this.onRefresh}
								componentType={constants.flatList}
								onRef={ref => {
									this.itemListRef = ref;
								}}
								getItemLayout={this.getLayout}
							/>
						</View>
						{role === customerAdmin && (
							<TouchableOpacity
								style={styles.addContainerUserList}
								activeOpacity={0.8}
								onPress={this.onPressAdd}>
								<ImageLoadComponent
									source={IMAGES.iconAddYellow}
									style={styles.iconAddUserList}
								/>
							</TouchableOpacity>
						)}
					</>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

UserListScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	addUserDetailsInfo: PropTypes.object.isRequired,
	addUserDetailsAction: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	userListAction: PropTypes.object.isRequired,
	usersList: PropTypes.object.isRequired,
	userDetailInfo: PropTypes.object.isRequired,
	userDetailActions: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		usersList: state.UserListReducer,
		addUserDetailsInfo: state.AddUserDetailsScreenReducer,
		userDetailInfo: state.UserDetailsScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		userListAction: bindActionCreators({ ...UserListActions }, dispatch),
		addUserDetailsAction: bindActionCreators({ ...AddUserDetailsAction }, dispatch),
		userDetailActions: bindActionCreators({ ...UserDetailActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(UserListScreen);
