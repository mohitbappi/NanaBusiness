import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	data: [],
	count: 0,
	isGetUserList: false,
};

const UserListReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.USER_LIST_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				data: isOverwriteExistingList
					? [...state.data, ...action.payload.retailer_list]
					: action.payload.retailer_list,
				count: action.payload.count,
				isGetUserList: true,
			};
		}
		case ActionTypes.USER_LIST_FAILURE:
			return {
				...state,
				error: true,
				success: true,
				loader: false,
				errorCode: action.payload,
				isGetUserList: true,
			};
		case ActionTypes.APPROVE_REJECT_USER_FAILURE:
			return {
				...state,
				error: true,
				success: true,
				loader: false,
				errorCode: action.payload,
				isGetUserList: false,
			};
		case ActionTypes.USER_LIST_LOADER:
		case ActionTypes.APPROVE_REJECT_USER_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: true,
			};
		case ActionTypes.APPROVE_REJECT_USER_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				isGetUserList: false,
			};
		case ActionTypes.RESET_USER_LIST:
			return initialState;
		default:
			return state;
	}
};

export default UserListReducer;
