export const ON_CHANGE_PASSWORD_TEXT = 'on_change_password_text';
export const RESET_CHANGE_PASSWORD_STATE = 'reset_change_password_state';
export const CHANGE_PASSWORD_SUCCESS = 'change_password_success';
export const CHANGE_PASSWORD_FAILURE = 'change_password_failure';
export const CHANGE_PASSWORD_LOADER = 'change_password_loader';
