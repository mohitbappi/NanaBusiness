import React, { Component } from 'react';
import { connect } from 'react-redux';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';
import { TouchableOpacity, Text, Keyboard, ScrollView } from 'react-native';
import { bindActionCreators } from 'redux';
import IMAGES from '@Images/index';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { passwordRegexEx, spaceRegexEx, passwordMaxLength } from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import navigations from '@routes/navigations';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import SetNewPasswordComponent from '@Components/SetNewPasswordComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import { changePasswordConstants } from './Constants';
import * as ChangePasswordActions from './ChangePasswordScreenAction';
import { createStyleSheet } from './ChangePasswordScreenStyle';

class ChangePasswordScreen extends Component {
	constructor(props) {
		super(props);
		this.newPassword = React.createRef(null);
		this.confirmPassword = React.createRef(null);
		this.state = {
			errorPasswordValidationMessage: false,
			errorConfirmPasswordValidationMessage: false,
			isShowPasswordInformation: false,
			errorOldPasswordValidationMessage: false,
		};
	}

	componentDidUpdate(prevProps) {
		const { changePasswordInfo, navigation } = this.props;
		const { newPassword, error, confirmNewPassword, success, errorCode } = changePasswordInfo;
		if (error && prevProps.changePasswordInfo.error !== error) {
			// Will check for errors.
			if (keyConstants.OLD_PASSWORD_WRONG === errorCode.error) {
				// If entered old password is incorrect.
				this.setState({
					errorOldPasswordValidationMessage: true,
				});
			} else {
				// If any other error occurs.
				ErrorAlertComponent(errorCode, this.onSavePassword);
			}
		}
		if (prevProps.changePasswordInfo !== changePasswordInfo) {
			// Will check for validations.
			if (passwordRegexEx.test(String(newPassword).toLowerCase())) {
				this.setState({
					errorPasswordValidationMessage: false,
				});
			}
			if (newPassword === confirmNewPassword) {
				this.setState({
					errorConfirmPasswordValidationMessage: false,
				});
			}
			if (success) {
				this.setState({
					errorOldPasswordValidationMessage: false,
				});
				navigation.navigate(navigations.VIEW_PROFILE_NAVIGATION);
			}
		}
	}

	componentWillUnmount() {
		// Will reset the values if user go back.
		this.onChangeText('', changePasswordConstants.oldPassword);
		this.onChangeText('', changePasswordConstants.newPassword);
		this.onChangeText('', changePasswordConstants.confirmNewPassword);
	}

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeText = (text, field) => {
		// Will save the input fields value.
		const { changePasswordActions } = this.props;
		changePasswordActions.onChangeText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = () => {
		const { changePasswordInfo } = this.props;
		const { newPassword } = changePasswordInfo;
		if (!passwordRegexEx.test(newPassword)) {
			this.setState({
				errorPasswordValidationMessage: true,
			});
		}
	};

	showPasswordInformation = value => {
		// Function to show password instructions.
		this.setState({
			isShowPasswordInformation: value,
		});
	};

	onMatchPassword = () => {
		const { changePasswordInfo } = this.props;
		const { newPassword, confirmNewPassword } = changePasswordInfo;
		if (confirmNewPassword !== newPassword) {
			this.setState({
				errorConfirmPasswordValidationMessage: true,
			});
		}
	};

	onSavePassword = () => {
		// API call to change the password.
		const { changePasswordInfo, changePasswordActions } = this.props;
		const { oldPassword, newPassword } = changePasswordInfo;
		this.onDissmissKeyboard();
		const passwordDetails = {
			old_password: oldPassword,
			new_password: newPassword,
		};
		changePasswordActions.onChangePassword(passwordDetails);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	render() {
		const {
			errorConfirmPasswordValidationMessage,
			errorPasswordValidationMessage,
			errorOldPasswordValidationMessage,
			isShowPasswordInformation,
		} = this.state;
		const { languageInfo, changePasswordInfo } = this.props;
		const { isRTL } = languageInfo;
		const { newPassword, confirmNewPassword, loader, oldPassword } = changePasswordInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<KeyboardAwareScrollView
				contentContainerStyle={styles.container}
				keyboardShouldPersistTaps="handled">
				{loader && <Spinner size="large" />}
				<TouchableOpacity
					activeOpacity={0.8}
					hitSlop={styles.hitSlop}
					style={styles.backButton}
					onPress={this.onGoBack}>
					<ImageLoadComponent source={IMAGES.iconCross} style={styles.image} />
				</TouchableOpacity>
				<ScrollView
					contentContainerStyle={styles.scrollView}
					showsVerticalScrollIndicator={false}
					keyboardShouldPersistTaps="handled">
					<Text style={styles.chooseText}>
						{localeString(keyConstants.CHANGE_PASSWORD)}
					</Text>
					<Text style={styles.defaultText}>
						{localeString(keyConstants.SET_A_NEW_PASSWORD)}
					</Text>
					<Input
						maxLength={passwordMaxLength}
						value={oldPassword}
						width={normalScale(260)}
						label={`${localeString(keyConstants.OLD_PASSWORD)}*`}
						placeholder={localeString(keyConstants.OLD_PASSWORD)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text =>
							(spaceRegexEx.test(String(text).toLocaleLowerCase()) || text === '') &&
							this.onChangeText(text, 'oldPassword')
						}
						onSubmitEditing={() => this.onSubmitRef(this.newPassword)}
						autoCapitalize="none"
						isError={errorOldPasswordValidationMessage}
						errorMessage={localeString(keyConstants.OLD_PASSWORD_WRONG)}
						hasIconPassword
					/>
					<SetNewPasswordComponent
						isRTL={isRTL}
						isShowPasswordInformation={isShowPasswordInformation}
						newPassword={newPassword}
						errorPasswordValidationMessage={errorPasswordValidationMessage}
						confirmNewPassword={confirmNewPassword}
						errorConfirmPasswordValidationMessage={
							errorConfirmPasswordValidationMessage
						}
						onChangeText={this.onChangeText}
						showPasswordInformation={this.showPasswordInformation}
						onBlur={this.onBlur}
						onMatchPassword={this.onMatchPassword}
						onSubmitRef={this.onSubmitRef}
						refCallback={this.refCallback}
						newPasswordRef={this.newPassword}
						confirmPasswordRef={this.confirmPassword}
					/>
				</ScrollView>
				<ButtonComponent
					viewStyle={styles.viewStyle}
					onPress={this.onSavePassword}
					text={localeString(keyConstants.SAVE_PASSWORD)}
					isButtonDisable={
						!(
							oldPassword &&
							passwordRegexEx.test(String(newPassword).toLowerCase()) &&
							newPassword === confirmNewPassword
						)
					}
				/>
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		changePasswordInfo: state.ChangePasswordScreenReducer,
		languageInfo: state.LanguageScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		changePasswordActions: bindActionCreators({ ...ChangePasswordActions }, dispatch),
	};
};

ChangePasswordScreen.propTypes = {
	changePasswordActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	changePasswordInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ChangePasswordScreen);
