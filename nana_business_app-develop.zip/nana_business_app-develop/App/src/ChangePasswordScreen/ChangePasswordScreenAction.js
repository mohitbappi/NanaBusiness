import { actions } from '@libapi/APIActionsBuilder';
import ChangePasswordService from '@ChangePassword/ChangePasswordService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to save the input field value at the given field.
 * @param {string} text
 * @param {string} field
 * @returns
 */

export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_PASSWORD_TEXT,
		payload: text,
		field,
	};
};

export const onResetChangePasswordState = () => ({ type: ActionTypes.RESET_CHANGE_PASSWORD_STATE });

/**
 * Action to change the password.
 * @param {object} passwordDetails
 * @returns
 */

export const onChangePassword = passwordDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.CHANGE_PASSWORD_SUCCESS,
		ActionTypes.CHANGE_PASSWORD_FAILURE,
		ActionTypes.CHANGE_PASSWORD_LOADER,
	);
	const changePasswordService = new ChangePasswordService(dispatchedActions);
	addBasicInterceptors(changePasswordService);
	changePasswordService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(changePasswordService.makeRequest(passwordDetails));
};
