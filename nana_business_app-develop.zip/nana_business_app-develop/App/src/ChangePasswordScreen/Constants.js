export const changePasswordConstants = {
	oldPassword: 'oldPassword',
	newPassword: 'newPassword',
	confirmNewPassword: 'confirmNewPassword',
};

export default changePasswordConstants;
