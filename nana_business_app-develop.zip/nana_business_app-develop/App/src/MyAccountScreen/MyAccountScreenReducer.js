import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	isCollector: false,
};

const MyAccountScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.CHECK_COLLECTOR_ACCESS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCollector: action.payload.can_collect,
			};
		case ActionTypes.CHECK_COLLECTOR_ACCESS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.CHECK_COLLECTOR_ACCESS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_ACCOUNT_STATE:
			return initialState;
		default:
			return state;
	}
};

export default MyAccountScreenReducer;
