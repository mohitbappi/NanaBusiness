export const CHECK_COLLECTOR_ACCESS_SUCCESS = 'check_collector_access_success';
export const CHECK_COLLECTOR_ACCESS_FAILURE = 'check_collector_access_failure';
export const CHECK_COLLECTOR_ACCESS_LOADER = 'check_collector_access_loader';
export const RESET_ACCOUNT_STATE = 'reset_account_state';
