import React, { Component } from 'react';
import { View, Text, Alert, TouchableOpacity, ImageBackground } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import IMAGES from '@Images/index';
import { localeString } from '@Localization/index';
import { keyConstants } from '@Constants/KeyConstants';
import LanguageScreen from '@LanguageScreen/LanguageScreen';
import * as RoleScreenActions from '@RoleScreen/RoleScreenAction';
import navigations from '@routes/navigations';
import vendorNavigations from '@routes/vendorNavigations';
import collectorNavigations from '@routes/collectorNavigations';
import cashierNavigations from '@routes/cashierNavigations';
import * as colors from '@assets/colors';
import LogoutHandler from '@Logout/LogoutHandler';
import {
	retailer,
	vendor,
	stretch,
	IMAGE_TYPE,
	collector,
	customerAdmin,
	driver,
	isToggleFeatureEnable,
	accountManager,
	cashier,
	salesExecutive,
} from '@Constants/Constants';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import BalanceDetailsActions from '@BalanceDetailsScreen/BalanceDetailsScreenAction';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal, convertAmount } from '@Util/GetValueInDecimal';
import Loader from '@Loader/Loader';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { businessTypeConstants } from '@SignUpNextScreen/SignUpConstants';
import { getStarUI } from '@Util/GetSatrUI';
import driverNavigations from '@routes/driverNavigations';
import { saveUserRole, editUserRole } from '@Util/SaveMasterData';
import * as SignInActions from '@SignInScreen/SignInScreenAction';
import CreditLineComponent from '@Components/CreditLineComponent';
import * as ViewProfileActions from '@ViewProfileScreen/ViewProfileScreenAction';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ToggleFeatureScreen from '@ToggleFeatureScreen/ToggleFeatureScreen';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { createStyleSheet } from './MyAccountScreenStyle';
import accountConstants from './AccountConstants';
import * as MyAccountActions from './MyAccountScreenAction';

class MyAccountScreen extends Component {
	async componentDidMount() {
		const { navigation, roleScreenActions, pullToRefreshActions, userDetails } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { role } = userDetails.user;
			if (role === driver || !isToggleFeatureEnable) {
				// Won't call toggle feature API if isToggleFeatureEnable return false
				this.onCallAPI();
			}
			roleScreenActions.onSetModalVisibility(false);
			this.onStoreUserDetails();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			toggleFeaturesInfo,
			myAccountInfo,
			pullToRefreshActions,
			viewProfileInfo,
		} = this.props;
		const { success: toggleApiSuccess } = toggleFeaturesInfo;
		const { success: myAccountSuccess, error, errorCode } = myAccountInfo;
		if (
			(viewProfileInfo.success &&
				viewProfileInfo.success !== prevProps.viewProfileInfo.success) ||
			(myAccountSuccess && myAccountInfo.success !== prevProps.myAccountInfo.success)
		) {
			// Will hide the pull to refresh loader.
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (
			toggleApiSuccess &&
			prevProps.toggleFeaturesInfo.success !== toggleFeaturesInfo.success
		) {
			// Will call API if toggle feature API succeed.
			this.onCallAPI();
		}
		if (error && prevProps.myAccountInfo.error !== myAccountInfo.error) {
			// Will show the alert if api fails.
			ErrorAlertComponent(errorCode, this.checkCollectorPermission);
		}
	}

	componentWillUnmount() {
		// Will reset the reducer.
		const { myAccountActions } = this.props;
		myAccountActions.onResetAccountState();
	}

	onCallAPI = () => {
		const { pullToRefreshActions, userDetails } = this.props;
		const { roles, role } = userDetails.user;
		if (role === retailer || role === customerAdmin) {
			this.onLoadMore(false);
			this.getCreditLineBalance();
		}
		if (roles && roles.includes(collector) && roles.includes(driver)) {
			this.checkCollectorPermission();
		} else {
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	};

	onStoreUserDetails = async () => {
		// Will store user details in async storage.
		const { homeScreenActions } = this.props;
		const userDetail = await AsyncStorage.getItem(accountConstants.userDetails);
		homeScreenActions.onStoreUserDetails(JSON.parse(userDetail));
	};

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		// API call the get the wallet balance.
		const { onGetBalanceDetails } = this.props;
		const queryParams = {};
		onGetBalanceDetails(queryParams, isOverwriteExistingList);
	};

	getCreditLineBalance = () => {
		// API call to get the credit line balance.
		const { viewProfileActions } = this.props;
		viewProfileActions.onGetProfile();
	};

	checkCollectorPermission = () => {
		// API call to check that the driver has collector permission or not.
		const { myAccountActions } = this.props;
		myAccountActions.onCheckPermission();
	};

	onRequestClose = () => {
		const { roleScreenActions } = this.props;
		roleScreenActions.onSetModalVisibility(false);
	};

	onViewProfile = () => {
		// Will navigate to the view profile screen.
		const { navigation, userDetails } = this.props;
		const { role } = userDetails.user;
		navigation.navigate(navigations.VIEW_PROFILE_NAVIGATION, { role });
	};

	openBalanceDetails = () => {
		// Will navigate balance details screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.BALANCE_DETAILS_NAVIGATION);
	};

	goToCreditLine = () => {
		// Will navigate credit line report screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.CREDIT_LINE_NAVIGATION);
	};

	onPressOption = (role, index) => {
		// Navigation routes based on the roles.
		const { navigation, roleScreenActions } = this.props;
		if (
			role === retailer ||
			role === customerAdmin ||
			role === accountManager ||
			role === salesExecutive
		) {
			switch (index) {
				case 0:
					return navigation.navigate(navigations.BRANCHES_NAVIGATION);
				case 1:
					return navigation.navigate(navigations.USER_LIST_NAVIGATION);
				case 2:
					return navigation.navigate(navigations.ITEM_LIST_NAVIGATION, {
						title: keyConstants.WISHLIST,
					});
				case 3:
					return roleScreenActions.onSetModalVisibility(true);
				case 4:
					return navigation.navigate(navigations.CONTACT_US);
				default:
					return null;
			}
		} else if (role === vendor) {
			switch (index) {
				case 0:
					return roleScreenActions.onSetModalVisibility(true);
				case 1:
					return navigation.navigate(vendorNavigations.TERMS_AND_CONDITION_NAVIGATION);
				case 3:
					return navigation.navigate(vendorNavigations.CONTACT_US);
				default:
					return null;
			}
		} else if (role === collector) {
			switch (index) {
				case 0:
					return roleScreenActions.onSetModalVisibility(true);
				case 1:
					return navigation.navigate(collectorNavigations.TERMS_AND_CONDITION_NAVIGATION);
				case 2:
					return navigation.navigate(collectorNavigations.CONTACT_US);
				default:
					return null;
			}
		} else if (role === cashier) {
			switch (index) {
				case 0:
					return roleScreenActions.onSetModalVisibility(true);
				case 1:
					return navigation.navigate(cashierNavigations.TERMS_AND_CONDITION_NAVIGATION);
				case 2:
					return navigation.navigate(cashierNavigations.CONTACT_US);
				default:
					return null;
			}
		} else {
			// If role is driver.
			switch (index) {
				case 0:
					return navigation.navigate(collectorNavigations.COLLECTION_NAVIGATION, {
						isDriverRole: true,
						backActionShipment: false,
					});
				case 1:
					return navigation.navigate(collectorNavigations.CUSTOMER_NAVIGATION, {
						isDriverRole: true,
					});
				case 2:
					return roleScreenActions.onSetModalVisibility(true);
				case 3:
					return navigation.navigate(driverNavigations.TERMS_AND_CONDITION_NAVIGATION);
				case 4:
					return navigation.navigate(driverNavigations.CONTACT_US);
				default:
					return null;
			}
		}
	};

	onLogout = () => {
		// Alert to confirm the logout.
		const { logout } = this.props;
		Alert.alert(
			'',
			localeString(keyConstants.ARE_YOU_SURE_LOGOUT),
			[
				{
					text: localeString(keyConstants.NO),
				},
				{
					text: localeString(keyConstants.YES),
					onPress: () => {
						// User will logout.
						logout();
					},
				},
			],
			{ cancelable: false },
		);
	};

	goToReports = organizationId => {
		// Will navigate to credit line report screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.CREDIT_LINE_REPORT_NAVIGATION, {
			organizationId,
		});
	};

	getMenu = (role, defaultUserId) => {
		// Will return the attributes based on user role.
		const { languageInfo, myAccountInfo } = this.props;
		const { isCollector } = myAccountInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (
			role === retailer ||
			role === customerAdmin ||
			role === accountManager ||
			role === salesExecutive
		) {
			return accountConstants.customerMenuArray.map((item, index) => {
				if (
					(role === accountManager || role === salesExecutive) &&
					(defaultUserId === undefined || defaultUserId === null) &&
					index <= 2
				) {
					// If the user is not selected then hide the branches, users & wishlist section.
					return null;
				}
				return (
					<TouchableOpacity
						onPress={() => this.onPressOption(role, index)}
						activeOpacity={0.8}
						style={styles.menuView}>
						<ImageLoadComponent source={item.image} style={styles.image} />
						<Text style={styles.label}>{localeString(item.label)}</Text>
					</TouchableOpacity>
				);
			});
		}
		if (role === vendor) {
			return accountConstants.vendorMenuArray.map((item, index) => {
				return (
					<TouchableOpacity
						onPress={() => this.onPressOption(role, index)}
						activeOpacity={0.8}
						style={styles.menuView}>
						<ImageLoadComponent source={item.image} style={styles.image} />
						<Text style={styles.label}>{localeString(item.label)}</Text>
					</TouchableOpacity>
				);
			});
		}
		if (role === driver) {
			return accountConstants.driverMenuArray.map((item, index) => {
				if (!isCollector && index <= 1) {
					// If driver is not a collector then first two hyperlinks will not appear.
					return null;
				}
				return (
					<TouchableOpacity
						onPress={() => this.onPressOption(role, index)}
						activeOpacity={0.8}
						style={styles.menuView}>
						<ImageLoadComponent source={item.image} style={styles.image} />
						<Text style={styles.label}>{localeString(item.label)}</Text>
					</TouchableOpacity>
				);
			});
		}
		return accountConstants.collectorMenuArray.map((item, index) => {
			return (
				<TouchableOpacity
					onPress={() => this.onPressOption(role, index)}
					activeOpacity={0.8}
					style={styles.menuView}>
					<ImageLoadComponent source={item.image} style={styles.image} />
					<Text style={styles.label}>{localeString(item.label)}</Text>
				</TouchableOpacity>
			);
		});
	};

	getUserType = role => {
		const { viewProfileInfo, userDetails } = this.props;
		if (role === retailer || role === customerAdmin) {
			const businessTypeKey =
				(viewProfileInfo.userDetails &&
					viewProfileInfo.userDetails.organization &&
					viewProfileInfo.userDetails.organization.business_type) ||
				(userDetails &&
					userDetails.user &&
					userDetails.user.organization &&
					userDetails.user.organization.business_type);
			let businessType =
				role === customerAdmin
					? localeString(keyConstants.CUSTOMER_ADMIN)
					: localeString(keyConstants.CUSTOMER);
			businessTypeConstants.forEach(item => {
				if (item.key === businessTypeKey) {
					businessType = localeString(item.name);
				}
			});
			return businessType;
		}
		if (role === vendor) {
			return localeString(keyConstants.VENDOR);
		}
		if (role === collector) {
			return localeString(keyConstants.COLLECTOR);
		}
		if (role === accountManager) {
			return localeString(keyConstants.ACCOUNT_MANAGER);
		}
		if (role === cashier) {
			return localeString(keyConstants.CASHIER);
		}
		if (role === salesExecutive) {
			return localeString(keyConstants.SALES_EXECUTIVE);
		}
		return localeString(keyConstants.DRIVER);
	};

	onChangeRole = async () => {
		const { signInActions } = this.props;
		const role = await AsyncStorage.getItem('user_role');
		const token = await AsyncStorage.getItem('user');
		if (role === driver) {
			saveUserRole(collector);
			editUserRole(collector).then(() => {
				signInActions.onSetToken(token, collector);
			});
		} else {
			saveUserRole(driver);
			editUserRole(driver).then(() => {
				signInActions.onSetToken(token, driver);
			});
		}
	};

	getCreditLineAmount = (totalAmount, remainingAmount) => {
		return `${convertAmount(totalAmount - remainingAmount)}/${convertAmount(totalAmount)}K`;
	};

	onRefresh = () => {
		if (isToggleFeatureEnable) {
			// Will call toggle feature API.
			this.toggleFeature.getToggleFeatures();
		} else {
			this.onCallAPI(); // Will call MyAccount API.
		}
	};

	render() {
		const {
			languageInfo,
			roleInfo,
			viewProfileInfo,
			balanceDetailsInfo,
			myAccountInfo,
			refreshControlComponentInfo,
			toggleFeaturesInfo,
			navigation,
			userDetails,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { isModalVisible } = roleInfo;
		const { role, default_user_id } = userDetails.user || {};
		const profilePicture =
			(viewProfileInfo.userDetails &&
				viewProfileInfo.userDetails.profile_images &&
				viewProfileInfo.userDetails.profile_images.medium) ||
			(userDetails.user.profile_images && userDetails.user.profile_images.medium);
		const name =
			(viewProfileInfo.userDetails && viewProfileInfo.userDetails.name) ||
			userDetails.user.name;
		const { loader, amountDataPoints, error, errorCode } = balanceDetailsInfo;
		const accountLoader = myAccountInfo.loader;
		const {
			loader: profileLoader,
			error: profileError,
			errorCode: profileErrorCode,
		} = viewProfileInfo;
		const { total, remaining_amounts, id, score } =
			(viewProfileInfo &&
				viewProfileInfo.userDetails &&
				viewProfileInfo.userDetails.organization) ||
			{};
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { loader: toggleApiLoader } = toggleFeaturesInfo;
		const { isConnected } = this.props;
		if (isModalVisible) {
			return (
				<LanguageScreen
					isModalVisible={isModalVisible}
					onRequestClose={this.onRequestClose}
				/>
			);
		}
		if (role === driver && !isFetchingForPullToRefresh && (accountLoader || toggleApiLoader)) {
			return <Loader size="large" />;
		}
		return (
			<View style={styles.container}>
				<ScrollViewComponent
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					onRefresh={this.onRefresh}
					componentType={constants.scrollView}
					isPullToRefreshDisabled={role === collector || role === vendor}>
					<TouchableOpacity
						activeOpacity={0.8}
						style={styles.logoutView}
						onPress={this.onLogout}>
						<ImageLoadComponent source={IMAGES.iconLogout} style={styles.iconLogout} />
					</TouchableOpacity>
					<View style={styles.imageView}>
						<View style={styles.innerImageView}>
							<ImageLoadComponent
								resizeMode={stretch}
								imageType={IMAGE_TYPE.account}
								isUrl={profilePicture}
								source={profilePicture || IMAGES.iconProfileDefault}
								style={styles.defaultImage}
							/>
						</View>
						<View style={styles.innerView}>
							<View style={styles.detailView}>
								<Text style={styles.name}>{name}</Text>
								<Text style={styles.role}>{this.getUserType(role)}</Text>
								<TouchableOpacity activeOpacity={0.8} onPress={this.onViewProfile}>
									<Text style={styles.viewProfile}>
										{localeString(keyConstants.VIEW_PROFILE)}
									</Text>
								</TouchableOpacity>
							</View>
							{(role === retailer || role === customerAdmin) && (
								<View>
									<View style={styles.starView}>{getStarUI(score || 0)}</View>
								</View>
							)}
						</View>
					</View>
					{(role === retailer || role === customerAdmin) && (
						<>
							{error ? (
								<ErrorComponent
									isRTL={isRTL}
									errorCode={errorCode}
									onCallApi={() => this.onLoadMore(false)}
									isSectionComponent
								/>
							) : (
								<TouchableOpacity
									style={styles.walletView}
									activeOpacity={0.8}
									onPress={this.openBalanceDetails}>
									{loader || toggleApiLoader ? (
										<Loader
											isSmallLoader
											activityIndicatorStyle={styles.activityIndicatorStyle}
											color={colors.darkOrange}
										/>
									) : (
										<View style={styles.amountView}>
											<ImageBackground
												source={IMAGES.iconYellowBackground}
												style={styles.background}>
												<View style={styles.shadow}>
													<ImageLoadComponent
														source={IMAGES.iconWallet}
														style={styles.iconWallet}
													/>
												</View>
											</ImageBackground>
											<View>
												<View style={styles.sarStyle}>
													{/* Will show total balance of the wallet. */}
													<Text style={styles.amount}>
														{currencyFormatter(
															getValueInDecimal(
																amountDataPoints &&
																	amountDataPoints.total_advance -
																		(amountDataPoints.total_unbilled +
																			amountDataPoints.total_used),
															),
														)}
													</Text>
													<Text style={[styles.amount, styles.amountSAR]}>
														{localeString(keyConstants.SAR)}
													</Text>
												</View>
												<Text style={styles.currentBalance}>
													{' '}
													{localeString(keyConstants.CURRENT_BALANCE)}
												</Text>
											</View>
										</View>
									)}
								</TouchableOpacity>
							)}
							{profileError ? (
								<ErrorComponent
									isRTL={isRTL}
									errorCode={profileErrorCode}
									onCallApi={this.getCreditLineBalance}
									isSectionComponent
								/>
							) : (
								<CreditLineComponent
									title={localeString(keyConstants.CREDIT_LINE)}
									amount={this.getCreditLineAmount(total, remaining_amounts)}
									isRTL={isRTL}
									onPress={() => this.goToReports(id)}
									titleStyle={styles.titleStyle}
									loader={profileLoader || toggleApiLoader}
								/>
							)}
						</>
					)}
					{this.getMenu(role, default_user_id)}
				</ScrollViewComponent>
				<ToggleFeatureScreen
					navigation={navigation}
					onRef={ref => {
						this.toggleFeature = ref;
					}}
					isDefaultApiCalling={role !== driver && isToggleFeatureEnable} // Boolean to call the toggle feature API.
					isConnected={isConnected}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		roleInfo: state.RoleScreenReducer,
		languageInfo: state.LanguageScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		viewProfileInfo: state.ViewProfileScreenReducer,
		balanceDetailsInfo: state.BalanceDetailsScreenReducer,
		myAccountInfo: state.MyAccountScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		isConnected: state.NoConnectionHandleReducer.isConnected,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		roleScreenActions: bindActionCreators({ ...RoleScreenActions }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		onGetBalanceDetails: bindActionCreators(BalanceDetailsActions, dispatch),
		myAccountActions: bindActionCreators({ ...MyAccountActions }, dispatch),
		signInActions: bindActionCreators({ ...SignInActions }, dispatch),
		viewProfileActions: bindActionCreators({ ...ViewProfileActions }, dispatch),
		logout: () => {
			new LogoutHandler().logout(dispatch);
		},
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

MyAccountScreen.propTypes = {
	roleInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	viewProfileInfo: PropTypes.object.isRequired,
	balanceDetailsInfo: PropTypes.object.isRequired,
	myAccountInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	roleScreenActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	myAccountActions: PropTypes.object.isRequired,
	signInActions: PropTypes.object.isRequired,
	viewProfileActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	onGetBalanceDetails: PropTypes.func.isRequired,
	logout: PropTypes.func.isRequired,
	isConnected: PropTypes.bool.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(MyAccountScreen);
