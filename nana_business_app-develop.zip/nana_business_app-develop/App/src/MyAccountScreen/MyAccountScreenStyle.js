import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		star: {
			width: normalScale(9),
			height: verticalScale(9),
			resizeMode: 'contain',
			marginRight: normalScale(1),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(16),
		},
		scrollView: {
			marginBottom: verticalScale(8),
		},
		logoutView: {
			marginTop: verticalScale(16),
			alignSelf: isRTL ? 'flex-start' : 'flex-end',
		},
		iconLogout: {
			width: normalScale(24),
			height: verticalScale(24),
			transform: isRTL ? [{ rotate: '180deg' }] : [{ rotate: '360deg' }],
		},
		imageView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			marginTop: verticalScale(16),
			marginBottom: verticalScale(18),
		},
		innerImageView: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
			justifyContent: 'center',
		},
		innerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			flex: 1,
		},
		defaultImage: {
			width: normalScale(80),
			height: normalScale(80),
			borderRadius: moderateScale(6),
		},
		detailView: {
			marginRight: isRTL ? normalScale(8) : 0,
			marginLeft: isRTL ? 0 : normalScale(8),
			width: normalScale(150),
		},
		name: {
			fontSize: normalize(16),
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		role: {
			fontSize: normalize(14),
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			marginTop: verticalScale(8),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		viewProfile: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
			marginTop: verticalScale(8),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		progressTextStyle: {
			color: colors.blackGrey,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		starView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(6),
		},
		walletView: {
			backgroundColor: colors.orange,
			height: normalScale(80),
			borderRadius: normalScale(8),
			flexDirection: isRTL ? 'row-reverse' : 'row',
			alignItems: 'center',
			paddingHorizontal: normalScale(16),
			justifyContent: 'space-between',
			marginBottom: verticalScale(8),
		},
		activityIndicatorStyle: {
			flex: 1,
		},
		amountView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		background: {
			height: normalScale(48),
			width: normalScale(48),
			resizeMode: 'contain',
			justifyContent: 'center',
			alignItems: 'center',
		},
		shadow: {
			shadowColor: colors.pureBlack,
			shadowOffset: {
				width: normalScale(12),
				height: verticalScale(11),
			},
			shadowRadius: moderateScale(21),
			shadowOpacity: 0.3,
			elevation: verticalScale(11),
			height: normalScale(28),
			width: normalScale(20),
			justifyContent: 'center',
		},
		iconWallet: {
			height: verticalScale(28),
			width: normalScale(20),
		},
		sarStyle: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		amount: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(16),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		amountSAR: {
			marginLeft: isRTL ? 0 : normalScale(2),
			marginRight: isRTL ? normalScale(2) : 0,
		},
		currentBalance: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
			marginTop: verticalScale(2),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		iconAdd: {
			height: verticalScale(24),
			width: normalScale(24),
		},
		menuView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			height: verticalScale(40),
			paddingHorizontal: normalScale(4),
			alignItems: 'center',
			marginTop: verticalScale(12),
		},
		image: {
			height: verticalScale(30),
			width: normalScale(30),
		},
		label: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		titleStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
	});
};

export default createStyleSheet;
