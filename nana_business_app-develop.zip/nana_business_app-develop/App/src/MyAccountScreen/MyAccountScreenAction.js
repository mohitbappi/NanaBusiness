import { actions } from '@libapi/APIActionsBuilder';
import CheckCollectorService from '@Account/CheckCollectorService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

export const onCheckPermission = () => dispatch => {
	// Action to check that the driver has collector permission or not.
	const dispatchedActions = actions(
		ActionTypes.CHECK_COLLECTOR_ACCESS_SUCCESS,
		ActionTypes.CHECK_COLLECTOR_ACCESS_FAILURE,
		ActionTypes.CHECK_COLLECTOR_ACCESS_LOADER,
	);
	const checkCollectorService = new CheckCollectorService(dispatchedActions);
	addBasicInterceptors(checkCollectorService);
	checkCollectorService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(checkCollectorService.makeRequest());
};

// Action to reset the reducer.
export const onResetAccountState = () => ({ type: ActionTypes.RESET_ACCOUNT_STATE });
