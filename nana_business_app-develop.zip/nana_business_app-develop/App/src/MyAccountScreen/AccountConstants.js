import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';

const accountConstants = {
	customerMenuArray: [
		{
			image: IMAGES.iconLocation,
			label: keyConstants.BRANCHES,
		},
		{
			image: IMAGES.iconUsers,
			label: keyConstants.USERS,
		},
		{
			image: IMAGES.iconGreenHeart,
			label: keyConstants.WISHLIST,
		},
		{
			image: IMAGES.iconLanguage,
			label: keyConstants.CHANGE_LANGUAGE,
		},
		{
			image: IMAGES.iconContactUs,
			label: keyConstants.CONTACT_US,
		},
	],
	vendorMenuArray: [
		{
			image: IMAGES.iconLanguage,
			label: keyConstants.CHANGE_LANGUAGE,
		},
		{
			image: IMAGES.iconTAndC,
			label: keyConstants.TERMS_AND_CONDITIONS,
		},
		{
			image: IMAGES.iconAbout,
			label: keyConstants.ABOUT_NANA_DIRECT,
		},
		{
			image: IMAGES.iconContactUs,
			label: keyConstants.CONTACT_US,
		},
	],
	driverMenuArray: [
		{
			image: IMAGES.iconGreenMyCollection,
			label: keyConstants.MY_COLLECTION,
		},
		{
			image: IMAGES.iconGreenCustomer,
			label: keyConstants.CUSTOMER,
		},
		{
			image: IMAGES.iconLanguage,
			label: keyConstants.CHANGE_LANGUAGE,
		},
		{
			image: IMAGES.iconTAndC,
			label: keyConstants.TERMS_AND_CONDITIONS,
		},
		{
			image: IMAGES.iconContactUs,
			label: keyConstants.CONTACT_US,
		},
	],
	collectorMenuArray: [
		{
			image: IMAGES.iconLanguage,
			label: keyConstants.CHANGE_LANGUAGE,
		},
		{
			image: IMAGES.iconTAndC,
			label: keyConstants.TERMS_AND_CONDITIONS,
		},
		{
			image: IMAGES.iconContactUs,
			label: keyConstants.CONTACT_US,
		},
	],
	userDetails: 'user_details',
};

export default accountConstants;
