// import libraries
import React, { Component } from 'react';
import { View, ScrollView, Keyboard } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';

// import utils
import IMAGES from '@Images/index';
import { localeString } from '@assets/Localization';
import { normalScale } from '@device/normalize';
import { uploadFile } from '@Util/UploadFile';
import { getImageUrl } from '@Util/GetImageUrl';
import { imagePicker } from '@Util/DocumentPicker';

// import styles
import { createStyleSheet } from '@AddUserDetailsScreen/AddUserDetailsScreenStyle';

// import components
import Input from '@Input/Input';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import OverlayComponent from '@OverlayComponent/OverlayComponent';
import EditImageComponent from '@Components/EditImageComponent';
import SaveCancelButtonComponent from '@Components/SaveCancelButtonComponent';
import ItemSelectionComponent from '@OverlayComponent/ItemSelectionComponent';
import Header from '@Header/Header';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';

// import constants
import {
	mobileNumberLength,
	numericRegexExp,
	toastShowTime,
	nameMaxLength,
	asterik,
	customMobileRegex,
	retailer,
	customerAdmin,
	vatCertificateNumberLength,
	vatCertificateNumberRegex,
	driver,
	nanaDirect,
	collector,
	accountManager,
	cashier,
	salesExecutive,
} from '@Constants/Constants';
import { keyConstants } from '@Constants/KeyConstants';
import { businessTypeConstants } from '@SignUpNextScreen/SignUpConstants';
import { constants } from './Constant';

// import actions
import * as EditProfileActions from './EditProfileScreenAction';

class EditProfileScreen extends Component {
	constructor(props) {
		super(props);
		this.companyName = React.createRef(null);
		this.companyNameAr = React.createRef(null);
		this.alternateMobileNumber = React.createRef(null);
		this.vatCertificateNumber = React.createRef(null);
		this.state = {
			errorValidationMessage: false,
			isApiError: false,
			toastMessage: '',
			imageLoader: false,
			errorMobileValidationMessage: false,
			errorVatCertificateNumberMessage: false,
			mobileErrorMessage: '',
			businessTypeSelectedIndex: null,
			isVisible: false,
			isDropdownVisible: false,
		};
	}

	componentDidMount() {
		const { route, editProfileActions } = this.props;
		const { name, organization, mobile, profile_images } = route.params.userDetails;
		// Will save all the saved information and autopopulate it.
		editProfileActions.onEditText(name, constants.name);
		editProfileActions.onEditText(
			organization ? organization.name : nanaDirect,
			constants.companyName,
		);
		editProfileActions.onEditText(
			organization ? organization.name_ar : nanaDirect,
			constants.companyNameAr,
		);
		editProfileActions.onEditText(mobile, constants.mobileNumber);
		editProfileActions.onEditText(
			organization && organization.phone_secondary,
			constants.alternateMobileNumber,
		);
		editProfileActions.onEditText(
			organization && organization.vat_certificate_number,
			constants.vatCertificateNumber,
		);
		editProfileActions.onEditText(
			organization && organization.business_type,
			constants.businessType,
		);
		if (organization && organization.business_type) {
			this.updateBusinessTypeDropDown(organization.business_type);
			editProfileActions.onUploadProfilePic(profile_images && profile_images.medium);
		}
	}

	componentDidUpdate(prevProps) {
		const { editProfileInfo } = this.props;
		const {
			mobileNumber,
			success,
			error,
			errorCode,
			alternateMobileNumber,
			vatCertificateNumber,
		} = editProfileInfo;
		const errorArray = [
			keyConstants.MOBILE_EXIST,
			keyConstants.MOBILE_SAME,
			keyConstants.EMAIL_ADDRESS,
			keyConstants.DUPLICATE_NAME,
			keyConstants.DUPLICATE_VAT_CERTIFICATE_NUMBER,
		];
		if (success && prevProps.editProfileInfo.success !== success) {
			// Will go back to the previous screen after succefully edited the profile.
			this.onGoBack();
		}
		if (error && prevProps.editProfileInfo.error !== error) {
			// Will show alert if there is any api error.
			if (errorArray.includes(errorCode && errorCode.error)) {
				this.setState({
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({ isApiError: false });
				}, toastShowTime);
			} else {
				ErrorAlertComponent(errorCode, this.onPressSave);
			}
		}
		if (prevProps.editProfileInfo !== editProfileInfo) {
			if (customMobileRegex.test(mobileNumber)) {
				// Will check for mobileNumber validation.
				this.setState({ errorValidationMessage: false });
			}
			if (vatCertificateNumberRegex.test(vatCertificateNumber)) {
				// Will check for vatCertificateNumber validation.
				this.setState({ errorVatCertificateNumberMessage: false });
			}
			if (
				customMobileRegex.test(alternateMobileNumber) ||
				alternateMobileNumber === '' ||
				mobileNumber !== alternateMobileNumber
			) {
				this.setState({
					errorMobileValidationMessage: false,
					mobileErrorMessage: '',
				});
			}
		}
	}

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	updateBusinessTypeDropDown = businessType => {
		let indexBusiness = null;
		businessTypeConstants.forEach((item, index) => {
			if (item.key === businessType) {
				indexBusiness = index;
			}
		});
		this.setState({ businessTypeSelectedIndex: indexBusiness });
	};

	onUploadProfilePic = async () => {
		// Function to upload the profile pic.
		const { editProfileActions } = this.props;
		const results = await imagePicker();
		const { response, success, fileName } = results;
		if (success) {
			this.onProfileImageSelectorVisible(false);
			this.setState({
				imageLoader: true,
			});
			const file = await uploadFile(response.uri, response.type, fileName);
			if (file) {
				this.setState({ imageLoader: false });
				editProfileActions.onUploadProfilePic(file);
			}
		}
	};

	onRemoveImage = () => {
		// Will remove the profile pic.
		const { editProfileActions } = this.props;
		this.onProfileImageSelectorVisible(false);
		editProfileActions.onUploadProfilePic(null);
	};

	onChangeText = (text, field) => {
		const { editProfileActions } = this.props;
		editProfileActions.onEditText(text, field);
	};

	onSubmitRef = textRef => textRef.current.focus();

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = () => {
		const { editProfileInfo } = this.props;
		const { mobileNumber } = editProfileInfo;
		if (!customMobileRegex.test(mobileNumber)) {
			this.setState({ errorValidationMessage: true });
		}
	};

	onCheckVatCertificateNumber = () => {
		// Validation for vatCertificateNumber.
		const { editProfileInfo } = this.props;
		const { vatCertificateNumber } = editProfileInfo;
		if (!vatCertificateNumberRegex.test(vatCertificateNumber)) {
			this.setState({ errorVatCertificateNumberMessage: true });
		}
	};

	onCheckAlternateNumber = () => {
		// Validation for mobileNumber.
		const { editProfileInfo } = this.props;
		const { mobileNumber, alternateMobileNumber } = editProfileInfo;
		if (!customMobileRegex.test(alternateMobileNumber) && alternateMobileNumber !== '') {
			this.setState({
				errorMobileValidationMessage: true,
				mobileErrorMessage: localeString(keyConstants.MOBILE_NUMBER_VALIDATION_MESSAGE),
			});
		}
		if (mobileNumber === alternateMobileNumber) {
			this.setState({
				errorMobileValidationMessage: true,
				mobileErrorMessage: localeString(keyConstants.MOBILE_SAME),
			});
		}
	};

	onPressSave = () => {
		// API call to edit the profile.
		const { editProfileInfo, route, editProfileActions } = this.props;
		const {
			name,
			companyName,
			companyNameAr,
			mobileNumber,
			profile_pic,
			alternateMobileNumber,
			businessType,
			vatCertificateNumber,
		} = editProfileInfo;
		const { mobile, id, organization, role, profile_images } = route.params.userDetails;
		const profilePic = route.params.userDetails && route.params.userDetails.profile_pic;
		this.onDissmissKeyboard();
		const userDetails = { name, id };
		if (this.getProfilePic(profile_pic, profile_images)) {
			userDetails.profile_pic = getImageUrl(profile_pic);
		} else {
			userDetails.profile_pic = getImageUrl(profilePic);
		}
		if (mobileNumber !== mobile) {
			// If mobile number is modified.
			userDetails.mobile = mobileNumber;
		}
		if ((role === retailer || role === customerAdmin) && businessType) {
			userDetails.business_type = businessType.key;
		}
		if (role === retailer || role === customerAdmin) {
			userDetails.mobile_secondary = alternateMobileNumber;
			userDetails.vat_certificate_number = vatCertificateNumber;
		}
		if (
			role !== collector &&
			role !== driver &&
			role !== accountManager &&
			role !== cashier &&
			role !== salesExecutive
		) {
			userDetails.org_id = organization && organization.id;
			userDetails.organization = companyName;
			userDetails.organization_ar = companyNameAr;
		}
		editProfileActions.onEditProfile(userDetails);
	};

	getProfilePic = (profilePic, profileImages) => {
		return (profileImages && profileImages.medium) !== profilePic;
	};

	onDissmissKeyboard = () => Keyboard.dismiss();

	onCloseDropdown = () => this.setState({ isDropdownVisible: false });

	onSelectOption = index => {
		// Will select dropdown value and update it.
		const { editProfileActions } = this.props;
		this.onCloseDropdown();
		this.setState({ businessTypeSelectedIndex: index }, () => {
			editProfileActions.onEditText(businessTypeConstants[index], constants.businessType);
		});
	};

	onPressDropdown = () => {
		this.onDissmissKeyboard();
		this.setState({ isDropdownVisible: true });
	};

	onProfileImageSelectorVisible = value => this.setState({ isVisible: value });

	render() {
		const { languageInfo, editProfileInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			name,
			companyName,
			companyNameAr,
			mobileNumber,
			profile_pic,
			loader,
			alternateMobileNumber,
			vatCertificateNumber,
		} = editProfileInfo;
		const {
			errorValidationMessage,
			isApiError,
			toastMessage,
			imageLoader,
			errorMobileValidationMessage,
			errorVatCertificateNumberMessage,
			mobileErrorMessage,
			businessTypeSelectedIndex,
			isVisible,
			isDropdownVisible,
		} = this.state;
		const { email_address, role } = route.params.userDetails;
		// Actions that will appear while uploading the profile pic.
		const imageData = [
			{
				title: localeString(keyConstants.VIEW_GALLERY),
				image: IMAGES.iconGallery,
				action: () => this.onUploadProfilePic(),
			},
			{
				title: localeString(keyConstants.REMOVE_IMAGE),
				image: IMAGES.iconDeleteRed,
				action: () => this.onRemoveImage(),
			},
		];
		return (
			<KeyboardAwareScrollView
				keyboardShouldPersistTaps="handled"
				contentContainerStyle={styles.container}>
				{loader && <Spinner size="large" />}
				<OverlayComponent
					isRTL={isRTL}
					isVisible={isVisible}
					onClose={() => this.onProfileImageSelectorVisible(false)}
					component={ItemSelectionComponent(isRTL, imageData)}
				/>
				<OptionPicker
					title={localeString(keyConstants.SELECT_BUSINESS_TYPE)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={businessTypeConstants}
					provideLanguageSupport
					onClose={this.onCloseDropdown}
					onSelectOption={this.onSelectOption}
					activeIndex={businessTypeSelectedIndex}
				/>
				<View style={styles.formView}>
					<Header onPressBack={this.onGoBack} hasIconBack />
				</View>
				<ScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollViewEditProfile}
					keyboardShouldPersistTaps="handled">
					<EditImageComponent
						isRTL={isRTL}
						profile_pic={profile_pic}
						imageLoader={imageLoader}
						onImageSelectorVisible={() => this.onProfileImageSelectorVisible(true)}
					/>
					<View style={styles.formView}>
						<Input
							maxLength={nameMaxLength}
							value={name}
							width={normalScale(288)}
							label={`${localeString(keyConstants.NAME)}${asterik}`}
							placeholder={localeString(keyConstants.YOUR_FULL_NAME)}
							blurOnSubmit={false}
							returnKeyType="next"
							isRTL={isRTL}
							onChangeText={text => this.onChangeText(text, constants.name)}
							onSubmitEditing={() => this.onSubmitRef(this.companyName)}
							autoCapitalize="none"
						/>
						<Input
							maxLength={nameMaxLength}
							value={companyName}
							width={normalScale(288)}
							label={`${localeString(keyConstants.COMPANY_NAME)}${asterik}`}
							placeholder={localeString(keyConstants.YOUR_COMPANY_NAME)}
							blurOnSubmit={false}
							returnKeyType="next"
							isRTL={isRTL}
							onChangeText={text => this.onChangeText(text, constants.companyName)}
							refs={this.refCallback(this.companyName)}
							onSubmitEditing={() => this.onSubmitRef(this.companyNameAr)}
							autoCapitalize="none"
							editable={role !== collector && role !== driver}
							textInputStyle={
								(role === collector || role === driver) && styles.textStyle
							}
						/>
						<Input
							maxLength={nameMaxLength}
							value={companyNameAr}
							width={normalScale(288)}
							label={`${localeString(keyConstants.COMPANY_ARABIC_NAME)}${asterik}`}
							placeholder={localeString(keyConstants.COMPANY_ARABIC_NAME)}
							blurOnSubmit
							returnKeyType="done"
							isRTL={isRTL}
							onChangeText={text => this.onChangeText(text, constants.companyNameAr)}
							autoCapitalize="none"
							refs={this.refCallback(this.companyNameAr)}
							editable={role !== collector && role !== driver}
							textInputStyle={
								(role === collector || role === driver) && styles.textStyle
							}
						/>
						{(role === retailer || role === customerAdmin) && (
							<DropdownFieldComponent
								isRTL={isRTL}
								onPress={this.onPressDropdown}
								value={
									businessTypeSelectedIndex !== null
										? localeString(
												businessTypeConstants[businessTypeSelectedIndex]
													.name,
										  )
										: ''
								}
								label={`${localeString(keyConstants.BUSINESS_TYPE)}*`}
								placeholder={`${localeString(keyConstants.BUSINESS_TYPE)}`}
							/>
						)}
						<Input
							value={email_address}
							width={normalScale(288)}
							label={`${localeString(keyConstants.EMAIL_ADDRESS)}${asterik}`}
							placeholder={localeString(keyConstants.ABC_EMAIL)}
							isRTL={isRTL}
							editable={false}
							textInputStyle={styles.textStyle}
						/>
						<Input
							maxLength={mobileNumberLength}
							value={mobileNumber}
							width={normalScale(288)}
							label={`${localeString(keyConstants.MOBILE_NUMBER)}${asterik}`}
							placeholder={localeString(keyConstants.MOBILE_NUMBER_PLACEHOLDER)}
							blurOnSubmit={role !== retailer}
							returnKeyType="done"
							keyboardType="number-pad"
							isRTL={isRTL}
							onChangeText={text =>
								(numericRegexExp.test(String(text).toLowerCase()) || text === '') &&
								this.onChangeText(text, constants.mobileNumber)
							}
							autoCapitalize="none"
							onBlur={this.onBlur}
							isError={errorValidationMessage}
							errorMessage={localeString(
								keyConstants.PHONE_NUMBER_VALIDATION_MESSAGE,
							)}
							hasMobilePrefix
							onSubmitEditing={() =>
								role === retailer || role === customerAdmin
									? this.onSubmitRef(this.alternateMobileNumber)
									: null
							}
							editable={false}
							textInputStyle={styles.textStyle}
						/>
						{(role === retailer || role === customerAdmin) && (
							<>
								<Input
									maxLength={mobileNumberLength}
									value={alternateMobileNumber}
									width={normalScale(288)}
									label={`${localeString(keyConstants.ALTERNATE_MOBILE_NUMBER)}`}
									placeholder={localeString(
										keyConstants.MOBILE_NUMBER_PLACEHOLDER,
									)}
									blurOnSubmit
									returnKeyType="done"
									keyboardType="number-pad"
									isRTL={isRTL}
									onChangeText={text =>
										(numericRegexExp.test(String(text).toLowerCase()) ||
											text === '') &&
										this.onChangeText(text, constants.alternateMobileNumber)
									}
									autoCapitalize="none"
									refs={this.refCallback(this.alternateMobileNumber)}
									onSubmitEditing={() =>
										this.onSubmitRef(this.vatCertificateNumber)
									}
									onBlur={this.onCheckAlternateNumber}
									isError={errorMobileValidationMessage}
									errorMessage={mobileErrorMessage}
									hasMobilePrefix
								/>
								<Input
									maxLength={vatCertificateNumberLength}
									value={vatCertificateNumber}
									width={normalScale(288)}
									label={`${localeString(keyConstants.VAT_CERTIFICATE_NUMBER)}`}
									placeholder={localeString(keyConstants.VAT_CERTIFICATE_NUMBER)}
									blurOnSubmit
									returnKeyType="done"
									keyboardType="number-pad"
									isRTL={isRTL}
									onChangeText={text =>
										(numericRegexExp.test(String(text).toLowerCase()) ||
											text === '') &&
										this.onChangeText(text, constants.vatCertificateNumber)
									}
									autoCapitalize="none"
									refs={this.refCallback(this.vatCertificateNumber)}
									onBlur={this.onCheckVatCertificateNumber}
									isError={errorVatCertificateNumberMessage}
									errorMessage={localeString(
										keyConstants.VAT_CERTIFICATE_NUMBER_VALIDATION_MESSAGE,
									)}
								/>
							</>
						)}
					</View>
				</ScrollView>
				<SaveCancelButtonComponent
					isRTL={isRTL}
					isButtonDisable={
						!(
							name &&
							companyName &&
							companyNameAr &&
							(role === retailer || role === customerAdmin
								? businessTypeSelectedIndex !== null && vatCertificateNumber
									? vatCertificateNumberRegex.test(vatCertificateNumber)
									: true
								: true) &&
							customMobileRegex.test(mobileNumber) &&
							!imageLoader
						)
					}
					cancelText={localeString(keyConstants.CANCEL)}
					onPressCancel={this.onGoBack}
					saveText={localeString(keyConstants.SAVE)}
					onPressSave={this.onPressSave}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		editProfileInfo: state.EditProfileScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		editProfileActions: bindActionCreators({ ...EditProfileActions }, dispatch),
	};
};

EditProfileScreen.propTypes = {
	editProfileInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	editProfileActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EditProfileScreen);
