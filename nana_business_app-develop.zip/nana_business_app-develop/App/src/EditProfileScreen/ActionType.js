export const ON_EDIT_TEXT = 'on_edit_text';
export const ON_UPLOAD_PROFILE_PIC = 'on_upload_profile_pic';
export const EDIT_PROFILE_SUCCESS = 'edit_profile_success';
export const EDIT_PROFILE_FAILURE = 'edit_profile_failure';
export const EDIT_PROFILE_LOADER = 'edit_profile_loader';
