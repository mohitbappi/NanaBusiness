export const constants = {
	name: 'name',
	companyName: 'companyName',
	companyNameAr: 'companyNameAr',
	mobileNumber: 'mobileNumber',
	alternateMobileNumber: 'alternateMobileNumber',
	businessType: 'businessType',
	vatCertificateNumber: 'vatCertificateNumber',
};

export default constants;
