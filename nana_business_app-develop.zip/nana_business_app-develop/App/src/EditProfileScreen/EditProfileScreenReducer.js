import { onEditUserDetails } from '@Util/SaveMasterData';
import * as ActionTypes from './ActionType';

const initialState = {
	name: '',
	companyName: '',
	companyNameAr: '',
	mobileNumber: '',
	alternateMobileNumber: '',
	businessType: '',
	vatCertificateNumber: '',
	profile_pic: null,
};

const EditProfileScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_EDIT_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.EDIT_PROFILE_SUCCESS:
			onEditUserDetails(
				action.payload.user.name,
				action.payload.user &&
					action.payload.user.profile_images &&
					action.payload.user.profile_images.medium,
				action.payload.user.organization,
			);
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
			};
		case ActionTypes.EDIT_PROFILE_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.EDIT_PROFILE_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.ON_UPLOAD_PROFILE_PIC:
			return {
				...state,
				profile_pic: action.payload,
			};
		default:
			return state;
	}
};

export default EditProfileScreenReducer;
