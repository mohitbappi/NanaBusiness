import { actions } from '@libapi/APIActionsBuilder';
import EditProfileService from '@Profile/EditProfileService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to save the input fields data.
 * @param {string} text
 * @param {string} field
 * @returns
 */

export const onEditText = (text, field) => {
	return {
		type: ActionTypes.ON_EDIT_TEXT,
		payload: text,
		field,
	};
};

/**
 * Action to edit the user profile.
 * @param {object} userDetails
 * @returns
 */

export const onEditProfile = userDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.EDIT_PROFILE_SUCCESS,
		ActionTypes.EDIT_PROFILE_FAILURE,
		ActionTypes.EDIT_PROFILE_LOADER,
	);
	const editProfileService = new EditProfileService(dispatchedActions);
	addBasicInterceptors(editProfileService);
	editProfileService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(editProfileService.makeRequest(userDetails));
};

/**
 * Action to save profile pic.
 * @param {string} file
 * @returns
 */

export const onUploadProfilePic = file => {
	return {
		type: ActionTypes.ON_UPLOAD_PROFILE_PIC,
		payload: file,
	};
};
