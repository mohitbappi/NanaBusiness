import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import { normalScale, verticalScale } from '@device/normalize';

export const createStyleSheet = () => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
			paddingHorizontal: normalScale(16),
		},
		submitButtonView: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
