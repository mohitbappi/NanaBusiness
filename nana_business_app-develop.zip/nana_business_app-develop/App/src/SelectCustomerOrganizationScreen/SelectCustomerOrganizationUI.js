// import libraries
import React from 'react';
import { FlatList, View } from 'react-native';
import PropTypes from 'prop-types';

// import utils
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

// import components
import Header from '@Header/Header';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import OptionPicker from '@OptionPicker/OptionPicker';

// import styles
import { createStyleSheet } from './SelectCustomerOrganizationStyle';

const SelectCustomerOrganizationUI = props => {
	const {
		isRTL,
		loader,
		zones,
		customerOrganizations,
		branches,
		users,
		count,
		selectedZoneId,
		selectedCustomerOrganizationId,
		selectedUserId,
		isDropdownVisible,
		onGoBack,
		onCloseDropdown,
		onSelectOption,
		onSubmit,
		onEndReached,
	} = props;
	const styles = createStyleSheet();

	const getSelectedIndex = () => {
		// Will return the index of the selected dropdown value.
		const { activeDropdown, selectedBranchId } = props;
		let index = 0;
		let dropdownList = [];
		switch (activeDropdown) {
			case 0:
				// If zone is selected.
				index = zones.findIndex(value => value.id === selectedZoneId);
				dropdownList = zones;
				break;
			case 1:
				// If customer organization is selected.
				index = customerOrganizations.findIndex(
					value => value.id === selectedCustomerOrganizationId,
				);
				break;
			case 2:
				// If branch is selected.
				index = branches.findIndex(value => value.id === selectedBranchId);
				dropdownList = branches;
				break;
			case 3:
				// If user is selected.
				index = users.findIndex(value => value.id === selectedUserId);
				dropdownList = users;
				break;
			default:
				break;
		}
		return { index, dropdownList };
	};

	const dropdownParameters = () => {
		// Function to return the selectedId, name and label.
		const {
			zoneName,
			zoneArabicName,
			customerOrganizationName,
			selectedBranchId,
			branchName,
			branchArabicName,
			userName,
		} = props;
		return [
			{
				selectedId: selectedZoneId,
				name: isRTL ? zoneArabicName : zoneName,
				label: `${localeString(keyConstants.ZONE)}*`,
			},
			{
				selectedId: selectedCustomerOrganizationId,
				name: customerOrganizationName,
				label: `${localeString(keyConstants.CUSTOMER_ORGANIZATION_NAME)}*`,
			},
			{
				selectedId: selectedBranchId,
				name: isRTL ? branchArabicName : branchName,
				label: `${localeString(keyConstants.BRANCH)}*`,
			},
			{
				selectedId: selectedUserId,
				name: userName,
				label: `${localeString(keyConstants.USER)}*`,
			},
		];
	};

	const renderItem = ({ item, index }) => {
		const { onPressDropdown, isBranchDropdownVisible, selectedBranchId } = props;
		const { selectedId, name, label } = item;
		if (index === 2 && !isBranchDropdownVisible) {
			// Will hide the branch dropdown if no branch exists.
			return null;
		}
		if (index === 3) {
			if (selectedCustomerOrganizationId === null) {
				// Will hide the user dropdown if customer organization is not selected.
				return null;
			}
			if (isBranchDropdownVisible && selectedBranchId === null) {
				// Will hide the user dropdown if branch is not selected.
				return null;
			}
		}
		return (
			<DropdownFieldComponent
				isRTL={isRTL}
				onPress={() => onPressDropdown(index)}
				value={selectedId !== null ? name : ''}
				label={label}
				placeholder={`${localeString(keyConstants.SELECT)}`}
			/>
		);
	};

	const keyExtractor = (item, index) => index.toString();

	return (
		<View style={styles.container}>
			<Header
				text={localeString(keyConstants.SELECT_ORGANIZATION)}
				onPressBack={onGoBack}
				hasIconBack
			/>
			<OptionPicker
				title={localeString(keyConstants.SELECT)}
				isRTL={isRTL}
				isVisible={isDropdownVisible}
				options={getSelectedIndex().dropdownList}
				onClose={onCloseDropdown}
				onSelectOption={onSelectOption}
				activeIndex={getSelectedIndex().index}
				loader={loader}
				count={count}
				onEndReached={onEndReached}
			/>
			<FlatList
				data={dropdownParameters()}
				renderItem={renderItem}
				keyExtractor={keyExtractor}
				showsVerticalScrollIndicator={false}
			/>
			<View style={styles.submitButtonView}>
				<ButtonComponent
					text={localeString(keyConstants.SUBMIT)}
					onPress={onSubmit}
					isButtonDisable={
						selectedZoneId === null ||
						selectedCustomerOrganizationId === null ||
						selectedUserId === null
					}
				/>
			</View>
		</View>
	);
};

SelectCustomerOrganizationUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	loader: PropTypes.bool.isRequired,
	count: PropTypes.number.isRequired,
	onGoBack: PropTypes.func.isRequired,
	onPressDropdown: PropTypes.func.isRequired,
	selectedZoneId: PropTypes.number.isRequired,
	zoneName: PropTypes.string.isRequired,
	zoneArabicName: PropTypes.string.isRequired,
	selectedCustomerOrganizationId: PropTypes.number.isRequired,
	customerOrganizationName: PropTypes.string.isRequired,
	selectedBranchId: PropTypes.number.isRequired,
	branchName: PropTypes.string.isRequired,
	branchArabicName: PropTypes.string.isRequired,
	selectedUserId: PropTypes.number.isRequired,
	userName: PropTypes.string.isRequired,
	onSubmit: PropTypes.func.isRequired,
	isDropdownVisible: PropTypes.bool.isRequired,
	zones: PropTypes.array.isRequired,
	customerOrganizations: PropTypes.array.isRequired,
	branches: PropTypes.array.isRequired,
	users: PropTypes.array.isRequired,
	onCloseDropdown: PropTypes.func.isRequired,
	onSelectOption: PropTypes.func.isRequired,
	activeDropdown: PropTypes.number.isRequired,
	onEndReached: PropTypes.func.isRequired,
	isBranchDropdownVisible: PropTypes.bool.isRequired,
};

export default SelectCustomerOrganizationUI;
