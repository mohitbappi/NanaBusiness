// import libraries
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// import actions
import * as SelectCustomerActions from '@SelectCustomerScreen/SelectCustomerScreenAction';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import * as SelectCustomerOrganizationActions from './SelectCustomerOrganizationAction';

// import components
import SelectCustomerOrganizationComponent from './SelectCustomerOrganizationComponent';

const SelectCustomerOrganizationContainer = props => {
	const customProps = { ...props }; // Will store all the props.
	return <SelectCustomerOrganizationComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		selectCustomerOrganizationInfo: state.SelectCustomerOrganizationReducer,
		selectCustomerInfo: state.SelectCustomerScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		selectCustomerOrganizationActions: bindActionCreators(
			{ ...SelectCustomerOrganizationActions },
			dispatch,
		),
		selectCustomerActions: bindActionCreators({ ...SelectCustomerActions }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectCustomerOrganizationContainer);
