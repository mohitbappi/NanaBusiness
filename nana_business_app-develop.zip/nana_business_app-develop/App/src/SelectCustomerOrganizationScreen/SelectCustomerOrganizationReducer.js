import * as ActionTypes from './ActionType';

const initialState = {
	count: 0,
	zones: [],
	selectedZoneId: null,
	zoneName: '',
	zoneArabicName: '',
	customerOrganizations: [],
	selectedCustomerOrganizationId: null,
	customerOrganizationName: '',
	branches: [],
	selectedBranchId: null,
	branchName: '',
	branchArabicName: '',
	users: [],
	selectedUserId: null,
	userName: '',
	succes: false,
	error: false,
	errorCode: '',
	loader: false,
	isGetBranches: false,
	isBranchDropdownVisible: false,
	isScreenActive: false,
};

const SelectCustomerOrganizationReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_ZONES_SUCCESS: {
			const isAppendInExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				zones: isAppendInExistingList
					? [...state.zones, ...action.payload.zones]
					: action.payload.zones,
				count: action.payload.count,
				isGetBranches: false,
			};
		}
		case ActionTypes.GET_ORGANIZATION_BRANCHES_SUCCESS: {
			const isAppendInExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				branches: isAppendInExistingList
					? [...state.branches, ...action.payload.branch_list]
					: action.payload.branch_list,
				count: action.payload.count,
				isGetBranches: true,
			};
		}
		case ActionTypes.GET_USERS_SUCCESS: {
			const isAppendInExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				users: isAppendInExistingList
					? [...state.users, ...action.payload.users]
					: action.payload.users,
			};
		}
		case ActionTypes.GET_ORGANIZATIONS_LOADER:
		case ActionTypes.GET_ZONES_LOADER:
		case ActionTypes.GET_ORGANIZATION_BRANCHES_LOADER:
		case ActionTypes.GET_USERS_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
			};
		case ActionTypes.GET_ORGANIZATIONS_FAILURE:
		case ActionTypes.GET_ZONES_FAILURE:
		case ActionTypes.GET_ORGANIZATION_BRANCHES_FAILURE:
		case ActionTypes.GET_USERS_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
			};
		case ActionTypes.SET_DETAILS:
			return {
				...state,
				...action.payload,
			};
		case ActionTypes.SET_BRANCH_DROPDOWN_VISIBILITY:
			return {
				...state,
				isBranchDropdownVisible: action.payload,
			};
		case ActionTypes.SET_SCREEN_VISIBILITY:
			return {
				...state,
				isScreenActive: action.payload,
			};
		case ActionTypes.RESET_SELECT_ORGANIZATION_STATE:
			return initialState;
		default:
			return state;
	}
};

export default SelectCustomerOrganizationReducer;
