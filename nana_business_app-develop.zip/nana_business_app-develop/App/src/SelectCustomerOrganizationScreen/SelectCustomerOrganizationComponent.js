// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import AsyncStorage from '@react-native-async-storage/async-storage';

// import constants
import { fetchDataWithPagination } from '@Constants/Constants';

// import navigations
import navigations from '@routes/navigations';

// import utils
import { onEditCustomerOrgAndUser } from '@Util/SaveMasterData';

// import components
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import SelectCustomerOrganizationUI from './SelectCustomerOrganizationUI';

class SelectCustomerOrganizationComponent extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			isDropdownVisible: false,
			activeDropdown: null,
			selectedZoneId: null,
			zoneName: '',
			zoneArabicName: '',
			selectedBranchId: null,
			branchName: '',
			branchArabicName: '',
			selectedUserId: null,
			userName: '',
			isBranchDropdownVisible: false,
		};
	}

	componentDidMount() {
		const { selectCustomerOrganizationInfo, selectCustomerActions } = this.props;
		const {
			selectedZoneId,
			zoneName,
			zoneArabicName,
			selectedCustomerOrganizationId,
			customerOrganizationName,
			selectedBranchId,
			branchName,
			branchArabicName,
			selectedUserId,
			userName,
			isBranchDropdownVisible,
		} = selectCustomerOrganizationInfo;
		selectCustomerActions.onSelectCustomer({
			id: selectedCustomerOrganizationId,
			name: customerOrganizationName,
		});
		this.setState({
			selectedZoneId,
			zoneName,
			zoneArabicName,
			selectedBranchId,
			branchName,
			branchArabicName,
			selectedUserId,
			userName,
			isBranchDropdownVisible,
		});
	}

	componentDidUpdate(prevProps) {
		const { activeDropdown, selectedZoneId } = this.state;
		const {
			selectCustomerOrganizationInfo,
			selectCustomerOrganizationActions,
			selectCustomerInfo,
		} = this.props;
		const {
			success,
			zones,
			error,
			errorCode,
			isGetBranches,
			count,
			isScreenActive,
		} = selectCustomerOrganizationInfo;
		const { customerId } = selectCustomerInfo;
		if (
			isScreenActive &&
			customerId &&
			prevProps.selectCustomerInfo.customerId !== customerId
		) {
			// Will reset the branch id and user id if user changed the selected customer organization.
			this.setState({
				selectedBranchId: null,
				branchName: '',
				branchArabicName: '',
				selectedUserId: null,
				userName: '',
			});
			selectCustomerOrganizationActions.onSetScreenVisibility(true);
			this.setState({
				isBranchDropdownVisible: false,
			});
			this.setState(
				{
					activeDropdown: 2,
				},
				() => this.onFetchBranches(false),
			);
		}
		if (
			success &&
			selectedZoneId === null &&
			zones &&
			prevProps.selectCustomerOrganizationInfo.success !== success
		) {
			// Will set the zone id and name.
			this.setState({
				selectedZoneId: zones[0].id,
				zoneName: zones[0].name,
				zoneArabicName: zones[0].name_ar,
			});
		}
		if (
			isGetBranches &&
			success &&
			count > 1 &&
			prevProps.selectCustomerOrganizationInfo.success !== success
		) {
			// Will show the branch dropdown if selected customer organization contains more than 2 branch.
			// If there is only 1 branch then it is representing itself.
			this.setState({
				isBranchDropdownVisible: true,
			});
		}
		if (error && prevProps.selectCustomerOrganizationInfo.error !== error) {
			// Will show popup in case of error.
			this.handleDropdown(false);
			ErrorAlertComponent(errorCode, () => this.onRetry(false, activeDropdown));
		}
	}

	componentWillUnmount() {
		// Will reset the reducer.
		const {
			selectCustomerActions,
			selectCustomerOrganizationInfo,
			selectCustomerOrganizationActions,
		} = this.props;
		const {
			selectedCustomerOrganizationId,
			customerOrganizationName,
		} = selectCustomerOrganizationInfo;
		selectCustomerActions.onSelectCustomer({
			id: selectedCustomerOrganizationId,
			name: customerOrganizationName,
		});
		selectCustomerOrganizationActions.onSetScreenVisibility(false);
	}

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onPressDropdown = index => {
		// Will show the dropdown.
		this.setState({
			activeDropdown: index,
		});
		if (index === 1) {
			this.onFetchCustomerOrganizations();
		} else {
			this.limit = fetchDataWithPagination.limit;
			this.page = fetchDataWithPagination.page;
			this.handleDropdown(true);
			this.onCallApi(false, index);
		}
	};

	handleDropdown = value => {
		// Will hide/show the dropdown.
		this.setState({
			isDropdownVisible: value,
		});
	};

	onCallApi = (isAppendInExistingList, activeDropdown) => {
		if (activeDropdown === 0) {
			this.onFetchZones(isAppendInExistingList);
		} else if (activeDropdown === 1) {
			this.onFetchCustomerOrganizations(isAppendInExistingList);
		} else if (activeDropdown === 2) {
			this.onFetchBranches(isAppendInExistingList);
		} else {
			this.onFetchUsers(isAppendInExistingList);
		}
	};

	onFetchZones = isAppendInExistingList => {
		// API call to get the zones.
		const { selectCustomerOrganizationActions } = this.props;
		const queryParams = {
			limit: this.limit,
			page: this.page,
		};
		selectCustomerOrganizationActions.onGetZones(queryParams, isAppendInExistingList);
	};

	onFetchCustomerOrganizations = () => {
		// Will navigate to the select customer screen.
		const { selectedZoneId } = this.state;
		const { navigation } = this.props;
		navigation.navigate(navigations.SELECT_CUSTOMER_NAVIGATION, { selectedZoneId });
	};

	onFetchBranches = isAppendInExistingList => {
		// API call to get the customer organizations.
		const { selectCustomerOrganizationActions, selectCustomerInfo } = this.props;
		const { customerId } = selectCustomerInfo;
		const queryParams = {
			limit: this.limit,
			page: this.page,
		};
		if (customerId !== null) {
			queryParams.customer_org_id = customerId;
		}
		selectCustomerOrganizationActions.onGetBranches(queryParams, isAppendInExistingList);
	};

	onFetchUsers = isAppendInExistingList => {
		// API call to get the users.
		const { selectCustomerOrganizationActions, selectCustomerInfo } = this.props;
		const { customerId } = selectCustomerInfo;
		const { selectedBranchId } = this.state;
		const requestPayload = {
			id: selectedBranchId || customerId,
			queryParams: {
				limit: this.limit,
				page: this.page,
			},
		};
		selectCustomerOrganizationActions.onGetUsers(requestPayload, isAppendInExistingList);
	};

	onRetry = (isAppendInExistingList, activeDropdown) => {
		// Will call the api again if api fails.
		this.handleDropdown(true);
		this.onCallApi(isAppendInExistingList, activeDropdown);
	};

	onCloseDropdown = () => {
		this.handleDropdown(false);
	};

	onSelectOption = index => {
		// Function to set the selected option into the reducer.
		const {
			selectCustomerOrganizationInfo,
			selectCustomerActions,
			selectCustomerOrganizationActions,
		} = this.props;
		const { zones, branches, users } = selectCustomerOrganizationInfo;
		const { activeDropdown } = this.state;
		switch (activeDropdown) {
			case 0: // If zone is selected.
				this.setState({
					selectedZoneId: zones[index].id,
					zoneName: zones[index].name,
					zoneArabicName: zones[index].name_ar,
					selectedBranchId: null,
					branchName: '',
					branchArabicName: '',
					selectedUserId: null,
					userName: '',
					isBranchDropdownVisible: false,
				});
				selectCustomerOrganizationActions.onSetScreenVisibility(true);
				selectCustomerActions.onResetCustomerState();
				break;
			case 2: // If branch is selected.
				this.setState({
					selectedBranchId: branches[index].id,
					branchName: branches[index].name,
					branchArabicName: branches[index].name_ar,
					selectedUserId: null,
					userName: '',
				});
				selectCustomerOrganizationActions.onSetScreenVisibility(true);
				break;
			case 3: // If user is selected.
				this.setState({
					selectedUserId: users[index].id,
					userName: users[index].name,
				});
				selectCustomerOrganizationActions.onSetScreenVisibility(true);
				break;
			default:
				break;
		}
		this.handleDropdown(false);
	};

	onSubmit = async () => {
		// Will set the selected customer organization and the user to the reducer and async storage.
		let userDetail = await AsyncStorage.getItem('user_details');
		userDetail = JSON.parse(userDetail);
		const {
			selectedZoneId,
			zoneName,
			zoneArabicName,
			selectedBranchId,
			branchName,
			branchArabicName,
			selectedUserId,
			userName,
			isBranchDropdownVisible,
		} = this.state;
		const {
			selectCustomerInfo,
			navigation,
			homeScreenActions,
			selectCustomerOrganizationActions,
		} = this.props;
		const { customerId, customerListing, customerName } = selectCustomerInfo;
		const selectedOrganization = customerListing.filter(element => element.id === customerId);
		selectCustomerOrganizationActions.onSetDetails({
			selectedZoneId,
			zoneName,
			zoneArabicName,
			selectedCustomerOrganizationId: customerId,
			customerOrganizationName: customerName,
			selectedBranchId,
			branchName,
			branchArabicName,
			selectedUserId,
			userName,
			isBranchDropdownVisible,
		});
		if (selectedOrganization.length > 0) {
			selectedOrganization[0].branch_id = selectedBranchId;
			selectedOrganization[0].branch_name = branchName;
			selectedOrganization[0].branch_name_ar = branchArabicName;
		}
		onEditCustomerOrgAndUser(
			selectedOrganization.length > 0
				? selectedOrganization[0]
				: userDetail.user.organization,
			selectedUserId,
			userName,
		);
		homeScreenActions.onSetCustomerOrgAndUser({
			organization:
				selectedOrganization.length > 0
					? selectedOrganization[0]
					: userDetail.user.organization,
			defaultUserId: selectedUserId,
			defaultUserName: userName,
		});
		setTimeout(() => {
			navigation.goBack();
		}, 200);
	};

	onEndReached = () => {
		// Will call the API for the next page with limit 10.
		const { activeDropdown } = this.state;
		this.page += 1;
		this.onCallApi(true, activeDropdown);
	};

	render() {
		const { languageInfo, selectCustomerOrganizationInfo, selectCustomerInfo } = this.props;
		const { isRTL } = languageInfo;
		const {
			loader,
			zones,
			branches,
			users,
			count,
			customerOrganizations,
		} = selectCustomerOrganizationInfo;
		const { customerId, customerName } = selectCustomerInfo;
		const {
			isDropdownVisible,
			activeDropdown,
			selectedZoneId,
			zoneName,
			zoneArabicName,
			selectedBranchId,
			branchName,
			branchArabicName,
			selectedUserId,
			userName,
			isBranchDropdownVisible,
		} = this.state;
		return (
			<SelectCustomerOrganizationUI
				isRTL={isRTL}
				loader={loader && this.page === 1}
				count={count}
				activeDropdown={activeDropdown}
				zones={zones}
				customerOrganizations={customerOrganizations}
				branches={branches}
				users={users}
				selectedZoneId={selectedZoneId}
				zoneName={zoneName}
				zoneArabicName={zoneArabicName}
				selectedCustomerOrganizationId={customerId}
				customerOrganizationName={customerName}
				selectedBranchId={selectedBranchId}
				branchName={branchName}
				branchArabicName={branchArabicName}
				selectedUserId={selectedUserId}
				userName={userName}
				isBranchDropdownVisible={isBranchDropdownVisible}
				isDropdownVisible={isDropdownVisible}
				onGoBack={this.onGoBack}
				onPressDropdown={this.onPressDropdown}
				onCloseDropdown={this.onCloseDropdown}
				onSelectOption={this.onSelectOption}
				onSubmit={this.onSubmit}
				onEndReached={this.onEndReached}
			/>
		);
	}
}

SelectCustomerOrganizationComponent.propTypes = {
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	selectCustomerOrganizationInfo: PropTypes.object.isRequired,
	selectCustomerOrganizationActions: PropTypes.object.isRequired,
	selectCustomerInfo: PropTypes.object.isRequired,
	selectCustomerActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
};

export default SelectCustomerOrganizationComponent;
