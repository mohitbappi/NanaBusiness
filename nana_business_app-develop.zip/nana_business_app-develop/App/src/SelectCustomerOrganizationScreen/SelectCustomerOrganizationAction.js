import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetZonesService from '@CustomerSuperAdmin/GetZonesService';
import GetBranchesService from '@Branch/GetBranchesService';
import GetUsersService from '@CustomerSuperAdmin/GetUsersService';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import * as ActionTypes from './ActionType';

/**
 * Action to get the zones.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetZones = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ZONES_SUCCESS,
		ActionTypes.GET_ZONES_FAILURE,
		ActionTypes.GET_ZONES_LOADER,
	)
		.addSuccessExtra(isAppendInExistingList)
		.build();
	const getZonesService = new GetZonesService(dispatchedActions);
	addBasicInterceptors(getZonesService);
	getZonesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getZonesService.makeRequest(props));
};

/**
 * Action to get the branches.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetBranches = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ORGANIZATION_BRANCHES_SUCCESS,
		ActionTypes.GET_ORGANIZATION_BRANCHES_FAILURE,
		ActionTypes.GET_ORGANIZATION_BRANCHES_LOADER,
	)
		.addSuccessExtra(isAppendInExistingList)
		.build();
	const getBranchesService = new GetBranchesService(dispatchedActions);
	addBasicInterceptors(getBranchesService);
	getBranchesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getBranchesService.makeRequest(props));
};

/**
 * Action to get the users.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetUsers = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_USERS_SUCCESS,
		ActionTypes.GET_USERS_FAILURE,
		ActionTypes.GET_USERS_LOADER,
	)
		.addSuccessExtra(isAppendInExistingList)
		.build();
	const getUsersService = new GetUsersService(dispatchedActions);
	addBasicInterceptors(getUsersService);
	getUsersService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getUsersService.makeRequest(props));
};

/**
 * Action to update the zoneId, branchId, userId.
 * @param {object} props
 * @returns
 */

export const onSetDetails = props => {
	return {
		type: ActionTypes.SET_DETAILS,
		payload: props,
	};
};

/**
 * Action to set the branch dropdown visibility.
 * @param {boolean} isBranchDropdownVisible
 * @returns
 */

export const onSetBranchDropdownVisibility = isBranchDropdownVisible => {
	return {
		type: ActionTypes.SET_BRANCH_DROPDOWN_VISIBILITY,
		payload: isBranchDropdownVisible,
	};
};

export const onResetSelectOrganizationState = () => ({
	// Action to reset the reducer.
	type: ActionTypes.RESET_SELECT_ORGANIZATION_STATE,
});

/**
 * Action to set the screen visibility.
 * @param {boolean} isScreenActive
 * @returns
 */

export const onSetScreenVisibility = isScreenActive => {
	return {
		type: ActionTypes.SET_SCREEN_VISIBILITY,
		payload: isScreenActive,
	};
};
