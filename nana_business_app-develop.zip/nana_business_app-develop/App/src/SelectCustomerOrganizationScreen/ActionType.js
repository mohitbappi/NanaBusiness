export const GET_ZONES_SUCCESS = 'get_zones_success';
export const GET_ZONES_FAILURE = 'get_zones_failure';
export const GET_ZONES_LOADER = 'get_zones_loader';

export const GET_ORGANIZATION_BRANCHES_SUCCESS = 'get_organization_branches_success';
export const GET_ORGANIZATION_BRANCHES_FAILURE = 'get_organization_branches_failure';
export const GET_ORGANIZATION_BRANCHES_LOADER = 'get_organization_branches_loader';

export const GET_USERS_SUCCESS = 'get_users_success';
export const GET_USERS_FAILURE = 'get_users_failure';
export const GET_USERS_LOADER = 'get_users_loader';

export const SET_DETAILS = 'set_details';

export const RESET_SELECT_ORGANIZATION_STATE = 'reset_select_organization_state';

export const SET_BRANCH_DROPDOWN_VISIBILITY = 'set_branch_dropdown_visibility';

export const SET_SCREEN_VISIBILITY = 'set_screen_visibility';
