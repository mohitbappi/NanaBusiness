// import libraries
import React, { Component } from 'react';
import { View, ScrollView, Text } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';

// import components
import Input from '@Input/Input';
import Header from '@Header/Header';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import Spinner from '@Spinner/Spinner';
import ConfimationModal from '@ConfimationModal/ConfimationModal';

// import method to get selected language string
import { localeString } from '@assets/Localization';

// import constants
import { keyConstants } from '@Constants/KeyConstants';
import { normalScale, verticalScale } from '@device/normalize';
import {
	numericRegexExp,
	crNumberLength,
	vatCertificateNumberLength,
	addressMaxLength,
} from '@Constants/Constants';
import { howOftenOrderConstant, dropdownTypeConstant, applyForCLConstant } from './Constant';

// import styles
import { createStyleSheet } from './IncreaseCreditLineStyle';

class IncreaseCreditLineUI extends Component {
	constructor(props) {
		super(props);
		this.vatCertificateNumber = React.createRef(null);
		this.averageSales = React.createRef(null);
		this.clAmount = React.createRef(null);
	}

	render() {
		const {
			isRTL,
			loader,
			isDropdownVisible,
			dropdownOptions,
			onCloseDropdown,
			onSelectDropdownOption,
			onGoBack,
			onPressDropdown,
			onRaiseRequest,
			onChangeText,
			refCallback,
			onSubmitRef,
			values,
			isError,
			onBlurCheck,
			howOftenOrderIndex,
			orderFromNanaIndex,
			applyForCLIndex,
			activeDropdownIndex,
			isappliedSuccessfully,
			onPressGoToHome,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return isappliedSuccessfully ? (
			<ConfimationModal
				title={localeString(keyConstants.SUCCESSFUL)}
				description={`${localeString(keyConstants.CREDIT_LINE_RAISED_SUCCESSFULLY)}`}
				onPress={onPressGoToHome}
				buttonTitle={localeString(keyConstants.GO_TO_HOME)}
				hasButton
			/>
		) : (
			<KeyboardAwareScrollView
				keyboardShouldPersistTaps="handled"
				contentContainerStyle={styles.container}>
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.APPLY_CREDIT_LINE)}
						onPressBack={onGoBack}
						hasIconBack
					/>
				</View>
				<OptionPicker
					title={localeString(keyConstants.SELECT)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={dropdownOptions}
					onClose={onCloseDropdown}
					onSelectOption={onSelectDropdownOption}
					activeIndex={activeDropdownIndex}
					provideLanguageSupport
				/>
				<ScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					keyboardShouldPersistTaps="handled">
					<Input
						value={values.nationalID}
						width={normalScale(288)}
						label={`${localeString(keyConstants.NATIONAL_ID)}*`}
						placeholder={localeString(keyConstants.NATIONAL_ID)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text =>
							(numericRegexExp.test(String(text).toLocaleLowerCase()) ||
								text === '') &&
							onChangeText(text, 'nationalID')
						}
						onSubmitEditing={() => onSubmitRef(this.vatCertificateNumber)}
						autoCapitalize="none"
						isError={isError.errorNationalIdValidation}
						errorMessage={localeString(keyConstants.MUST_BE_ELEVEN_DIGITS)}
						onBlur={onBlurCheck.onCheckNationalId}
						maxLength={crNumberLength}
					/>
					<Input
						value={values.vatCertificateNumber}
						width={normalScale(288)}
						label={`${localeString(keyConstants.VAT_CERTIFICATE_NUMBER)}*`}
						placeholder={localeString(keyConstants.VAT_CERTIFICATE_NUMBER)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text =>
							(numericRegexExp.test(String(text).toLocaleLowerCase()) ||
								text === '') &&
							onChangeText(text, 'vatCertificateNumber')
						}
						refs={refCallback(this.vatCertificateNumber)}
						onSubmitEditing={() => onSubmitRef(this.averageSales)}
						autoCapitalize="none"
						isError={isError.errorVatCertificateNumberValidation}
						errorMessage={localeString(
							keyConstants.VAT_CERTIFICATE_NUMBER_VALIDATION_MESSAGE,
						)}
						onBlur={onBlurCheck.onCheckVatCertificateNumber}
						maxLength={vatCertificateNumberLength}
					/>
					<Input
						value={values.averageSales}
						width={normalScale(288)}
						label={`${localeString(keyConstants.AVERAGE_DAILY_SALES)}*`}
						placeholder={localeString(keyConstants.AVERAGE_DAILY_SALES)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => onChangeText(text, 'averageSales')}
						onSubmitEditing={() => onSubmitRef(this.clAmount)}
						autoCapitalize="none"
						keyboardType="decimal-pad"
						refs={refCallback(this.averageSales)}
						isError={isError.errorAverageSalesValidation}
						errorMessage={localeString(keyConstants.ONLY_TWO_DIGIT_AFTER_DECIMAL)}
						onBlur={onBlurCheck.onCheckAverageSales}
						hasAmountPostfix
					/>
					<Input
						value={values.clAmount}
						width={normalScale(288)}
						label={`${localeString(keyConstants.REQUIRED_CL_AMOUNT)}*`}
						placeholder={localeString(keyConstants.REQUIRED_CL_AMOUNT)}
						blurOnSubmit
						returnKeyType="done"
						isRTL={isRTL}
						onChangeText={text => onChangeText(text, 'clAmount')}
						refs={refCallback(this.clAmount)}
						autoCapitalize="none"
						keyboardType="decimal-pad"
						isError={isError.errorClAmounValidation}
						errorMessage={localeString(keyConstants.ONLY_TWO_DIGIT_AFTER_DECIMAL)}
						onBlur={onBlurCheck.onCheckClAmount}
						hasAmountPostfix
					/>
					<DropdownFieldComponent
						isRTL={isRTL}
						onPress={() => onPressDropdown(dropdownTypeConstant.howOftenOrder)}
						value={
							howOftenOrderIndex !== null
								? localeString(howOftenOrderConstant[howOftenOrderIndex].name)
								: ''
						}
						label={`${localeString(keyConstants.HOW_DID_OFTEN_ORDER)}*`}
						placeholder={`${localeString(keyConstants.SELECT)}`}
					/>
					<DropdownFieldComponent
						isRTL={isRTL}
						onPress={() => onPressDropdown(dropdownTypeConstant.orderFromNana)}
						value={
							orderFromNanaIndex !== null
								? localeString(applyForCLConstant[orderFromNanaIndex].name)
								: ''
						}
						label={`${localeString(keyConstants.ORDER_NANA_BUSINESS)}*`}
						placeholder={`${localeString(keyConstants.SELECT)}`}
					/>
					<DropdownFieldComponent
						isRTL={isRTL}
						onPress={() => onPressDropdown(dropdownTypeConstant.applyForCL)}
						value={
							applyForCLIndex !== null
								? localeString(applyForCLConstant[applyForCLIndex].name)
								: ''
						}
						label={`${localeString(keyConstants.APPLY_CL)}*`}
						placeholder={`${localeString(keyConstants.SELECT)}`}
					/>
					<Input
						maxLength={addressMaxLength}
						value={values.reason}
						width={normalScale(288)}
						label={`${localeString(keyConstants.REASON_MESSAGE)}*`}
						placeholder={`${localeString(keyConstants.TYPE_HERE)}...`}
						blurOnSubmit={false}
						returnKeyType="done"
						isRTL={isRTL}
						onChangeText={text => onChangeText(text, 'reason')}
						autoCapitalize="none"
						textInputStyle={styles.textInputStyle}
						height={verticalScale(84)}
						textAlignVertical="top"
						multiline
					/>
					<Text style={styles.maxCharacters}>
						{localeString(keyConstants.MAX_CHARACTERS)}
					</Text>
				</ScrollView>
				<View style={styles.raiseRequestButtonView}>
					<ButtonComponent
						text={localeString(keyConstants.RAISE_REQUEST)}
						onPress={onRaiseRequest}
						isButtonDisable={
							!(
								values.nationalID &&
								values.vatCertificateNumber &&
								values.averageSales &&
								values.clAmount &&
								howOftenOrderIndex !== null &&
								orderFromNanaIndex !== null &&
								applyForCLIndex !== null &&
								values.reason &&
								!isError.errorNationalIdValidation &&
								!isError.errorVatCertificateNumberValidation &&
								!isError.errorAverageSalesValidation &&
								!isError.errorClAmounValidation
							)
						}
					/>
				</View>
			</KeyboardAwareScrollView>
		);
	}
}

IncreaseCreditLineUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	isDropdownVisible: PropTypes.bool.isRequired,
	dropdownOptions: PropTypes.array.isRequired,
	onCloseDropdown: PropTypes.func.isRequired,
	onSelectDropdownOption: PropTypes.func.isRequired,
	onPressDropdown: PropTypes.func.isRequired,
	onRaiseRequest: PropTypes.func.isRequired,
	onChangeText: PropTypes.func.isRequired,
	refCallback: PropTypes.func.isRequired,
	onSubmitRef: PropTypes.func.isRequired,
	values: PropTypes.array.isRequired,
	isError: PropTypes.bool.isRequired,
	onBlurCheck: PropTypes.func.isRequired,
	howOftenOrderIndex: PropTypes.element.isRequired,
	orderFromNanaIndex: PropTypes.element.isRequired,
	applyForCLIndex: PropTypes.element.isRequired,
	activeDropdownIndex: PropTypes.element.isRequired,
	isappliedSuccessfully: PropTypes.bool.isRequired,
	onPressGoToHome: PropTypes.func.isRequired,
};

export default IncreaseCreditLineUI;
