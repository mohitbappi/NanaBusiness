/* import libraries */
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

/* import components */
import IncreaseCreditLineComponent from './IncreaseCreditLineComponent';

/* import actions */
import * as IncreaseCreditLineActions from './IncreaseCreditLineAction';

const IncreaseCreditLineContainer = props => {
	const customProps = { ...props };
	return <IncreaseCreditLineComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		increaseCreditLineInfo: state.IncreaseCreditLineReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		increaseCreditLineActions: bindActionCreators({ ...IncreaseCreditLineActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(IncreaseCreditLineContainer);
