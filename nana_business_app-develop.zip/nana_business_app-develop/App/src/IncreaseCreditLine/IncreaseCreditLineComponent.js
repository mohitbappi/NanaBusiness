/* import libraries */
import React, { Component } from 'react';
import { Keyboard } from 'react-native';
import PropTypes from 'prop-types';

/** import util for navigation */
import navigations from '@routes/navigations';

/* import constants */
import {
	vatCertificateNumberRegex,
	numericRegexWithDecimalEx,
	nationalIqamaIdLength,
} from '@Constants/Constants';

/* import components */
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import IncreaseCreditLineUI from './IncreaseCreditLineUI';

/* import IncreaseCreditLine constants */
import { howOftenOrderConstant, dropdownTypeConstant, applyForCLConstant } from './Constant';

class IncreaseCreditLineComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.state = {
			errorNationalIdValidation: false,
			errorVatCertificateNumberValidation: false,
			errorAverageSalesValidation: false,
			errorClAmounValidation: false,
			isDropdownVisible: false,
			options: [],
			optionSelectedIndex: null,
			howOftenOrderIndex: 0,
			orderFromNanaIndex: 0,
			applyForCLIndex: 1,
			selectedDropdownType: '',
			isappliedSuccessfully: false,
		};
	}

	componentDidMount() {
		this.getCreditLineInfoData();
	}

	componentDidUpdate(prevProps) {
		const { increaseCreditLineInfo } = this.props;
		const {
			nationalID,
			vatCertificateNumber,
			averageSales,
			clAmount,
			isCLIncrease,
			error,
			errorCode,
			success,
		} = increaseCreditLineInfo;
		if (isCLIncrease && prevProps.increaseCreditLineInfo.success !== success) {
			this.setState({ isappliedSuccessfully: true });
		}
		if (prevProps.increaseCreditLineInfo !== increaseCreditLineInfo) {
			if (nationalID.length >= nationalIqamaIdLength) {
				// Will check nationalID validation.
				this.setState({ errorNationalIdValidation: false });
			}
			if (vatCertificateNumberRegex.test(vatCertificateNumber)) {
				// Will check vatCertificateNumber validation.
				this.setState({ errorVatCertificateNumberValidation: false });
			}
			if (numericRegexWithDecimalEx.test(String(averageSales).toLowerCase())) {
				// Will check averageSales validation.
				this.setState({ errorAverageSalesValidation: false });
			}
			if (numericRegexWithDecimalEx.test(String(clAmount).toLowerCase())) {
				// Will check clAmount validation.
				this.setState({ errorClAmounValidation: false });
			}
		}
		if (
			error &&
			isCLIncrease &&
			prevProps.increaseCreditLineInfo.error !== increaseCreditLineInfo.error
		) {
			// Will show alert if api fails.
			ErrorAlertComponent(errorCode, this.onRaiseRequest);
		}
	}

	componentWillUnmount() {
		// Will reset the reducer.
		const { increaseCreditLineActions } = this.props;
		increaseCreditLineActions.onResetIncreaseCreditLine();
	}

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	// Will navigate to the home screen.
	onPressGoToHome = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.HOME_NAVIGATION);
	};

	onCloseDropdown = () => this.setState({ isDropdownVisible: false });

	// API call to get vat certificate number.
	getCreditLineInfoData = () => {
		const { increaseCreditLineActions } = this.props;
		increaseCreditLineActions.onGetCreditLineInfo();
	};

	onRaiseRequest = () => {
		// API call to apply for the increase of credit line.
		const { increaseCreditLineInfo, increaseCreditLineActions } = this.props;
		this.onDismissKeyboard();
		const {
			averageSales,
			vatCertificateNumber,
			clAmount,
			nationalID,
			reason,
		} = increaseCreditLineInfo;
		const { howOftenOrderIndex, orderFromNanaIndex, applyForCLIndex } = this.state;
		const queryParams = {};
		queryParams.vat_certificate = vatCertificateNumber;
		queryParams.national_iqama_id = nationalID;
		queryParams.requested_cl_limit = clAmount;
		queryParams.order_frequency = howOftenOrderConstant[howOftenOrderIndex].name;
		queryParams.message = reason;
		queryParams.applied_before = applyForCLConstant[applyForCLIndex].value;
		queryParams.order_before = applyForCLConstant[orderFromNanaIndex].value;
		queryParams.avg_daily_sales = averageSales;
		increaseCreditLineActions.onIncreaseCreditLine(queryParams);
	};

	onDismissKeyboard = () => Keyboard.dismiss();

	onSelectOption = index => {
		const { selectedDropdownType } = this.state;
		this.onCloseDropdown();
		switch (selectedDropdownType) {
			case dropdownTypeConstant.howOftenOrder:
				this.setState({ howOftenOrderIndex: index });
				break;
			case dropdownTypeConstant.orderFromNana:
				this.setState({ orderFromNanaIndex: index });
				break;
			case dropdownTypeConstant.applyForCL:
				this.setState({ applyForCLIndex: index });
				break;
			default:
				break;
		}
	};

	// Will save input fields in reducer.
	onChangeText = (text, field) => {
		const { increaseCreditLineActions } = this.props;
		increaseCreditLineActions.onChangeText(text, field);
	};

	onSubmitRef = textRef => textRef.current.focus();

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onDissmissKeyboard = () => Keyboard.dismiss();

	onCheckNationalId = () => {
		// Will check nationalID validation.
		const { increaseCreditLineInfo } = this.props;
		const { nationalID } = increaseCreditLineInfo;
		if (nationalID.length < nationalIqamaIdLength) {
			this.setState({ errorNationalIdValidation: true });
		}
	};

	onCheckVatCertificateNumber = () => {
		// Will check vatCertificateNumber validation.
		const { increaseCreditLineInfo } = this.props;
		const { vatCertificateNumber } = increaseCreditLineInfo;
		if (!vatCertificateNumberRegex.test(vatCertificateNumber)) {
			this.setState({ errorVatCertificateNumberValidation: true });
		}
	};

	onCheckAverageSales = () => {
		// Will check averageSales validation.
		const { increaseCreditLineInfo } = this.props;
		const { averageSales } = increaseCreditLineInfo;
		if (!numericRegexWithDecimalEx.test(String(averageSales).toLowerCase())) {
			this.setState({ errorAverageSalesValidation: true });
		}
	};

	onCheckClAmount = () => {
		// Will check clAmount validation.
		const { increaseCreditLineInfo } = this.props;
		const { clAmount } = increaseCreditLineInfo;
		if (!numericRegexWithDecimalEx.test(String(clAmount).toLowerCase())) {
			this.setState({ errorClAmounValidation: true });
		}
	};

	onPressDropdown = type => {
		this.setState({ isDropdownVisible: true });
		this.onDissmissKeyboard();
		const { howOftenOrderIndex, orderFromNanaIndex, applyForCLIndex } = this.state;
		switch (type) {
			case dropdownTypeConstant.howOftenOrder:
				this.setState({
					options: howOftenOrderConstant,
					optionSelectedIndex: howOftenOrderIndex,
					selectedDropdownType: type,
				});
				break;
			case dropdownTypeConstant.orderFromNana:
				this.setState({
					options: applyForCLConstant,
					optionSelectedIndex: orderFromNanaIndex,
					selectedDropdownType: type,
				});
				break;
			case dropdownTypeConstant.applyForCL:
				this.setState({
					options: applyForCLConstant,
					optionSelectedIndex: applyForCLIndex,
					selectedDropdownType: type,
				});
				break;
			default:
				break;
		}
	};

	render() {
		const { increaseCreditLineInfo, languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const {
			nationalID,
			vatCertificateNumber,
			averageSales,
			clAmount,
			reason,
			loader,
		} = increaseCreditLineInfo;
		const {
			errorNationalIdValidation,
			errorVatCertificateNumberValidation,
			errorAverageSalesValidation,
			errorClAmounValidation,
			isDropdownVisible,
			options,
			optionSelectedIndex,
			howOftenOrderIndex,
			orderFromNanaIndex,
			applyForCLIndex,
			isappliedSuccessfully,
		} = this.state;
		/* Values for the input Fields */
		const values = { nationalID, vatCertificateNumber, averageSales, reason, clAmount };
		/* errors for input fields */
		const isError = {
			errorNationalIdValidation,
			errorVatCertificateNumberValidation,
			errorAverageSalesValidation,
			errorClAmounValidation,
		};
		/* onBlur Check methods for input fields */
		const onBlurCheck = {
			onCheckNationalId: this.onCheckNationalId,
			onCheckVatCertificateNumber: this.onCheckVatCertificateNumber,
			onCheckAverageSales: this.onCheckAverageSales,
			onCheckClAmount: this.onCheckClAmount,
		};
		return (
			<IncreaseCreditLineUI
				isRTL={isRTL}
				loader={loader}
				isDropdownVisible={isDropdownVisible}
				dropdownOptions={options}
				onCloseDropdown={this.onCloseDropdown}
				onSelectDropdownOption={this.onSelectOption}
				onGoBack={this.onGoBack}
				onPressDropdown={this.onPressDropdown}
				onRaiseRequest={this.onRaiseRequest} /** called when request is raised */
				onChangeText={this.onChangeText} /** called when text is changed in input field */
				refCallback={this.refCallback}
				onSubmitRef={this.onSubmitRef} /** called when text is submitted in input field */
				onPressGoToHome={this.onPressGoToHome} /** called to got to home screen */
				values={values}
				isError={isError}
				onBlurCheck={onBlurCheck}
				activeDropdownIndex={optionSelectedIndex}
				howOftenOrderIndex={howOftenOrderIndex}
				orderFromNanaIndex={orderFromNanaIndex}
				applyForCLIndex={applyForCLIndex}
				isappliedSuccessfully={
					isappliedSuccessfully
				} /** check: if raise credit line request is submitted successfully */
			/>
		);
	}
}

IncreaseCreditLineComponent.propTypes = {
	increaseCreditLineInfo: PropTypes.object.isRequired,
	increaseCreditLineActions: PropTypes.object.isRequired,
	customProps: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default IncreaseCreditLineComponent;
