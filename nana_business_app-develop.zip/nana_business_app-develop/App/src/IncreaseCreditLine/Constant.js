/* import constants */
import { keyConstants } from '@Constants/KeyConstants';

/** array constant for how often user order */
export const howOftenOrderConstant = [
	{
		name: keyConstants.DAILY,
	},
	{
		name: keyConstants.WEEKLY,
	},
	{
		name: keyConstants.MONTHLY,
	},
	{
		name: keyConstants.QUARTERLY,
	},
];

/** array constant for has applied for CL earlier */
export const applyForCLConstant = [
	{
		name: keyConstants.YES,
		value: true,
	},
	{
		name: keyConstants.NO,
		value: false,
	},
];

export const dropdownTypeConstant = {
	howOftenOrder: 'howOftenOrder',
	orderFromNana: 'orderFromNana',
	applyForCL: 'applyForCL',
};
