// import actions
import { actions } from '@libapi/APIActionsBuilder';

// import interceptor layer
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';

// import API service methods
import IncreaseCreditLineService from '@CreditLine/IncreaseCreditLineService';
import GetCreditLineInfoService from '@CreditLine/GetCreditLineInfoService';
import * as ActionTypes from './ActionType';

/**
 *
 * @param {string} text
 * @param {string} field
 * method called when inputField text is changed
 */
export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_INCREASE_CREDIT_LINE_TEXT,
		payload: text,
		field,
	};
};

/** used to reset the state of IncreaseCreditLine reducer */
export const onResetIncreaseCreditLine = () => ({
	type: ActionTypes.ON_RESET_INCREASE_CREDIT_LINE,
});

/**
 *
 * @param {object} data
 * method to increase credit Line
 */
export const onIncreaseCreditLine = data => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.INCREASE_CREDIT_LINE_SUCCESS,
		ActionTypes.INCREASE_CREDIT_LINE_FAILURE,
		ActionTypes.INCREASE_CREDIT_LINE_LOADER,
	);
	const increaseCreditLineService = new IncreaseCreditLineService(dispatchedActions);
	addBasicInterceptors(increaseCreditLineService);
	increaseCreditLineService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(increaseCreditLineService.makeRequest(data));
};

/**
 * method to call get credit Line Info
 */
export const onGetCreditLineInfo = () => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_CREDIT_LINE_INFO_SUCCESS,
		ActionTypes.GET_CREDIT_LINE_INFO_FAILURE,
		ActionTypes.GET_CREDIT_LINE_INFO_LOADER,
	);
	const getCreditLineInfoService = new GetCreditLineInfoService(dispatchedActions);
	addBasicInterceptors(getCreditLineInfoService);
	getCreditLineInfoService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCreditLineInfoService.makeRequest());
};
