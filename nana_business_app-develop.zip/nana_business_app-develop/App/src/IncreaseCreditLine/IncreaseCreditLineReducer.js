import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	clInfoData: null,
	nationalID: '',
	vatCertificateNumber: '',
	averageSales: '',
	clAmount: '',
	howOftenOrder: '',
	orderFromNana: '',
	applyForCL: '',
	reason: '',
	isCLIncrease: false,
};

const IncreaseCreditLineReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_INCREASE_CREDIT_LINE_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.ON_RESET_INCREASE_CREDIT_LINE:
			return initialState;
		case ActionTypes.GET_CREDIT_LINE_INFO_SUCCESS:
			return {
				...state,
				success: true,
				vatCertificateNumber: action.payload.vat_certificate_number,
				error: false,
				errorCode: '',
				loader: false,
				clInfoData: action.payload,
				isCLIncrease: false,
			};
		case ActionTypes.GET_CREDIT_LINE_INFO_LOADER:
		case ActionTypes.INCREASE_CREDIT_LINE_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCLIncrease: false,
			};
		case ActionTypes.GET_CREDIT_LINE_INFO_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCLIncrease: false,
			};
		case ActionTypes.INCREASE_CREDIT_LINE_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCLIncrease: true,
			};
		case ActionTypes.INCREASE_CREDIT_LINE_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCLIncrease: true,
			};
		default:
			return { ...state };
	}
};

export default IncreaseCreditLineReducer;
