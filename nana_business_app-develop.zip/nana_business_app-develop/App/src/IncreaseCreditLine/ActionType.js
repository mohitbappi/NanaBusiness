export const ON_CHANGE_INCREASE_CREDIT_LINE_TEXT = 'on_change_increase_credit_line_text';
export const ON_RESET_INCREASE_CREDIT_LINE = 'on_reset_increase_credit_line';

export const INCREASE_CREDIT_LINE_SUCCESS = 'increase_credit_line_success';
export const INCREASE_CREDIT_LINE_LOADER = 'increase_credit_line_loader';
export const INCREASE_CREDIT_LINE_FAILURE = 'increase_credit_line_failure';

export const GET_CREDIT_LINE_INFO_SUCCESS = 'get_credit_line_info_success';
export const GET_CREDIT_LINE_INFO_LOADER = 'get_credit_line_info_loader';
export const GET_CREDIT_LINE_INFO_FAILURE = 'get_credit_line_info_failure';
