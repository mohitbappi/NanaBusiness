import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		cardView: {
			marginHorizontal: normalScale(16),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		containerStyle: {
			justifyContent: 'flex-start',
			paddingTop: verticalScale(35),
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		searchContainer: {
			marginBottom: verticalScale(4),
			marginHorizontal: normalScale(16),
		},
		noData: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		scrollViewStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
