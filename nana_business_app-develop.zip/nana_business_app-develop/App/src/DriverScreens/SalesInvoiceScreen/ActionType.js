export const GET_SALES_INVOICE_LISTING_FAILURE = 'get_sales_invoice_listing_failure';
export const GET_SALES_INVOICE_LISTING_SUCCESS = 'get_sales_invoice_listing_success';
export const GET_SALES_INVOICE_LISTING_LOADER = 'get_sales_invoice_listing_loader';

/** action types for templates */
export const GET_TEMPLATES_SUCCESS = 'get_templates_success';
export const GET_TEMPLATES_FAILURE = 'get_templates_failure';
export const GET_TEMPLATES_LOADER = 'get_templates_loader';

/** action types for download invoice */
export const DOWNLOAD_INVOICE_SUCCESS = 'download_invoice_success';
export const DOWNLOAD_INVOICE_FAILURE = 'download_invoice_failure';
export const DOWNLOAD_INVOICE_LOADER = 'download_invoice_loader';
