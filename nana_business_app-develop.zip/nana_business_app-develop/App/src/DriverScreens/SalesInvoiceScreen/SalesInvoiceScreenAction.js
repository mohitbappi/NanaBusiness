import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import GetSalesInvoiceService from '@SalesInvoice/GetSalesInvoiceService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetTemplatesService from '@SalesInvoice/GetTemplatesService';
import DownloadInvoiceService from '@SalesInvoice/DownloadInvoiceService';
import * as ActionTypes from './ActionType';

/**
 * Action to get the sales invoices list.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetSalesInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_SALES_INVOICE_LISTING_SUCCESS,
		ActionTypes.GET_SALES_INVOICE_LISTING_FAILURE,
		ActionTypes.GET_SALES_INVOICE_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getSalesInvoiceService = new GetSalesInvoiceService(dispatchedActions);
	addBasicInterceptors(getSalesInvoiceService);
	getSalesInvoiceService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getSalesInvoiceService.makeRequest(props));
};

export const onGetTemplates = () => dispatch => {
	// Action to get the templates.
	const dispatchedActions = actions(
		ActionTypes.GET_TEMPLATES_SUCCESS,
		ActionTypes.GET_TEMPLATES_FAILURE,
		ActionTypes.GET_TEMPLATES_LOADER,
	);
	const getTemplatesService = new GetTemplatesService(dispatchedActions);
	addBasicInterceptors(getTemplatesService);
	getTemplatesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getTemplatesService.makeRequest());
};

/**
 * Action to download the template in the given language.
 * @param {object} props
 * @returns
 */
export const onDownloadTemplate = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.DOWNLOAD_INVOICE_SUCCESS,
		ActionTypes.DOWNLOAD_INVOICE_FAILURE,
		ActionTypes.DOWNLOAD_INVOICE_LOADER,
	);
	const downloadInvoiceService = new DownloadInvoiceService(dispatchedActions);
	addBasicInterceptors(downloadInvoiceService);
	downloadInvoiceService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(downloadInvoiceService.makeRequest(props));
};
