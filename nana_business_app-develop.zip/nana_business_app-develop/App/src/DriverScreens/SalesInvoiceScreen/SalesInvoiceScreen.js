// import libraries
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Search from '@Search/Search';
import DriverAppInvoiceCardComponent from '@DriverAppInvoiceCardComponent/DriverAppInvoiceCardComponent';
import Loader from '@Loader/Loader';
import OptionPicker from '@OptionPicker/OptionPicker';
import ListEmpty from '@ListEmpty/ListEmpty';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';

// import constants
import { keyConstants } from '@Constants/KeyConstants';
import { fetchDataWithPagination, fullRefund, partialRefund } from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import utils
import { localeString } from '@Localization/index';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDate } from '@Util/GetFormattedDate';
import driverNavigations from '@routes/driverNavigations';

// import actions
import * as ShipmentScreenActions from '@ShipmentScreen/ShipmentScreenAction';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as SalesInvoiceActions from './SalesInvoiceScreenAction';

// import styles
import { createStyleSheet } from './SalesInvoiceScreenStyle';

class SalesInvoiceScreen extends Component {
	constructor(props) {
		super(props);
		this.languageRef = React.createRef(null);
		this.templateRef = React.createRef(null);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			searchText: '',
			isPickerVisible: false,
			activePickerIndex: 0, // By default search will work for sales invoice id
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.page = fetchDataWithPagination.page;
			this.setState({ searchText: '' }, () => {
				this.onGetNotificationCount();
				this.onFetchData(false);
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { salesInvoiceInfo, pullToRefreshActions } = this.props;
		const { success } = salesInvoiceInfo;
		if (success && prevProps.salesInvoiceInfo.success !== salesInvoiceInfo.success) {
			// Will hide the bottom loader.
			this.setState({ bottomLoader: false });
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onFetchData = isOverwriteExistingList => {
		// API call to fetch the sales invoices list.
		const { salesInvoiceActions } = this.props;
		const { searchText, activePickerIndex } = this.state;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			if (activePickerIndex) {
				queryParams.customer_name = searchText;
			} else {
				queryParams.invoice_id = searchText;
			}
		}
		salesInvoiceActions.onGetSalesInvoices(queryParams, isOverwriteExistingList);
	};

	// API call to get the notification count.
	onGetNotificationCount = () => {
		const { shipmentScreenActions } = this.props;
		shipmentScreenActions.onGetNotificationCount();
	};

	handlePicker = value => this.setState({ isPickerVisible: value });

	onSelectOptionPicker = index => {
		this.setState({ activePickerIndex: index }, () => this.handlePicker(false));
	};

	renderItem = ({ item }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (item.type === fullRefund || item.type === partialRefund) {
			return null;
		}
		const shipmentId = item.shipment_delivery_id ? `(${item.shipment_delivery_id})` : '';
		return (
			<View style={styles.cardView}>
				<DriverAppInvoiceCardComponent
					name={`${item.customer_name} ${shipmentId}`}
					amount={`${currencyFormatter(
						getValueInDecimal(item.total_amount),
					)} ${localeString(keyConstants.SAR)}`}
					isDisable={false}
					date={`${localeString(keyConstants.CREATED_AT)}: ${getFormattedDate(
						item.created_at,
					)}`}
					onPress={() =>
						this.getInvoiceDetail(
							item.id,
							currencyFormatter(getValueInDecimal(item.total_amount)),
							item.customer_name,
						)
					}
				/>
			</View>
		);
	};

	keyExtractor = (item, index) => index.toString();

	getInvoiceDetail = (id, amount, organization) => {
		// Will navigate to the sales invoice detail screen.
		const { navigation } = this.props;
		navigation.navigate(driverNavigations.SALES_INVOICE_DETAIL_NAVIGATION, {
			id,
			amount,
			organization,
			isSalesInvoice: true,
			isPurchase: true,
		});
	};

	onSearch = text => {
		// API call to search the invoice using invoice id.
		this.page = fetchDataWithPagination.page;
		this.setState({ searchText: text }, () => this.onFetchData(false));
	};

	listFooterComponent = () => {
		const { languageInfo, salesInvoiceInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { invoiceListing, count } = salesInvoiceInfo;
		const endReached = count === invoiceListing.length || count < invoiceListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return <Text style={styles.noData}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>;
	};

	onEndReached = () => {
		const { salesInvoiceInfo } = this.props;
		const { loader } = salesInvoiceInfo;
		if (!loader) {
			this.setState({ bottomLoader: true });
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onRefresh = () => {
		// API calls while pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onGetNotificationCount();
		this.onFetchData(false);
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { shipmentScreenInfo, navigation } = this.props;
		const { notificationCount } = shipmentScreenInfo;
		navigation.navigate(driverNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	render() {
		const { bottomLoader, searchText, isPickerVisible, activePickerIndex } = this.state;
		const { shipmentScreenInfo, languageInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, invoiceListing, count, isTemplate } = languageInfo;
		const { notificationCount } = shipmentScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader &&
					!isFetchingForPullToRefresh &&
					!isTemplate &&
					!bottomLoader &&
					searchText === '' && <Loader size="large" />}
				<OptionPicker
					isVisible={isPickerVisible}
					options={[
						{ name: localeString(keyConstants.SALES_INVOICE_ID) },
						{ name: localeString(keyConstants.CUSTOMER_NAME) },
					]}
					title={localeString(keyConstants.SEARCH)}
					isRTL={isRTL}
					onClose={() => this.handlePicker(false)}
					onSelectOption={this.onSelectOptionPicker}
					activeIndex={activePickerIndex}
				/>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.PURCHASE_INVOICES)}
						hasIconSales
						hasIconNotification
						onPressNotification={this.onPressNotification}
						notificationCount={notificationCount}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasIconFilter
						placeholder={localeString(keyConstants.SEARCH_BY_NAME_OR_SALES_INVOICE_ID)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
						onPressFilter={() => this.handlePicker(true)}
					/>
				</View>
				<FlatListComponent
					keyboardShouldPersistTaps="handled"
					data={invoiceListing}
					renderItem={this.renderItem}
					keyExtractor={this.keyExtractor}
					showsVerticalScrollIndicator={false}
					onEndReached={() => invoiceListing.length !== count && this.onEndReached()}
					ListFooterComponent={
						invoiceListing.length !== 0 &&
						count > fetchDataWithPagination.limit &&
						this.listFooterComponent()
					}
					onEndReachedThreshold={0.5}
					ListEmptyComponent={() => (
						<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
					)}
					contentContainerStyle={
						invoiceListing.length === 0 ? styles.scrollViewStyle : null
					}
					onRefresh={this.onRefresh}
					componentType={constants.flatList}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		salesInvoiceInfo: state.SalesInvoiceScreenReducer,
		shipmentScreenInfo: state.ShipmentScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		salesInvoiceActions: bindActionCreators({ ...SalesInvoiceActions }, dispatch),
		shipmentScreenActions: bindActionCreators({ ...ShipmentScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

SalesInvoiceScreen.propTypes = {
	salesInvoiceInfo: PropTypes.object.isRequired,
	shipmentScreenInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	salesInvoiceActions: PropTypes.object.isRequired,
	shipmentScreenActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SalesInvoiceScreen);
