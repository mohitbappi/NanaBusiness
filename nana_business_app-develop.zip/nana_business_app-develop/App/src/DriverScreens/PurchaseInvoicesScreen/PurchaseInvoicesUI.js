// import libraries
import React, { Component } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Search from '@Search/Search';
import DriverAppInvoiceCardComponent from '@DriverAppInvoiceCardComponent/DriverAppInvoiceCardComponent';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import IconFilter from 'App/src/Widgets/IconFilter/IconFilter';

// import utils
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDate } from '@Util/GetFormattedDate';
import { removeSpaces } from '@Util/GetFormattedString';
import { verticalScale } from '@device/normalize';

// import constants
import { constants } from '@RefreshControlComponent/Constants';
import { keyConstants } from '@Constants/KeyConstants';
import { fetchDataWithPagination, purchaseReturnInvoiceStatus } from '@Constants/Constants';
import { localeString } from '@Localization/index';

// import styles
import { createStyleSheet } from './PurchaseInvoicesStyle';

class PurchaseInvoicesUI extends Component {
	renderItem = ({ item, index }) => {
		const { isRTL, onDownloadInvoice, getInvoiceDetail } = this.props;
		const styles = createStyleSheet(isRTL);
		const {
			id,
			vendor_name,
			vendor_name_ar,
			total_amount,
			created_at,
			acceptance_status,
			invoice_url,
			invoice_url_ar,
			pickup_task_id, // Tookan pick up id
		} = item;
		const vendorOrganizationName = isRTL ? vendor_name_ar : vendor_name;
		// Will store the file name by replacing space with -.
		const downloadFileName = `${removeSpaces(vendorOrganizationName)}-${id}`;
		return (
			<View style={styles.cardView}>
				<DriverAppInvoiceCardComponent
					name={`${vendorOrganizationName} (${id})`}
					amount={`${currencyFormatter(getValueInDecimal(total_amount))} ${localeString(
						keyConstants.SAR,
					)}`}
					isDisable={false} // Boolean to disable the click on cards.
					date={`${localeString(keyConstants.ASSIGNED)}: ${getFormattedDate(created_at)}`}
					hasHyperlink // Boolean to show hyperlink
					hyperlinkTitle={localeString(keyConstants.DOWNLOAD)}
					onPressHyperlink={() =>
						onDownloadInvoice(isRTL ? invoice_url_ar : invoice_url, downloadFileName)
					}
					isShowStatus // Boolean to show status of purchase invoice.
					status={this.getPurchaseInvoiceStatus(acceptance_status).name}
					statusStyle={this.getPurchaseInvoiceStatus(acceptance_status).style}
					onPress={() => getInvoiceDetail(item, downloadFileName, index)}
					idText={`${localeString(keyConstants.TOOKAN_ID)}: ${pickup_task_id}`}
				/>
			</View>
		);
	};

	keyExtractor = (item, index) => index.toString();

	getPurchaseInvoiceStatus = status => {
		// Will return name and style according to status.
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		const purchaseInvoiceStatus = {
			[`${purchaseReturnInvoiceStatus.pending}`]: {
				name: localeString(keyConstants.PENDING),
				style: styles.pendingStatus,
			},
			[`${purchaseReturnInvoiceStatus.approved}`]: {
				name: localeString(keyConstants.APPROVED),
				style: styles.approvedStatus,
			},
			[`${purchaseReturnInvoiceStatus.rejected}`]: {
				name: localeString(keyConstants.REJECTED),
				style: styles.cancelledStatus,
			},
			default: {
				name: localeString(keyConstants.ASSIGNED),
				style: styles.assignedStatus,
			},
		};
		if (status) {
			// If status exists
			return purchaseInvoiceStatus[status];
		}
		return purchaseInvoiceStatus.default; // If status is null
	};

	listFooterComponent = () => {
		const { isRTL, purchaseInvoicesListing, purchaseInvoicesCount } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached =
			purchaseInvoicesCount === purchaseInvoicesListing.length ||
			purchaseInvoicesCount < purchaseInvoicesListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return <Text style={styles.noData}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>;
	};

	getLayout = (data, index) => ({
		// To Get length and offset for Scroll To Index Functionality
		length: verticalScale(70),
		offset: verticalScale(70) * index,
		index,
	});

	optionsAvailable = () => {
		return [
			{ name: localeString(keyConstants.ALL) },
			{ name: localeString(keyConstants.ASSIGNED) },
			{ name: localeString(keyConstants.PENDING) },
			{ name: localeString(keyConstants.APPROVED) },
			{ name: localeString(keyConstants.REJECTED) },
		];
	};

	render() {
		const {
			isRTL,
			searchText,
			loader,
			notificationCount,
			onSearch,
			purchaseInvoicesListing,
			purchaseInvoicesCount,
			onPullToRefresh,
			onEndReached,
			onPressNotification,
			isShowToast,
			toastMessage,
			error,
			errorCode,
			onRefresh,
			forwardedRef,
			handlePicker,
			onSelectOption,
			isPickerVisible,
			activePickerIndex,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<OptionPicker
					isVisible={isPickerVisible}
					options={this.optionsAvailable()}
					title={localeString(keyConstants.STATUS)}
					isRTL={isRTL}
					onClose={() => handlePicker(false)}
					onSelectOption={onSelectOption}
					activeIndex={activePickerIndex}
				/>
				<View style={styles.header}>
					<Header
						text={localeString(keyConstants.PURCHASE_INVOICES)}
						hasIconInvoices
						hasIconNotification
						onPressNotification={onPressNotification}
						notificationCount={notificationCount}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasSearchIcon
						placeholder={localeString(keyConstants.SEARCH_BY_PURCHASE_INV_VID)}
						onChangeText={onSearch}
						value={searchText}
					/>
				</View>
				<IconFilter
					onPress={() => handlePicker(true)}
					activePickerIndex={activePickerIndex}
				/>
				{error ? (
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<FlatListComponent
						keyboardShouldPersistTaps="handled"
						data={purchaseInvoicesListing}
						renderItem={this.renderItem}
						keyExtractor={this.keyExtractor}
						showsVerticalScrollIndicator={false}
						onEndReached={() =>
							purchaseInvoicesListing.length !== purchaseInvoicesCount &&
							onEndReached()
						}
						ListFooterComponent={
							purchaseInvoicesListing.length !== 0 &&
							purchaseInvoicesCount > fetchDataWithPagination.limit &&
							this.listFooterComponent()
						}
						onEndReachedThreshold={0.5}
						ListEmptyComponent={() => (
							<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
						)}
						contentContainerStyle={
							purchaseInvoicesListing.length === 0 ? styles.scrollViewStyle : null
						}
						onRefresh={onPullToRefresh}
						componentType={constants.flatList}
						onRef={forwardedRef}
						getItemLayout={this.getLayout}
					/>
				)}
				<ToastComponent
					isRTL={isRTL}
					isApiError={isShowToast}
					toastMessage={toastMessage}
				/>
			</View>
		);
	}
}

PurchaseInvoicesUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onPullToRefresh: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	onDownloadInvoice: PropTypes.func.isRequired,
	isShowToast: PropTypes.bool.isRequired,
	error: PropTypes.bool.isRequired,
	onSearch: PropTypes.func.isRequired,
	purchaseInvoicesCount: PropTypes.element.isRequired,
	notificationCount: PropTypes.element.isRequired,
	onRefresh: PropTypes.func.isRequired,
	purchaseInvoicesListing: PropTypes.array.isRequired,
	searchText: PropTypes.string.isRequired,
	toastMessage: PropTypes.string.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onPressNotification: PropTypes.func.isRequired,
	getInvoiceDetail: PropTypes.object.isRequired,
	errorCode: PropTypes.object.isRequired,
	forwardedRef: PropTypes.object.isRequired,
	handlePicker: PropTypes.func.isRequired,
	onSelectOption: PropTypes.func.isRequired,
	isPickerVisible: PropTypes.bool.isRequired,
	activePickerIndex: PropTypes.number.isRequired,
};

export default PurchaseInvoicesUI;
