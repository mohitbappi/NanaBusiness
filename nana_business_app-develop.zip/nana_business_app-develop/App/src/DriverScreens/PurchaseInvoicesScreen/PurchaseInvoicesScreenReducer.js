import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	purchaseInvoicesListing: [],
	count: 0,
};

const PurchaseInvoicesScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_PURCHASE_INVOICES_LISTING_SUCCESS: {
			// Action will call if api call succeed.
			const appendToExistingList = action.extra; // boolean to append data in the existing list.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				purchaseInvoicesListing: appendToExistingList
					? [...state.purchaseInvoicesListing, ...action.payload.rows]
					: action.payload.rows,
				count: action.payload.count, // count of the purchase invoices list
			};
		}
		case ActionTypes.GET_PURCHASE_INVOICES_LISTING_LOADER:
			// Action will call if api calling is in progress.
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_PURCHASE_INVOICES_LISTING_FAILURE:
			// Action will call if api calling is failed.
			return {
				...state,
				error: true,
				errorCode: action.payload, // Will store error reason
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default PurchaseInvoicesScreenReducer;
