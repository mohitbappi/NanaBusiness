// import libraries
import React, { Component } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PropTypes from 'prop-types';

// import constants
import {
	fetchDataWithPagination,
	toastShowTime,
	userDetails,
	filterPurchaseInvoice,
} from '@Constants/Constants';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

// import utils
import { downloadFile } from '@Util/DownloadFile';
import driverNavigations from '@routes/driverNavigations';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';

// import components
import PurchaseInvoicesUI from './PurchaseInvoicesUI';

class PurchaseInvoicesComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			searchText: '',
			isShowToast: false,
			toastMessage: '',
			isPickerVisible: false,
			activePickerIndex: 0,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.onStoreUserDetails();
		this.willFocusListener = navigation.addListener('focus', () => {
			const { pullToRefreshActions, refreshControlComponentInfo } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.page = fetchDataWithPagination.page; // resetting the page to 1
			this.limit = getScrollingIndex(scrollIndex);
			this.setState(
				{
					searchText: '',
				},
				() => {
					this.onGetNotificationCount();
					this.onFetchData(false);
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false); // Will hide the pull to refresh loader
		});

		this.willFocusListener = navigation.addListener('blur', () => {
			this.resetScrollIndex();
		});
	}

	componentDidUpdate(prevProps) {
		const { purchaseInvoicesInfo, pullToRefreshActions } = this.props;
		const { success } = purchaseInvoicesInfo;
		if (success && prevProps.purchaseInvoicesInfo.success !== success) {
			// Will hide the bottom loader if pagination occurs and pull to refresh loader.
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.page === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	onStoreUserDetails = async () => {
		const { shipmentScreenActions } = this.props;
		const userDetail = await AsyncStorage.getItem(userDetails);
		shipmentScreenActions.onStoreUserDetails(JSON.parse(userDetail));
	};

	onFetchData = appendToExistingList => {
		// Will call the API to fetch the purchase invoices listing.
		const { purchaseInvoicesActions } = this.props;
		const { searchText, activePickerIndex } = this.state;
		const queryParams = {};
		const activeSort = [
			filterPurchaseInvoice.assigned,
			filterPurchaseInvoice.pending,
			filterPurchaseInvoice.approved,
			filterPurchaseInvoice.rejected,
		];
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		// will call API using filter
		if (activePickerIndex > 0) {
			queryParams.status = activeSort[activePickerIndex - 1];
		}
		if (searchText) {
			// Will call API using search value if user enters it.
			queryParams.filter = searchText;
		}
		purchaseInvoicesActions.onGetPurchaseInvoices(queryParams, appendToExistingList);
	};

	onGetNotificationCount = () => {
		// Will call API to get the notificaiton count.
		const { shipmentScreenActions } = this.props;
		shipmentScreenActions.onGetNotificationCount();
	};

	// will show or disable filter modal
	handlePicker = value => {
		this.setState({
			isPickerVisible: value,
		});
	};

	// will set the filter
	onSelectOption = index => {
		this.setState(
			{
				activePickerIndex: index,
			},
			() => {
				this.page = fetchDataWithPagination.page; // resetting the page to 1
				this.handlePicker(false);
				this.onFetchData();
			},
		);
	};

	onSearch = text => {
		// Will set the search value and call the API.
		this.page = fetchDataWithPagination.page; // resetting the page to 1
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onFetchData(false);
			},
		);
	};

	onEndReached = () => {
		// Will call the API for the next page with limit 10.
		const { purchaseInvoicesInfo } = this.props;
		const { loader } = purchaseInvoicesInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onFetchData(true);
		}
	};

	onRefresh = () => {
		// Will call the API's if user do the PTR.
		this.page = fetchDataWithPagination.page; // resetting the page to 1
		this.limit = fetchDataWithPagination.limit;
		this.resetScrollIndex();
		this.onGetNotificationCount();
		this.onFetchData(false);
	};

	onPressNotification = notificationCount => {
		// Will navigate to the notification screen.
		const { navigation } = this.props;
		navigation.navigate(driverNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	onDownloadInvoice = (downloadUrl, downloadFileName) => {
		// Will download the purchase invoice by passing the url and the name.
		downloadFile(
			downloadUrl,
			downloadFileName,
			() => {
				// If downloading is in progress.
				this.onShowFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
			},
			() => {
				// If downloading succeed.
				this.onShowFileStatus(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
			},
			() => {
				// If downloading is failed.
				this.onShowFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
			},
		);
	};

	onShowFileStatus = message => {
		// Will show downloading status of purchase invoice.
		this.setState({
			toastMessage: message,
			isShowToast: true,
		});
		setTimeout(() => {
			this.setState({
				isShowToast: false,
			});
		}, toastShowTime);
	};

	getInvoiceDetail = (item, downloadFileName, index) => {
		// Will navigate to the purchase invoice detail.
		const { languageInfo, navigation } = this.props;
		const { isRTL } = languageInfo;
		const {
			id,
			invoice_url,
			invoice_url_ar,
			acceptance_status,
			purchase_invoice_return_id,
		} = item;
		navigation.navigate(driverNavigations.SALES_INVOICE_DETAIL_NAVIGATION, {
			id,
			index,
			downloadUrl: isRTL ? invoice_url_ar : invoice_url,
			downloadFileName,
			status: acceptance_status,
			acceptanceRequestId: purchase_invoice_return_id,
			isPurchase: true,
		});
	};

	render() {
		const {
			languageInfo,
			shipmentScreenInfo,
			refreshControlComponentInfo,
			purchaseInvoicesInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const {
			searchText,
			bottomLoader,
			isShowToast,
			toastMessage,
			isPickerVisible,
			activePickerIndex,
		} = this.state;
		const { loader, purchaseInvoicesListing, count, error, errorCode } = purchaseInvoicesInfo;
		const { notificationCount } = shipmentScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<PurchaseInvoicesUI
				isRTL={isRTL}
				searchText={searchText}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				notificationCount={notificationCount}
				onSearch={this.onSearch} // prop to search invoice using purchase invoice id & vendor name.
				purchaseInvoicesListing={purchaseInvoicesListing}
				purchaseInvoicesCount={count}
				handlePicker={this.handlePicker}
				isPickerVisible={isPickerVisible}
				activePickerIndex={activePickerIndex}
				onSelectOption={this.onSelectOption}
				onPullToRefresh={this.onRefresh} // prop to do the PTR
				onEndReached={this.onEndReached} // prop for the pagination
				onPressNotification={() => this.onPressNotification(notificationCount)}
				onDownloadInvoice={this.onDownloadInvoice} // prop to download the purchase invoice
				getInvoiceDetail={this.getInvoiceDetail}
				isShowToast={isShowToast}
				toastMessage={toastMessage}
				error={error}
				errorCode={errorCode}
				onRefresh={this.onRefresh}
				forwardedRef={ref => {
					this.itemListRef = ref;
				}}
			/>
		);
	}
}

PurchaseInvoicesComponent.propTypes = {
	purchaseInvoicesInfo: PropTypes.object.isRequired,
	purchaseInvoicesActions: PropTypes.object.isRequired,
	customProps: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	shipmentScreenActions: PropTypes.object.isRequired,
	shipmentScreenInfo: PropTypes.object.isRequired,
};

export default PurchaseInvoicesComponent;
