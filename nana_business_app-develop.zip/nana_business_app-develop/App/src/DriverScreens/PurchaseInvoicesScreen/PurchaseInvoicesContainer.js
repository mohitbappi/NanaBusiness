// import libraries
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as ShipmentScreenActions from '@ShipmentScreen/ShipmentScreenAction';
import * as PurchaseInvoicesActions from './PurchaseInvoicesScreenAction';

// import components
import PurchaseInvoicesComponent from './PurchaseInvoicesComponent';

const PurchaseInvoicesContainer = props => {
	const customProps = { ...props }; // Will store all the props like navigation, reducer state and actions.
	return <PurchaseInvoicesComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer, // Language screen reducer
		purchaseInvoicesInfo: state.PurchaseInvoicesScreenReducer, // Purchase invoices screen reducer
		shipmentScreenInfo: state.ShipmentScreenReducer, // Shipment screen reducer
		refreshControlComponentInfo: state.RefreshControlComponentReducer, // Pull to refresh screen reducer
	};
};

const mapDispatchToProps = dispatch => {
	return {
		purchaseInvoicesActions: bindActionCreators({ ...PurchaseInvoicesActions }, dispatch), // Purchase invoices actions
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch), // Pull to refresh actions
		shipmentScreenActions: bindActionCreators({ ...ShipmentScreenActions }, dispatch), // Shipment actions
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(PurchaseInvoicesContainer);
