import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetPurchaseInvoicesService from '@PurchaseInvoices/GetPurchaseInvoicesService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Function to call API for fetchin the list of purchase invoices.
 * @param {object} props
 * @param {boolean} appendToExistingList
 * @returns
 */

export const onGetPurchaseInvoices = (props, appendToExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_PURCHASE_INVOICES_LISTING_SUCCESS,
		ActionTypes.GET_PURCHASE_INVOICES_LISTING_FAILURE,
		ActionTypes.GET_PURCHASE_INVOICES_LISTING_LOADER,
	)
		.addSuccessExtra(appendToExistingList)
		.build();
	const getPurchaseInvoicesService = new GetPurchaseInvoicesService(dispatchedActions);
	addBasicInterceptors(getPurchaseInvoicesService);
	getPurchaseInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPurchaseInvoicesService.makeRequest(props));
};

export default onGetPurchaseInvoices;
