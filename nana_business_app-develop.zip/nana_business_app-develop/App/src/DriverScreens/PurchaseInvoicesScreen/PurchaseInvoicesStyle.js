import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		cardView: {
			marginHorizontal: normalScale(16),
		},
		pendingStatus: {
			color: colors.darkOrange,
		},
		approvedStatus: {
			color: colors.darkBlue,
		},
		cancelledStatus: {
			color: colors.lightRed,
		},
		assignedStatus: {
			color: colors.black,
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		searchContainer: {
			marginBottom: verticalScale(4),
			marginHorizontal: normalScale(16),
		},
		scrollViewStyle: {
			flex: 1,
		},
		noData: {
			alignSelf: 'center',
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			color: colors.lightWhite,
			marginBottom: verticalScale(10),
			marginTop: verticalScale(5),
		},
	});
};

export default createStyleSheet;
