// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import utils
import { downloadFile } from '@Util/DownloadFile';
import { localeString } from '@assets/Localization';

// import constants
import { toastShowTime, purchaseInvoiceSummaryDoc } from '@Constants/Constants';
import driverNavigations from '@routes/driverNavigations';
import { keyConstants } from '@Constants/KeyConstants';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';

// import components
import PurchaseInvoiceSummaryUI from './PurchaseInvoiceSummaryUI';

class PurchaseInvoiceSummaryComponent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isShowToast: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.getSummary();
		});
	}

	componentDidUpdate(prevProps) {
		const {
			purchaseInvoiceSummaryInfo,
			navigation,
			purchaseInvoiceSummaryActions,
		} = this.props;
		const { success, isUploadInvoice, error, errorCode } = purchaseInvoiceSummaryInfo;
		if (
			success &&
			isUploadInvoice &&
			prevProps.purchaseInvoiceSummaryInfo.success !== purchaseInvoiceSummaryInfo.success
		) {
			// After getting API success it will navigate to purchase invoice acceptance screen and reset the purchase invoice summary reducer.
			navigation.navigate(driverNavigations.PURCHASE_INVOICE_ACCEPTANCE_NAVIGATION, {
				isFullyAccepted: false,
			});
			purchaseInvoiceSummaryActions.onResetInvoiceSummaryState();
		}
		if (
			error &&
			isUploadInvoice &&
			prevProps.purchaseInvoiceSummaryInfo.error !== purchaseInvoiceSummaryInfo.error
		) {
			ErrorAlertComponent(errorCode, this.onUploadInvoice);
		}
	}

	getSummary = () => {
		// API call to get the purchase invoice summary.
		const { purchaseInvoiceSummaryActions } = this.props;
		const { route } = this.props;
		const { acceptanceRequestId } = route.params || {};
		const queryParams = {
			id: acceptanceRequestId,
		};
		purchaseInvoiceSummaryActions.getPurchaseInvoiceSummary(queryParams);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onPressDownload = downloadUrl => {
		// Will downalod the purchase invoice summary.
		downloadFile(
			downloadUrl,
			purchaseInvoiceSummaryDoc,
			() => {
				// If downloading is in progress.
				this.onShowSummaryFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
			},
			() => {
				// If downloading succeed.
				this.onShowSummaryFileStatus(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
			},
			() => {
				// If downloading is failed.
				this.onShowSummaryFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
			},
		);
	};

	onShowSummaryFileStatus = message => {
		// Will show downloading status of purchase invoice summary.
		this.setState({
			toastMessage: message,
			isShowToast: true,
		});
		setTimeout(() => {
			this.setState({
				isShowToast: false,
			});
		}, toastShowTime);
	};

	onUploadInvoice = () => {
		// API to create acceptance request while uploading purchase invoice.
		const { route, imageInputComponentInfo, purchaseInvoiceSummaryActions } = this.props;
		const { acceptanceRequestId } = route.params || {};
		const { image: imageUrl } = imageInputComponentInfo;
		const queryParams = {};
		queryParams.id = acceptanceRequestId;
		queryParams.body = {
			image_url: imageUrl,
		};
		purchaseInvoiceSummaryActions.onUploadPurchaseInvoice(queryParams);
	};

	getTotalUnavailableItems = purchaseInvoiceSummary => {
		// This function add up total number of items unavailable.
		return purchaseInvoiceSummary.reduce((accumulator, item) => accumulator + item.quantity, 0);
	};

	getTotalCostOfAllUnavailableItems = purchaseInvoiceSummary => {
		// This function add up cost of all unavailable items.
		return purchaseInvoiceSummary.reduce(
			(accumulator, item) => accumulator + (item.price + item.vat_amount) * item.quantity,
			0,
		);
	};

	render() {
		const {
			languageInfo,
			imageInputComponentInfo,
			purchaseInvoiceSummaryInfo,
			route,
		} = this.props;
		const { isRTL } = languageInfo;
		const { image: imageUrl } = imageInputComponentInfo;
		const { isShowToast, toastMessage } = this.state;
		const {
			loader,
			purchaseInvoiceSummary,
			isUploadInvoice,
			purchaseInvoiceSummaryEnglishUrl,
			purchaseInvoiceSummaryArabicUrl,
			error,
			errorCode,
		} = purchaseInvoiceSummaryInfo;
		const { isSubmitButtonEnable } = route.params || {};
		const totalUnavailableItems = this.getTotalUnavailableItems(purchaseInvoiceSummary);
		const totalCost = this.getTotalCostOfAllUnavailableItems(purchaseInvoiceSummary);
		return (
			<PurchaseInvoiceSummaryUI
				isRTL={isRTL}
				purchaseInvoiceSummary={purchaseInvoiceSummary}
				loader={loader && !isUploadInvoice}
				spinner={loader && isUploadInvoice}
				onPressBack={this.onGoBack}
				onPressDownload={() =>
					this.onPressDownload(
						isRTL ? purchaseInvoiceSummaryArabicUrl : purchaseInvoiceSummaryEnglishUrl,
					)
				} // Function to download the purchase invoice summary.
				totalUnavailableItems={totalUnavailableItems}
				totalCostOfUnavailableItems={totalCost}
				onUploadInvoice={this.onUploadInvoice}
				isSubmitButtonEnable={isSubmitButtonEnable}
				imageUrl={imageUrl}
				isShowToast={isShowToast}
				toastMessage={toastMessage}
				error={error && !isUploadInvoice}
				errorCode={errorCode}
				onRefresh={this.getSummary}
			/>
		);
	}
}

PurchaseInvoiceSummaryComponent.propTypes = {
	purchaseInvoiceSummaryInfo: PropTypes.object.isRequired,
	purchaseInvoiceSummaryActions: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	imageInputComponentInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default PurchaseInvoiceSummaryComponent;
