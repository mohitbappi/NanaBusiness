import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	isUploadInvoice: false,
	purchaseInvoiceSummary: [],
	purchaseInvoiceSummaryEnglishUrl: '',
	purchaseInvoiceSummaryArabicUrl: '',
};

const PurchaseInvoiceSummaryScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_PURCHASE_INVOICE_SUMMARY_SUCCESS:
			// API call to fetch the summary of the purchase invoice.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isUploadInvoice: false,
				purchaseInvoiceSummary: action.payload.rows,
				purchaseInvoiceSummaryEnglishUrl: action.payload.summary_doc_url,
				purchaseInvoiceSummaryArabicUrl: action.payload.summary_doc_url_ar,
			};
		case ActionTypes.GET_PURCHASE_INVOICE_SUMMARY_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
				isUploadInvoice: false,
			};
		case ActionTypes.GET_PURCHASE_INVOICE_SUMMARY_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				isUploadInvoice: false,
			};
		case ActionTypes.UPLOAD_PURCHASE_INVOICE_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				isUploadInvoice: true,
			};
		case ActionTypes.UPLOAD_PURCHASE_INVOICE_SUCCESS:
			// API call to upload the purchase invoice.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isUploadInvoice: true,
			};
		case ActionTypes.UPLOAD_PURCHASE_INVOICE_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
				isUploadInvoice: true,
			};
		case ActionTypes.RESET_PURCHASE_INVOICE_SUMMARY_STATE:
			return initialState;
		default:
			return state;
	}
};

export default PurchaseInvoiceSummaryScreenReducer;
