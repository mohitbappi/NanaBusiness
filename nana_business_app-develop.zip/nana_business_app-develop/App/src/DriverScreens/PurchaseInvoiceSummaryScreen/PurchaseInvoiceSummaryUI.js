// import libraries
import React, { Component } from 'react';
import { FlatList, Text, View } from 'react-native';
import PropTypes from 'prop-types';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { invoiceImg } from '@Constants/Constants';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

// import components
import Header from '@Header/Header';
import ImageInputComponent from '@ImageInputComponent/ImageInputComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Loader from '@Loader/Loader';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import UnavailableItem from './UnavailableItem';

// import styles
import { createStyleSheet } from './PurchaseInvoiceSummaryScreenStyle';

class PurchaseInvoiceSummaryUI extends Component {
	renderItem = ({ item }) => {
		const { isRTL } = this.props;
		return (
			<UnavailableItem // Component to show the list of the unavailable items.
				item={item}
				isRTL={isRTL}
			/>
		);
	};

	keyExtractor = (item, index) => {
		return index;
	};

	render() {
		const {
			isRTL,
			loader,
			spinner,
			onPressBack,
			onPressDownload,
			purchaseInvoiceSummary, // Array of all the unavailable items.
			totalUnavailableItems,
			totalCostOfUnavailableItems,
			onUploadInvoice,
			isSubmitButtonEnable,
			imageUrl,
			isShowToast,
			toastMessage,
			error,
			errorCode,
			onRefresh,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				{spinner && <Spinner size="large" />}
				<Header
					text={localeString(keyConstants.SUMMARY)}
					hasIconBack
					onPressBack={onPressBack}
					hasIconDownload
					onPressDownload={onPressDownload}
				/>
				{error ? (
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.imageInputContainer}>
							<ImageInputComponent
								label={`${localeString(
									keyConstants.UPLOAD_PURCHASE_RETURN_INVOICE,
								)}*`}
								placeholder={localeString(keyConstants.UPLOAD_INVOICE_IMAGE)}
								isRTL={isRTL}
								selectedImageTitle={invoiceImg}
							/>
						</View>
						<View style={styles.listHeadingContainer}>
							<Text style={styles.itemsUnavailable}>
								{/* Will show unavailable units (total quantity of each & every item) of the invoice */}
								{`${localeString(
									keyConstants.ITEMS_UNAVAILABLE,
								)} (${totalUnavailableItems} ${localeString(
									totalUnavailableItems > 1
										? keyConstants.UNITS
										: keyConstants.UNIT_LABEL,
								)})`}
							</Text>
							<Text style={styles.itemsUnavailableCost}>
								{`${currencyFormatter(
									getValueInDecimal(totalCostOfUnavailableItems),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<FlatList
							data={purchaseInvoiceSummary}
							renderItem={this.renderItem}
							keyExtractor={this.keyExtractor}
							showsVerticalScrollIndicator={false}
							style={styles.scrollView}
						/>
						<View style={styles.bottomButton}>
							<ButtonComponent
								onPress={onUploadInvoice}
								text={localeString(keyConstants.SUBMIT)}
								isButtonDisable={!(isSubmitButtonEnable && imageUrl)}
							/>
						</View>
					</>
				)}
				<ToastComponent
					isRTL={isRTL}
					isApiError={isShowToast}
					toastMessage={toastMessage}
				/>
			</View>
		);
	}
}

PurchaseInvoiceSummaryUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onPressBack: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	onPressDownload: PropTypes.func.isRequired,
	isShowToast: PropTypes.bool.isRequired,
	spinner: PropTypes.bool.isRequired,
	error: PropTypes.bool.isRequired,
	isSubmitButtonEnable: PropTypes.bool.isRequired,
	totalUnavailableItems: PropTypes.element.isRequired,
	totalCostOfUnavailableItems: PropTypes.element.isRequired,
	onRefresh: PropTypes.func.isRequired,
	imageUrl: PropTypes.string.isRequired,
	toastMessage: PropTypes.string.isRequired,
	onUploadInvoice: PropTypes.func.isRequired,
	errorCode: PropTypes.object.isRequired,
	purchaseInvoiceSummary: PropTypes.array.isRequired,
};

export default PurchaseInvoiceSummaryUI;
