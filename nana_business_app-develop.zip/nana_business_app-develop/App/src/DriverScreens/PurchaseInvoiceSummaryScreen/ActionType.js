export const GET_PURCHASE_INVOICE_SUMMARY_SUCCESS = 'get_purchase_invoice_summary_success';
export const GET_PURCHASE_INVOICE_SUMMARY_FAILURE = 'get_purchase_invoice_summary_failure';
export const GET_PURCHASE_INVOICE_SUMMARY_LOADER = 'get_purchase_invoice_summary_loader';

export const UPLOAD_PURCHASE_INVOICE_SUCCESS = 'uplaod_purchase_invoice_succes';
export const UPLOAD_PURCHASE_INVOICE_FAILURE = 'uplaod_purchase_invoice_failure';
export const UPLOAD_PURCHASE_INVOICE_LOADER = 'uplaod_purchase_invoice_loader';

export const RESET_PURCHASE_INVOICE_SUMMARY_STATE = 'reset_purchase_invoice_summary_state';
