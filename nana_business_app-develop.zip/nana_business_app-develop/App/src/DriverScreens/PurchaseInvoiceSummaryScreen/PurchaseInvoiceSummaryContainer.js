/* import libraries */
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

/* import components */
import PurchaseInvoiceSummaryComponent from './PurchaseInvoiceSummaryComponent';

// import actions
import * as PurchaseInvoiceSummaryActions from './PurchaseInvoiceSummaryScreenAction';

const PurchaseInvoiceSummaryContainer = props => {
	const customProps = { ...props }; // Store all the props including actions and reducers.
	return <PurchaseInvoiceSummaryComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		purchaseInvoiceSummaryInfo: state.PurchaseInvoiceSummaryScreenReducer,
		imageInputComponentInfo: state.ImageInputComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		purchaseInvoiceSummaryActions: bindActionCreators(
			{ ...PurchaseInvoiceSummaryActions },
			dispatch,
		),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(PurchaseInvoiceSummaryContainer);
