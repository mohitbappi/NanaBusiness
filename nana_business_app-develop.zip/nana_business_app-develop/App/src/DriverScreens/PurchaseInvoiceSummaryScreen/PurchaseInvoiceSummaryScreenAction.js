import { actions } from '@libapi/APIActionsBuilder';
import GetPurchaseInvoiceSummaryService from '@PurchaseInvoices/GetPurchaseInvoiceSummaryService';
import UploadPurchaseInvoiceService from '@PurchaseInvoices/UploadPurchaseInvoiceService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to fetch the summary of the purchase invoice.
 * @param {object} props
 * @returns
 */

export const getPurchaseInvoiceSummary = props => dispatch => {
	const dispatchedActions = new actions(
		ActionTypes.GET_PURCHASE_INVOICE_SUMMARY_SUCCESS,
		ActionTypes.GET_PURCHASE_INVOICE_SUMMARY_FAILURE,
		ActionTypes.GET_PURCHASE_INVOICE_SUMMARY_LOADER,
	);
	const getPurchaseInvoiceSummaryService = new GetPurchaseInvoiceSummaryService(
		dispatchedActions,
	);
	addBasicInterceptors(getPurchaseInvoiceSummaryService);
	getPurchaseInvoiceSummaryService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPurchaseInvoiceSummaryService.makeRequest(props));
};

/**
 * API call to upload the purchase invoice.
 * @param {object} props
 * @returns
 */

export const onUploadPurchaseInvoice = props => dispatch => {
	const dispatchedActions = new actions(
		ActionTypes.UPLOAD_PURCHASE_INVOICE_SUCCESS,
		ActionTypes.UPLOAD_PURCHASE_INVOICE_FAILURE,
		ActionTypes.UPLOAD_PURCHASE_INVOICE_LOADER,
	);
	const uploadPurchaseInvoiceService = new UploadPurchaseInvoiceService(dispatchedActions);
	addBasicInterceptors(uploadPurchaseInvoiceService);
	uploadPurchaseInvoiceService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(uploadPurchaseInvoiceService.makeRequest(props));
};

export const onResetInvoiceSummaryState = () => ({
	type: ActionTypes.RESET_PURCHASE_INVOICE_SUMMARY_STATE,
});
