import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import normalize, { verticalScale } from '@device/normalize';
import * as colors from '@assets/colors';
import { fontsConstants, multiplyString } from '@Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

const createStyleSheet = isRTL => {
	const rtlFunctions = new RTLFunctions();
	return StyleSheet.create({
		container: {
			marginTop: verticalScale(12),
		},
		name: {
			fontSize: normalize(10),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			color: colors.black,
			textAlign: rtlFunctions.getTextAlign(isRTL),
			marginBottom: verticalScale(4),
		},
		barcode: {
			color: colors.blackGreyWhite,
			marginBottom: verticalScale(4),
		},
		priceQuantity: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		quantity: {
			fontSize: normalize(10),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		total: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.darkBlue,
			marginBottom: 0,
		},
	});
};

const UnavailableItem = props => {
	// Component to show list of the unavailable items.

	const { isRTL, item } = props;
	const styles = createStyleSheet(isRTL);
	return (
		<View style={styles.container}>
			<Text style={styles.name}>{item.name}</Text>
			<Text style={[styles.name, styles.barcode]}>
				{`${localeString(keyConstants.BARCODE_NO)}: ${item.carton_barcode}`}
			</Text>
			<View style={styles.priceQuantity}>
				<Text style={styles.quantity}>
					{`${item.quantity} ${multiplyString} ${currencyFormatter(
						getValueInDecimal(item.price + item.vat_amount),
					)} ${localeString(keyConstants.SAR)}`}
				</Text>
				<Text style={[styles.name, styles.total]}>
					{`${currencyFormatter(
						getValueInDecimal(item.quantity * (item.price + item.vat_amount)),
					)} ${localeString(keyConstants.SAR)}`}
				</Text>
			</View>
		</View>
	);
};

UnavailableItem.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	item: PropTypes.array.isRequired,
};

export default UnavailableItem;
