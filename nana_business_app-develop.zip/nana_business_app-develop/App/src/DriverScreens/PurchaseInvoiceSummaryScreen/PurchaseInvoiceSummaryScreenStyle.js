import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@config/device/normalize';
import { fontsConstants } from '@assets/Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(16),
		},
		imageInputContainer: {
			marginBottom: verticalScale(16),
			height: verticalScale(85),
		},
		listHeadingContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		itemsUnavailable: {
			fontSize: normalize(14),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		itemsUnavailableCost: {
			fontSize: normalize(12),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		scrollView: {
			marginBottom: verticalScale(65),
		},
		bottomButton: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
