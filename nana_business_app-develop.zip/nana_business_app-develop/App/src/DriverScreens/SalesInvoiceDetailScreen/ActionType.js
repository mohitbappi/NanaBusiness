/** action types for invoice detail */
export const GET_SALES_INVOICE_DETAIL_FAILURE = 'get_sales_invoice_detail_failure';
export const GET_SALES_INVOICE_DETAIL_SUCCESS = 'get_sales_invoice_detail_success';
export const GET_SALES_INVOICE_DETAIL_LOADER = 'get_sales_invoice_detail_loader';

/** action types for full refund */
export const FULL_REFUND_SUCCESS = 'full_refund_success';
export const FULL_REFUND_FAILURE = 'full_refund_failure';
export const FULL_REFUND_LOADER = 'full_refund_loader';

/** action types for partial */
export const PARTIAL_REFUND_SUCCESS = 'partial_refund_success';
export const PARTIAL_REFUND_FAILURE = 'partial_refund_failure';
export const PARTIAL_REFUND_LOADER = 'partial_refund_loader';

/** action types for purchase-invoice deteail */
export const GET_PURCHASE_RETURN_INVOICE_DETAIL_SUCCESS =
	'get_purchase_return_invoice_detail_success';
export const GET_PURCHASE_RETURN_INVOICE_DETAIL_FAILURE =
	'get_purchase_return_invoice_detail_failure';
export const GET_PURCHASE_RETURN_INVOICE_DETAIL_LOADER =
	'get_purchase_return_invoice_detail_loader';

export const GET_PURCHASE_INVOICE_DETAIL_SUCCESS = 'get_purchase_invoice_detail_success';
export const GET_PURCHASE_INVOICE_DETAIL_FAILURE = 'get_purchase_invoice_detail_failure';
export const GET_PURCHASE_INVOICE_DETAIL_LOADER = 'get_purchase_invoice_detail_loader';

export const RESET_REFUND_STATE = 'reset_refund_state';
