import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	invoiceDetail: [],
	isFullRefund: false,
	isPartialRefund: false,
	partialRefundData: null,
	markDeliveredData: null,
};

const SalesInvoiceDetailScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_SALES_INVOICE_DETAIL_SUCCESS:
		case ActionTypes.GET_PURCHASE_RETURN_INVOICE_DETAIL_SUCCESS:
		case ActionTypes.GET_PURCHASE_INVOICE_DETAIL_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				invoiceDetail: action.payload,
				isFullRefund: false,
				isPartialRefund: false,
				isDownload: false,
			};
		case ActionTypes.GET_SALES_INVOICE_DETAIL_LOADER:
		case ActionTypes.GET_PURCHASE_RETURN_INVOICE_DETAIL_LOADER:
		case ActionTypes.GET_PURCHASE_INVOICE_DETAIL_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isFullRefund: false,
				isPartialRefund: false,
				isDownload: false,
			};
		case ActionTypes.FULL_REFUND_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isFullRefund: true,
				isPartialRefund: false,
			};
		case ActionTypes.PARTIAL_REFUND_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isFullRefund: false,
				isPartialRefund: true,
			};
		case ActionTypes.GET_PURCHASE_RETURN_INVOICE_DETAIL_FAILURE:
		case ActionTypes.GET_PURCHASE_INVOICE_DETAIL_FAILURE:
		case ActionTypes.GET_SALES_INVOICE_DETAIL_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isFullRefund: false,
				isPartialRefund: false,
				isDownload: false,
			};
		case ActionTypes.FULL_REFUND_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isFullRefund: true,
				isPartialRefund: false,
			};
		case ActionTypes.PARTIAL_REFUND_SUCCESS: {
			const { amount, customer_organization, vat_amount } = action.payload.row || {};
			const { data } = action.payload || {};
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isPartialRefund: true,
				isFullRefund: false,
				markDeliveredData: {
					customer_org_id: customer_organization?.id,
					customer_name: customer_organization?.name,
					customer_name_ar: customer_organization?.name_ar,
					amount: data?.amount,
					is_collector: data?.is_collector,
					collection_request: data?.collection_request,
				},
				partialRefundData: {
					amount,
					vat_amount,
					organization: customer_organization ? customer_organization.name : '',
				},
			};
		}
		case ActionTypes.FULL_REFUND_LOADER:
		case ActionTypes.PARTIAL_REFUND_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isFullRefund: true,
			};
		case ActionTypes.RESET_REFUND_STATE:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
				isFullRefund: false,
				isPartialRefund: false,
				partialRefundData: null,
				markDeliveredData: null,
			};
		default:
			return state;
	}
};

export default SalesInvoiceDetailScreenReducer;
