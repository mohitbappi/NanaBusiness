// import libraries
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { View, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Spinner from '@Spinner/Spinner';
import Search from '@Search/Search';
import InvoiceItemCardComponent from '@InvoiceItemCardComponent/InvoiceItemCardComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import AlertComponent from '@Util/AlertComponent';
import SaveCancelButtonComponent from '@Components/SaveCancelButtonComponent';
import PopupConfirmationComponent from '@PopupConfirmationComponent/PopupConfirmationComponent';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import ImageInputComponent from '@ImageInputComponent/ImageInputComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';

/** import constants */
import { keyConstants } from '@Constants/KeyConstants';
import { constants } from '@RefreshControlComponent/Constants';
import {
	dash,
	invoiceImg,
	purchaseReturnInvoiceStatus,
	asterik,
	toastShowTime,
	shipmentStatus,
} from '@Constants/Constants';

/* import to get selected language string */
import { localeString } from '@Localization/index';

/** import utils */
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import driverNavigations from '@routes/driverNavigations';
import { getSumOfItemQuantity } from '@EditItemsQuantityScreen/getSomeOfItemQuantity';
import { removeSpaces } from '@Util/GetFormattedString';
import CustomToast from '@CustomToast/CustomToast';
import { downloadFile } from '@Util/DownloadFile';

/** import actions */
import * as SalesInvoiceScreenAction from '@SalesInvoiceScreen/SalesInvoiceScreenAction';
import * as ShipmentScreenActions from '@ShipmentScreen/ShipmentScreenAction';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as PurchaseReturnInvoiceScreenActions from '@PurchaseReturnInvoiceScreen/PurchaseReturnInvoiceScreenAction';
import * as InvoiceDetailActions from './SalesInvoiceDetailScreenAction';

// import styles
import { createStyleSheet } from './SalesInvoiceDetailScreenStyle';

class SalesInvoiceDetailScreen extends Component {
	constructor(props) {
		super(props);
		this.onUploadImage = React.createRef(null);
		this.state = {
			isPartialRefund: false,
			itemsArray: [],
			searchText: '',
			itemsListing: [],
			quantityArray: [],
			isPopupVisible: false,
			isClickDownload: false,
			dropdownSelectedIndex: null,
			otherDropdownSelectedIndex: null,
			downloadFileName: '',
			languageArray: [],
			isShowToast: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.setState({ searchText: '' }, () => {
				this.onGetNotificationCount();
				this.getInvoiceDetail();
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			invoiceDetailInfo,
			purchaseReturnInvoiceInfo,
			salesInvoiceInfo,
			pullToRefreshActions,
		} = this.props;
		const { success, isDownload, downloadUrl, error, errorCode } = salesInvoiceInfo;
		const { downloadFileName } = this.state;
		const {
			errorCode: invoiceDetailErrorCode,
			error: invoiceDetailError,
			isFullRefund,
		} = invoiceDetailInfo;
		const {
			errorCode: purchaseReturnErrorCode,
			error: purchaseReturnError,
			isResellItems,
		} = purchaseReturnInvoiceInfo;
		if (success && prevProps.salesInvoiceInfo.success !== success) {
			if (isDownload) {
				// Will download the invoice.
				this.onClickDownload();
				downloadFile(
					downloadUrl, // Url of the invoice.
					downloadFileName, // File name of the downloaded invoice.
					() => {
						this.onShowFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
					},
					() => {
						this.onShowFileStatus(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
					},
					() => {
						this.onShowFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
					},
				);
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (error && prevProps.salesInvoiceInfo.error !== salesInvoiceInfo.error) {
			// Will show alert if api call fails.
			ErrorAlertComponent(errorCode, this.onRefresh);
		}
		if (
			invoiceDetailError &&
			isFullRefund &&
			prevProps.invoiceDetailInfo.error !== invoiceDetailInfo.error
		) {
			// Will show alert if api call fails.
			ErrorAlertComponent(invoiceDetailErrorCode, this.onFullRefund);
		}
		if (
			purchaseReturnError &&
			isResellItems &&
			prevProps.purchaseReturnInvoiceInfo.error !== purchaseReturnInvoiceInfo.error
		) {
			// Will show alert if api call fails.
			ErrorAlertComponent(purchaseReturnErrorCode, this.onPressAcceptResell);
		}
	}

	// API call to get the notification count.
	onGetNotificationCount = () => {
		const { shipmentScreenActions } = this.props;
		shipmentScreenActions.onGetNotificationCount();
	};

	getInvoiceDetail = () => {
		// API call to get the invoice detail.
		const { route, invoiceDetailActions, pullToRefreshActions } = this.props;
		const { id, index, isSalesInvoice, isPurchase } = route.params || {};
		const { searchText } = this.state;
		const invoiceDetail = {
			id,
		};
		pullToRefreshActions.onSetSelectIndex(index);
		if (searchText) {
			invoiceDetail.queryParams = {
				filter: searchText,
			};
		}
		if (isSalesInvoice) {
			invoiceDetailActions.onGetSalesInvoices(invoiceDetail);
		} else if (isPurchase) {
			// Will call API to get the items of the purchase invoice.
			invoiceDetailActions.onGetPurchaseInvoiceDetail(invoiceDetail);
		} else {
			// Will call API to get the items of the purchase return invoice.
			invoiceDetailActions.onGetPurchaseReturnInvoiceDetail(invoiceDetail);
		}
	};

	onClickDownload = () => {
		// Will set file name of the invoice.
		const { route } = this.props;
		const { isClickDownload } = this.state;
		const { id, organization, shipmentID } = route.params;
		this.setState({
			isClickDownload: !isClickDownload,
			dropdownSelectedIndex: null,
			otherDropdownSelectedIndex: null,
			selectedInvoiceId: id,
			downloadFileName: `${removeSpaces(organization)}-${shipmentID}`,
		});
	};

	onDownloadSalesInvoice = () => {
		// API call to download the invoice.
		const { salesInvoiceInfo, salesInvoiceScreenAction } = this.props;
		const { templates } = salesInvoiceInfo;
		const { dropdownSelectedIndex, otherDropdownSelectedIndex, selectedInvoiceId } = this.state;
		const queryParams = {};
		queryParams.sales_invoice_ids = selectedInvoiceId;
		queryParams.invoice_template = `${templates[otherDropdownSelectedIndex].lang[dropdownSelectedIndex]}_${templates[otherDropdownSelectedIndex].id}.html`;
		salesInvoiceScreenAction.onDownloadTemplate(queryParams);
	};

	onSelectOption = index => this.setState({ dropdownSelectedIndex: index });

	onSelectOtherOption = index => {
		// Function to select the dropdown option.
		const { salesInvoiceInfo } = this.props;
		const { templates } = salesInvoiceInfo;
		const tempArray = [];
		if (templates[index]) {
			templates[index].lang.map(item => {
				tempArray.push({ name: localeString(keyConstants[item]) });
			});
		}
		this.setState({
			otherDropdownSelectedIndex: index,
			languageArray: tempArray,
		});
	};

	onPressOtherDropdown = () => this.onGetTemplates();

	// API call to get the templates.
	onGetTemplates = () => {
		const { salesInvoiceScreenAction } = this.props;
		salesInvoiceScreenAction.onGetTemplates();
	};

	onShowFileStatus = message => {
		// Will show status of the download as a toast.
		this.setState({
			toastMessage: message,
			isShowToast: true,
		});
		setTimeout(() => {
			this.setState({
				isShowToast: false,
			});
		}, toastShowTime);
	};

	onPressReturnNotification = () => {
		// Will navigate to the notification screen.
		const { shipmentScreenInfo, navigation } = this.props;
		const { notificationCount } = shipmentScreenInfo;
		navigation.navigate(driverNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	onGoToInvoice = isNavigationToShipment => {
		const {
			purchaseReturnInvoiceInfo,
			navigation,
			purchaseReturnInvoiceScreenActions,
		} = this.props;
		const { isResellItems, success } = purchaseReturnInvoiceInfo;
		if (isNavigationToShipment || (success && isResellItems)) {
			// Will return true if navigation to shipment screen.
			this.onPressClose();
			navigation.goBack();
			navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
			purchaseReturnInvoiceScreenActions.onResetPurchaseReturnState();
		} else {
			navigation.navigate(driverNavigations.PURCHASE_RETURN_INVOICE_NAVIGATION);
		}
	};

	onPressAcceptItems = (invoiceDetail, index) => {
		// Function to navigate on the accept items screen
		const { route, navigation } = this.props;
		const { id, status, acceptanceRequestId } = route.params || {};
		// Will navigate only if status is rejected and null.
		if (
			status !== purchaseReturnInvoiceStatus.pending &&
			status !== purchaseReturnInvoiceStatus.approved
		) {
			navigation.navigate(driverNavigations.ACCEPT_ITEM_NAVIGATION, {
				invoiceDetail,
				itemIndex: index,
				id,
				acceptanceRequestId,
			});
		}
		return null;
	};

	getItemIndex = ItemsAcceptedBooleanArray => {
		// Function to return the firstmost item which is skipped by the driver while accepting the items.
		const { acceptItemInfo, route } = this.props;
		const { purchaseInvoiceId } = acceptItemInfo;
		const { id } = route.params || {};
		let index = 0;
		if (purchaseInvoiceId === id) {
			// If the purchase invoice is already visited for acceptance.
			index = ItemsAcceptedBooleanArray.length
				? ItemsAcceptedBooleanArray.findIndex(value => value === false)
				: 0;
		}
		return index < 0 ? 0 : index; // If index = -1 it means either all the items are accepted or none of the items are accepted.
	};

	// Will navigate to the previous screen.
	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onDownloadInvoice = () => {
		// Function to download the purchase invoice.
		const { route } = this.props;
		const { downloadUrl, downloadFileName } = route.params || {};
		downloadFile(
			downloadUrl, // Invoice url.
			downloadFileName, // Download file name.
			() => {
				this.onShowFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
			},
			() => {
				this.onShowFileStatus(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
			},
			() => {
				this.onShowFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
			},
		);
	};

	renderItem = ({ item, index }) => {
		const { route } = this.props;
		const { isSalesInvoice, isPurchase } = route.params || {};
		if (isSalesInvoice) {
			// Will fetch sales invoice detail.
			return this.renderSalesInvoiceItem(item, index);
		}
		if (isPurchase) {
			// Will fetch purchase invoice detail.
			return this.renderPurchaseInvoiceItem(item, index);
		}
		// Will fetch purchase return invoice detail.
		return this.renderPurchaseReturnInvoiceItem(item, index);
	};

	renderSalesInvoiceItem = item => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet();
		const { isPartialRefund, itemsArray } = this.state;
		const {
			item_name_ar,
			item_name,
			price,
			vat_amount,
			quantity,
			images,
			item_id,
			return_qty,
		} = item || {};
		return (
			<View style={styles.cardView}>
				<InvoiceItemCardComponent
					title={isRTL ? item_name_ar : item_name}
					amount={`${currencyFormatter(
						getValueInDecimal((price + vat_amount) * quantity),
					)} ${localeString(keyConstants.SAR)}`}
					orderedQunatity={`${localeString(keyConstants.QTY_ORDERED)}: ${
						quantity + return_qty
					}`}
					refundedQty={return_qty || dash}
					isRefundedQuantity
					showCheckBox={isPartialRefund && quantity !== 0}
					id={item_id}
					selectedItems={itemsArray}
					onSelect={() => this.onSelect(item_id, item, quantity + return_qty)}
					productImage={images && images.small}
				/>
			</View>
		);
	};

	renderPurchaseInvoiceItem = (item, index) => {
		const { invoiceDetailInfo, languageInfo } = this.props;
		const { invoiceDetail } = invoiceDetailInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet();
		const {
			name_ar, // Item Arabic name.
			name, // Item English name.
			price,
			vat_amount,
			images,
			returned_qty,
			quantity,
			items_per_packet,
			value_of_item,
			unit,
			unit_ar,
		} = item || {};
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				onPress={() => this.onPressAcceptItems(invoiceDetail, index)}
				style={styles.cardView}>
				<InvoiceItemCardComponent
					title={isRTL ? name_ar : name}
					amount={`${currencyFormatter(
						getValueInDecimal((price + vat_amount) * (quantity - returned_qty)),
					)} ${localeString(keyConstants.SAR)}`}
					orderedQunatity={`${localeString(keyConstants.QTY_ORDERED)}: ${quantity}`}
					isUnavailableQuantity
					refundedQty={returned_qty || dash}
					productImage={images && images.small}
					itemsPerPacket={items_per_packet}
					valueOfItem={value_of_item}
					unit={isRTL ? unit_ar : unit}
					pricePerItem={getValueInDecimal((price + vat_amount) / items_per_packet)}
					hasUnitManagement
				/>
			</TouchableOpacity>
		);
	};

	renderPurchaseReturnInvoiceItem = item => {
		const { route, languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet();
		const { item_name_ar, item_name, price, vat_amount, images, return_qty } = item || {};
		const { purchaseInvoiceData } = route.params || {};
		return (
			<View style={styles.cardView}>
				<InvoiceItemCardComponent
					title={isRTL ? item_name_ar : item_name}
					amount={`${currencyFormatter(
						getValueInDecimal((price + vat_amount) * return_qty),
					)} ${localeString(keyConstants.SAR)}`}
					orderedQunatity={`${localeString(keyConstants.RETURNED)}: ${return_qty}`}
					isReselledQuantity
					reselledQty={
						purchaseInvoiceData.status === purchaseReturnInvoiceStatus.resold
							? return_qty || dash
							: dash
					}
					productImage={images && images.small}
				/>
			</View>
		);
	};

	keyExtractor = (item, index) => index.toString();

	onSearch = text => {
		// API call to search the item using item name and barcode.
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.getInvoiceDetail();
			},
		);
	};

	onSelect = (id, item, quantity) => {
		// Will select multiple items for partial refund.
		const { itemsArray, itemsListing, quantityArray } = this.state;
		const itemsArrayCopy = itemsArray;
		const itemsListingCopy = itemsListing;
		const quantityArrayCopy = quantityArray;
		if (itemsArrayCopy.includes(id)) {
			// If item already exists in the array then it will remove it.
			const itemIndex = itemsArrayCopy.indexOf(id);
			itemsArrayCopy.splice(itemIndex, 1);
			itemsListingCopy.splice(itemIndex, 1);
			quantityArrayCopy.splice(itemIndex, 1);
		} else {
			// If item is not in the array then it will add.
			itemsArrayCopy.push(id);
			itemsListingCopy.push(item);
			quantityArrayCopy.push(quantity);
		}
		this.setState({
			itemsArray: itemsArrayCopy,
			itemsListing: itemsListingCopy,
			quantityArray: quantityArrayCopy,
		});
	};

	onSubmit = itemListing => {
		// Will navigate to the edit items quantity screen.
		const { route, navigation } = this.props;
		const totalQuantity = getSumOfItemQuantity(itemListing);
		const { itemsListing, quantityArray } = this.state;
		const { id } = route.params;
		navigation.navigate(driverNavigations.EDIT_QUANTITY_SCREEN_NAVIGATION, {
			itemsListing,
			quantityArray,
			id,
			totalQuantity,
		});
	};

	onPartialRefund = () => {
		this.setState({
			isPartialRefund: true,
		});
	};

	onFullRefund = () => {
		// API call to do the full refund.
		const { route, invoiceDetailActions } = this.props;
		const { id } = route.params;
		const queryParams = {};
		queryParams.sales_invoice_id = id;
		invoiceDetailActions.onFullRefund(queryParams);
	};

	onRefund = () => {
		// Confirmation of the user before performing the refund.
		const alertProps = {
			message: localeString(keyConstants.PROCEED_REFUND_REQUEST),
			onPressYes: () => this.onFullRefund(),
		};
		AlertComponent(alertProps);
	};

	onUploadInvoice = id => this.onUploadImage.onClickAddImage(id);

	onRefresh = () => {
		// API calls while pull to refresh.
		this.onGetNotificationCount();
		this.getInvoiceDetail();
	};

	onShowHidePopup = value => {
		// Function to show hide resell popup.
		this.setState({ isPopupVisible: value });
	};

	onPressResell = () => {
		this.onShowHidePopup(true);
	};

	onPressRejectResell = () => {
		this.onShowHidePopup(false);
	};

	onPressAcceptResell = () => {
		// Function to call the resell items API.
		const { route, invoiceDetailInfo, purchaseReturnInvoiceScreenActions } = this.props;
		const { purchaseInvoiceData, id } = route.params || {};
		const { invoiceDetail } = invoiceDetailInfo;
		const { rows } = invoiceDetail || {};
		const resellItemDetails = {
			return_si_id: purchaseInvoiceData && purchaseInvoiceData.return_si_id,
			purchase_return_invoices_id: id,
			items: this.getItemsRequestPayload(rows),
		};
		purchaseReturnInvoiceScreenActions.onResellItems(resellItemDetails);
	};

	getItemsRequestPayload = itemsArray => {
		// Will return request payload which contains the items which user wants to resold.
		const object = {};
		itemsArray.map(item => {
			const itemObject = item;
			const { item_id, return_qty } = itemObject;
			object[item_id] = return_qty;
		});
		return object;
	};

	onPressClose = () => {
		this.setState({ isPopupVisible: false });
	};

	navigationHandler = status => {
		const { route, invoiceDetailInfo, acceptItemInfo, navigation } = this.props;
		const { acceptanceRequestId } = route.params || {};
		// Will navigate to accept items screen if the acceptance request never generated.
		if (status === null && acceptanceRequestId === null) {
			const { invoiceDetail } = invoiceDetailInfo;
			const { ItemsAcceptedBooleanArray } = acceptItemInfo;
			this.onPressAcceptItems(invoiceDetail, this.getItemIndex(ItemsAcceptedBooleanArray));
		} else {
			// Will navigate to purchase invoice summary screen if acceptance request is generated.
			navigation.navigate(driverNavigations.PURCHASE_INVOICE_SUMMARY_NAVIGATION, {
				acceptanceRequestId,
				isSubmitButtonEnable: status !== purchaseReturnInvoiceStatus.pending,
			});
		}
	};

	renderConfirmationModal = () => {
		// Component to show the confirmation of the action.
		const { imageInputComponentInfo, route } = this.props;
		const { amount, organization, isSalesInvoice, purchaseInvoiceData } = route.params || {};
		const { image, isUploadToDriver } = imageInputComponentInfo;
		let title = '';
		let description = '';
		let buttonTitle = '';
		if (purchaseInvoiceData) {
			// If purchase return invoice.
			title =
				image && isUploadToDriver
					? localeString(keyConstants.RETURN_REQUEST)
					: localeString(keyConstants.ITEMS_RESOLD);
			description =
				image && isUploadToDriver
					? localeString(keyConstants.RETURN_REQUEST_MESSAGE)
					: localeString(keyConstants.ITEMS_RESOLD_MESSAGE);
			buttonTitle =
				image && isUploadToDriver
					? localeString(keyConstants.OKAY)
					: localeString(keyConstants.BACK_TO_SHIPMENTS);
		} else if (isSalesInvoice) {
			// If sales invoice.
			title = localeString(keyConstants.TOTAL_REFUND);
			description = localeString(keyConstants.TOTAL_REFUND_MESSAGE);
			buttonTitle = localeString(keyConstants.OKAY);
		}
		return (
			<ConfimationModal
				title={title}
				description={description}
				innerDescription={
					isSalesInvoice
						? ` ${currencyFormatter(getValueInDecimal(amount))} ${localeString(
								keyConstants.SAR,
						  )} `
						: ''
				}
				descriptionTwo={
					isSalesInvoice
						? `${localeString(keyConstants.TOTAL_REFUND_MESSAGES)} ${organization}`
						: ''
				}
				onPress={() => this.onGoToInvoice(isSalesInvoice)}
				buttonTitle={buttonTitle}
				hasButton
			/>
		);
	};

	render() {
		const {
			languageInfo,
			invoiceDetailInfo,
			shipmentScreenInfo,
			route,
			refreshControlComponentInfo,
			salesInvoiceInfo,
			acceptItemInfo,
			purchaseReturnInvoiceInfo,
			imageInputComponentInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet();
		const {
			isPartialRefund,
			itemsArray,
			searchText,
			isPopupVisible,
			isClickDownload,
			dropdownSelectedIndex,
			otherDropdownSelectedIndex,
			languageArray,
			isShowToast,
			toastMessage,
		} = this.state;
		const {
			loader,
			invoiceDetail,
			isFullRefund,
			success,
			error,
			errorCode,
		} = invoiceDetailInfo;
		const { loader: salesInvoiceLoader, templates, isTemplate, isDownload } = salesInvoiceInfo;
		const { rows, is_refunded } = invoiceDetail || {};
		const { notificationCount } = shipmentScreenInfo;
		const {
			isSalesInvoice, // True if navigation from sales invoice screen.
			id, // Invoice id.
			purchaseInvoiceData, // Invoice data if navigation from purchase return invoice screen.
			status, // Status of purchase invoice.
			isPurchase, // True if navigation from purchase invoice screen.
			acceptanceRequestId, // Purchase invoice acceptance request id.
		} = route.params || {};
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { isSavedAsDraft } = acceptItemInfo;
		const {
			loader: purchaseReturnLoader,
			isResellItems,
			success: purchaseReturnSuccess,
		} = purchaseReturnInvoiceInfo;
		const { image, isUploadToDriver, imageLoader } = imageInputComponentInfo;
		const isShowRefundButton =
			isSalesInvoice &&
			rows &&
			rows.length &&
			rows[0].acceptance_status === purchaseReturnInvoiceStatus.approved;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !isFullRefund && searchText === '' && (
					<Loader size="large" />
				)}
				{((loader && !isFetchingForPullToRefresh && isFullRefund) ||
					(isUploadToDriver && imageLoader) ||
					(purchaseReturnLoader && isResellItems)) && <Spinner size="large" />}
				<PopupConfirmationComponent
					isRTL={isRTL}
					isPopupVisible={isPopupVisible}
					rejectText={localeString(keyConstants.NO)}
					onPressReject={this.onPressRejectResell}
					acceptText={localeString(keyConstants.YES)}
					onPressAccept={this.onPressAcceptResell}
					message={localeString(keyConstants.WANT_TO_RESELL_TO_NANA_WAREHOUSE)}
					title={localeString(keyConstants.RESELL_ITEMS)}
					onPressClose={this.onPressClose}
				/>
				{((success && isFullRefund) ||
					(!!image && isUploadToDriver) ||
					(purchaseReturnSuccess && isResellItems)) &&
					this.renderConfirmationModal()}
				{isClickDownload && (
					<ConfimationModal
						containerStyle={styles.confirmationModalContainerStyle}
						textStyle={styles.textStyle}
						title={localeString(keyConstants.PRINT_INVOICE)}
						description={localeString(keyConstants.PRINT_INVOICE_TEXT)}
						onPress={this.onDownloadSalesInvoice}
						buttonTitle={localeString(keyConstants.SUBMIT)}
						isButtonDisable={
							!(dropdownSelectedIndex !== null && otherDropdownSelectedIndex !== null)
						}
						dropdownLabel={`${localeString(keyConstants.SELECT_LANGUAGE)}${asterik}`}
						dropdownPlaceholder={localeString(keyConstants.SELECT_LANGUAGE)}
						dropdownValues={languageArray}
						dropdownSelectedIndex={dropdownSelectedIndex}
						dropdownRef={ref => {
							this.languageRef = ref;
						}}
						onSelectOption={this.onSelectOption}
						hasDropdown={otherDropdownSelectedIndex !== null}
						otherDropdownLabel={`${localeString(
							keyConstants.SELECT_TEMPLATE,
						)}${asterik}`}
						otherDropdownPlaceholder={localeString(keyConstants.SELECT_TEMPLATE)}
						otherDropdownValues={templates}
						otherDropdownSelectedIndex={otherDropdownSelectedIndex}
						otherDropdownRef={ref => {
							this.templateRef = ref;
						}}
						onSelectOtherOption={this.onSelectOtherOption}
						onPressOtherDropdown={this.onPressOtherDropdown}
						hasOtherDropdown
						hasIconCross
						onGoBack={() => this.onClickDownload()}
						hasButton
						modalLoader={salesInvoiceLoader && isDownload}
						loader={
							salesInvoiceLoader && isTemplate && templates && templates.length === 0
						}
					/>
				)}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.INVOICE_DETAIL)}
						hasIconBack
						onPressBack={this.onGoBack}
						notificationCount={notificationCount}
						hasIconDownload={
							isPurchase ||
							(rows?.length &&
								rows[0].delivery_status !== shipmentStatus.failed &&
								isSalesInvoice)
						}
						onPressDownload={isPurchase ? this.onDownloadInvoice : this.onClickDownload}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasSearchIcon
						placeholder={localeString(
							isPurchase
								? keyConstants.SEARCH_BY_ITEM_OR_BARCODE
								: keyConstants.SEARCH_BY_BARCODE_SKU,
						)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
					/>
				</View>
				{error && !isFullRefund ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<>
						{rows && rows.length !== 0 && (
							<FlatListComponent
								keyboardShouldPersistTaps="handled"
								data={rows}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								contentContainerStyle={
									rows.length === 0 ? styles.scrollViewStyle : styles.flatList
								}
								ListEmptyComponent={() => (
									<ListEmpty text={localeString(keyConstants.NO_ITEMS_FOUND)} />
								)}
								componentType={constants.flatList}
								onRefresh={this.onRefresh}
							/>
						)}
						{isSalesInvoice && !isPurchase ? (
							isPartialRefund ? (
								<View style={styles.buttonView}>
									<ButtonComponent
										text={localeString(keyConstants.NEXT)}
										onPress={() => this.onSubmit(rows)}
										isButtonDisable={!itemsArray.length}
									/>
								</View>
							) : (
								// Will return true only if full refund or partial refund is not initiated.
								!is_refunded &&
								rows &&
								rows.length !== 0 &&
								rows[0].delivery_status !== shipmentStatus.successful &&
								rows[0].delivery_status !== shipmentStatus.cancel &&
								isShowRefundButton && (
									<SaveCancelButtonComponent
										isRTL={isRTL}
										cancelText={localeString(keyConstants.PARTIAL_REFUND)}
										onPressCancel={this.onPartialRefund}
										saveText={localeString(keyConstants.FULL_REFUND)}
										onPressSave={this.onRefund}
									/>
								)
							)
						) : null}
						{
							// This component will show in case of purchase invoice detail
							isPurchase && status !== purchaseReturnInvoiceStatus.approved ? (
								<View style={styles.buttonView}>
									<ButtonComponent
										text={
											status === null && acceptanceRequestId === null
												? localeString(keyConstants.START_ACCEPTING)
												: localeString(keyConstants.VIEW_SUMMARY)
										}
										onPress={() => this.navigationHandler(status)}
									/>
								</View>
							) : null
						}
						{
							// This component will show in case of purchase return invoice detail
							purchaseInvoiceData &&
								(purchaseInvoiceData.status === purchaseReturnInvoiceStatus.open ||
									purchaseInvoiceData.status ===
										purchaseReturnInvoiceStatus.rejected) && (
									<>
										<SaveCancelButtonComponent
											isRTL={isRTL}
											cancelText={localeString(keyConstants.RE_SELL)}
											onPressCancel={this.onPressResell}
											saveText={localeString(keyConstants.RETURN)}
											onPressSave={() => this.onUploadInvoice(id)}
										/>
										<ImageInputComponent
											selectedImageTitle={invoiceImg}
											hideInput
											uploadToDriver
											isRTL={isRTL}
											onRef={ref => {
												this.onUploadImage = ref;
											}}
										/>
									</>
								)
						}
					</>
				)}
				{
					// Component to show saved as draft as a toast.
					isSavedAsDraft && (
						<CustomToast
							isRTL={isRTL}
							toastMessage={localeString(keyConstants.SAVED_AS_DRAFT)}
							containerStyle={styles.containerStyle}
						/>
					)
				}
				<ToastComponent
					isRTL={isRTL}
					isApiError={isShowToast}
					toastMessage={toastMessage}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		invoiceDetailInfo: state.SalesInvoiceDetailScreenReducer,
		shipmentScreenInfo: state.ShipmentScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		acceptItemInfo: state.AcceptItemScreenReducer,
		purchaseReturnInvoiceInfo: state.PurchaseReturnInvoiceScreenReducer,
		salesInvoiceInfo: state.SalesInvoiceScreenReducer,
		imageInputComponentInfo: state.ImageInputComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		invoiceDetailActions: bindActionCreators({ ...InvoiceDetailActions }, dispatch),
		salesInvoiceScreenAction: bindActionCreators({ ...SalesInvoiceScreenAction }, dispatch),
		shipmentScreenActions: bindActionCreators({ ...ShipmentScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		purchaseReturnInvoiceScreenActions: bindActionCreators(
			{ ...PurchaseReturnInvoiceScreenActions },
			dispatch,
		),
	};
};

SalesInvoiceDetailScreen.propTypes = {
	invoiceDetailInfo: PropTypes.object.isRequired,
	shipmentScreenInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	acceptItemInfo: PropTypes.object.isRequired,
	purchaseReturnInvoiceInfo: PropTypes.object.isRequired,
	salesInvoiceInfo: PropTypes.object.isRequired,
	imageInputComponentInfo: PropTypes.object.isRequired,
	invoiceDetailActions: PropTypes.object.isRequired,
	salesInvoiceScreenAction: PropTypes.object.isRequired,
	shipmentScreenActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	purchaseReturnInvoiceScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SalesInvoiceDetailScreen);
