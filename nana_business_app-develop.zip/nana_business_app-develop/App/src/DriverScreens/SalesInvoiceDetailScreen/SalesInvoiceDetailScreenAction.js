/** import API layer */
import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
/** import services */
import GetInvoiceDetailService from '@SalesInvoice/GetInvoiceDetailService';
import FullRefundService from '@SalesInvoice/FullRefundService';
import PartialRefundService from '@SalesInvoice/PartialRefundService';
import GetPurchaseReturnInvoiceDetailService from '@PurchaseInvoice/GetPurchaseReturnInvoiceDetailService';
import GetPurchaseInvoiceDetailService from '@PurchaseInvoices/GetPurchaseInvoiceDetailService';

/** import action types */
import * as ActionTypes from './ActionType';

/**
 * Action to get the sales invoice detail.
 * @param {object} props
 * @returns
 */
export const onGetSalesInvoices = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_SALES_INVOICE_DETAIL_SUCCESS,
		ActionTypes.GET_SALES_INVOICE_DETAIL_FAILURE,
		ActionTypes.GET_SALES_INVOICE_DETAIL_LOADER,
	);
	const getInvoiceDetailService = new GetInvoiceDetailService(dispatchedActions);
	addBasicInterceptors(getInvoiceDetailService);
	getInvoiceDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getInvoiceDetailService.makeRequest(props));
};

/**
 * Action to do the full refund.
 * @param {object} props
 * to raise full refund
 */
export const onFullRefund = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.FULL_REFUND_SUCCESS,
		ActionTypes.FULL_REFUND_FAILURE,
		ActionTypes.FULL_REFUND_LOADER,
	);
	const fullRefundService = new FullRefundService(dispatchedActions);
	addBasicInterceptors(fullRefundService);
	fullRefundService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(fullRefundService.makeRequest(props));
};

/**
 * Action to do the partial refund.
 * @param {object} props
 * to raise partial refund
 */
export const onPartialRefund = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.PARTIAL_REFUND_SUCCESS,
		ActionTypes.PARTIAL_REFUND_FAILURE,
		ActionTypes.PARTIAL_REFUND_LOADER,
	);
	const partialRefundService = new PartialRefundService(dispatchedActions);
	addBasicInterceptors(partialRefundService);
	partialRefundService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(partialRefundService.makeRequest(props));
};

/**
 * Action to call API of purchase return invoice detail.
 * @param {object} props
 * @returns
 */

export const onGetPurchaseReturnInvoiceDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_PURCHASE_RETURN_INVOICE_DETAIL_SUCCESS,
		ActionTypes.GET_PURCHASE_RETURN_INVOICE_DETAIL_FAILURE,
		ActionTypes.GET_PURCHASE_RETURN_INVOICE_DETAIL_LOADER,
	);
	const getPurchaseReturnInvoiceDetailService = new GetPurchaseReturnInvoiceDetailService(
		dispatchedActions,
	);
	addBasicInterceptors(getPurchaseReturnInvoiceDetailService);
	getPurchaseReturnInvoiceDetailService.addRequestInterceptor(
		new AuthenticationHeaderInterceptor(),
	);
	dispatch(getPurchaseReturnInvoiceDetailService.makeRequest(props));
};

/**
 * Action to call API of purchase invoice detail.
 * @param {object} props
 * @returns
 */

export const onGetPurchaseInvoiceDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_PURCHASE_INVOICE_DETAIL_SUCCESS,
		ActionTypes.GET_SALES_INVOICE_DETAIL_FAILURE,
		ActionTypes.GET_SALES_INVOICE_DETAIL_LOADER,
	);
	const getPurchaseInvoiceDetailService = new GetPurchaseInvoiceDetailService(dispatchedActions);
	addBasicInterceptors(getPurchaseInvoiceDetailService);
	getPurchaseInvoiceDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPurchaseInvoiceDetailService.makeRequest(props));
};

// Action to reset the state.
export const onResetRefundState = () => ({ type: ActionTypes.RESET_REFUND_STATE });
