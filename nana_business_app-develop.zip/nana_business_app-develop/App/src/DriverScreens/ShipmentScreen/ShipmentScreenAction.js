import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import GetShipmentsService from '@Shipment/GetShipmentsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetNotificationCountService from '@Notification/GetNotificationCountService';
import * as ActionTypes from './ActionType';

export const onStoreUserDetails = userDetails => {
	// Action to store the user details into the async storage.
	return {
		type: ActionTypes.STORE_USER_DETAILS,
		payload: userDetails,
	};
};

/**
 * Action to get the shipment listing.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetShipments = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_SHIPMENT_LISTING_SUCCESS,
		ActionTypes.GET_SHIPMENT_LISTING_FAILURE,
		ActionTypes.GET_SHIPMENT_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getShipmentsService = new GetShipmentsService(dispatchedActions);
	addBasicInterceptors(getShipmentsService);
	getShipmentsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getShipmentsService.makeRequest(props));
};

export const onGetNotificationCount = () => dispatch => {
	// Action to get the unread notification count.
	const dispatchedActions = actions(
		ActionTypes.GET_DRIVER_NOTIFICATION_COUNT_SUCCESS,
		ActionTypes.GET_DRIVER_NOTIFICATION_COUNT_FAILURE,
		ActionTypes.GET_DRIVER_NOTIFICATION_COUNT_LOADER,
	);
	const getNotificationCountService = new GetNotificationCountService(dispatchedActions);
	addBasicInterceptors(getNotificationCountService);
	getNotificationCountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getNotificationCountService.makeRequest());
};
