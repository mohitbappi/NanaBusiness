import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';
import { fetchDataWithPagination, shipmentStatus, filterShipments } from '@Constants/Constants';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import Search from '@Search/Search';
import DriverAppInvoiceCardComponent from '@DriverAppInvoiceCardComponent/DriverAppInvoiceCardComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import IconFilter from 'App/src/Widgets/IconFilter/IconFilter';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getShipmentStatus } from '@Util/GetShipmentStatus';
import driverNavigations from '@routes/driverNavigations';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { verticalScale } from '@device/normalize';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';
import * as ShipmentScreenActions from './ShipmentScreenAction';
import { createStyleSheet } from './ShipmentScreenStyle';

class ShipmentScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			searchText: '',
			isPickerVisible: false,
			isFilterVisible: false,
			activePickerIndex: 0, // By default search will work for shipment id
			activeFilterIndex: 0,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { refreshControlComponentInfo, pullToRefreshActions } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.page = fetchDataWithPagination.page;
			this.limit = getScrollingIndex(scrollIndex);
			this.setState(
				{
					searchText: '',
				},
				() => {
					this.onGetNotificationCount();
					this.onLoadMore(false);
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
		this.willFocusListener = navigation.addListener('blur', () => {
			this.resetScrollIndex();
		});
	}

	componentDidUpdate(prevProps) {
		const { shipmentScreenInfo, pullToRefreshActions } = this.props;
		const { success } = shipmentScreenInfo;
		if (success && prevProps.shipmentScreenInfo.success !== shipmentScreenInfo.success) {
			// Will hide the bottom loader.
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.page === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	onGetNotificationCount = () => {
		// API call to get the notification count.
		const { shipmentScreenActions } = this.props;
		shipmentScreenActions.onGetNotificationCount();
	};

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		// API call to get the shipment listing.
		const { shipmentScreenActions } = this.props;
		const { searchText, activePickerIndex, activeFilterIndex } = this.state;
		const queryParams = {};
		const activeSort = [
			filterShipments.assigned,
			filterShipments.started,
			filterShipments.inProgress,
			filterShipments.successful,
			filterShipments.failed,
		];
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (activeFilterIndex > 0) {
			queryParams.status = activeSort[activeFilterIndex - 1];
		}

		if (searchText) {
			if (activePickerIndex) {
				queryParams.customer_name = searchText;
			} else {
				queryParams.purchase_invoice_id = searchText;
			}
		}
		shipmentScreenActions.onGetShipments(queryParams, isOverwriteExistingList);
	};

	handlePicker = value => {
		this.setState({
			isPickerVisible: value,
		});
	};

	getLayout = (data, index) => ({
		// To Get length and offset for Scroll To Index Functionality
		length: verticalScale(70),
		offset: verticalScale(70) * index,
		index,
	});

	onSelectOption = index => {
		// Function to choose search criteria (attribute).
		this.setState(
			{
				activePickerIndex: index,
			},
			() => this.handlePicker(false),
		);
	};

	renderItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<DriverAppInvoiceCardComponent
					name={isRTL ? item.customer_name_ar || item.customer_name : item.customer_name}
					amount={`${currencyFormatter(getValueInDecimal(item.price))} ${localeString(
						keyConstants.SAR,
					)}`}
					status={getShipmentStatus(item.status)}
					statusStyle={item.status === shipmentStatus.successful && styles.statusStyle}
					isDisable={false}
					itemQuantity={item.quantity}
					onPress={() => this.getShipmentDetail(item.shipment_id, index)}
					hasViewInvoiceIcon
					onPressInvoice={() =>
						this.getInvoiceDetail(
							index,
							item.sales_invoice_id,
							item.shipment_id,
							currencyFormatter(getValueInDecimal(item.price)),
							item.customer_name,
						)
					}
					idText={`${localeString(keyConstants.PURCHASE_INVOICE_ID)}: ${
						item.purchase_invoice_id
					}`}
				/>
			</View>
		);
	};

	keyExtractor = (item, index) => index.toString();

	getShipmentDetail = (id, index) => {
		// Will navigate to the shipment detail screen.
		const { navigation } = this.props;
		navigation.navigate(driverNavigations.SHIPMENT_DETAIL_NAVIGATION, {
			id,
			index,
			isDriver: true,
		});
	};

	getInvoiceDetail = (index, id, shipmentID, amount, organization) => {
		// Will navigate to the sales invoice detail screen.
		const { navigation } = this.props;
		navigation.navigate(driverNavigations.SALES_INVOICE_DETAIL_NAVIGATION, {
			id,
			index,
			shipmentID,
			amount,
			organization,
			isSalesInvoice: true,
			isPurchase: false,
		});
	};

	onSearch = text => {
		// API call to search the shipment using purchase invoice id and customer name.
		this.page = fetchDataWithPagination.page;
		this.setState({ searchText: text }, () => {
			this.onLoadMore(false);
		});
	};

	listFooterComponent = () => {
		const { languageInfo, shipmentScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { shipmentsListing, count } = shipmentScreenInfo;
		const endReached = count === shipmentsListing.length || count < shipmentsListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { shipmentScreenInfo } = this.props;
		const { loader } = shipmentScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onLoadMore(true);
		}
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { shipmentScreenInfo, navigation } = this.props;
		const { notificationCount } = shipmentScreenInfo;
		navigation.navigate(driverNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	onRefresh = () => {
		// API calls while pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		this.resetScrollIndex();
		this.onGetNotificationCount();
		this.onFetchData(false);
	};

	// show or disable the filter modal
	handleFilter = value => {
		this.setState({
			isFilterVisible: value,
		});
	};

	// will set the filter
	onSelectFilter = index => {
		this.setState(
			{
				activeFilterIndex: index,
			},
			() => {
				this.page = fetchDataWithPagination.page; // resetting the page to 1
				this.handleFilter(false);
				this.onFetchData();
			},
		);
	};

	availableOptions = () => {
		return [
			{ name: localeString(keyConstants.ALL) },
			{ name: localeString(keyConstants.ASSIGNED) },
			{ name: localeString(keyConstants.STARTED) },
			{ name: localeString(keyConstants.IN_PROGRESS) },
			{ name: localeString(keyConstants.SUCCESSFUL) },
			{ name: localeString(keyConstants.FAILED) },
		];
	};

	render() {
		const {
			bottomLoader,
			searchText,
			isPickerVisible,
			activePickerIndex,
			isFilterVisible,
			activeFilterIndex,
		} = this.state;
		const { shipmentScreenInfo, languageInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			loader,
			shipmentsListing,
			count,
			notificationCount,
			error,
			errorCode,
		} = shipmentScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === '' && (
					<Loader size="large" />
				)}
				<OptionPicker
					isVisible={isFilterVisible}
					options={this.availableOptions()}
					title={localeString(keyConstants.STATUS)}
					isRTL={isRTL}
					onClose={() => this.handleFilter(false)}
					onSelectOption={this.onSelectFilter}
					activeIndex={activeFilterIndex}
				/>
				<OptionPicker
					isVisible={isPickerVisible}
					options={[
						{ name: localeString(keyConstants.PURCHASE_INVOICE_ID) },
						{ name: localeString(keyConstants.CUSTOMER_NAME) },
					]}
					title={localeString(keyConstants.SEARCH)}
					isRTL={isRTL}
					onClose={() => this.handlePicker(false)}
					onSelectOption={this.onSelectOption}
					activeIndex={activePickerIndex}
				/>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.SHIPMENTS)}
						hasIconShipment
						hasIconNotification
						onPressNotification={this.onPressNotification}
						notificationCount={notificationCount}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasIconFilter
						placeholder={localeString(
							keyConstants.SEARCH_BY_NAME_OR_PURCHASE_INVOICE_ID,
						)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
						onPressFilter={() => this.handlePicker(true)}
						keyboardType={activePickerIndex ? 'default' : 'numeric'}
					/>
				</View>
				<IconFilter
					onPress={() => this.handleFilter(true)}
					activePickerIndex={activeFilterIndex}
				/>
				{error ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<FlatListComponent
						keyboardShouldPersistTaps="handled"
						data={shipmentsListing}
						renderItem={this.renderItem}
						keyExtractor={this.keyExtractor}
						showsVerticalScrollIndicator={false}
						onEndReached={() =>
							shipmentsListing.length !== count && this.onEndReached()
						}
						ListFooterComponent={
							shipmentsListing.length !== 0 &&
							count > fetchDataWithPagination.limit &&
							this.listFooterComponent()
						}
						onEndReachedThreshold={0.5}
						ListEmptyComponent={() => (
							<ListEmpty text={localeString(keyConstants.NO_SHIPMENTS_FOUND)} />
						)}
						contentContainerStyle={
							shipmentsListing.length === 0 ? styles.scrollViewStyle : null
						}
						onRefresh={this.onRefresh}
						componentType={constants.flatList}
						onRef={ref => {
							this.itemListRef = ref;
						}}
						getItemLayout={this.getLayout}
					/>
				)}
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		shipmentScreenInfo: state.ShipmentScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		shipmentScreenActions: bindActionCreators({ ...ShipmentScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

ShipmentScreen.propTypes = {
	shipmentScreenInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	shipmentScreenActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ShipmentScreen);
