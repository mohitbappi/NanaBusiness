export const STORE_USER_DETAILS = 'store_user_details';

export const GET_SHIPMENT_LISTING_FAILURE = 'get_shipment_listing_failure';
export const GET_SHIPMENT_LISTING_SUCCESS = 'get_shipment_listing_success';
export const GET_SHIPMENT_LISTING_LOADER = 'get_shipment_listing_loader';

export const GET_DRIVER_NOTIFICATION_COUNT_SUCCESS = 'get_driver_notification_count_success';
export const GET_DRIVER_NOTIFICATION_COUNT_FAILURE = 'get_driver_notification_count_failure';
export const GET_DRIVER_NOTIFICATION_COUNT_LOADER = 'get_driver_notification_count_loader';
