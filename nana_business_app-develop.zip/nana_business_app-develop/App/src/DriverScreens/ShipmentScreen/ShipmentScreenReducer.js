import * as ActionTypes from './ActionType';

const initialState = {
	userDetails: null,
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	shipmentsListing: [],
	notificationCount: 0,
	count: 0,
};

const ShipmentScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.STORE_USER_DETAILS:
			return {
				...state,
				userDetails: action.payload,
			};
		case ActionTypes.GET_SHIPMENT_LISTING_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				shipmentsListing: isOverwriteExistingList
					? [...state.shipmentsListing, ...action.payload.rows]
					: action.payload.rows,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_SHIPMENT_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_SHIPMENT_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.GET_DRIVER_NOTIFICATION_COUNT_SUCCESS:
			return {
				...state,
				notificationCount: action.payload.pending_notifications,
			};
		default:
			return state;
	}
};

export default ShipmentScreenReducer;
