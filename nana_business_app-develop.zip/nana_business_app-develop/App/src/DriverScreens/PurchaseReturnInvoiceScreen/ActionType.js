export const GET_PURCHASE_INVOICE_LISTING_FAILURE = 'get_purchase_invoice_listing_failure';
export const GET_PURCHASE_INVOICE_LISTING_SUCCESS = 'get_purchase_invoice_listing_success';
export const GET_PURCHASE_INVOICE_LISTING_LOADER = 'get_purchase_invoice_listing_loader';

export const RESELL_ITEMS_SUCCESS = 'resell_items_success';
export const RESELL_ITEMS_FAILURE = 'resell_items_failure';
export const RESELL_ITEMS_LOADER = 'resell_items_loader';

export const RESET_PURCHASE_RETURN_STATE = 'reset_purchase_return_state';
