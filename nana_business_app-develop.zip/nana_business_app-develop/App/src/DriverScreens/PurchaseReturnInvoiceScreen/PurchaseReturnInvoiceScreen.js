// import libraries
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Search from '@Search/Search';
import DriverAppInvoiceCardComponent from '@DriverAppInvoiceCardComponent/DriverAppInvoiceCardComponent';
import Loader from '@Loader/Loader';
import OptionPicker from '@OptionPicker/OptionPicker';
import ListEmpty from '@ListEmpty/ListEmpty';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

// import constants
import { keyConstants } from '@assets/Constants/KeyConstants';
import { localeString } from '@Localization/index';
import {
	fetchDataWithPagination,
	purchaseReturnInvoiceStatus,
	toastShowTime,
} from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import utils
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDate } from '@Util/GetFormattedDate';
import driverNavigations from '@routes/driverNavigations';
import { removeSpaces } from '@Util/GetFormattedString';
import { downloadFile } from '@Util/DownloadFile';
import { verticalScale } from '@device/normalize';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';

// import actions
import * as ShipmentScreenActions from '@ShipmentScreen/ShipmentScreenAction';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as PurchaseReturnInvoiceScreenActions from './PurchaseReturnInvoiceScreenAction';

// import styles
import { createStyleSheet } from './PurchaseReturnInvoiceScreenStyle';

class PurchaseReturnInvoiceScreen extends Component {
	constructor(props) {
		super(props);
		this.purchaseInvoiceLimit = fetchDataWithPagination.limit;
		this.purchaseInvoicePage = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			searchText: '',
			isPickerVisible: false,
			activePickerIndex: 0, // By default search will work for invoice id
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { refreshControlComponentInfo, pullToRefreshActions } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.purchaseInvoicePage = fetchDataWithPagination.page;
			this.limit = getScrollingIndex(scrollIndex);
			this.setState(
				{
					searchText: '',
				},
				() => {
					this.onGetNotificationCount();
					this.onLoadPurchaseInvoices(false);
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
		this.willFocusListener = navigation.addListener('blur', () => {
			this.resetScrollIndex();
		});
	}

	componentDidUpdate(prevProps) {
		const { purchaseInvoiceScreenInfo, pullToRefreshActions } = this.props;
		const { success } = purchaseInvoiceScreenInfo;
		if (
			success &&
			prevProps.purchaseInvoiceScreenInfo.success !== purchaseInvoiceScreenInfo.success
		) {
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.purchaseInvoicePage === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	onGetNotificationCount = () => {
		// API call to get the notification count.
		const { shipmentScreenActions } = this.props;
		shipmentScreenActions.onGetNotificationCount();
	};

	onLoadPurchaseInvoices = isOverwriteExistingList => {
		this.onFetchPurchaseInvoices(isOverwriteExistingList);
	};

	onFetchPurchaseInvoices = isOverwriteExistingList => {
		// API call to fetch purchase return invoice listing.
		const { purchaseReturnInvoiceScreenActions } = this.props;
		const { searchText, activePickerIndex } = this.state;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.purchaseInvoicePage;
		if (searchText) {
			if (activePickerIndex) {
				queryParams.vendor_name = searchText; // Search by vendor name.
			} else {
				queryParams.invoice_id = searchText; // Search by vendor pi id.
			}
		}
		purchaseReturnInvoiceScreenActions.onGetPurchaseInvoices(
			queryParams,
			isOverwriteExistingList,
		);
	};

	onSelectSearchOption = index => {
		this.setState(
			{
				activePickerIndex: index,
			},
			() => this.handlePicker(false),
		);
	};

	getLayout = (data, index) => ({
		// To Get length and offset for Scroll To Index Functionality
		length: verticalScale(70),
		offset: verticalScale(70) * index,
		index,
	});

	handlePicker = value => {
		// Handling to close search filter.
		this.setState({
			isPickerVisible: value,
		});
	};

	onPressReturnNotification = () => {
		// Will navigate to notification screen.
		const { shipmentScreenInfo, navigation } = this.props;
		const { notificationCount } = shipmentScreenInfo;
		navigation.navigate(driverNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	renderItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<DriverAppInvoiceCardComponent
					name={`${isRTL ? item.vendor_name_ar || item.vendor_name : item.vendor_name} (${
						item.reference_id
					})`}
					amount={`${currencyFormatter(
						getValueInDecimal(item.total_amount),
					)} ${localeString(keyConstants.SAR)}`}
					isDisable={false}
					returnInvoiceId={
						item.shipment_delivery_id
							? `${localeString(keyConstants.SHIPMENT_ID)}: ${
									item.shipment_delivery_id
							  }`
							: ''
					}
					date={getFormattedDate(item.created_at)}
					isShowStatus // Boolean to show status
					status={this.getPurchaseReturnInvoiceStatus(item.status).name}
					statusStyle={this.getPurchaseReturnInvoiceStatus(item.status).style}
					onPress={() => this.onGotoDetail(item, index)}
					hasHyperlink={
						item.status !== purchaseReturnInvoiceStatus.open &&
						item.status !== purchaseReturnInvoiceStatus.resold
					} // Boolean to show hyperlink
					hyperlinkTitle={localeString(keyConstants.DOWNLOAD)}
					onPressHyperlink={() => this.onDownloadInvoice(item)}
				/>
			</View>
		);
	};

	onGotoDetail = (item, index) => {
		const { navigation } = this.props;
		navigation.navigate(driverNavigations.SALES_INVOICE_DETAIL_NAVIGATION, {
			id: item.id,
			index,
			amount: '',
			organization: '',
			isSalesInvoice: false,
			purchaseInvoiceData: item,
		});
	};

	onDownloadInvoice = item => {
		// Function to download purchase return invoice.
		const { image, customer_name, reference_id } = item;
		this.onDownloadFile(image, `${removeSpaces(customer_name)}-${reference_id}`);
	};

	onDownloadFile = (downloadUrl, downloadFileName) => {
		downloadFile(
			downloadUrl, // Url of the purchase return invoice.
			downloadFileName, // File name of the purchase return invoice.
			() => {
				this.onShowDownloadFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
			},
			() => {
				this.onShowDownloadFileStatus(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
			},
			() => {
				this.onShowDownloadFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
			},
		);
	};

	onShowDownloadFileStatus = message => {
		// function to show file downloading status in toast message
		this.setState({
			toastMessage: message,
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	keyExtractor = (item, index) => index.toString();

	getPurchaseReturnInvoiceStatus = status => {
		// Function to return status name and it's style according to the status.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const purchaseReturnStatus = {
			[`${purchaseReturnInvoiceStatus.open}`]: {
				name: localeString(keyConstants.OPEN),
				style: styles.openStatusStyle,
			},
			[`${purchaseReturnInvoiceStatus.pending}`]: {
				name: localeString(keyConstants.PENDING),
				style: styles.pendingStatusStyle,
			},
			[`${purchaseReturnInvoiceStatus.approved}`]: {
				name: localeString(keyConstants.APPROVED),
				style: styles.approvedStatusStyle,
			},
			[`${purchaseReturnInvoiceStatus.rejected}`]: {
				name: localeString(keyConstants.REJECTED),
				style: styles.cancelledStatusStyle,
			},
			[`${purchaseReturnInvoiceStatus.resold}`]: {
				name: localeString(keyConstants.RESOLD),
				style: styles.approvedStatusStyle,
			},
		};
		return purchaseReturnStatus[status];
	};

	listFooterComponent = () => {
		const { languageInfo, purchaseInvoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { purchaseInvoiceListing, count } = purchaseInvoiceScreenInfo;
		const endReached =
			count === purchaseInvoiceListing.length || count < purchaseInvoiceListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { purchaseInvoiceScreenInfo } = this.props;
		const { loader } = purchaseInvoiceScreenInfo;
		if (!loader) {
			this.setState(
				{
					bottomLoader: true,
				},
				() => {
					this.purchaseInvoicePage += getPage(this.limit);
					this.limit = fetchDataWithPagination.limit;
					this.onLoadPurchaseInvoices(true);
				},
			);
		}
	};

	onSearchText = text => {
		// Will call API while searching.
		this.purchaseInvoicePage = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onLoadPurchaseInvoices(false);
			},
		);
	};

	onRefresh = () => {
		this.purchaseInvoicePage = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		this.resetScrollIndex();
		this.onGetNotificationCount();
		this.onFetchPurchaseInvoices(false);
	};

	render() {
		const {
			languageInfo,
			purchaseInvoiceScreenInfo,
			shipmentScreenInfo,
			refreshControlComponentInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			bottomLoader,
			searchText,
			isPickerVisible,
			activePickerIndex,
			isApiError,
			toastMessage,
		} = this.state;
		const {
			loader,
			purchaseInvoiceListing,
			count,
			isResellItems,
			error,
			errorCode,
		} = purchaseInvoiceScreenInfo;
		const { notificationCount } = shipmentScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader &&
					!isResellItems &&
					!isFetchingForPullToRefresh &&
					!bottomLoader &&
					searchText === '' && <Loader size="large" />}
				<OptionPicker
					isRTL={isRTL}
					isVisible={isPickerVisible}
					activeIndex={activePickerIndex}
					options={[
						{ name: localeString(keyConstants.VENDOR_PI_ID) },
						{ name: localeString(keyConstants.CUSTOMER_NAME) },
					]}
					title={localeString(keyConstants.SEARCH)}
					onClose={() => this.handlePicker(false)}
					onSelectOption={this.onSelectSearchOption}
				/>
				<View style={styles.headerContainer}>
					<Header
						hasIconPurchase
						hasIconNotification
						text={localeString(keyConstants.PURCHASE_RETURN)}
						onPressNotification={this.onPressReturnNotification}
						notificationCount={notificationCount}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						value={searchText}
						placeholder={localeString(keyConstants.SEARCH_BY_NAME_OR_VENDOR_PI_ID)}
						hasIconFilter
						onChangeText={text => this.onSearchText(text)}
						onPressFilter={() => this.handlePicker(true)}
					/>
				</View>
				{error && !isResellItems ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<FlatListComponent
						keyboardShouldPersistTaps="handled"
						data={purchaseInvoiceListing}
						renderItem={this.renderItem}
						keyExtractor={this.keyExtractor}
						showsVerticalScrollIndicator={false}
						onEndReached={() =>
							purchaseInvoiceListing.length !== count && this.onEndReached()
						}
						ListFooterComponent={
							purchaseInvoiceListing.length !== 0 &&
							count > fetchDataWithPagination.limit &&
							this.listFooterComponent()
						}
						onEndReachedThreshold={0.5}
						ListEmptyComponent={() => (
							<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
						)}
						contentContainerStyle={
							purchaseInvoiceListing.length === 0 ? styles.scrollViewStyle : null
						}
						onRefresh={this.onRefresh}
						componentType={constants.flatList}
						onRef={ref => {
							this.itemListRef = ref;
						}}
						getItemLayout={this.getLayout}
					/>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		purchaseInvoiceScreenInfo: state.PurchaseReturnInvoiceScreenReducer,
		shipmentScreenInfo: state.ShipmentScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		purchaseReturnInvoiceScreenActions: bindActionCreators(
			{ ...PurchaseReturnInvoiceScreenActions },
			dispatch,
		),
		shipmentScreenActions: bindActionCreators({ ...ShipmentScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

PurchaseReturnInvoiceScreen.propTypes = {
	purchaseInvoiceScreenInfo: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	shipmentScreenActions: PropTypes.object.isRequired,
	purchaseReturnInvoiceScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	shipmentScreenInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(PurchaseReturnInvoiceScreen);
