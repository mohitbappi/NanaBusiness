import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	purchaseInvoiceListing: [],
	count: 0,
	isResellItems: false,
};

const PurchaseReturnInvoiceScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_PURCHASE_INVOICE_LISTING_SUCCESS: {
			// Action to call purchase return invoice listing API.
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				purchaseInvoiceListing: isOverwriteExistingList
					? [...state.purchaseInvoiceListing, ...action.payload.rows]
					: action.payload.rows,
				count: action.payload.count,
				isResellItems: false,
			};
		}
		case ActionTypes.GET_PURCHASE_INVOICE_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isResellItems: false,
			};
		case ActionTypes.GET_PURCHASE_INVOICE_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isResellItems: false,
			};
		case ActionTypes.RESELL_ITEMS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isResellItems: true,
			};
		case ActionTypes.RESELL_ITEMS_SUCCESS:
			// Action to call resell items API.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isResellItems: true,
			};
		case ActionTypes.RESELL_ITEMS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isResellItems: true,
			};
		case ActionTypes.RESET_PURCHASE_RETURN_STATE:
			return initialState;
		default:
			return state;
	}
};

export default PurchaseReturnInvoiceScreenReducer;
