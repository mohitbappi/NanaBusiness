import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetPurchaseInvoicesService from '@PurchaseInvoice/GetPurchaseInvoicesService';
import ResellItemsService from '@PurchaseInvoice/ResellItemsService';
import * as ActionTypes from './ActionType';

/**
 * Action to call the API to fetch purchase return listing.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetPurchaseInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_PURCHASE_INVOICE_LISTING_SUCCESS,
		ActionTypes.GET_PURCHASE_INVOICE_LISTING_FAILURE,
		ActionTypes.GET_PURCHASE_INVOICE_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getPurchaseInvoicesService = new GetPurchaseInvoicesService(dispatchedActions);
	addBasicInterceptors(getPurchaseInvoicesService);
	getPurchaseInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPurchaseInvoicesService.makeRequest(props));
};

/**
 * API call to resell the items.
 * @param {object} props
 * @returns
 */

export const onResellItems = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.RESELL_ITEMS_SUCCESS,
		ActionTypes.RESELL_ITEMS_FAILURE,
		ActionTypes.RESELL_ITEMS_LOADER,
	);
	const resellItemsService = new ResellItemsService(dispatchedActions);
	addBasicInterceptors(resellItemsService);
	resellItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(resellItemsService.makeRequest(props));
};

export const onResetPurchaseReturnState = () => ({ type: ActionTypes.RESET_PURCHASE_RETURN_STATE });
