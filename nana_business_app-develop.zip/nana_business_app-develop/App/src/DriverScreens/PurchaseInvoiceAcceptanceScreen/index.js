export { default } from './PurchaseInvoiceAcceptanceUI';
