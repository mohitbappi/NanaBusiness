// import libraries
import React from 'react';
import PropTypes from 'prop-types';

// import components
import ConfimationModal from '@ConfimationModal/ConfimationModal';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import driverNavigations from '@routes/driverNavigations';

const PurchaseInvoiceAcceptanceUI = props => {
	// Component to show message of acceptance on modal.

	const onGoToPurchaseInvoices = () => {
		const { navigation } = props;
		navigation.navigate(driverNavigations.PURCHASE_INVOICE_NAVIGATION);
	};

	const { route } = props;
	const { isFullyAccepted } = route.params || {};
	return (
		<ConfimationModal
			title={localeString(
				isFullyAccepted
					? keyConstants.INVOICE_ACCEPTED
					: keyConstants.ITEM_MODIFICATION_REQUEST_GENERATED,
			)}
			description={isFullyAccepted ? localeString(keyConstants.INVOICE_ACCEPTED_MESSAGE) : ''}
			onPress={onGoToPurchaseInvoices}
			buttonTitle={localeString(keyConstants.BACK_TO_PURCHASE_INVOICES)}
			hasButton
		/>
	);
};

PurchaseInvoiceAcceptanceUI.propTypes = {
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default PurchaseInvoiceAcceptanceUI;
