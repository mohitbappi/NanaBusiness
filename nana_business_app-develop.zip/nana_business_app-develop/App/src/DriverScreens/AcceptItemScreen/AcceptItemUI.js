/* import libraries */
import React, { Component } from 'react';
import { View } from 'react-native';
import SwiperFlatList from 'react-native-swiper-flatlist';
import PropTypes from 'prop-types';

/* import constants */
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

/* import components */
import ProductDetailCardComponent from '@Products/ProductDetailCardComponent';
import Header from '@Header/Header';
import Spinner from '@Spinner/Spinner';

/* import styles */
import { createStyleSheet } from './AcceptItemScreenStyle';

class AcceptItemUI extends Component {
	constructor(props) {
		super(props);
		this.itemListRef = React.createRef(null);
	}

	renderProductDetail = (item, index) => {
		const {
			isRTL,
			itemsListing,
			isShowSwipeMessages, // Boolean to show/hide swipe left & swipe right indicator.
			onUpdateItemQuantity,
			onChangeItemQuantity,
			itemQuantity,
			isShowItemAcceptedToast,
			ItemsAcceptedBooleanArray,
			numberOfItemsAccepted,
		} = this.props;
		return (
			<ProductDetailCardComponent
				isRTL={isRTL}
				isAcceptItem
				item={item}
				isFirstItem={index === 1 && isShowSwipeMessages} // Will show swipe right indicator if invoice contains more than 1 item.
				isLastItem={
					((itemsListing.length > 1 && index === 0) ||
						(itemsListing.length > 2 && index === 1)) &&
					isShowSwipeMessages
				} // Will show swipe left indicator if invoice more than 1 item.
				onUpdateItemQuantity={actionType => onUpdateItemQuantity(actionType, index)} // Will update item quantity at the given index.
				itemQuantity={itemQuantity}
				onChangeItemQuantity={onChangeItemQuantity}
				isShowItemAcceptedToast={isShowItemAcceptedToast}
				isItemAccepted={ItemsAcceptedBooleanArray[index]}
				numberOfItemsAccepted={numberOfItemsAccepted}
				itemsListing={itemsListing}
				onPress={() => this.onAcceptItem(index)}
			/>
		);
	};

	onAcceptItem = index => {
		const { onAcceptItem, itemsListing } = this.props;
		if (index + 1 < itemsListing.length) {
			this.itemListRef.current.scrollToIndex({
				index: index + 1,
				animated: true,
			});
		}
		onAcceptItem();
	};

	render() {
		const {
			isRTL,
			itemsListing,
			onGoBack,
			onChangeIndex,
			selectedItemIndex,
			loader,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.ITEM_DETAIL)}
						hasIconBack
						onPressBack={onGoBack}
					/>
				</View>
				<SwiperFlatList // Flatlist which will work as a slider or carousel.
					data={itemsListing}
					index={selectedItemIndex}
					onChangeIndex={({ index, prevIndex }) => onChangeIndex(index, prevIndex)} // Prop to perform action if index changes.
					renderItem={({ item, index }) => this.renderProductDetail(item, index)}
					renderAll
					ref={this.itemListRef}
				/>
			</View>
		);
	}
}

AcceptItemUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	onUpdateItemQuantity: PropTypes.func.isRequired,
	isShowSwipeMessages: PropTypes.bool.isRequired,
	isShowItemAcceptedToast: PropTypes.bool.isRequired,
	onChangeItemQuantity: PropTypes.func.isRequired,
	numberOfItemsAccepted: PropTypes.element.isRequired,
	itemsListing: PropTypes.array.isRequired,
	ItemsAcceptedBooleanArray: PropTypes.array.isRequired,
	itemQuantity: PropTypes.string.isRequired,
	onAcceptItem: PropTypes.func.isRequired,
	onChangeIndex: PropTypes.func.isRequired,
	selectedItemIndex: PropTypes.element.isRequired,
};

export default AcceptItemUI;
