/* import libraries */
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import driverNavigations from '@routes/driverNavigations';

/* import components */
import { toastShowTime, QUANTITY_MODIFICATION_OPERATION } from '@Constants/Constants';
import {
	getSumOfItemQuantity,
	getSumOfReturnItemQuantity,
} from '@EditItemsQuantityScreen/getSomeOfItemQuantity';
import AcceptItemUI from './AcceptItemUI';

class AcceptItemComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.state = {
			isShowSwipeMessages: false,
			selectedItemQuantity: 0, // Store quantity of the selected item.
			selectedItemIndex: 0, // Store index of the selected item.
			isShowItemAcceptedToast: false,
		};
	}

	componentDidMount() {
		const { route, acceptItemInfo, navigation, acceptItemActions } = this.props;
		const { invoiceDetail, itemIndex, id } = route.params || {};
		const { itemsListing, purchaseInvoiceId } = acceptItemInfo;
		this.willFocusListener = navigation.addListener('focus', () => {
			if (purchaseInvoiceId !== id) {
				// If user started the purchase invoice acceptance first time.
				acceptItemActions.onSaveInvoiceItems(invoiceDetail.rows, id);
				this.onSetItemQuantity(invoiceDetail.rows, itemIndex);
			} else {
				// If user already completed the purchase invoice acceptance or it is in progress.
				this.onSetItemQuantity(itemsListing, itemIndex);
			}
			if (itemsListing.length >= 1) {
				// Will show/hide swipe messages if there are atleast one item in the invoice detail.
				this.setState(
					{
						isShowSwipeMessages: true,
					},
					() => this.onShowHideSwipeMessages(),
				);
			}
		});
	}

	componentDidUpdate(prevProps) {
		const { acceptItemInfo, navigation } = this.props;
		const { success, acceptanceRequestId, itemsListing } = acceptItemInfo;
		if (success && prevProps.acceptItemInfo.success !== acceptItemInfo.success) {
			// If API succeed.
			if (this.onCheckAllItemsAccepted(itemsListing)) {
				// If all the items are accepted with all the quantity (It means all the items are available) then, it will navigate to purchase invoice acceptance screen..
				navigation.navigate(driverNavigations.PURCHASE_INVOICE_ACCEPTANCE_NAVIGATION, {
					isFullyAccepted: true,
				});
			} else {
				// If some of the items are unavailable then, it will navigate to purchase invoice summary screen.
				navigation.navigate(driverNavigations.PURCHASE_INVOICE_SUMMARY_NAVIGATION, {
					acceptanceRequestId,
					isSubmitButtonEnable: true,
				});
			}
		}
	}

	componentWillUnmount() {
		const { acceptItemInfo, acceptItemActions } = this.props;
		const { numberOfItemsAccepted } = acceptItemInfo;
		if (numberOfItemsAccepted > 0) {
			// If any of the item accepted the will show saved as draft.
			acceptItemActions.onSavedAsDraft(true);
			setTimeout(() => {
				acceptItemActions.onSavedAsDraft(false);
			}, toastShowTime);
		}
	}

	onSetItemQuantity = (itemsListing, index) => {
		// Will store modified item quantity locally.
		let selectedItemQuantity = 0;
		if (itemsListing && itemsListing[index].returned_qty === 0) {
			// If returned quantity === 0.
			selectedItemQuantity = itemsListing[index].quantity;
		} else {
			// If returned quantity <= quantity.
			selectedItemQuantity = itemsListing[index].quantity - itemsListing[index].returned_qty;
		}
		this.setState({
			selectedItemQuantity,
			selectedItemIndex: index,
		});
	};

	onShowHideSwipeMessages = () => {
		setTimeout(() => {
			this.setState({
				isShowSwipeMessages: false,
			});
		}, toastShowTime);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeIndex = (index, prevIndex) => {
		// Will execute if swiperFlatlist index has been changed.
		const { acceptItemInfo } = this.props;
		const { itemsListing } = acceptItemInfo;
		if (itemsListing[index] && index !== prevIndex) {
			this.onSetItemQuantity(itemsListing, index);
		}
		if (index <= 1 && itemsListing.length >= 1) {
			this.setState(
				{
					isShowSwipeMessages: true,
				},
				() => this.onShowHideSwipeMessages(),
			);
		}
	};

	onUpdateItemQuantity = (actionType, index) => {
		// Will update & store modified item quantity.
		const { acceptItemInfo } = this.props;
		const { itemsListing } = acceptItemInfo;
		if (itemsListing[index]) {
			let { selectedItemQuantity } = this.state;
			if (
				actionType === QUANTITY_MODIFICATION_OPERATION.UPDATE &&
				selectedItemQuantity > itemsListing[index].quantity
			) {
				// If user enters the quantity greater than original quantity then it will store original quantity.
				selectedItemQuantity = this.getUpdatedQuantity(itemsListing[index].quantity)[
					QUANTITY_MODIFICATION_OPERATION.UPDATE
				];
			} else {
				selectedItemQuantity = this.getUpdatedQuantity(selectedItemQuantity)[actionType];
			}
			this.setState({
				selectedItemQuantity,
			});
		}
	};

	getUpdatedQuantity = quantity => {
		return {
			[`${QUANTITY_MODIFICATION_OPERATION.ADD}`]: quantity + 1, // Will increase quantity by 1.
			[`${QUANTITY_MODIFICATION_OPERATION.REMOVE}`]: quantity - 1, // Will decrease quantity by 1.
			[`${QUANTITY_MODIFICATION_OPERATION.UPDATE}`]: quantity, // Will update quantity with the new one.
		};
	};

	onChangeItemQuantity = text => {
		const updatedText = text || 0;
		this.setState({
			selectedItemQuantity: parseInt(updatedText, 10),
		});
	};

	onAcceptItem = () => {
		// Function to accept the item and show the toast.
		const { acceptItemInfo, acceptItemActions } = this.props;
		const { selectedItemIndex, selectedItemQuantity } = this.state;
		const {
			itemsListing,
			numberOfItemsAccepted, // Count of accepted items
		} = acceptItemInfo;
		acceptItemActions.onAcceptItemQuantity(
			selectedItemIndex,
			itemsListing[selectedItemIndex].quantity - selectedItemQuantity,
		);
		this.setState(
			{
				isShowItemAcceptedToast: true,
			},
			() => {
				setTimeout(() => {
					this.setState({
						isShowItemAcceptedToast: false,
					});
				}, toastShowTime);
			},
		);
		if (
			itemsListing.length === numberOfItemsAccepted + 1 ||
			itemsListing.length === numberOfItemsAccepted
		) {
			// If all the items are accepted then call the API to create acceptance request.
			this.onCreateAcceptanceRequest();
		}
	};

	onCreateAcceptanceRequest = () => {
		// API call to create acceptance request.
		const { route, acceptItemActions } = this.props;
		const { id } = route.params || {};
		const queryParams = {};
		queryParams.id = id;
		queryParams.body = this.getRequestBody();
		acceptItemActions.onCreateAcceptanceRequest(queryParams);
	};

	getRequestBody = () => {
		const { acceptItemInfo } = this.props;
		const { itemsListing } = acceptItemInfo;
		const body = {};
		if (this.onCheckAllItemsAccepted(itemsListing)) {
			// If all items are available.
			body.fully_accepted = true;
		} else {
			// If some of the items are unavailable.
			const tempArray = itemsListing.reduce((accumulator, item) => {
				if (item.returned_qty !== 0) {
					// If returned quantity > 0.
					accumulator.push({
						item_id: item.id,
						quantity: item.returned_qty, // Unavailable quantity.
					});
				}
				return accumulator;
			}, []);
			body.items = tempArray;
			body.fully_accepted = false;
		}
		return body;
	};

	onCheckAllItemsAccepted = itemsListing => {
		// Function to check if all the items are accepted or not with all the quantity.
		return getSumOfItemQuantity(itemsListing) === getSumOfReturnItemQuantity(itemsListing);
	};

	render() {
		const { languageInfo, acceptItemInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const {
			itemsListing,
			numberOfItemsAccepted,
			loader,
			ItemsAcceptedBooleanArray,
		} = acceptItemInfo;
		const { isShowSwipeMessages, selectedItemQuantity, isShowItemAcceptedToast } = this.state;
		const { itemIndex } = route.params || {};
		return (
			<AcceptItemUI
				isRTL={isRTL}
				itemsListing={itemsListing}
				onGoBack={this.onGoBack}
				isShowSwipeMessages={isShowSwipeMessages}
				onChangeIndex={this.onChangeIndex}
				onUpdateItemQuantity={this.onUpdateItemQuantity}
				onChangeItemQuantity={this.onChangeItemQuantity}
				itemQuantity={selectedItemQuantity}
				numberOfItemsAccepted={numberOfItemsAccepted}
				onAcceptItem={this.onAcceptItem}
				selectedItemIndex={itemIndex}
				isShowItemAcceptedToast={isShowItemAcceptedToast}
				loader={loader}
				ItemsAcceptedBooleanArray={ItemsAcceptedBooleanArray}
			/>
		);
	}
}

AcceptItemComponent.propTypes = {
	acceptItemInfo: PropTypes.object.isRequired,
	acceptItemActions: PropTypes.object.isRequired,
	customProps: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default AcceptItemComponent;
