import { actions } from '@libapi/APIActionsBuilder';
import CreateAcceptanceRequestService from '@PurchaseInvoices/CreateAcceptanceRequestService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to save items and purchase invoice id.
 * @param {Array} itemsListing
 * @param {integer} id
 * @returns
 */

export const onSaveInvoiceItems = (itemsListing, id) => {
	return {
		type: ActionTypes.SAVE_INVOICE_ITEMS,
		payload: { itemsListing, id },
	};
};

/**
 * Action to save modified return quantity of the item at the given index.
 * @param {integer} index
 * @param {integer} quantity
 * @returns
 */

export const onAcceptItemQuantity = (index, quantity) => {
	return {
		type: ActionTypes.ACCEPT_ITEM_QUANTITY,
		payload: { index, quantity },
	};
};

/**
 * Action to show saved as draft toast.
 * @param {boolean} value
 * @returns
 */

export const onSavedAsDraft = value => {
	return {
		type: ActionTypes.SAVED_AS_DRAFT,
		payload: value,
	};
};

/**
 * Action to call the create acceptance request.
 * @param {object} props
 * @returns
 */

export const onCreateAcceptanceRequest = props => dispatch => {
	const dispatchedActions = new actions(
		ActionTypes.CREATE_ACCEPTANCE_REQUEST_SUCCESS,
		ActionTypes.CREATE_ACCEPTANCE_REQUEST_FAILURE,
		ActionTypes.CREATE_ACCEPTANCE_REQUEST_LOADER,
	);
	const createAcceptanceRequestService = new CreateAcceptanceRequestService(dispatchedActions);
	addBasicInterceptors(createAcceptanceRequestService);
	createAcceptanceRequestService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(createAcceptanceRequestService.makeRequest(props));
};
