import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	purchaseInvoiceId: null,
	itemsListing: [],
	ItemsAcceptedBooleanArray: [],
	numberOfItemsAccepted: 0,
	isSavedAsDraft: false,
	acceptanceRequestId: null,
};

const getAccepedItemsCount = array => {
	// Function to return the accepted items count.
	const filteredArray = array.filter(value => value === true);
	return filteredArray.length;
};

const AcceptItemScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.SAVE_INVOICE_ITEMS: {
			// ItemsAcceptedBooleanArray will store false values of the itemsListing length.
			const ItemsAcceptedBooleanArray = Array(action.payload.itemsListing.length).fill(false);
			return {
				...state,
				purchaseInvoiceId: action.payload.id,
				itemsListing: action.payload.itemsListing,
				ItemsAcceptedBooleanArray,
				numberOfItemsAccepted: 0,
			};
		}
		case ActionTypes.ACCEPT_ITEM_QUANTITY: {
			// Will update return quantity if the item after accepting the item and mark it accepted using ItemsAcceptedBooleanArray array.
			const { index, quantity } = action.payload;
			const updateState = state;
			if (state.itemsListing && state.itemsListing[index]) {
				updateState.itemsListing[index].returned_qty = quantity;
				updateState.ItemsAcceptedBooleanArray[index] = true;
			}
			return {
				...state,
				itemsListing: state.itemsListing,
				ItemsAcceptedBooleanArray: state.ItemsAcceptedBooleanArray,
				numberOfItemsAccepted: getAccepedItemsCount(state.ItemsAcceptedBooleanArray),
			};
		}
		case ActionTypes.SAVED_AS_DRAFT:
			return {
				...state,
				isSavedAsDraft: action.payload,
			};
		case ActionTypes.CREATE_ACCEPTANCE_REQUEST_SUCCESS:
			// API call to create acceptance request.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				acceptanceRequestId: action.payload ? action.payload.id : null,
			};
		case ActionTypes.CREATE_ACCEPTANCE_REQUEST_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
			};
		case ActionTypes.CREATE_ACCEPTANCE_REQUEST_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
			};
		default:
			return state;
	}
};

export default AcceptItemScreenReducer;
