import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import { normalScale } from '@device/normalize';

export const createStyleSheet = () => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
		},
	});
};

export default createStyleSheet;
