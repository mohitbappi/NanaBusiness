export const SAVE_INVOICE_ITEMS = 'save_invoice_items';

export const ACCEPT_ITEM_QUANTITY = 'accept_item_quantity';

export const SAVED_AS_DRAFT = 'saved_as_draft';

export const CREATE_ACCEPTANCE_REQUEST_SUCCESS = 'create_acceptance_request_success';
export const CREATE_ACCEPTANCE_REQUEST_FAILURE = 'create_acceptance_request_failure';
export const CREATE_ACCEPTANCE_REQUEST_LOADER = 'create_acceptance_request_loader';
