/* import libraries */
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

/* import components */
import AcceptItemComponent from './AcceptItemComponent';

// import actions
import * as AcceptItemActions from './AcceptItemScreenAction';

const AcceptItemContainer = props => {
	const customProps = { ...props }; // Will store all the props.
	return <AcceptItemComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		acceptItemInfo: state.AcceptItemScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		acceptItemActions: bindActionCreators({ ...AcceptItemActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(AcceptItemContainer);
