// import libraries
import React, { Component } from 'react';
import { View, FlatList } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import ProductCardComponent from '@Products/ProductCardComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import AlertComponent from '@Util/AlertComponent';
import { localeString } from '@assets/Localization';

// import constants
import { keyConstants } from '@Constants/KeyConstants';

// import utils
import driverNavigations from '@routes/driverNavigations';
import * as ShipmentScreenActions from '@ShipmentScreen/ShipmentScreenAction';
import { getSumOfItemQuantity } from './getSomeOfItemQuantity';

// import styles
import { createStyleSheet } from './EditItemsQuantityScreenStyle';

class EditItemsQuantityScreen extends Component {
	constructor(props) {
		super(props);
		this.state = { itemsListing: [], totalQuantityOrdered: 0 };
	}

	componentDidMount() {
		const { route, navigation } = this.props;
		const { itemsListing, totalQuantity } = route.params;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.setState({ itemsListing }, () => {
				this.onGetNotificationCount();
				this.setState({
					// Will save the total quantity of the items of all the products ordered by the user.
					totalQuantityOrdered: totalQuantity,
				});
			});
		});
	}

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onGetNotificationCount = () => {
		const { shipmentScreenActions } = this.props;
		shipmentScreenActions.onGetNotificationCount();
	};

	onRefund = () => {
		const { itemsListing, totalQuantityOrdered } = this.state;
		const alertProps = {};
		if (getSumOfItemQuantity(itemsListing) === totalQuantityOrdered) {
			// If refunded quantity is equal to the total quantity ordered then it will show error in alert.
			alertProps.message = localeString(keyConstants.PARTIAL_REFUND_ERROR_MESSAGE);
			alertProps.isOneButton = true; // Boolean to show only one action button.
			alertProps.yesText = localeString(keyConstants.OK);
		} else {
			// Confirmation from the user to do the partial refund.
			alertProps.message = localeString(keyConstants.PROCEED_REFUND_REQUEST);
			alertProps.onPressYes = () => this.onPartialRefund();
		}
		AlertComponent(alertProps);
	};

	onPartialRefund = () => {
		const { route, navigation } = this.props;
		const { id } = route.params;
		const { itemsListing } = this.state;
		const tempArray = [];
		itemsListing.map(item => {
			const { item_id, quantity } = item;
			tempArray.push({ item_id, quantity });
		});
		const queryParams = {};
		queryParams.sales_invoice_id = id;
		queryParams.items = tempArray;
		navigation.navigate(driverNavigations.OTP_SCREEN_NAVIGATION, {
			mobileNumber: '',
			isSignIn: false,
			isDriver: true,
			isPartialRefund: true,
			queryParams,
			id,
		});
	};

	onPressReturnNotification = () => {
		// Will navigate to the notification screen.
		const { shipmentScreenInfo, navigation } = this.props;
		const { notificationCount } = shipmentScreenInfo;
		navigation.navigate(driverNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	renderItem = ({ item, index }) => {
		const { languageInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { quantityArray } = route.params;
		const {
			item_name_ar,
			item_name,
			price,
			vat_amount,
			quantity,
			images,
			sub_category_name,
			sub_category_name_ar,
			brand_name,
			brand_name_ar,
			return_qty,
			items_per_packet,
			value_of_item,
			unit,
			unit_ar,
		} = item || {};
		const subTitleText = `${isRTL ? brand_name_ar : brand_name}${
			sub_category_name ? ` | ${isRTL ? sub_category_name_ar : sub_category_name}` : ''
		}`;
		return (
			<ProductCardComponent
				containerStyle={styles.containerStyle}
				image={images && images.small}
				title={isRTL ? item_name_ar : item_name}
				subtitle={subTitleText}
				discountedPrice={price + vat_amount}
				onPressPlus={() => this.onUpdateQuantity(0, index, quantity)}
				onPressMinus={() => this.onUpdateQuantity(1, index, quantity)}
				itemCount={quantity}
				onChangeText={text =>
					this.onUpdateQuantity(2, index, text ? parseInt(text, 10) : text)
				}
				updateCart={() =>
					this.onUpdateQuantity(
						2,
						index,
						quantity === 0 || quantity === ''
							? 1
							: quantity > quantityArray[index] - return_qty
							? quantityArray[index] - return_qty
							: quantity,
					)
				}
				isDriverApp
				originalQuantity={quantityArray[index]}
				orderedQuantity={quantityArray[index] - return_qty}
				hasFooterView
				itemsPerPacket={items_per_packet}
				valueOfItem={value_of_item}
				unit={isRTL ? unit_ar : unit}
			/>
		);
	};

	keyExtractor = (item, index) => index.toString();

	onUpdateQuantity = (actionType, index, quantity) => {
		let updatedQuantity = quantity;
		let { itemsListing } = this.state;
		itemsListing = [...itemsListing];
		if (actionType === 0) {
			updatedQuantity += 1;
		} else {
			updatedQuantity -= 1;
		}
		itemsListing[index].quantity = updatedQuantity;
		this.setState({ itemsListing });
	};

	render() {
		const { languageInfo, shipmentScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { itemsListing } = this.state;
		const { notificationCount } = shipmentScreenInfo;
		return (
			<View style={styles.container}>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.INVOICE_DETAIL)}
						hasIconBack
						hasIconNotification
						onPressBack={this.onGoBack}
						onPressNotification={this.onPressReturnNotification}
						notificationCount={notificationCount}
					/>
				</View>
				<FlatList
					data={itemsListing}
					renderItem={this.renderItem}
					keyExtractor={this.keyExtractor}
					showsVerticalScrollIndicator={false}
					style={styles.scrollView}
				/>
				<View style={styles.bottomView}>
					<ButtonComponent
						buttonStyle={styles.cancelBottomButton}
						text={localeString(keyConstants.CANCEL)}
						textStyle={styles.cancelBottomText}
						onPress={this.onGoBack}
					/>
					<ButtonComponent
						buttonStyle={styles.submitButton}
						text={localeString(keyConstants.SUBMIT)}
						onPress={this.onRefund}
					/>
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		invoiceDetailInfo: state.SalesInvoiceDetailScreenReducer,
		shipmentScreenInfo: state.ShipmentScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		shipmentScreenActions: bindActionCreators({ ...ShipmentScreenActions }, dispatch),
	};
};

EditItemsQuantityScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	shipmentScreenActions: PropTypes.object.isRequired,
	shipmentScreenInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EditItemsQuantityScreen);
