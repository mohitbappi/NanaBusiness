export const getSumOfItemQuantity = object => {
	// Will return the sum of the quantity of all the products.
	const totalQuantity = object.reduce((accumulator, item) => accumulator + item.quantity, 0);
	return parseInt(totalQuantity, 10);
};

export const getSumOfReturnItemQuantity = object => {
	// Will return the sum of the returned quantity of all the products.
	const totalQuantity = object.reduce(
		(accumulator, item) => accumulator + (item.quantity - item.returned_qty),
		0,
	);
	return parseInt(totalQuantity, 10);
};
