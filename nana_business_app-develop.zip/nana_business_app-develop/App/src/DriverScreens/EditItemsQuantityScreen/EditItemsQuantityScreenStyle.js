import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		containerStyle: {
			marginTop: verticalScale(10),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
		},
		cancelBottomButton: {
			paddingHorizontal: normalScale(47),
			backgroundColor: colors.white,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(36),
			justifyContent: 'center',
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
		},
		cancelBottomText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
		},
		scrollView: {
			marginBottom: verticalScale(65),
		},
		bottomView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
		submitButton: {
			paddingHorizontal: normalScale(47),
		},
	});
};

export default createStyleSheet;
