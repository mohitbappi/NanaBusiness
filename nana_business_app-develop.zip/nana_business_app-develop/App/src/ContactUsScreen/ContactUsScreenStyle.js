import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		phoneImage: {
			height: normalScale(14),
			width: normalScale(14),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 16),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 16),
		},
		smsImage: {
			height: normalScale(16),
			width: normalScale(16),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 6),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 6),
		},
		whatsappImage: {
			height: verticalScale(41),
			width: normalScale(40),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(16),
		},
		header: {
			marginBottom: verticalScale(5),
		},
		hitSlop: {
			right: normalScale(15),
			left: normalScale(15),
			top: verticalScale(15),
			bottom: verticalScale(15),
		},
		image: {
			width: normalScale(16),
			height: verticalScale(12),
		},
		headingText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			marginHorizontal: normalScale(12),
		},
	});
};

export default createStyleSheet;
