import * as ActionTypes from './ActionType';

const initialState = {
	contactDetails: null,
	success: false,
	error: false,
	errorCode: null,
	loader: false,
};

const ContactUsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_CONTACTS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				contactDetails: action.payload,
			};
		case ActionTypes.GET_CONTACTS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_CONTACTS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default ContactUsScreenReducer;
