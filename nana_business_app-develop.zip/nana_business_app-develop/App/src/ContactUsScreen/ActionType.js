export const GET_CONTACTS_SUCCESS = 'get_contacts_success';
export const GET_CONTACTS_FAILURE = 'get_contacts_failure';
export const GET_CONTACTS_LOADER = 'get_contacts_loader';
