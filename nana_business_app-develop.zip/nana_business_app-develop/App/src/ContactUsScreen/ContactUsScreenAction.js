import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import { actions } from '@libapi/APIActionsBuilder';
import GetContactDetailService from '@ContactUs/GetContactDetailService';
import * as ActionTypes from './ActionType';

export const onGetContactDetails = () => dispatch => {
	// Action to get the contact details.
	const dispatchedActions = actions(
		ActionTypes.GET_CONTACTS_SUCCESS,
		ActionTypes.GET_CONTACTS_FAILURE,
		ActionTypes.GET_CONTACTS_LOADER,
	);
	const getContactDetailService = new GetContactDetailService(dispatchedActions);
	addBasicInterceptors(getContactDetailService);
	getContactDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getContactDetailService.makeRequest());
};

export default onGetContactDetails;
