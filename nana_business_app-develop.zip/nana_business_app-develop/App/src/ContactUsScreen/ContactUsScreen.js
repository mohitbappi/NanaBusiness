import React, { Component } from 'react';
import { View, Linking } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import IMAGES from '@Images/index';
import { localeString } from '@Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { saudiMobilePrefix, toastShowTime } from '@Constants/Constants';
import Loader from '@Loader/Loader';
import ProfileDetailComponent from '@Components/ProfileDetailComponent';
import Header from '@Header/Header';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ToastComponent from '../Widgets/ToastComponent/ToastComponent';
import * as ContactUsScreenAction from './ContactUsScreenAction';
import { createStyleSheet } from './ContactUsScreenStyle';

class ContactUsScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			detailsArray: [],
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onGetContactDetails();
		});
	}

	componentDidUpdate(prevProps) {
		const { contactUsInfo } = this.props;
		const { success, contactDetails } = contactUsInfo;
		const { support_email_id, support_primary_contact, support_secondary_contact } =
			contactDetails || {};
		if (success && prevProps.contactUsInfo !== contactUsInfo) {
			// Will set email address, primary mobile number and secondary mobile number after successful api call.
			const detailsArray = [
				{
					key: keyConstants.EMAIL_ADDRESS,
					image: IMAGES.iconEmail,
					label: keyConstants.EMAIL_ADDRESS,
					value: support_email_id,
				},
				{
					key: keyConstants.MOBILE_NUMBER,
					image: IMAGES.iconPhone,
					label: keyConstants.PRIMARY_MOBILE_NUMBER,
					value: `${saudiMobilePrefix} ${support_primary_contact}`,
					number: support_primary_contact,
				},
				{
					key: keyConstants.MOBILE_NUMBER,
					image: IMAGES.iconPhone,
					label: keyConstants.SECONDARY_MOBILE_NUMBER,
					value: `${saudiMobilePrefix} ${support_secondary_contact}`,
					number: support_secondary_contact,
				},
			];
			this.setState({
				detailsArray,
			});
		}
	}

	onGetContactDetails = () => {
		// API call to get the contact details.
		const { contactUsScreenAction } = this.props;
		contactUsScreenAction.onGetContactDetails();
	};

	onPressEmail = item => {
		const { value } = item;
		// Will create a draft email with the given value.
		Linking.openURL(`mailto:${value}`);
	};

	onGoBack = () => {
		// Will navigate to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	getSocialIcons = item => {
		// Will return the social icons.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return [
			{
				iconImage: IMAGES.iconPhoneBlack,
				action: () => this.onPressContact(item.number),
				style: styles.phoneImage,
			},
			{
				iconImage: IMAGES.iconSms,
				action: () => this.onPressSms(item.number),
				style: styles.smsImage,
			},
			{
				iconImage: IMAGES.iconWhatsapp,
				action: () => this.onPressWhatsapp(item.number),
				style: styles.whatsappImage,
			},
		];
	};

	onPressContact = number => {
		// Will open dialpad with the given number.
		Linking.openURL(`tel:${saudiMobilePrefix}${number}`);
	};

	onPressSms = number => {
		// Will open sms app with the given number.
		Linking.openURL(`sms://${saudiMobilePrefix}${number}`);
	};

	onPressWhatsapp = number => {
		// Will open whatsapp with the given number.
		Linking.openURL(`whatsapp://send?phone=${saudiMobilePrefix}${number}`)
			.then(() => {})
			.catch(() => {
				this.setState({
					toastMessage: localeString(keyConstants.WHATSAPP_ERROR_MESSAGE),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			});
	};

	render() {
		const { languageInfo, contactUsInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { detailsArray, toastMessage, isApiError } = this.state;
		const { loader, error, errorCode } = contactUsInfo;
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<View style={styles.header}>
					<Header
						text={localeString(keyConstants.CONTACT_US)}
						hasIconBack
						onPressBack={this.onGoBack}
					/>
				</View>
				{error ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onGetContactDetails}
					/>
				) : (
					detailsArray.map((item, index) => {
						return (
							<ProfileDetailComponent
								isRTL={isRTL}
								item={item}
								onPressContact={() =>
									index === 0 ? this.onPressEmail(item) : null
								}
								socialIconsArray={this.getSocialIcons(item)}
								hasSocialMediaIcons={index !== 0}
							/>
						);
					})
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		contactUsInfo: state.ContactUsScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		contactUsScreenAction: bindActionCreators({ ...ContactUsScreenAction }, dispatch),
	};
};

ContactUsScreen.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	navigation: PropTypes.object.isRequired,
	contactUsInfo: PropTypes.object.isRequired,
	contactUsScreenAction: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ContactUsScreen);
