import { actions } from '@libapi/APIActionsBuilder';
import GetPaymentStatus from '@Payment/GetPaymentStatus';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to call get payment status api
 * @param {object} props
 */
export const onGetPaymentStatus = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_PAYMENT_STATUS_SUCCESS,
		ActionTypes.GET_PAYMENT_STATUS_FAILURE,
		ActionTypes.GET_PAYMENT_STATUS_LOADER,
	);
	const getPaymentStatus = new GetPaymentStatus(dispatchedActions);
	addBasicInterceptors(getPaymentStatus);
	getPaymentStatus.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPaymentStatus.makeRequest(props));
};

// Action to reset payment screen reducer
export const onResetPaymentState = () => ({ type: ActionTypes.RESET_PAYMENT_STATUS });
