import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Loader from '@Loader/Loader';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { paymentStatus, navigationType } from '@Constants/Constants';
import navigations from '@routes/navigations';
import IMAGES from '@Images/index';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import * as AddMoneyActions from '@AddMoneyScreen/AddMoneyScreenAction';
import * as PaymentScreenActions from './PaymentConfirmationScreenAction';

class PaymentConfirmationScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			modalData: {
				title: '',
				description: '',
			},
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.getPaymentStatus();
		});
	}

	componentDidUpdate(prevProps) {
		const { paymentScreenInfo } = this.props;
		const { paymentDetails, success } = paymentScreenInfo;
		const { payment_status } = paymentDetails || {};
		if (
			success &&
			paymentDetails &&
			prevProps.paymentScreenInfo.success !== paymentScreenInfo.success
		) {
			// if payment api return success
			this.getData(payment_status);
		}
	}

	componentWillUnmount() {
		// Reset Payment screen reducer on unmonuting
		const { paymentScreenActions } = this.props;
		paymentScreenActions.onResetPaymentState();
	}

	getData = transactionStatus => {
		switch (transactionStatus) {
			case paymentStatus.success:
				// if transaction status is successful
				this.setState({
					modalData: {
						title: localeString(keyConstants.PAYMENT_SUCCESSFUL),
					},
				});
				break;
			case paymentStatus.failed:
				// if transaction status is failed
				this.setState({
					modalData: {
						title: localeString(keyConstants.PAYMENT_FAILED),
						description: this.getFailedDescription(),
					},
				});
				break;
			case paymentStatus.waiting:
				// if transaction status is waiting
				this.setState({
					modalData: {
						title: localeString(keyConstants.PAYMENT_PENDING),
						description: this.getPendingDescription(),
					},
				});
				break;
			default:
				break;
		}
	};

	getPaymentStatus = () => {
		// Call api to get payment status
		const { route, paymentScreenActions } = this.props;
		const { paymentDetail } = route.params;
		const { payment_id } = paymentDetail || {};
		const queryparams = {
			id: payment_id,
		};
		paymentScreenActions.onGetPaymentStatus(queryparams);
	};

	getFailedDescription = () => {
		const { route } = this.props;
		const { type } = route.params;
		switch (type) {
			case navigationType.order:
				// payment failure in case of order
				return localeString(keyConstants.PAYMENT_FAILED_FOR_ORDER);
			case navigationType.balance:
				// payment failure in case of balance
				return localeString(keyConstants.PAYMENT_FAILED_FOR_BALANCE);
			case navigationType.home:
				// Payment failure in case of balance section from home.
				return localeString(keyConstants.PAYMENT_FAILED_FOR_BALANCE);
			case navigationType.creditLine:
				// payment failure in case of credit line
				return localeString(keyConstants.PAYMENT_FAILED_FOR_CREDIT_LINE);
			default:
				return null;
		}
	};

	getPendingDescription = () => {
		const { route } = this.props;
		const { type } = route.params;
		switch (type) {
			case navigationType.order:
				// payment pending in case of order
				return localeString(keyConstants.PAYMENT_PENDING_FOR_ORDER);
			case navigationType.balance:
				// payment pending in case of balance
				return localeString(keyConstants.PAYMENT_PENDING_FOR_BALANCE);
			case navigationType.home:
				// Payment pending in case of balance section from home.
				return localeString(keyConstants.PAYMENT_PENDING_FOR_BALANCE);
			case navigationType.creditLine:
				// payment pending in case of credit line
				return localeString(keyConstants.PAYMENT_PENDING_FOR_CREDIT_LINE);
			default:
				return null;
		}
	};

	getImage = transactionStatus => {
		switch (transactionStatus) {
			case paymentStatus.success:
				// image for successful payment
				return IMAGES.iconCongratulations;
			case paymentStatus.waiting:
				// image for pending payment
				return IMAGES.iconPending;
			case paymentStatus.failed:
				// image for failed payment
				return IMAGES.iconFailed;
			default:
				return null;
		}
	};

	onClose = type => {
		const { route, navigation, addMoneyActions, paymentScreenActions } = this.props;
		const { extraParams } = route.params;
		switch (type) {
			case navigationType.order:
				// If online payment is done for order
				navigation.navigate(navigations.ORDER_DETAIL_NAVIGATION, {
					...extraParams,
					isShowAlert: false,
				});
				break;
			case navigationType.balance:
				// If online payment is done for balance
				navigation.navigate(navigations.BALANCE_DETAILS_NAVIGATION);
				break;
			case navigationType.home:
				// If online payment is done for balance but initiated from home screen.
				navigation.navigate(navigations.HOME_NAVIGATION);
				break;
			case navigationType.creditLine:
				// If online payment is done for credit line
				navigation.navigate(navigations.CREDIT_LINE_REPORT_NAVIGATION, extraParams);
				break;
			default:
				break;
		}
		addMoneyActions.onResetAddMoneyState(); // Will reset the add money reducer.
		paymentScreenActions.onResetPaymentState(); // Will reset the payment reducer.
	};

	render() {
		const { route, paymentScreenInfo } = this.props;
		const { type } = route.params;
		const { modalData } = this.state;
		const { loader, paymentDetails, success } = paymentScreenInfo;
		const { payment_status, payment_id, amount } = paymentDetails || {};
		if (loader) {
			return <Loader size="large" />;
		}
		return (
			<>
				{success && (
					<ConfimationModal
						title={modalData.title}
						amount={`${localeString(
							keyConstants.TRANSACTION_AMOUNT,
						)}: ${currencyFormatter(getValueInDecimal(amount))} ${localeString(
							keyConstants.SAR,
						)}`}
						transactionId={`${localeString(
							keyConstants.TRANSACTION_ID,
						)}: ${payment_id}`}
						description={modalData.description}
						onPress={() => this.onClose(type)}
						buttonTitle={localeString(keyConstants.PROCEED)}
						hasButton
						imageSource={this.getImage(payment_status)}
					/>
				)}
			</>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		paymentScreenInfo: state.PaymentConfirmationScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		paymentScreenActions: bindActionCreators({ ...PaymentScreenActions }, dispatch),
		addMoneyActions: bindActionCreators({ ...AddMoneyActions }, dispatch),
	};
};

PaymentConfirmationScreen.propTypes = {
	paymentScreenInfo: PropTypes.object.isRequired,
	paymentScreenActions: PropTypes.object.isRequired,
	addMoneyActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(PaymentConfirmationScreen);
