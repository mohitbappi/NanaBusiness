export const GET_PAYMENT_STATUS_SUCCESS = 'get_payment_status_success';
export const GET_PAYMENT_STATUS_FAILURE = 'get_payment_status_failure';
export const GET_PAYMENT_STATUS_LOADER = 'get_payment_status_loader';
export const RESET_PAYMENT_STATUS = 'reset_payment_status';
