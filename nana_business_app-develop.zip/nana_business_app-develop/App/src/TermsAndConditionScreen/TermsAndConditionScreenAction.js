import { actions } from '@libapi/APIActionsBuilder';
import TermsAndConditionService from '@TermsAndCondition/TermsAndConditionService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import * as ActionTypes from './ActionType';

// ACtion to call term and condition data api
export const onGetTermsAndCondition = () => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_TERMS_AND_CONDITION_SUCCESS,
		ActionTypes.GET_TERMS_AND_CONDITION_FAILURE,
		ActionTypes.GET_TERMS_AND_CONDITION_LOADER,
	);
	const termsAndConditionService = new TermsAndConditionService(dispatchedActions);
	addBasicInterceptors(termsAndConditionService);
	dispatch(termsAndConditionService.makeRequest());
};

export default onGetTermsAndCondition;
