import React, { Component } from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Loader from '@Loader/Loader';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Header from '@Header/Header';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { createStyleSheet } from './TermsAndConditionScreenStyle';
import * as TermsAndConditionActions from './TermsAndConditionScreenAction';

class TermsAndConditionScreen extends Component {
	componentDidMount() {
		this.onGetTermsAndCondition(false);
	}

	onGetTermsAndCondition = () => {
		const { termsAndConditionActions } = this.props;
		termsAndConditionActions.onGetTermsAndCondition();
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	render() {
		const { languageInfo, termsAndConditionInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet();
		const { loader, tncData, error, errorCode } = termsAndConditionInfo;
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<Header
					text={localeString(keyConstants.TERMS_AND_CONDITIONS)}
					onPressBack={this.onGoBack}
					hasIconBack
				/>
				{error ? (
					<ErrorComponent // Error component if api fails.
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onGetTermsAndCondition}
					/>
				) : (
					<WebView source={{ html: tncData }} />
				)}
			</View>
		);
	}
}

TermsAndConditionScreen.propTypes = {
	termsAndConditionActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	termsAndConditionInfo: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		termsAndConditionInfo: state.TermsAndConditionScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		termsAndConditionActions: bindActionCreators({ ...TermsAndConditionActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(TermsAndConditionScreen);
