import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	tncData: '',
};

const TermsAndConditionScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_TERMS_AND_CONDITION_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				tncData: action.payload.html,
			};
		case ActionTypes.GET_TERMS_AND_CONDITION_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_TERMS_AND_CONDITION_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default TermsAndConditionScreenReducer;
