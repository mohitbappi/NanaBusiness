import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import { normalScale, verticalScale } from '@device/normalize';

export const createStyleSheet = () => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
			paddingHorizontal: normalScale(16),
			paddingBottom: verticalScale(10),
		},
	});
};

export default createStyleSheet;
