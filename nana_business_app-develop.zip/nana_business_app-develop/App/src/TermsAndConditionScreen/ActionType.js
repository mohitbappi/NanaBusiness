export const GET_TERMS_AND_CONDITION_SUCCESS = 'get_terms_and_condition_success';
export const GET_TERMS_AND_CONDITION_FAILURE = 'get_terms_and_condition_failure';
export const GET_TERMS_AND_CONDITION_LOADER = 'get_terms_and_condition_loader';
