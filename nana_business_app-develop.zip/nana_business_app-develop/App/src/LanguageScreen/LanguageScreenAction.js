import { setLocale } from '@assets/Localization';
import AsyncStorageUtil from '@AsyncStorage/AsyncStorageUtil';
import * as ActionTypes from './ActionType';

const setCurrentLangauge = async language => {
	// Function to set the given language in async storage.
	setLocale(language);
	await new AsyncStorageUtil('language').saveData(language);
};

/**
 * Action to set the given language in reducer.
 * @param {string} value
 * @returns
 */

export const onSetLanguage = value => {
	setCurrentLangauge(value);
	return {
		type: ActionTypes.SET_LANGUAGE,
		payload: value,
	};
};

export default onSetLanguage;
