import React, { Component } from 'react';
import { View, TouchableOpacity, Text } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import RNRestart from 'react-native-restart';
import PropTypes from 'prop-types';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { localeString, setLocale } from '@Localization/index';
import SelectComponent from '@SelectComponent/SelectComponent';
import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { createStyleSheet } from './LanguageScreenStyle';
import * as LanguageActions from './LanguageScreenAction';

class LanguageScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			selectedLanguage: 'ar',
		};
	}

	componentDidMount() {
		const { languageInfo } = this.props;
		const { language } = languageInfo;
		// Will set the default language.
		this.setState({
			selectedLanguage: language,
		});
	}

	componentDidUpdate(prevProps) {
		const { languageInfo } = this.props;
		const { language } = languageInfo;
		if (prevProps.languageInfo !== languageInfo) {
			// Will update the selected language if modified.
			this.setState({
				selectedLanguage: language,
			});
		}
	}

	onClose = () => {
		// Will close the screen.
		const { languageInfo } = this.props;
		const { language } = languageInfo;
		this.onRequestClose(language);
	};

	onSelectLanguage = language => {
		// Will save the selected language.
		this.setState({
			selectedLanguage: language,
		});
		setLocale(language);
	};

	onRequestClose = language => {
		// Will close the screen.
		const { onRequestClose } = this.props;
		setLocale(language);
		onRequestClose();
	};

	onSubmit = () => {
		// Will set the selected language and restart the app.
		const { selectedLanguage } = this.state;
		const { signInInfo, languageActions } = this.props;
		const { token } = signInInfo;
		languageActions.onSetLanguage(selectedLanguage);
		this.onRequestClose(selectedLanguage);
		if (token) {
			RNRestart.Restart();
		}
	};

	render() {
		const { selectedLanguage } = this.state;
		const isRTL = selectedLanguage === 'ar';
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<TouchableOpacity
					activeOpacity={0.8}
					hitSlop={styles.hitSlop}
					style={styles.closeButton}
					onPress={this.onClose}>
					<ImageLoadComponent source={IMAGES.iconCross} style={styles.image} />
				</TouchableOpacity>
				<Text style={styles.chooseText}>
					{localeString(keyConstants.CHOOSE_YOUR_LANGUAGE)}
				</Text>
				<Text style={styles.defaultText}>
					{localeString(keyConstants.DEFAULT_LANGUAGE)}
				</Text>
				<View style={styles.languageView}>
					<SelectComponent
						onPress={() => this.onSelectLanguage('en')}
						isSelected={selectedLanguage === 'en'}
						isRTL={isRTL}
						caption="English"
						label="Hello"
					/>
					<SelectComponent
						onPress={() => this.onSelectLanguage('ar')}
						isSelected={selectedLanguage === 'ar'}
						isRTL={isRTL}
						caption="Arabic"
						label="مرحبا"
					/>
				</View>
				<View style={styles.buttonStyle}>
					<ButtonComponent
						onPress={this.onSubmit}
						text={localeString(keyConstants.SUBMIT)}
					/>
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		signInInfo: state.SignInScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		languageActions: bindActionCreators({ ...LanguageActions }, dispatch),
	};
};

LanguageScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	onRequestClose: PropTypes.func.isRequired,
	languageActions: PropTypes.object.isRequired,
	signInInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(LanguageScreen);
