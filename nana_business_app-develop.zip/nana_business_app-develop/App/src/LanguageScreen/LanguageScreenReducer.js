import * as ActionTypes from './ActionType';

const initialState = {
	language: 'ar',
	isRTL: false,
};

const LanguageScreenReducer = (state = initialState, action = {}) => {
	if (action.type === ActionTypes.SET_LANGUAGE) {
		return {
			...state,
			language: action.payload,
			isRTL: action.payload === 'ar',
		};
	}
	return state;
};

export default LanguageScreenReducer;
