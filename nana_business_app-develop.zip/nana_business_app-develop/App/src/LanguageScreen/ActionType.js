export const SET_LANGUAGE = 'set_language';

export default SET_LANGUAGE;
