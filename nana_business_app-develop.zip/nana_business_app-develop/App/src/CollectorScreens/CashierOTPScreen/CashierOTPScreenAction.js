import { actions } from '@lib/libapi/APIActionsBuilder';
import SendOTPToCashier from '@CollectorServices/Cashier/SendOTPToCashier';
import CreateCashierDepositService from '@CollectorServices/Cashier/CreateCashierDepositService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to send otp to the cashier
 * @param {object} cashierDetails
 */
export const onSendOtp = cashierDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SEND_OTP_TO_CASHIER_SUCCESS,
		ActionTypes.SEND_OTP_TO_CASHIER_FAILURE,
		ActionTypes.SEND_OTP_TO_CASHIER_LOADER,
	);
	const sendOTPToCashier = new SendOTPToCashier(dispatchedActions);
	addBasicInterceptors(sendOTPToCashier);
	sendOTPToCashier.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(sendOTPToCashier.makeRequest(cashierDetails));
};

/**
 * Action to verify otp and create cashier deposit.
 * @param {object} otpDetails
 */
export const onCreateDeposit = otpDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.VALIDATE_CASHIER_OTP_SUCCESS,
		ActionTypes.VALIDATE_CASHIER_OTP_FAILURE,
		ActionTypes.VALIDATE_CASHIER_OTP_LOADER,
	);
	const createCashierDepositService = new CreateCashierDepositService(dispatchedActions);
	addBasicInterceptors(createCashierDepositService);
	createCashierDepositService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(createCashierDepositService.makeRequest(otpDetails));
};

// Action to reset cashier otp screen reducer
export const onResetOtpScreenState = () => ({ type: ActionTypes.RESET_CASHIER_OTP_STATE });
