// import libraries
import React, { Component } from 'react';
import { Text, View } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import OTPComponent from '@OTPComponent/OTPComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@assets/Constants/KeyConstants';
import { mobilePrefix } from '@assets/Constants/Constants';

// import styles
import { createStyleSheet } from './CashierOTPScreenStyle';

class CashierOTPUI extends Component {
	onSubmit = () => {
		const { onSubmit } = this.props;
		onSubmit();
	};

	render() {
		const {
			onChange,
			isRTL,
			onGoBack,
			otpValidation,
			cashierDetails,
			loader,
			onResend,
			isApiError,
			toastMessage,
		} = this.props;
		const { name, mobile } = cashierDetails;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header hasIconBack onPressBack={onGoBack} />
				</View>
				<Text style={styles.otp}>
					{`${localeString(keyConstants.ENTER_OTP)} ${name} ${localeString(
						keyConstants.ON,
					)} +${mobilePrefix} ${mobile}`}
				</Text>
				<View style={styles.otpView}>
					<OTPComponent
						style={styles.otpBox}
						length={4}
						onChange={onChange}
						isRTL={isRTL}
						onResend={onResend}
					/>
				</View>
				<View style={styles.buttonStyle}>
					<ButtonComponent
						onPress={this.onSubmit}
						text={localeString(keyConstants.VALIDATE)}
						isButtonDisable={otpValidation}
					/>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

CashierOTPUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	otpValidation: PropTypes.bool.isRequired,
	onChange: PropTypes.func.isRequired,
	cashierDetails: PropTypes.object.isRequired,
	onSubmit: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	onResend: PropTypes.func.isRequired,
	isApiError: PropTypes.bool.isRequired,
	toastMessage: PropTypes.string.isRequired,
};

export default CashierOTPUI;
