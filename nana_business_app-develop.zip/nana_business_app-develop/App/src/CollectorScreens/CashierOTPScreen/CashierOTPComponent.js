// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import actions
import collectorNavigations from '@config/routes/collectorNavigations';

// import assests
import { toastShowTime } from '@assets/Constants/Constants';
import { keyConstants } from '@assets/Constants/KeyConstants';
import { localeString } from '@assets/Localization';

// import components
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import CashierOTPUI from './CashierOTPUI';

class CashierOTPComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.state = {
			otpValue: '',
			otpValidation: true,
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidUpdate(prevProps) {
		const {
			cashierOtpInfo,
			navigation,
			myCollectionActions,
			cashierOtpScreenActions,
			selectCashierActions,
		} = this.props;
		const { success, isValidate, error, errorCode, isOtpSend } = cashierOtpInfo;
		if (success && prevProps.cashierOtpInfo.success !== success) {
			if (isValidate) {
				// Navigate to payment screen screen if api verified successfully.
				myCollectionActions.onSetTabIndex(2);
				navigation.navigate(collectorNavigations.COLLECTION_NAVIGATION);
				selectCashierActions.onSelectCashier(null);
			} else if (isOtpSend) {
				this.onShowToast(keyConstants.OTP_SENT_SUCCESSFULLY);
			}
			cashierOtpScreenActions.onResetOtpScreenState();
		}
		if (error && prevProps.cashierOtpInfo.error !== error) {
			// Will show toast if api error occurs.
			if (keyConstants[errorCode.error]) {
				this.onShowToast(keyConstants[errorCode.error]);
			} else {
				ErrorAlertComponent(errorCode, this.onSubmitOtp);
			}
		}
	}

	onShowToast = message => {
		// Will show toast.
		this.setState({
			toastMessage: localeString(message),
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeOtp = (value, otpValidation) => {
		this.setState({ otpValue: value, otpValidation });
	};

	onResendOtp = () => {
		// Action to resend otp.
		const { route, cashierOtpScreenActions } = this.props;
		const { totalAmount, walletTransactions, cashierDetails } = route.params;
		const otpDetails = {
			cashier_id: cashierDetails?.id,
			amount: totalAmount,
			payment_received_ids: walletTransactions,
		};
		cashierOtpScreenActions.onSendOtp(otpDetails);
	};

	onSubmitOtp = () => {
		// Will create cashier deposit.
		const { otpValue } = this.state;
		const { route, cashierOtpScreenActions } = this.props;
		const { totalAmount, walletTransactions, cashierDetails } = route.params;
		const otpDetails = {
			cashier_id: cashierDetails?.id,
			otp: parseInt(otpValue, 10),
			payment_received_ids: walletTransactions,
			amount: totalAmount,
		};
		cashierOtpScreenActions.onCreateDeposit(otpDetails);
	};

	render() {
		const { languageInfo, cashierOtpInfo, route } = this.props;
		const { cashierDetails } = route.params;
		const { otpValidation, isApiError, toastMessage } = this.state;
		const { isRTL } = languageInfo;
		const { loader } = cashierOtpInfo;
		return (
			<CashierOTPUI
				isRTL={isRTL}
				loader={loader}
				otpValidation={otpValidation}
				onGoBack={this.onGoBack}
				onChange={this.onChangeOtp}
				cashierDetails={cashierDetails}
				onResend={this.onResendOtp}
				onSubmit={this.onSubmitOtp}
				isApiError={isApiError}
				toastMessage={toastMessage}
			/>
		);
	}
}

CashierOTPComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	cashierOtpInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	cashierOtpScreenActions: PropTypes.object.isRequired,
	myCollectionActions: PropTypes.object.isRequired,
	selectCashierActions: PropTypes.object.isRequired,
};

export default CashierOTPComponent;
