import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { lineHeightScale, normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
			paddingHorizontal: normalScale(16),
		},
		headerContainer: {
			marginBottom: verticalScale(8),
		},
		otp: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(16),
			alignSelf: 'center',
			marginTop: verticalScale(60),
			marginBottom: verticalScale(30),
			lineHeight: lineHeightScale(24),
			textAlign: 'center',
		},
		otpView: {
			marginHorizontal: normalScale(32),
		},
		otpBox: {
			width: normalScale(44),
			height: verticalScale(44),
		},
		buttonStyle: {
			left: normalScale(16),
			right: normalScale(16),
			bottom: verticalScale(16),
			position: 'absolute',
		},
	});
};

export default createStyleSheet;
