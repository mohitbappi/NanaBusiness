// import libraries
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// import actions
import * as MyCollectionActions from '@CollectionScreen/CollectionScreenAction';
import * as SelectCashierScreenActions from '@SelectCashierScreen/SelectCashierScreenAction';
import * as CashierOtpScreenActions from './CashierOTPScreenAction';

// import components
import CashierOTPComponent from './CashierOTPComponent';

const CashierOTPContainer = props => {
	const customProps = { ...props }; // Will store all the props like navigation, reducer state and actions.
	return <CashierOTPComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer, // Language screen reducer
		cashierOtpInfo: state.CashierOTPScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		cashierOtpScreenActions: bindActionCreators({ ...CashierOtpScreenActions }, dispatch),
		myCollectionActions: bindActionCreators({ ...MyCollectionActions }, dispatch),
		selectCashierActions: bindActionCreators({ ...SelectCashierScreenActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(CashierOTPContainer);
