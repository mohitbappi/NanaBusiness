import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	isValidate: false,
	isOtpSend: false,
};

const CashierOTPScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.SEND_OTP_TO_CASHIER_SUCCESS: {
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isOtpSend: true,
				isValidate: false,
			};
		}
		case ActionTypes.VALIDATE_CASHIER_OTP_SUCCESS: {
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isOtpSend: false,
				isValidate: true,
			};
		}
		case ActionTypes.SEND_OTP_TO_CASHIER_LOADER:
		case ActionTypes.VALIDATE_CASHIER_OTP_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.SEND_OTP_TO_CASHIER_FAILURE:
		case ActionTypes.VALIDATE_CASHIER_OTP_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_CASHIER_OTP_STATE:
			return initialState;
		default:
			return { ...state };
	}
};

export default CashierOTPScreenReducer;
