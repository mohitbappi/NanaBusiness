export const SEND_OTP_TO_CASHIER_SUCCESS = 'send_otp_to_cashier_success';
export const SEND_OTP_TO_CASHIER_FAILURE = 'send_otp_to_cashier_failure';
export const SEND_OTP_TO_CASHIER_LOADER = 'send_otp_to_cashier_loader';

export const VALIDATE_CASHIER_OTP_SUCCESS = 'validate_cashier_otp_success';
export const VALIDATE_CASHIER_OTP_FAILURE = 'validate_cashier_otp_failure';
export const VALIDATE_CASHIER_OTP_LOADER = 'validate_cashier_otp_loader';

export const RESET_CASHIER_OTP_STATE = 'reset_cashier_otp_state';
