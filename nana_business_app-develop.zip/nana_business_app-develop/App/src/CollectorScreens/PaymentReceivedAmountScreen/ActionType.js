export const SET_CREATE_PAYMENT_MODE = 'set_create_payment_mode';

export const SET_IS_ADVANCE_PAYMENT = 'set_is_advance_payment';

export const PAY_AMOUNT_SUCCESS = 'pay_amount_success';
export const PAY_AMOUNT_FAILURE = 'pay_amount_failure';
export const PAY_AMOUNT_LOADER = 'pay_amount_loader';

export const ON_CHANGE_PAYMENT_RECEIVED_TEXT = 'on_change_payment_received_text';

export const RESET_PAY_AMOUNT_STATE = 'reset_pay_amount_state';

export const CREATE_MADA_TRANSACTION_SUCCESS = 'create_mada_transaction_success';
export const CREATE_MADA_TRANSACTION_FAILURE = 'create_mada_transaction_failure';
export const CREATE_MADA_TRANSACTION_LOADER = 'create_mada_transaction_loader';
