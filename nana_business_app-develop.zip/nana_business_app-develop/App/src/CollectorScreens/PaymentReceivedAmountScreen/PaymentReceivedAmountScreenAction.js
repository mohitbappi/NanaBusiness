import { actions } from '@libapi/APIActionsBuilder';
import CreatePaymentService from '@InvoicesCollectorServices/CreatePaymentService';
import CreateMadaTransactionService from '@MadaPayments/CreateMadaTransactionService';
import ResubmitMadaTransactionService from '@MadaPayments/ResubmitMadaTransactionService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to set the payment mode.
 * @param {integer} mode
 * @returns
 */

export const onSetPaymentMode = mode => {
	return {
		type: ActionTypes.SET_CREATE_PAYMENT_MODE,
		payload: mode,
	};
};

/**
 * Action to set is it advance payment or not.
 * @param {integer} index
 * @returns
 */

export const onSetIsAdvancePayment = index => {
	return {
		type: ActionTypes.SET_IS_ADVANCE_PAYMENT,
		payload: index,
	};
};

/**
 * Action to sets 'field' value as 'text' in redux state.
 * @param {string} text
 * @param {string} field
 * @returns
 */

export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_PAYMENT_RECEIVED_TEXT,
		payload: text,
		field,
	};
};

/**
 * Action to create a payment received.
 * @param {object} paymentDetails
 * @returns
 */

export const onCreatePayment = paymentDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.PAY_AMOUNT_SUCCESS,
		ActionTypes.PAY_AMOUNT_FAILURE,
		ActionTypes.PAY_AMOUNT_LOADER,
	);
	const createPaymentService = new CreatePaymentService(dispatchedActions);
	addBasicInterceptors(createPaymentService);
	createPaymentService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(createPaymentService.makeRequest(paymentDetails));
};

// Action to reset the state.
export const onResetPayAmountState = () => ({ type: ActionTypes.RESET_PAY_AMOUNT_STATE });

/**
 * Action to create the mada transaction request.
 * @param {object} madaDetails
 * @returns
 */

export const onCreateMadaTransaction = madaDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.CREATE_MADA_TRANSACTION_SUCCESS,
		ActionTypes.CREATE_MADA_TRANSACTION_FAILURE,
		ActionTypes.CREATE_MADA_TRANSACTION_LOADER,
	);
	const createMadaTransactionService = new CreateMadaTransactionService(dispatchedActions);
	addBasicInterceptors(createMadaTransactionService);
	createMadaTransactionService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(createMadaTransactionService.makeRequest(madaDetails));
};

/**
 * Action to resubmit the mada transaction request.
 * @param {object} madaDetails
 * @returns
 */

export const onResubmitMadaTransaction = madaDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.CREATE_MADA_TRANSACTION_SUCCESS,
		ActionTypes.CREATE_MADA_TRANSACTION_FAILURE,
		ActionTypes.CREATE_MADA_TRANSACTION_LOADER,
	);
	const resubmitMadaTransactionService = new ResubmitMadaTransactionService(dispatchedActions);
	addBasicInterceptors(resubmitMadaTransactionService);
	resubmitMadaTransactionService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(resubmitMadaTransactionService.makeRequest(madaDetails));
};
