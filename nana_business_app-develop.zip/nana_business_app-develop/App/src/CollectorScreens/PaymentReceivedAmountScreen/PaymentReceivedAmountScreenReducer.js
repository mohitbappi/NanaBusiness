import { keyConstants } from '@Constants/KeyConstants';
import * as ActionTypes from './ActionType';

const initialState = {
	paymentModeIndex: 0,
	amount: 0,
	terminalId: '',
	isAdvancePayment: 0,
	isMadaPayment: false,
	crIds: [],
};

const PaymentReceivedAmountScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.SET_CREATE_PAYMENT_MODE:
			return {
				...state,
				paymentModeIndex: action.payload,
			};
		case ActionTypes.SET_IS_ADVANCE_PAYMENT:
			return {
				...state,
				isAdvancePayment: action.payload,
			};
		case ActionTypes.ON_CHANGE_PAYMENT_RECEIVED_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.PAY_AMOUNT_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isMadaPayment: false,
				crIds: [],
			};
		case ActionTypes.PAY_AMOUNT_LOADER:
		case ActionTypes.CREATE_MADA_TRANSACTION_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				crIds: [],
			};
		case ActionTypes.PAY_AMOUNT_FAILURE:
		case ActionTypes.CREATE_MADA_TRANSACTION_FAILURE: {
			const { error, cr_ids } = action.payload;
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				crIds:
					error === keyConstants.MADA_TXN_REQUEST_ALREADY_MADE_FROM_COLLECTION
						? cr_ids
						: [],
			};
		}
		case ActionTypes.CREATE_MADA_TRANSACTION_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isMadaPayment: true,
				crIds: [],
			};
		case ActionTypes.RESET_PAY_AMOUNT_STATE:
			return initialState;
		default:
			return { ...state };
	}
};

export default PaymentReceivedAmountScreenReducer;
