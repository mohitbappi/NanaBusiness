import { StyleSheet } from 'react-native';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import * as colors from '@assets/colors';
import { fontsConstants } from '@Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			marginBottom: verticalScale(10),
			marginTop: verticalScale(5),
		},
		cardContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			paddingVertical: verticalScale(12),
			marginHorizontal: normalScale(16),
			borderBottomColor: colors.whitishGrey,
			borderBottomWidth: normalScale(1),
			borderRadius: normalScale(8),
			alignItems: 'center',
		},
		companyName: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			width: normalScale(250),
		},
		companyType: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(8),
		},
		icon: {
			height: verticalScale(17),
			width: normalScale(17),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		searchContainer: {
			marginBottom: verticalScale(12),
			marginHorizontal: normalScale(16),
		},
		scrollView: {
			paddingBottom: verticalScale(65),
		},
		nextButton: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			left: normalScale(8),
			right: normalScale(8),
			position: 'absolute',
			paddingTop: verticalScale(10),
			bottom: verticalScale(0),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
