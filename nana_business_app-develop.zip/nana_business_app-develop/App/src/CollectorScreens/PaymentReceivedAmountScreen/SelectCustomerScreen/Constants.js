import { keyConstants } from '@Constants/KeyConstants';

export const businessTypeConstants = {
	miniMarket: keyConstants.MINI_MARKET,
	superMarket: keyConstants.SUPER_MARKET,
	restaurant: keyConstants.RESTAURANTS,
	hotel: keyConstants.HOTELS,
	cafeShop: keyConstants.CAFE_SHOP,
	hospital: keyConstants.HOSPITAL,
	others: keyConstants.OTHERS,
};

export default businessTypeConstants;
