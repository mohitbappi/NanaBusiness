export { default } from './SelectCustomerContainer';
