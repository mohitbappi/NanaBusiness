import * as ActionTypes from './ActionType';

const initialState = {
	customerName: '',
	customerId: null,
	customerListing: [],
	count: 0,
};

const SelectCustomerScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_SELECT_CUSTOMER: {
			const { id, name } = action.payload;
			return {
				...state,
				customerName: name,
				customerId: id,
			};
		}
		case ActionTypes.GET_CUSTOMERS_LISTING_SUCCESS: {
			const { isAppendInExistingList } = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				customerListing: isAppendInExistingList
					? [...state.customerListing, ...action.payload.organizations]
					: [...action.payload.selected_org, ...action.payload.organizations],
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_ORGANIZATIONS_SUCCESS: {
			const isAppendInExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				customerListing: isAppendInExistingList
					? [...state.customerListing, ...action.payload.customers]
					: action.payload.customers,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_CUSTOMERS_LISTING_LOADER:
		case ActionTypes.GET_ORGANIZATIONS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_CUSTOMERS_LISTING_FAILURE:
		case ActionTypes.GET_ORGANIZATIONS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_CUSTOMER_STATE:
			return initialState;
		default:
			return { ...state };
	}
};

export default SelectCustomerScreenReducer;
