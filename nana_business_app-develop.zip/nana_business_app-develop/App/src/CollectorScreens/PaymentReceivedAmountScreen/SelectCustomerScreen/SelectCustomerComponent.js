// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { accountManager, salesExecutive, fetchDataWithPagination } from '@Constants/Constants';

// import components
import SelectCustomerUI from './SelectCustomerUI';

class SelectCustomerComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			searchText: '',
			bottomLoader: false,
			selectedCustomer: null,
		};
	}

	componentDidMount() {
		const { navigation, selectCustomerInfo, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.page = fetchDataWithPagination.page;
			const { customerId, customerName } = selectCustomerInfo;
			const { selectedCustomer } = this.state;
			this.setState(
				{
					searchText: '',
					selectedCustomer: {
						...selectedCustomer,
						id: customerId,
						name: customerName,
					},
				},
				() => this.onCallApi(false),
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { selectCustomerInfo, pullToRefreshActions } = this.props;
		const { success } = selectCustomerInfo;
		if (success && prevProps.selectCustomerInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onCallApi = isAppendInExistingList => {
		const { userDetails } = this.props;
		const { role } = userDetails.user;
		if (role === accountManager || role === salesExecutive) {
			// API call to get the customer organizations using zone.
			this.onFetchCustomerOrganizations(isAppendInExistingList);
		} else {
			// API call to get the customers.
			this.onFetchData(isAppendInExistingList);
		}
	};

	onSearch = text => {
		// Will search customer using name.
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => this.onCallApi(false),
		);
	};

	onFetchData = isAppendInExistingList => {
		// API call to get the customer listing.
		const { selectCustomerInfo, selectCustomerActions } = this.props;
		const { searchText } = this.state;
		const { customerId } = selectCustomerInfo;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			queryParams.organization = searchText; // If search is done by name.
		}
		if (customerId) {
			// Will add selected customer in request payload.
			queryParams.selected_ids = customerId;
		}
		selectCustomerActions.onGetCustomers(queryParams, isAppendInExistingList);
	};

	onFetchCustomerOrganizations = isAppendInExistingList => {
		// API call to get the customer organizations.
		const { searchText } = this.state;
		const { selectCustomerActions, route } = this.props;
		const { selectedZoneId } = route.params || {};
		const queryParams = {
			limit: this.limit,
			page: this.page,
		};
		if (selectedZoneId !== null) {
			queryParams.zone_id = selectedZoneId;
		}
		if (searchText) {
			queryParams.filter = searchText; // If search is done by name or cr number.
		}
		selectCustomerActions.onGetCustomerOrganizations(queryParams, isAppendInExistingList);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onEndReached = () => {
		const { selectCustomerInfo } = this.props;
		const { loader } = selectCustomerInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onCallApi(true);
		}
	};

	onChooseCustomer = item => {
		// Will set selected customer.
		this.setState({
			selectedCustomer: item,
		});
	};

	onSelectCustomer = () => {
		// Will set selected customer in reducer.
		const {
			navigation,
			selectCustomerActions,
			selectCustomerOrganizationActions,
			selectCustomerInfo,
			languageInfo,
			selectCollRequestsActions,
		} = this.props;
		const { isRTL } = languageInfo;
		const { selectedCustomer } = this.state;
		const { id, name, name_ar } = selectedCustomer;
		const { customerListing } = selectCustomerInfo;
		selectCustomerActions.onSelectCustomer({ id, name: isRTL ? name_ar || name : name });
		selectCustomerOrganizationActions.onSetDetails({
			customerOrganizations: customerListing,
		});
		selectCustomerOrganizationActions.onSetScreenVisibility(true);
		selectCollRequestsActions.onResetCollRequestsState();
		navigation.goBack();
	};

	onRefresh = () => {
		// Will call api after pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onCallApi(false);
	};

	render() {
		const {
			languageInfo,
			selectCustomerInfo,
			refreshControlComponentInfo,
			userDetails,
		} = this.props;
		const { isRTL } = languageInfo;
		const { customerListing, count, loader, error, errorCode } = selectCustomerInfo;
		const { bottomLoader, searchText, selectedCustomer } = this.state;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { role } = userDetails.user;
		return (
			<SelectCustomerUI
				isRTL={isRTL}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				customerListing={customerListing}
				count={count}
				role={role}
				selectedCustomer={selectedCustomer}
				error={error}
				errorCode={errorCode}
				searchText={searchText}
				onRefresh={this.onRefresh}
				onSearch={this.onSearch}
				onGoBack={this.onGoBack}
				onEndReached={this.onEndReached}
				onChooseCustomer={this.onChooseCustomer}
				onSelectCustomer={this.onSelectCustomer}
			/>
		);
	}
}

SelectCustomerComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	selectCustomerInfo: PropTypes.object.isRequired,
	selectCustomerActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	selectCustomerOrganizationActions: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	selectCollRequestsActions: PropTypes.object.isRequired,
};

export default SelectCustomerComponent;
