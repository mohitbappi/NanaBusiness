import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetCustomersService from '@MadaPayments/GetCustomersService';
import GetCustomerOrganizationsService from '@CustomerSuperAdmin/GetCustomerOrganizationsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to set the selected customer.
 * @param {object} customerDetail
 * @returns
 */

export const onSelectCustomer = customerDetail => {
	return {
		type: ActionTypes.ON_SELECT_CUSTOMER,
		payload: customerDetail,
	};
};

/**
 * Action to get the customer listing.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetCustomers = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_CUSTOMERS_LISTING_SUCCESS,
		ActionTypes.GET_CUSTOMERS_LISTING_FAILURE,
		ActionTypes.GET_CUSTOMERS_LISTING_LOADER,
	)
		.addSuccessExtra({ isAppendInExistingList })
		.build();
	const getCustomersService = new GetCustomersService(dispatchedActions);
	addBasicInterceptors(getCustomersService);
	getCustomersService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCustomersService.makeRequest(props));
};

/**
 * Action to get the customer organizations using zone.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetCustomerOrganizations = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ORGANIZATIONS_SUCCESS,
		ActionTypes.GET_ORGANIZATIONS_FAILURE,
		ActionTypes.GET_ORGANIZATIONS_LOADER,
	)
		.addSuccessExtra(isAppendInExistingList)
		.build();
	const getCustomerOrganizationsService = new GetCustomerOrganizationsService(dispatchedActions);
	addBasicInterceptors(getCustomerOrganizationsService);
	getCustomerOrganizationsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCustomerOrganizationsService.makeRequest(props));
};

// Action to reset the state.
export const onResetCustomerState = () => ({ type: ActionTypes.RESET_CUSTOMER_STATE });
