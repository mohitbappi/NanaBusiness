// import libraries
import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import Search from '@Search/Search';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';

// import utils
import { localeString } from '@Localization/index';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';

// import constants
import { accountManager, salesExecutive, fetchDataWithPagination } from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';
import { businessTypeConstants } from './Constants';

// import styles
import { createStyleSheet } from './SelectCustomerScreenStyle';

class SelectCustomerUI extends Component {
	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		// Will show loader while pagination.
		const { isRTL, customerListing, count } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached = count === customerListing.length || count < customerListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	renderItem = ({ item }) => {
		const { isRTL, selectedCustomer, onChooseCustomer } = this.props;
		const styles = createStyleSheet(isRTL);
		const { name_ar, name, business_type, id } = item;
		const customerName = isRTL ? name_ar || name : name;
		return (
			<View style={styles.cardContainer}>
				<View>
					<Text style={styles.companyName}>{customerName}</Text>
					<Text style={styles.companyType}>
						{business_type
							? localeString(businessTypeConstants[business_type])
							: localeString(keyConstants.OTHERS)}
					</Text>
				</View>
				<TouchableOpacity onPress={() => onChooseCustomer(item)} activeOpacity={0.8}>
					<ImageLoadComponent
						source={
							(selectedCustomer && selectedCustomer.id) === id
								? IMAGES.iconCheckCircle
								: IMAGES.iconUnCheckCircle
						}
						style={styles.icon}
					/>
				</TouchableOpacity>
			</View>
		);
	};

	render() {
		const {
			isRTL,
			loader,
			customerListing,
			count,
			role,
			error,
			errorCode,
			searchText,
			onRefresh,
			onSearch,
			onGoBack,
			onEndReached,
			onSelectCustomer,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<View style={styles.headerContainer}>
					<Header
						onPressBack={onGoBack}
						hasIconBack
						text={localeString(keyConstants.CUSTOMER_NAME)}
					/>
				</View>
				{error ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.searchContainer}>
							<Search
								hasSearchIcon
								placeholder={localeString(
									role === accountManager || role === salesExecutive
										? keyConstants.SEARCH_BY_CUSTOMER_NAME_CR_NUMBER
										: keyConstants.SEARCH_BY_CUSTOMER,
								)}
								onChangeText={text => onSearch(text)}
								value={searchText}
							/>
						</View>
						{customerListing.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_CUSTOMERS_FOUND)} />
						) : (
							<FlatListComponent
								data={customerListing}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								keyboardShouldPersistTaps
								onEndReached={() =>
									customerListing.length !== count && onEndReached()
								}
								ListFooterComponent={
									customerListing.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								onRefresh={onRefresh}
								componentType={constants.flatList}
								contentContainerStyle={styles.scrollView}
							/>
						)}
						<View style={styles.nextButton}>
							<ButtonComponent
								text={localeString(keyConstants.NEXT)}
								onPress={onSelectCustomer}
							/>
						</View>
					</>
				)}
			</View>
		);
	}
}

SelectCustomerUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	customerListing: PropTypes.object.isRequired,
	loader: PropTypes.bool.isRequired,
	onChooseCustomer: PropTypes.func.isRequired,
	onSearch: PropTypes.func.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	count: PropTypes.any.isRequired,
	selectedCustomer: PropTypes.array.isRequired,
	searchText: PropTypes.string.isRequired,
	onSelectCustomer: PropTypes.func.isRequired,
	role: PropTypes.string.isRequired,
};

export default SelectCustomerUI;
