// import libraries
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as SelectCustomerOrganizationActions from '@SelectCustomerOrganizationScreen/SelectCustomerOrganizationAction';
import * as SelectCollRequestsActions from '@SelectCollRequestsScreen/SelectCollRequestsScreenAction';
import * as SelectCustomerActions from './SelectCustomerScreenAction';

// import components
import SelectCustomerComponent from './SelectCustomerComponent';

const SelectCustomerContainer = props => {
	const customProps = { ...props }; // Will store all the props including actions & reducers.
	return <SelectCustomerComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		selectCustomerInfo: state.SelectCustomerScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		userDetails: state.HomeScreenReducer.userDetails,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		selectCustomerActions: bindActionCreators({ ...SelectCustomerActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		selectCustomerOrganizationActions: bindActionCreators(
			{ ...SelectCustomerOrganizationActions },
			dispatch,
		),
		selectCollRequestsActions: bindActionCreators({ ...SelectCollRequestsActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(SelectCustomerContainer);
