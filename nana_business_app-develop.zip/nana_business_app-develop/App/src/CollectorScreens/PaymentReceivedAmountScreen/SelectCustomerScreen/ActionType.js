export const ON_SELECT_CUSTOMER = 'on_select_customer';

export const GET_CUSTOMERS_LISTING_SUCCESS = 'get_customers_listing_success';
export const GET_CUSTOMERS_LISTING_LOADER = 'get_customers_listing_loader';
export const GET_CUSTOMERS_LISTING_FAILURE = 'get_customers_listing_failure';

export const GET_ORGANIZATIONS_SUCCESS = 'get_organizations_success';
export const GET_ORGANIZATIONS_FAILURE = 'get_organizations_failure';
export const GET_ORGANIZATIONS_LOADER = 'get_organizations_loader';

export const RESET_CUSTOMER_STATE = 'reset_customer_state';
