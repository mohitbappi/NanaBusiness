import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			justifyContent: 'flex-start',
			marginHorizontal: normalScale(16),
		},
		innerContainer: {
			paddingHorizontal: normalScale(16),
			paddingBottom: verticalScale(65),
		},
		paymentMode: {
			color: colors.black,
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			marginTop: verticalScale(16),
		},
		wrapStyle: {
			flexWrap: 'wrap',
			justifyContent: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		crContainer: {
			borderRadius: normalScale(12),
			backgroundColor: colors.whitishGrey,
			paddingHorizontal: normalScale(12),
			paddingVertical: verticalScale(5),
			alignItems: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginLeft: isRTL
				? rtlFunctions.getMarginLeft(isRTL, 8)
				: rtlFunctions.getMarginLeftRTL(isRTL, 8),
			marginRight: isRTL
				? rtlFunctions.getMarginRight(isRTL, 8)
				: rtlFunctions.getMarginRightRTL(isRTL, 8),
			marginTop: verticalScale(8),
		},
		crId: {
			color: colors.black,
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		iconCrossStyle: {
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
			marginRight: rtlFunctions.getMarginRight(isRTL, 8),
		},
		iconCross: {
			height: normalScale(9),
			width: normalScale(9),
		},
		buttonView: {
			position: 'absolute',
			width: '100%',
			bottom: verticalScale(16),
			paddingHorizontal: normalScale(16),
		},
		textStyle: {
			color: colors.lightWhite,
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		textInput: {
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		isAdvance: {
			color: colors.lightBlack,
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			marginTop: verticalScale(16),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		isAdvanceContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(8),
			paddingVertical: verticalScale(14),
		},
		optionContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
		},
		margin: {
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 105),
			marginRight: rtlFunctions.getMarginRight(isRTL, 105),
		},
		checkedIcon: {
			height: verticalScale(14),
			width: normalScale(14),
		},
		icon: {
			height: verticalScale(12),
			width: normalScale(12),
		},
		title: {
			color: colors.black,
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
			marginRight: rtlFunctions.getMarginRight(isRTL, 8),
		},
	});
};

export default createStyleSheet;
