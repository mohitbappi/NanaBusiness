import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetCollRequestsService from '@MadaPayments/GetCollRequestsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to set the selected collection requests and amount.
 * @param {object} payload
 * @returns
 */

export const onSelectCollRequests = payload => {
	return {
		type: ActionTypes.ON_SELECT_COLL_REQUESTS,
		payload,
	};
};

/**
 * Action to get the collection requests.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetCollRequests = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_COLL_REQUESTS_LISTING_SUCCESS,
		ActionTypes.GET_COLL_REQUESTS_LISTING_FAILURE,
		ActionTypes.GET_COLL_REQUESTS_LISTING_LOADER,
	)
		.addSuccessExtra({ isAppendInExistingList })
		.build();
	const getCollRequestsService = new GetCollRequestsService(dispatchedActions);
	addBasicInterceptors(getCollRequestsService);
	getCollRequestsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCollRequestsService.makeRequest(props));
};

/**
 * Action to remove the collection request using CR id.
 * @param {integer} id
 * @returns
 */

export const onRemoveCollRequest = id => {
	return {
		type: ActionTypes.REMOVE_COLL_REQUESTS,
		payload: id,
	};
};

// Action to reset the state.
export const onResetCollRequestsState = () => ({ type: ActionTypes.RESET_COLL_REQUESTS_STATE });
