// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { driver, fetchDataWithPagination } from '@Constants/Constants';

// import utils
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';

// import components
import SelectCollRequestsUI from './SelectCollRequestsUI';

class SelectCollRequestsComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.customerId = props.route.params.customerId;
		this.roles = props.userDetails.user.roles;
		this.id = props.userDetails.user.id;
		this.state = {
			searchText: '',
			bottomLoader: false,
			selectedCollRequests: [],
			totalAmount: 0,
		};
	}

	componentDidMount() {
		const { navigation, selectCollRequestsInfo, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.page = fetchDataWithPagination.page;
			const { selectedCollRequests, totalAmount } = selectCollRequestsInfo;
			this.setState(
				{
					searchText: '',
					selectedCollRequests: [...selectedCollRequests], // Selected collection requests ids.
					totalAmount,
				},
				() => this.onFetchData(false),
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { selectCollRequestsInfo, pullToRefreshActions } = this.props;
		const { success } = selectCollRequestsInfo;
		if (success && prevProps.selectCollRequestsInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onSearch = text => {
		// Will search collection request using id.
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onFetchData(false);
			},
		);
	};

	onFetchData = isAppendInExistingList => {
		// API call to get the collection requests.
		const { selectCollRequestsInfo, selectCollRequestsActions } = this.props;
		const { searchText } = this.state;
		const { selectedCollRequests } = selectCollRequestsInfo;
		let collRequests = '';
		selectedCollRequests.map((item, index) => {
			collRequests += `${item.id}`;
			if (index === selectedCollRequests.length - 1) {
				return;
			}
			collRequests += ',';
		});
		const request = {
			customerId: this.customerId,
			queryParams: {
				limit: this.limit,
				page: this.page,
			},
		};
		if (searchText) {
			request.queryParams.collection_id = searchText; // If search is done by collection request id
		}
		if (selectedCollRequests.length !== 0) {
			// Will add selected collection requests in request payload.
			request.queryParams.selected_ids = collRequests;
		}
		if (this.roles.includes(driver)) {
			// Adding driver_id in params if role is driver.
			request.queryParams.driver_id = this.id;
		}
		selectCollRequestsActions.onGetCollRequests(request, isAppendInExistingList);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onEndReached = () => {
		const { selectCollRequestsInfo } = this.props;
		const { loader } = selectCollRequestsInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onChooseCollRequests = (collRequestId, amount) => {
		// Will set selected collection request and sum of all the selected collection requests.
		const { selectedCollRequests } = this.state;
		let { totalAmount } = this.state;
		const itemIndex = selectedCollRequests.findIndex(element => element.id === collRequestId);
		if (itemIndex !== -1) {
			// If CR is selected then it will remove it.
			selectedCollRequests.splice(itemIndex, 1);
			totalAmount -= parseFloat(amount);
		} else {
			// If CR is not selected then it will add it.
			selectedCollRequests.push({
				id: collRequestId,
				invoiceNo: `${localeString(keyConstants.CR)}-${collRequestId}`,
			});
			totalAmount += parseFloat(amount);
		}
		this.setState({
			selectedCollRequests,
			totalAmount,
		});
	};

	onSelectCollRequests = () => {
		// Will set selected collection request and sum of all the selected collection requests in reducer.
		const { navigation, selectCollRequestsActions } = this.props;
		const { selectedCollRequests, totalAmount } = this.state;
		selectCollRequestsActions.onSelectCollRequests({
			selectedCollRequests,
			totalAmount,
		});
		navigation.goBack();
	};

	onRefresh = () => {
		// Will call api after pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	render() {
		const { languageInfo, selectCollRequestsInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const { collRequestsListing, count, loader, error, errorCode } = selectCollRequestsInfo;
		const { bottomLoader, searchText, selectedCollRequests } = this.state;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<SelectCollRequestsUI
				isRTL={isRTL}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				collRequestsListing={collRequestsListing}
				count={count}
				selectedCollRequests={selectedCollRequests}
				error={error}
				errorCode={errorCode}
				searchText={searchText}
				onRefresh={this.onRefresh}
				onSearch={this.onSearch}
				onGoBack={this.onGoBack}
				onEndReached={this.onEndReached}
				onChooseCollRequests={this.onChooseCollRequests}
				onSelectCollRequests={this.onSelectCollRequests}
			/>
		);
	}
}

SelectCollRequestsComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	selectCollRequestsInfo: PropTypes.object.isRequired,
	selectCollRequestsActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
};

export default SelectCollRequestsComponent;
