// import libraries
import React, { Component } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import Search from '@Search/Search';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';

// import utils
import { localeString } from '@Localization/index';
import { keyConstants } from '@Constants/KeyConstants';
import { getFormattedDate } from '@Util/GetFormattedDate';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

// import constants
import { fetchDataWithPagination, minus } from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import styles
import { createStyleSheet } from './SelectCollRequestsScreenStyle';

class SelectCollRequestsUI extends Component {
	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		// Will show loader while pagination.
		const { isRTL, collRequestsListing, count } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached =
			count === collRequestsListing.length || count < collRequestsListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	renderItem = ({ item }) => {
		const { isRTL, selectedCollRequests, onChooseCollRequests } = this.props;
		const selectedCollRequestsIds = selectedCollRequests.reduce((accumulator, element) => {
			accumulator.push(element.id);
			return accumulator;
		}, []);
		const styles = createStyleSheet(isRTL);
		const { invoice_no, due, invoice_total, id } = item;
		return (
			<View style={styles.invoiceContainer}>
				<InvoiceCardComponent
					name={`${localeString(keyConstants.CR)}${minus}${id}`}
					extraId={`${localeString(keyConstants.SALES_INVOICE_ID)}: ${invoice_no}`}
					dateLabel={`${localeString(keyConstants.DUE_DATE)}: `}
					date={getFormattedDate(due)}
					amount={`${currencyFormatter(getValueInDecimal(invoice_total))} ${localeString(
						keyConstants.SAR,
					)}`}
					isDisable
					dateStyle={styles.dateStyle}
					showCheckBox // Boolean to show checkboxes.
					selectedItem={selectedCollRequestsIds || []}
					id={id}
					onSelect={() => onChooseCollRequests(id, invoice_total)}
				/>
			</View>
		);
	};

	render() {
		const {
			isRTL,
			loader,
			collRequestsListing,
			count,
			error,
			errorCode,
			searchText,
			onRefresh,
			onSearch,
			onGoBack,
			onEndReached,
			onSelectCollRequests,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<View style={styles.headerContainer}>
					<Header
						onPressBack={onGoBack}
						hasIconBack
						text={localeString(keyConstants.COLLECTION_REQUEST)}
					/>
				</View>
				{error ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.searchContainer}>
							{/* Will remove the false when we will implement search. */}
							{false && (
								<Search
									hasSearchIcon
									placeholder={localeString(
										keyConstants.SEARCH_BY_COLLECTION_REQUEST_ID,
									)}
									onChangeText={text => onSearch(text)}
									value={searchText}
								/>
							)}
						</View>
						{collRequestsListing.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
						) : (
							<FlatListComponent
								data={collRequestsListing}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								onEndReached={() =>
									collRequestsListing.length !== count && onEndReached()
								}
								ListFooterComponent={
									collRequestsListing.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								onRefresh={onRefresh}
								componentType={constants.flatList}
								contentContainerStyle={styles.scrollView}
								keyboardShouldPersistTaps
							/>
						)}
						<View style={styles.nextButton}>
							<ButtonComponent
								text={localeString(keyConstants.NEXT)}
								onPress={onSelectCollRequests}
							/>
						</View>
					</>
				)}
			</View>
		);
	}
}

SelectCollRequestsUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	collRequestsListing: PropTypes.object.isRequired,
	loader: PropTypes.bool.isRequired,
	onChooseCollRequests: PropTypes.func.isRequired,
	onSearch: PropTypes.func.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	count: PropTypes.any.isRequired,
	selectedCollRequests: PropTypes.array.isRequired,
	searchText: PropTypes.string.isRequired,
	onSelectCollRequests: PropTypes.func.isRequired,
};

export default SelectCollRequestsUI;
