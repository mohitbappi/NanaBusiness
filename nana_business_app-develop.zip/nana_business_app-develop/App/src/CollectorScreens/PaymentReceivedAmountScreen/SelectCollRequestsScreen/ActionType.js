export const ON_SELECT_COLL_REQUESTS = 'on_select_coll_requests';

export const GET_COLL_REQUESTS_LISTING_SUCCESS = 'get_coll_requests_listing_success';
export const GET_COLL_REQUESTS_LISTING_LOADER = 'get_coll_requests_listing_loader';
export const GET_COLL_REQUESTS_LISTING_FAILURE = 'get_coll_requests_listing_failure';

export const REMOVE_COLL_REQUESTS = 'remove_coll_requests';

export const RESET_COLL_REQUESTS_STATE = 'reset_coll_requests_state';
