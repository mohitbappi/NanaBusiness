// import libraries
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as SelectCollRequestsActions from './SelectCollRequestsScreenAction';

// import components
import SelectCollRequestsComponent from './SelectCollRequestsComponent';

const SelectCollRequestsContainer = props => {
	const customProps = { ...props }; // Will store all the props including actions & reducers.
	return <SelectCollRequestsComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		selectCollRequestsInfo: state.SelectCollRequestsScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		userDetails: state.ShipmentScreenReducer.userDetails,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		selectCollRequestsActions: bindActionCreators({ ...SelectCollRequestsActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(SelectCollRequestsContainer);
