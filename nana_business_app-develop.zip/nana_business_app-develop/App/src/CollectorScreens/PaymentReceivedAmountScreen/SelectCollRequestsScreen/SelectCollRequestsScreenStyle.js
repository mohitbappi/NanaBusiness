import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import { fontsConstants } from '@Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginBottom: verticalScale(10),
			marginTop: verticalScale(5),
		},
		invoiceContainer: {
			marginHorizontal: normalScale(16),
		},
		dateStyle: {
			color: colors.red,
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		searchContainer: {
			marginBottom: verticalScale(12),
			marginHorizontal: normalScale(16),
		},
		scrollView: {
			paddingBottom: verticalScale(65),
		},
		nextButton: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
