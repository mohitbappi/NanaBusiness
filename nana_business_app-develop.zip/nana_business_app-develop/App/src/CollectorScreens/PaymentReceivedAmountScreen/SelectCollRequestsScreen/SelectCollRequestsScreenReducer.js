import * as ActionTypes from './ActionType';

const initialState = {
	selectedCollRequests: [],
	totalAmount: 0,
	collRequestsListing: [],
	count: 0,
};

const SelectCollRequestsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_SELECT_COLL_REQUESTS: {
			const { selectedCollRequests, totalAmount } = action.payload;
			return {
				...state,
				selectedCollRequests,
				totalAmount,
			};
		}
		case ActionTypes.REMOVE_COLL_REQUESTS: {
			const { id, amount } = action.payload;
			let { totalAmount } = state;
			const itemIndex = state.selectedCollRequests.findIndex(element => element.id === id);
			state.selectedCollRequests.splice(itemIndex, 1);
			totalAmount -= parseFloat(amount);
			return {
				...state,
				totalAmount,
			};
		}
		case ActionTypes.GET_COLL_REQUESTS_LISTING_SUCCESS: {
			const { isAppendInExistingList } = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				collRequestsListing: isAppendInExistingList
					? [...state.collRequestsListing, ...action.payload.invoices]
					: [...action.payload.selected_invoices, ...action.payload.invoices],
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_COLL_REQUESTS_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_COLL_REQUESTS_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_COLL_REQUESTS_STATE:
			return {
				...state,
				selectedCollRequests: [],
				totalAmount: 0,
				collRequestsListing: [],
				count: 0,
			};
		default:
			return state;
	}
};

export default SelectCollRequestsScreenReducer;
