// import libraries
import React, { Component } from 'react';
import { Keyboard, View, Text, FlatList, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';

// import constants
import { numericRegexWithDecimalEx, spaceRegexEx, invoiceImg } from '@Constants/Constants';
import { keyConstants } from '@Constants/KeyConstants';

// import utils
import { localeString } from '@assets/Localization';
import { normalScale } from '@device/normalize';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

// import images
import IMAGES from '@Images/index';

// import components
import Header from '@Header/Header';
import Input from '@Input/Input';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import PaymentModeCard from '@PaymentModeCard/PaymentModeCard';
import ImageInputComponent from '@ImageInputComponent/ImageInputComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { ParallelFormatCardComponent } from '@DetailCardComponent/DetailCardComponent';
import AlertComponent from '@Util/AlertComponent';
import ConfimationModal from '@ConfimationModal/ConfimationModal';

// import navigations
import collectorNavigations from '@routes/collectorNavigations';
import driverNavigations from '@config/routes/driverNavigations';

// import actions
import * as MyCollectionActions from '@CollectionScreen/CollectionScreenAction';
import * as ImageInputActions from '@ImageInputComponent/ImageInputComponentAction';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as PaymentReceivedActions from './PaymentReceivedAmountScreenAction';
import * as SelectCustomerActions from './SelectCustomerScreen/SelectCustomerScreenAction';
import * as SelectCollRequestsActions from './SelectCollRequestsScreen/SelectCollRequestsScreenAction';
import * as SelectRRNActions from './SelectRRNScreen/SelectRRNScreenAction';

// import styles
import { createStyleSheet } from './PaymentReceivedAmountScreenStyle';

class PaymentReceivedAmountScreen extends Component {
	constructor(props) {
		super(props);
		this.scrollRef = React.createRef(null);
		this.state = {
			isAmountError: false,
			amountErrorMessage: '',
			showConfirmationModal: false,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const {
				route,
				languageInfo,
				selectRRNActions,
				selectCustomerActions,
				imageInputActions,
				pullToRefreshActions,
			} = this.props;
			const { isNewMadaPayment, extraParams, transactionDetail, isResubmit, isDriverRole } =
				route.params || {};
			const { terminal_id, rrn, amount, madaId, index } = extraParams || {};
			pullToRefreshActions.onSetSelectIndex(index);
			const { isRTL } = languageInfo;
			if (isDriverRole) {
				// Will autofill the amount and customer name if the role is driver.
				const { shipmentData } = extraParams || {};
				this.onChangeText(`${shipmentData?.amount}`, 'amount'); // Will set amount in reducer.
				selectCustomerActions.onSelectCustomer({
					id: shipmentData?.customer_org_id,
					name: isRTL ? shipmentData?.customer_name_ar : shipmentData?.customer_name,
				});
				this.setExistingCrs([shipmentData?.collection_request]);
			} else if (!isNewMadaPayment) {
				// If the request is not new mada payment
				this.onChangeText(terminal_id, 'terminalId'); // Will set terminal id in reducer.
				this.onChangeText(`${amount}`, 'amount'); // Will set amount in reducer.
				selectRRNActions.onSelectRRN(madaId, rrn); // Will set RRN id and RRN number in reducer.
			} else if (isResubmit && transactionDetail) {
				// If user trying to resubmit the mada transaction request.
				const { customer_organization, image, details } = transactionDetail;
				const { name_ar, name, id } = customer_organization || {};
				const { is_advance_payment, cr_ids } = details || {};
				this.onChangeText(terminal_id, 'terminalId'); // Will set terminal id in reducer.
				this.onChangeText(`${amount}`, 'amount'); // Will set amount in reducer.
				selectRRNActions.onSelectRRN(null, rrn); // Will set RRN number in reducer.
				selectCustomerActions.onSelectCustomer({
					id,
					name: isRTL ? name_ar : name,
				});
				this.onSelectIsAdvancePayment(is_advance_payment === 'true' ? 1 : 0);
				this.setExistingCrs(cr_ids);
				imageInputActions.onChangeImage(image, false);
				delete route.params.isResubmit;
			} else {
				selectRRNActions.onGetRRNListing(null, false);
			}
		});
	}

	componentDidUpdate(prevProps) {
		const {
			paymentReceivedInfo,
			selectRRNInfo,
			myCollectionActions,
			navigation,
			selectCollRequestsInfo,
			route,
		} = this.props;
		const {
			amount,
			success,
			error,
			errorCode,
			isMadaPayment,
			crIds,
			paymentModeIndex,
		} = paymentReceivedInfo;
		const { terminalId, success: rrnSuccess, rrnId } = selectRRNInfo;
		const { totalAmount } = selectCollRequestsInfo;
		const { isDriverRole } = route.params || {};
		if (rrnSuccess && prevProps.selectRRNInfo.success !== rrnSuccess) {
			this.onChangeText(terminalId, 'terminalId');
		}
		if (success && prevProps.paymentReceivedInfo.success !== success) {
			// Will navigate back to the previous screen and reset the reducer.
			if (isDriverRole) {
				// If role is driver then it will show the confimation modal.
				this.handleConfimationModal(true);
			} else {
				if (isMadaPayment) {
					myCollectionActions.onSetTabIndex(1);
				} else {
					myCollectionActions.onSetTabIndex(2);
				}
				navigation.navigate(collectorNavigations.COLLECTION_NAVIGATION);
				this.onResetReducer();
			}
		}
		if (
			paymentReceivedInfo.amount !== prevProps.paymentReceivedInfo.amount &&
			numericRegexWithDecimalEx.test(String(amount).toLowerCase())
		) {
			// Will check amount validations.
			this.setState({
				isAmountError: false,
				amountErrorMessage: '',
			});
		}
		if (rrnId && prevProps.selectRRNInfo.rrnId !== rrnId) {
			// Will set amount using RRN in reducer.
			this.onChangeText(`${this.getSelectedRRNAmount()}`, 'amount');
		}
		if (paymentModeIndex === 0 && prevProps.selectCollRequestsInfo !== selectCollRequestsInfo) {
			this.onChangeText(`${getValueInDecimal(totalAmount)}`, 'amount');
		}
		if (error && prevProps.paymentReceivedInfo.error !== error) {
			if (errorCode.error === keyConstants.MADA_TXN_REQUEST_ALREADY_EXISTS) {
				// Will show alert if error occurs.
				const alertOptions = {
					message: localeString(keyConstants.MADA_TXN_REQUEST_ALREADY_EXISTS),
					yesText: localeString(keyConstants.OKAY),
					isOneButton: true,
				};
				setTimeout(() => {
					AlertComponent(alertOptions);
				}, 100);
			} else if (
				errorCode.error === keyConstants.MADA_TXN_REQUEST_ALREADY_MADE_FROM_COLLECTION
			) {
				// Will show alert if error occurs and remove the cr's which is already used in other mada transaction.
				const alertOptions = {
					message: localeString(
						keyConstants.MADA_TXN_REQUEST_ALREADY_MADE_FROM_COLLECTION,
					),
					yesText: localeString(keyConstants.YES),
					noText: localeString(keyConstants.NO),
					onPressYes: () => {
						crIds.forEach(element => {
							this.onRemoveCrId(element);
						});
					},
				};
				setTimeout(() => {
					AlertComponent(alertOptions);
				}, 100);
			} else {
				// Will show alert if api fails.
				ErrorAlertComponent(errorCode, this.createPayment);
			}
		}
	}

	componentWillUnmount() {
		const { route, navigation } = this.props;
		const { isDriverRole } = route.params || {};
		this.onResetReducer();
		if (isDriverRole) {
			// Will navigate to the shipment screen if role is driver.
			navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
		}
	}

	onResetReducer = () => {
		// Will reset the reducers.
		const {
			paymentReceivedActions,
			selectCustomerActions,
			selectCollRequestsActions,
			selectRRNActions,
		} = this.props;
		paymentReceivedActions.onResetPayAmountState();
		selectCustomerActions.onResetCustomerState();
		selectCollRequestsActions.onResetCollRequestsState();
		selectRRNActions.onResetRRNState();
	};

	getSelectedRRNAmount = () => {
		// Will return selected RRN amount.
		const { paymentReceivedInfo, selectRRNInfo } = this.props;
		const { amount } = paymentReceivedInfo;
		const { rrnId, rrnListing } = selectRRNInfo;
		if (rrnId && rrnListing && rrnListing.length !== 0) {
			const index = rrnListing.findIndex(element => element.id === rrnId);
			return rrnListing[index].amount;
		}
		return getValueInDecimal(amount);
	};

	setExistingCrs = crIds => {
		// Will set CR in case of resubmit.
		const { selectCollRequestsActions } = this.props;
		if (crIds) {
			const selectedCollRequests = [];
			let totalAmount = 0;
			crIds.forEach(element => {
				const { id, invoice_no, invoice_total } = element || {};
				selectedCollRequests.push({
					id,
					invoiceNo: `${localeString(keyConstants.CR)}-${invoice_no}`,
				});
				totalAmount += parseFloat(invoice_total);
			});
			selectCollRequestsActions.onSelectCollRequests({
				selectedCollRequests,
				totalAmount,
			});
		}
	};

	onPressBack = () => {
		// Will go back to previous screen & reset the reducer.
		const { paymentReceivedActions, navigation, route } = this.props;
		const { isDriverRole } = route.params || {};
		if (isDriverRole) {
			// Will navigate to the shipment screen if role is driver.
			navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
		} else {
			navigation.goBack();
		}
		paymentReceivedActions.onResetPayAmountState();
	};

	getMadaDetails = () => {
		// Will return the mada details.
		const { paymentReceivedInfo, selectRRNInfo } = this.props;
		const { terminalId, amount } = paymentReceivedInfo;
		const { rrn } = selectRRNInfo;
		return [
			{
				label: localeString(keyConstants.AMOUNT),
				labelValue: `${currencyFormatter(getValueInDecimal(amount))} ${localeString(
					keyConstants.SAR,
				)}`,
			},
			{
				label: localeString(keyConstants.TERMINAL_ID),
				labelValue: terminalId,
			},
			{
				label: localeString(keyConstants.RRN_NUMBER),
				labelValue: rrn,
			},
		];
	};

	getPaymentOptions = () => {
		// Will return the payment options.
		const { paymentReceivedInfo } = this.props;
		const { terminalId } = paymentReceivedInfo;
		const options = [
			{
				icon: IMAGES.iconCOD,
				title: localeString(keyConstants.CASH),
			},
		];
		if (terminalId) {
			// If terminal id exists.
			options.push({
				icon: IMAGES.iconMadaGreen,
				title: localeString(keyConstants.MADA_POS),
			});
		}
		return options;
	};

	getIsAdvancePaymentOptions = () => {
		// Will return the advance payment options.
		return [localeString(keyConstants.NO), localeString(keyConstants.YES)];
	};

	onChangeText = (text, field) => {
		// Sets 'field' value to 'text' in redux state using onChangeText action.
		const { paymentReceivedActions } = this.props;
		paymentReceivedActions.onChangeText(text, field);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onBlur = () => {
		const { paymentReceivedInfo } = this.props;
		const { amount } = paymentReceivedInfo;
		if (!numericRegexWithDecimalEx.test(String(amount).toLowerCase())) {
			this.setState({
				isAmountError: true,
				amountErrorMessage: localeString(keyConstants.ONLY_TWO_DIGIT_AFTER_DECIMAL),
			});
		}
	};

	onSearchCustomer = () => {
		// Will navigate to the select customer screen.
		const { navigation } = this.props;
		navigation.navigate(collectorNavigations.SELECT_CUSTOMER_NAVIGATION);
	};

	createPayment = () => {
		// API call to create the payment received.
		const {
			route,
			selectCustomerInfo,
			selectRRNInfo,
			imageInputComponentInfo,
			paymentReceivedInfo,
			paymentReceivedActions,
		} = this.props;
		const { id, transactionDetail } = route.params || {};
		const { amount, paymentModeIndex, isAdvancePayment, terminalId } = paymentReceivedInfo;
		const { customerId } = selectCustomerInfo;
		const { rrn, rrnId } = selectRRNInfo;
		const { image } = imageInputComponentInfo;
		const paymentDetails = {
			amount,
			organization_id: customerId,
		};
		if (isAdvancePayment === 0) {
			// If it is not an advance payment.
			paymentDetails.cr_ids = this.getCrIds();
		}
		if (parseFloat(this.getSelectedRRNAmount()) !== parseFloat(amount)) {
			// Will show error if selected RRN amount is not equal to the entered amount.
			const alertOptions = {
				message: localeString(keyConstants.RRN_REQUEST_AMOUNT_ERROR),
				yesText: localeString(keyConstants.OKAY),
				isOneButton: true,
			};
			setTimeout(() => {
				AlertComponent(alertOptions);
			}, 100);
		} else if (isAdvancePayment === 0 && !this.onCheckCRError()) {
			// Will show error if selected CR's amount is not equal to the entered amount.
			const alertOptions = {
				message: localeString(keyConstants.COLL_REQUEST_AMOUNT_ERROR),
				yesText: localeString(keyConstants.OKAY),
				isOneButton: true,
			};
			setTimeout(() => {
				AlertComponent(alertOptions);
			}, 100);
		} else if (paymentModeIndex === 0) {
			// Will create advance payment if mode is cash.
			paymentReceivedActions.onCreatePayment(paymentDetails);
		} else if (paymentModeIndex === 1) {
			// Will mada transaction request if mode is MadaPos.
			paymentDetails.terminal_id = terminalId;
			paymentDetails.rrn = rrn;
			if (rrnId) {
				paymentDetails.mada_transaction_id = rrnId;
			}
			paymentDetails.image = image;
			paymentDetails.is_advance_payment = isAdvancePayment === 0 ? 'false' : 'true';
			if (transactionDetail) {
				const payload = {
					id,
					body: paymentDetails,
				};
				this.onCreateTransaction(transactionDetail, payload);
			} else {
				this.onCreateTransaction(transactionDetail, paymentDetails);
			}
		}
	};

	onCreateTransaction = (isResubmit, payload) => {
		// Will show confirmation popup to create the request.
		const { paymentReceivedInfo, paymentReceivedActions } = this.props;
		const { amount } = paymentReceivedInfo;
		const alertOptions = {
			message: `${localeString(
				keyConstants.MADA_TRANSACTION_CONFIRMATION_POPUP,
			)} ${amount} ${localeString(keyConstants.SAR)}`,
			yesText: localeString(keyConstants.YES),
			noText: localeString(keyConstants.NO),
			onPressYes: () =>
				isResubmit
					? paymentReceivedActions.onResubmitMadaTransaction(payload)
					: paymentReceivedActions.onCreateMadaTransaction(payload),
		};
		AlertComponent(alertOptions);
	};

	onScrollToTop = () => {
		// Will scroll the user to the top.
		if (
			this.scrollRef &&
			this.scrollRef._internalFiberInstanceHandleDEV &&
			this.scrollRef._internalFiberInstanceHandleDEV.memoizedProps &&
			this.scrollRef._internalFiberInstanceHandleDEV.memoizedProps.scrollToPosition
		) {
			this.scrollRef._internalFiberInstanceHandleDEV.memoizedProps.scrollToPosition(0, 0);
		}
	};

	getCrIds = () => {
		// Will return the selected CR's.
		const { selectCollRequestsInfo } = this.props;
		const { selectedCollRequests } = selectCollRequestsInfo;
		const tempArray = [];
		selectedCollRequests.forEach(element => {
			tempArray.push(element.id);
		});
		return tempArray;
	};

	onSelectOption = index => {
		// Will set payment mode.
		const { paymentReceivedActions } = this.props;
		paymentReceivedActions.onSetPaymentMode(index);
	};

	onChangeReferenceNumber = text => {
		// Will set RRN number.
		const { selectRRNActions } = this.props;
		selectRRNActions.onSelectRRN(null, text);
	};

	onSearchRRN = () => {
		// Will navigate to the RRN screen.
		const { navigation } = this.props;
		navigation.navigate(collectorNavigations.SELECT_RRN_NAVIGATION);
	};

	keyExtractor = (item, index) => index.toString();

	onSelectIsAdvancePayment = index => {
		// Will set advance payment.
		const { paymentReceivedInfo, paymentReceivedActions } = this.props;
		const { amount } = paymentReceivedInfo;
		if (
			index === 1 &&
			numericRegexWithDecimalEx.test(String(amount).toLowerCase()) &&
			parseFloat(this.getSelectedRRNAmount()) === parseFloat(amount)
		) {
			this.setState({
				isAmountError: false,
			});
		}
		paymentReceivedActions.onSetIsAdvancePayment(index);
	};

	onSearchCR = () => {
		// Will navigate to the select collection request screen.
		// If user is not selected any customer then will show error to select the customer first.
		const { selectCustomerInfo, navigation } = this.props;
		const { customerId } = selectCustomerInfo;
		if (customerId) {
			navigation.navigate(collectorNavigations.SELECT_COLL_REQUESTS_NAVIGATION, {
				customerId,
			});
		} else {
			const alertOptions = {
				message: localeString(keyConstants.COLL_REQUEST_ERROR),
				yesText: localeString(keyConstants.OKAY),
				onPressYes: this.onSearchCustomer,
				isOneButton: true,
			};
			AlertComponent(alertOptions);
			this.onDissmissKeyboard();
		}
	};

	onRemoveCrId = id => {
		// Will remove the cr id.
		const { route, selectCollRequestsInfo, selectCollRequestsActions } = this.props;
		const { transactionDetail } = route.params || {};
		const { details } = transactionDetail || {};
		const { cr_ids } = details || {};
		const { selectedCollRequests, collRequestsListing } = selectCollRequestsInfo;
		let { totalAmount } = selectCollRequestsInfo;
		if (collRequestsListing.length !== 0) {
			const index = collRequestsListing.findIndex(element => element.id === id);
			selectCollRequestsActions.onRemoveCollRequest({
				id,
				amount: collRequestsListing[index].invoice_total,
			});
		} else {
			const itemIndex = selectedCollRequests.findIndex(element => element.id === id);
			if (itemIndex !== -1) {
				// If CR is selected then it will remove it.
				selectedCollRequests.splice(itemIndex, 1);
				if (cr_ids && cr_ids.length !== 0) {
					totalAmount -= parseFloat(cr_ids[itemIndex].invoice_total);
				}
			}
			selectCollRequestsActions.onSelectCollRequests({
				selectedCollRequests,
				totalAmount,
			});
		}
	};

	onCheckCRError = () => {
		// Will check the sum of all the selected CR's amount and amount entered.
		const { paymentReceivedInfo, selectCollRequestsInfo } = this.props;
		const { amount } = paymentReceivedInfo;
		const { selectedCollRequests, totalAmount } = selectCollRequestsInfo;
		return selectedCollRequests.length !== 0
			? getValueInDecimal(parseFloat(amount)) === getValueInDecimal(parseFloat(totalAmount))
			: true;
	};

	isButtonDisable = () => {
		// Will Disable the button according to condition.
		const {
			paymentReceivedInfo,
			selectCustomerInfo,
			selectCollRequestsInfo,
			selectRRNInfo,
			imageInputComponentInfo,
		} = this.props;
		const { amount, paymentModeIndex, isAdvancePayment } = paymentReceivedInfo;
		const { customerName } = selectCustomerInfo;
		const { selectedCollRequests } = selectCollRequestsInfo;
		const { rrn } = selectRRNInfo;
		const { terminalId } = paymentReceivedInfo;
		const { image } = imageInputComponentInfo;
		return (
			numericRegexWithDecimalEx.test(String(amount).toLowerCase()) &&
			parseFloat(amount) > 0 &&
			customerName &&
			(isAdvancePayment === 0 ? selectedCollRequests.length !== 0 : true) &&
			(paymentModeIndex === 1 ? terminalId && rrn && image : true)
		);
	};

	onGoToShipments = () => {
		// Will navigate to the shipment screen.
		const { navigation } = this.props;
		this.handleConfimationModal(false);
		navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
	};

	viewMyCollection = () => {
		// Will navigate to the collection screen and reset the reducer.
		const { myCollectionActions, navigation } = this.props;
		this.handleConfimationModal(false);
		myCollectionActions.onSetTabIndex(2);
		navigation.navigate(collectorNavigations.COLLECTION_NAVIGATION, {
			isDriverRole: true,
			backActionShipment: true,
		});
		this.onResetReducer();
	};

	handleConfimationModal = value => {
		// Will show hide the confirmation modal.
		this.setState({
			showConfirmationModal: value,
		});
	};

	render() {
		const {
			languageInfo,
			paymentReceivedInfo,
			route,
			selectCustomerInfo,
			selectCollRequestsInfo,
			selectRRNInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			isAmountError,
			amountErrorMessage,
			isReferenceNumberError,
			showConfirmationModal,
		} = this.state;
		const {
			paymentModeIndex,
			amount,
			terminalId,
			isAdvancePayment,
			loader,
		} = paymentReceivedInfo;
		const { isNewMadaPayment, transactionDetail, isDriverRole } = route.params || {};
		const { customerName } = selectCustomerInfo;
		const { selectedCollRequests } = selectCollRequestsInfo;
		const { rrn } = selectRRNInfo;
		const isButtonDisable = this.isButtonDisable();
		return (
			<View style={styles.container}>
				{showConfirmationModal ? (
					<ConfimationModal
						buttonTitle={localeString(keyConstants.VIEW_MY_COLLECTION)}
						secondaryButtonTitle={localeString(keyConstants.BACK_TO_SHIPMENTS)}
						hasButton
						title={localeString(keyConstants.PAYMENT_HAS_RECEIVED)}
						onPressButton={this.onGoToShipments}
						description={localeString(keyConstants.PAYMENT_DESCRIPTION)}
						innerDescription={` ${currencyFormatter(
							getValueInDecimal(amount),
						)} ${localeString(keyConstants.SAR)} `}
						descriptionTwo={`${localeString(
							keyConstants.PAYMENT_DESCRIPTION_TWO,
						)} ${customerName}`}
						hasSecondaryButton
						onPress={this.viewMyCollection}
					/>
				) : null}
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						hasIconBack
						onPressBack={this.onPressBack}
						text={localeString(keyConstants.CREATE_PAYMENT)}
					/>
				</View>
				<KeyboardAwareScrollView
					contentContainerStyle={styles.innerContainer}
					keyboardShouldPersistTaps="handled"
					showsVerticalScrollIndicator={false}
					innerRef={scroll => {
						this.scrollRef = scroll;
					}}>
					{!isNewMadaPayment ? (
						<ParallelFormatCardComponent
							isRTL={isRTL}
							detailsArray={this.getMadaDetails()}
						/>
					) : (
						<>
							<Text style={styles.paymentMode}>
								{localeString(keyConstants.PAYMENT_MODE)}
							</Text>
							<FlatList
								data={this.getPaymentOptions()}
								renderItem={({ item, index }) => {
									return (
										<PaymentModeCard
											isRTL={isRTL}
											PaymentModeIcon={item.icon}
											PaymentMode={item.title}
											onSelectOption={() => this.onSelectOption(index)}
											selectedIndex={paymentModeIndex}
											index={index}
											isDisable={transactionDetail}
										/>
									);
								}}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
							/>
							{paymentModeIndex === 1 ? (
								<Input
									value={terminalId}
									width={normalScale(288)}
									label={`${localeString(keyConstants.TERMINAL_ID)}*`}
									placeholder={localeString(keyConstants.TERMINAL_ID)}
									isRTL={isRTL}
									editable={false}
									textInputStyle={styles.textStyle}
								/>
							) : null}
						</>
					)}
					<Input
						width={normalScale(288)}
						value={customerName}
						label={`${localeString(keyConstants.CUSTOMER_NAME)}*`}
						placeholder={localeString(keyConstants.SEARCH)}
						isRTL={isRTL}
						hasSearchIcon={!isDriverRole}
						onPressSearch={this.onSearchCustomer}
						onFocus={this.onSearchCustomer}
						textInputStyle={styles.textInput}
						editable={!isDriverRole}
					/>
					{paymentModeIndex === 1 && isNewMadaPayment ? (
						<Input
							width={normalScale(288)}
							value={rrn}
							label={`${localeString(keyConstants.RRN_NUMBER)}*`}
							placeholder={localeString(keyConstants.TYPE_OR_SEARCH)}
							blurOnSubmit
							returnKeyType="done"
							isRTL={isRTL}
							onChangeText={this.onChangeReferenceNumber}
							autoCapitalize="none"
							keyboardType="numeric"
							isError={isReferenceNumberError}
							errorMessage={localeString(keyConstants.REFERENCE_NUMBER_EXIST)}
							hasSearchIcon
							onPressSearch={this.onSearchRRN}
							textInputStyle={styles.textInput}
						/>
					) : null}
					{paymentModeIndex === 1 ? (
						<Input
							value={amount}
							width={normalScale(288)}
							label={`${localeString(keyConstants.AMOUNT)}*`}
							placeholder={localeString(keyConstants.AMOUNT)}
							blurOnSubmit
							returnKeyType="done"
							keyboardType="decimal-pad"
							isRTL={isRTL}
							onChangeText={text =>
								(spaceRegexEx.test(String(text).toLowerCase()) || text === '') &&
								this.onChangeText(text, 'amount')
							}
							autoCapitalize="none"
							isError={isAmountError}
							errorMessage={amountErrorMessage}
							onBlur={this.onBlur}
							textInputStyle={styles.textInput}
						/>
					) : null}
					<Text style={styles.isAdvance}>
						{`${localeString(keyConstants.IS_ADVANCE_PAYMENT)} ${localeString(
							keyConstants.QUESTION_MARK,
						)}`}
					</Text>
					<View>
						<FlatList
							data={this.getIsAdvancePaymentOptions()}
							horizontal
							renderItem={({ item, index }) => {
								return (
									<TouchableOpacity
										style={[
											styles.optionContainer,
											index === 1 && styles.margin,
										]}
										activeOpacity={0.8}
										onPress={() => this.onSelectIsAdvancePayment(index)}>
										<ImageLoadComponent
											source={
												isAdvancePayment === index
													? IMAGES.iconCheckDot
													: IMAGES.iconUnCheckCircle
											}
											style={
												isAdvancePayment === index
													? styles.checkedIcon
													: styles.icon
											}
										/>
										<Text style={styles.title}>{item}</Text>
									</TouchableOpacity>
								);
							}}
							keyExtractor={this.keyExtractor}
							showsHorizontalScrollIndicator={false}
							style={styles.isAdvanceContainer}
						/>
					</View>
					{isAdvancePayment === 0 ? (
						<>
							<Input
								width={normalScale(288)}
								label={`${localeString(keyConstants.COLLECTION_REQUEST)}*`}
								placeholder={localeString(keyConstants.SEARCH)}
								isRTL={isRTL}
								hasSearchIcon={!isDriverRole}
								onPressSearch={this.onSearchCR}
								onFocus={this.onSearchCR}
								value=""
								textInputStyle={styles.textInput}
								editable={!isDriverRole}
							/>
							<FlatList
								data={selectedCollRequests}
								numColumns={10}
								columnWrapperStyle={styles.wrapStyle}
								scrollEnabled={false}
								renderItem={({ item }) => {
									return (
										<View style={styles.crContainer}>
											<Text style={styles.crId}>{item.invoiceNo}</Text>
											{!isDriverRole ? (
												<TouchableOpacity
													activeOpacity={0.8}
													style={styles.iconCrossStyle}
													onPress={() => this.onRemoveCrId(item.id)}>
													<ImageLoadComponent
														source={IMAGES.iconCross}
														style={styles.iconCross}
													/>
												</TouchableOpacity>
											) : null}
										</View>
									);
								}}
								keyExtractor={this.keyExtractor}
								showsHorizontalScrollIndicator={false}
							/>
						</>
					) : null}
					{paymentModeIndex === 1 ? (
						<ImageInputComponent
							label={`${localeString(keyConstants.INVOICE_IMAGE)}*`}
							placeholder={localeString(keyConstants.UPLOAD_INVOICE_IMAGE)}
							isRTL={isRTL}
							selectedImageTitle={invoiceImg}
						/>
					) : null}
					{paymentModeIndex === 0 ? (
						<Input
							value={amount}
							width={normalScale(288)}
							label={`${localeString(keyConstants.AMOUNT)}*`}
							placeholder={localeString(keyConstants.AMOUNT)}
							returnKeyType="done"
							keyboardType="decimal-pad"
							blurOnSubmit
							isRTL={isRTL}
							onChangeText={text =>
								(spaceRegexEx.test(String(text).toLowerCase()) || text === '') &&
								this.onChangeText(text, 'amount')
							}
							autoCapitalize="none"
							onBlur={this.onBlur}
							isError={isAmountError}
							errorMessage={amountErrorMessage}
							textInputStyle={!isAdvancePayment && styles.textStyle}
							editable={!!isAdvancePayment}
						/>
					) : null}
				</KeyboardAwareScrollView>
				<View style={styles.buttonView}>
					<ButtonComponent
						text={localeString(keyConstants.SUBMIT)}
						onPress={this.createPayment}
						isButtonDisable={!isButtonDisable}
					/>
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		paymentReceivedInfo: state.PaymentReceivedAmountScreenReducer,
		selectCustomerInfo: state.SelectCustomerScreenReducer,
		selectCollRequestsInfo: state.SelectCollRequestsScreenReducer,
		selectRRNInfo: state.SelectRRNScreenReducer,
		imageInputComponentInfo: state.ImageInputComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		paymentReceivedActions: bindActionCreators({ ...PaymentReceivedActions }, dispatch),
		selectCustomerActions: bindActionCreators({ ...SelectCustomerActions }, dispatch),
		selectCollRequestsActions: bindActionCreators({ ...SelectCollRequestsActions }, dispatch),
		selectRRNActions: bindActionCreators({ ...SelectRRNActions }, dispatch),
		imageInputActions: bindActionCreators({ ...ImageInputActions }, dispatch),
		myCollectionActions: bindActionCreators({ ...MyCollectionActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

PaymentReceivedAmountScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	paymentReceivedInfo: PropTypes.object.isRequired,
	selectCustomerInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	selectCollRequestsInfo: PropTypes.object.isRequired,
	selectRRNInfo: PropTypes.object.isRequired,
	imageInputComponentInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	paymentReceivedActions: PropTypes.object.isRequired,
	selectCustomerActions: PropTypes.object.isRequired,
	selectCollRequestsActions: PropTypes.object.isRequired,
	selectRRNActions: PropTypes.object.isRequired,
	imageInputActions: PropTypes.object.isRequired,
	myCollectionActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentReceivedAmountScreen);
