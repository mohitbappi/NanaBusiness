export const ON_SELECT_RRN = 'on_select_rrn';

export const GET_RRN_LISTING_SUCCESS = 'get_rrn_listing_success';
export const GET_RRN_LISTING_FAILURE = 'get_rrn_listing_failure';
export const GET_RRN_LISTING_LOADER = 'get_rrn_listing_loader';

export const RESET_RRN_STATE = 'reset_rrn_state';
