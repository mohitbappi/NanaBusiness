import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetRRNListingService from '@MadaPayments/GetRRNListingService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to set the rrnId and RRN number.
 * @param {integer} rrnId
 * @param {string} rrn
 * @returns
 */

export const onSelectRRN = (rrnId, rrn) => {
	return {
		type: ActionTypes.ON_SELECT_RRN,
		payload: { rrnId, rrn },
	};
};

/**
 * Action to get the RRN listing.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */

export const onGetRRNListing = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_RRN_LISTING_SUCCESS,
		ActionTypes.GET_RRN_LISTING_FAILURE,
		ActionTypes.GET_RRN_LISTING_LOADER,
	)
		.addSuccessExtra({ isAppendInExistingList })
		.build();
	const getRRNListingService = new GetRRNListingService(dispatchedActions);
	addBasicInterceptors(getRRNListingService);
	getRRNListingService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getRRNListingService.makeRequest(props));
};

// Action to reset the state.
export const onResetRRNState = () => ({ type: ActionTypes.RESET_RRN_STATE });
