import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		dateStyle: {
			color: colors.red,
		},
		invoiceContainer: {
			marginHorizontal: normalScale(16),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		searchContainer: {
			marginBottom: verticalScale(12),
			marginHorizontal: normalScale(16),
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		scrollView: {
			paddingBottom: verticalScale(65),
		},
		nextButton: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
