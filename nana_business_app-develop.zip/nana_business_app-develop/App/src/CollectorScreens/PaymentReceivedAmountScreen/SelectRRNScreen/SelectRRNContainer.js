// import libraries
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as SelectRRNActions from './SelectRRNScreenAction';

// import components
import SelectRRNComponent from './SelectRRNComponent';

const SelectRRNContainer = props => {
	const customProps = { ...props }; // Will store all the props including actions & reducers.
	return <SelectRRNComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		selectRRNInfo: state.SelectRRNScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		selectRRNActions: bindActionCreators({ ...SelectRRNActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(SelectRRNContainer);
