import * as ActionTypes from './ActionType';

const initialState = {
	rrn: '',
	rrnId: null,
	rrnListing: [],
	count: 0,
	terminalId: '',
};

const SelectRRNScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_SELECT_RRN: {
			const { rrnId } = action.payload;
			let { rrn } = action.payload;
			if (rrnId && state.rrnListing && state.rrnListing.length !== 0) {
				const index = state.rrnListing.findIndex(element => element.id === rrnId);
				rrn = state.rrnListing[index].rrn;
			}
			return {
				...state,
				rrnId,
				rrn,
			};
		}
		case ActionTypes.GET_RRN_LISTING_SUCCESS: {
			const { isAppendInExistingList } = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				rrnListing: isAppendInExistingList
					? [...state.rrnListing, ...action.payload.txn_requests]
					: [...action.payload.selected_txn, ...action.payload.txn_requests],
				count: action.payload.count,
				terminalId: action.payload.terminal_id,
			};
		}
		case ActionTypes.GET_RRN_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_RRN_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_RRN_STATE:
			return initialState;
		default:
			return { ...state };
	}
};

export default SelectRRNScreenReducer;
