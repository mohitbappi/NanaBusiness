// import libraries
import React, { Component } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import Search from '@Search/Search';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';

// import utils
import { getFormattedDate } from '@Util/GetFormattedDate';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { currencyFormatter } from '@Util/CurrencyFormatter';

// import constants
import { fetchDataWithPagination } from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';

// import styles
import { createStyleSheet } from './SelectRRNScreenStyle';

class SelectRRNUI extends Component {
	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		// Will show loader while pagination.
		const { isRTL, count, rrnListing } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached = count === rrnListing.length || count < rrnListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return <Text style={styles.noText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>;
	};

	renderItem = ({ item }) => {
		const { isRTL, selectedRRN, onChooseRRN } = this.props;
		const styles = createStyleSheet(isRTL);
		const { rrn, id, amount, created_at } = item;
		return (
			<View style={styles.invoiceContainer}>
				<InvoiceCardComponent
					name={rrn}
					dateLabel={`${localeString(keyConstants.TXN_DATE)}: `}
					date={getFormattedDate(created_at)}
					amount={`${currencyFormatter(getValueInDecimal(amount))} ${localeString(
						keyConstants.SAR,
					)}`}
					isDisable
					dateStyle={styles.dateStyle}
					showCheckBox // Boolean to show radio button to select value.
					selectedItem={[selectedRRN]}
					id={id}
					onSelect={() => onChooseRRN(id)}
				/>
			</View>
		);
	};

	render() {
		const {
			isRTL,
			loader,
			rrnListing,
			count,
			error,
			errorCode,
			searchText,
			onRefresh,
			onSearch,
			onGoBack,
			onEndReached,
			onSelectRRN,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<View style={styles.headerContainer}>
					<Header
						onPressBack={onGoBack}
						hasIconBack
						text={localeString(keyConstants.RRN_NUMBER)}
					/>
				</View>
				{error ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.searchContainer}>
							<Search
								hasSearchIcon
								placeholder={localeString(keyConstants.SEARCH_BY_RRN_NUMBER)}
								onChangeText={text => onSearch(text)}
								value={searchText}
							/>
						</View>
						{rrnListing.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_RRN_FOUND)} />
						) : (
							<FlatListComponent
								data={rrnListing}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								keyboardShouldPersistTaps
								onEndReached={() => rrnListing.length !== count && onEndReached()}
								ListFooterComponent={
									rrnListing.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								onRefresh={onRefresh}
								componentType={constants.flatList}
								contentContainerStyle={styles.scrollView}
							/>
						)}
						<View style={styles.nextButton}>
							<ButtonComponent
								text={localeString(keyConstants.NEXT)}
								onPress={onSelectRRN}
							/>
						</View>
					</>
				)}
			</View>
		);
	}
}

SelectRRNUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	rrnListing: PropTypes.object.isRequired,
	loader: PropTypes.bool.isRequired,
	onChooseRRN: PropTypes.func.isRequired,
	onSearch: PropTypes.func.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	count: PropTypes.any.isRequired,
	selectedRRN: PropTypes.array.isRequired,
	searchText: PropTypes.string.isRequired,
	onSelectRRN: PropTypes.func.isRequired,
};

export default SelectRRNUI;
