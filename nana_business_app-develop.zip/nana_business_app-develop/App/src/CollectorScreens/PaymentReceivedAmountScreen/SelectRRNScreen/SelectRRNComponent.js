// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { fetchDataWithPagination } from '@Constants/Constants';

// import components
import SelectRRNUI from './SelectRRNUI';

class SelectRRNComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			searchText: '',
			bottomLoader: false,
			selectedRRN: null,
		};
	}

	componentDidMount() {
		const { navigation, selectRRNInfo, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.page = fetchDataWithPagination.page;
			const { rrnId } = selectRRNInfo;
			this.setState(
				{
					searchText: '',
					selectedRRN: rrnId,
				},
				() => this.onFetchData(false),
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { selectRRNInfo, pullToRefreshActions } = this.props;
		const { success } = selectRRNInfo;
		if (success && prevProps.selectRRNInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onSearch = text => {
		// Will search RRN using RRN number.
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onFetchData(false);
			},
		);
	};

	onFetchData = isAppendInExistingList => {
		// API call to get the RRN listing.
		const { selectRRNInfo, selectRRNActions } = this.props;
		const { searchText } = this.state;
		const { rrnId } = selectRRNInfo;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			queryParams.rrn = searchText; // If search is done by RRN number.
		}
		if (rrnId) {
			// Will add selected RRN in request payload.
			queryParams.selected_ids = rrnId;
		}
		selectRRNActions.onGetRRNListing(queryParams, isAppendInExistingList);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onEndReached = () => {
		const { selectRRNInfo } = this.props;
		const { loader } = selectRRNInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onChooseRRN = id => {
		// Will set selected RRN.
		this.setState({
			selectedRRN: id,
		});
	};

	onSelectRRN = () => {
		// Will set selected RRN in reducer.
		const { navigation, selectRRNActions } = this.props;
		const { selectedRRN } = this.state;
		selectRRNActions.onSelectRRN(selectedRRN, '');
		navigation.goBack();
	};

	onRefresh = () => {
		// Will call api while pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	render() {
		const { languageInfo, selectRRNInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const { rrnListing, count, loader, error, errorCode } = selectRRNInfo;
		const { bottomLoader, searchText, selectedRRN } = this.state;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<SelectRRNUI
				isRTL={isRTL}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				rrnListing={rrnListing}
				count={count}
				selectedRRN={selectedRRN}
				error={error}
				errorCode={errorCode}
				searchText={searchText}
				onRefresh={this.onRefresh}
				onSearch={this.onSearch}
				onGoBack={this.onGoBack}
				onEndReached={this.onEndReached}
				onChooseRRN={this.onChooseRRN}
				onSelectRRN={this.onSelectRRN}
			/>
		);
	}
}

SelectRRNComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	selectRRNInfo: PropTypes.object.isRequired,
	selectRRNActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
};

export default SelectRRNComponent;
