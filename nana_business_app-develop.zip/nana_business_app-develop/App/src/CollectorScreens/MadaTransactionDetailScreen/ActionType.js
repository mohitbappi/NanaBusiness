export const GET_MADA_TRANSACTION_DETAIL_SUCCESS = 'get_mada_transaction_detail_success';
export const GET_MADA_TRANSACTION_DETAIL_FAILURE = 'get_mada_transaction_detail_failure';
export const GET_MADA_TRANSACTION_DETAIL_LOADER = 'get_mada_transaction_detail_loader';
