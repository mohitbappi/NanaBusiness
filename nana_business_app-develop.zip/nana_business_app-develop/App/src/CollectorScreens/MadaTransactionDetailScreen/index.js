export { default } from './MadaTransactionDetailContainer';
