import GetMadaTransactionDetailService from '@MadaPayments/GetMadaTransactionDetailService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import { actions } from '@libapi/APIActionsBuilder';
import * as ActionTypes from './ActionType';

/**
 * Action to get the mada transaction details.
 * @param {integer} id
 * @returns
 */

export const onGetTransactionDetail = id => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_MADA_TRANSACTION_DETAIL_SUCCESS,
		ActionTypes.GET_MADA_TRANSACTION_DETAIL_FAILURE,
		ActionTypes.GET_MADA_TRANSACTION_DETAIL_LOADER,
	);
	const getMadaTransactionDetailService = new GetMadaTransactionDetailService(dispatchedActions);
	addBasicInterceptors(getMadaTransactionDetailService);
	getMadaTransactionDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getMadaTransactionDetailService.makeRequest(id));
};

export default onGetTransactionDetail;
