// import libraries
import React, { Component } from 'react';
import { ImageBackground, Text, TouchableOpacity, View } from 'react-native';
import ImageView from 'react-native-image-view';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import {
	DetailCardComponent,
	ParallelFormatCardComponent,
} from '@DetailCardComponent/DetailCardComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

// import constants
import { keyConstants } from '@Constants/KeyConstants';

// import utils
import { localeString } from '@assets/Localization';
import IMAGES from '@Images/index';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDateWithoutHyphen } from '@Util/GetFormattedDate';
import { dash, invoiceImg, purchaseReturnInvoiceStatus } from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import styles
import { createStyleSheet } from './MadaTransactionDetailScreenStyle';

class MadaTransactionDetailUI extends Component {
	getHeader = () => {
		// Will return the header component.
		const { isRTL, onGoBack } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.header}>
				<Header
					onPressBack={onGoBack}
					hasIconBack
					text={localeString(keyConstants.TRANSACTION_DETAIL)}
				/>
			</View>
		);
	};

	getTransactionDetails = () => {
		// Will return the mada transaction details.
		const { transactionDetail } = this.props;
		const { terminal_id, rrn, created_at, status, details, mada_transaction, amount } =
			transactionDetail || {};
		const { txn_date, payment_status } = mada_transaction || {};
		return [
			{
				label: localeString(keyConstants.AMOUNT),
				labelValue: `${currencyFormatter(getValueInDecimal(amount))} ${localeString(
					keyConstants.SAR,
				)}`,
			},
			{
				label: localeString(keyConstants.TERMINAL_ID),
				labelValue: this.onValidateValue(terminal_id),
			},
			{
				label: localeString(keyConstants.RRN_NUMBER),
				labelValue: this.onValidateValue(rrn),
			},
			{
				label: localeString(keyConstants.TRANSACTION_DATE),
				labelValue: txn_date ? getFormattedDateWithoutHyphen(txn_date) : dash,
			},
			{
				label: localeString(keyConstants.TRANSACTION_STATUS),
				labelValue: payment_status ? localeString(keyConstants[payment_status]) : dash,
			},
			{
				label: localeString(keyConstants.SUBMISSION_DATE),
				labelValue: created_at ? getFormattedDateWithoutHyphen(created_at) : dash,
			},
			{
				label: localeString(keyConstants.SUBMISSION_STATUS),
				labelValue: this.getStatus(status),
			},
			{
				label: localeString(keyConstants.COLL_REQUESTS),
				labelValue:
					details && details.cr_ids ? this.getCommaSeparatedCrs(details.cr_ids) : dash,
			},
		];
	};

	onValidateValue = value => {
		// Will check value exists or not.
		if (value) {
			return value;
		}
		return dash;
	};

	getStatus = status => {
		// Will return status if exists otherwise dash(---).
		const statusData = {
			[`${purchaseReturnInvoiceStatus.pending}`]: localeString(keyConstants.PENDING),
			[`${purchaseReturnInvoiceStatus.approved}`]: localeString(keyConstants.APPROVED),
			[`${purchaseReturnInvoiceStatus.rejected}`]: localeString(keyConstants.REJECTED),
		};
		if (status) {
			return statusData[status];
		}
		return dash;
	};

	getCommaSeparatedCrs = crListing => {
		// Will return the comma separated colleciton requests.
		if (crListing.length !== 0) {
			let crString = '';
			crListing.map((element, index) => {
				if (index === crListing.length - 1) {
					crString += element.invoice_no;
				} else {
					crString += `${element.invoice_no}, `;
				}
			});
			return crString;
		}
		return dash;
	};

	getReconciliationDetails = () => {
		// Will return the mada reconciliation details
		const { transactionDetail } = this.props;
		const { mada_transaction } = transactionDetail || {};
		const { reconcilation_end_date, reconciliation_start_date, reconciliation_number } =
			mada_transaction || {};
		return [
			{
				label: localeString(keyConstants.RECONCILIATION_DETAILS),
				labelValue: reconciliation_number || dash,
			},
			{
				label: localeString(keyConstants.START_DATE),
				labelValue: reconciliation_start_date
					? getFormattedDateWithoutHyphen(reconciliation_start_date)
					: dash,
			},
			{
				label: localeString(keyConstants.END_DATE),
				labelValue: reconcilation_end_date
					? getFormattedDateWithoutHyphen(reconcilation_end_date)
					: dash,
			},
		];
	};

	render() {
		const { isRTL, loader } = this.props;
		const styles = createStyleSheet(isRTL);
		const {
			transactionDetail,
			onReSubmit,
			isImageVisible,
			showInvoiceImage,
			onRefresh,
			error,
			errorCode,
		} = this.props;
		const { customer_organization, image, reject_reason, status } = transactionDetail || {};
		return (
			<View style={styles.container}>
				<ImageView
					images={[
						{
							source: { uri: image },
						},
					]}
					animationType="fade"
					isTapZoomEnabled
					isPinchZoomEnabled
					onClose={() => showInvoiceImage(false)}
					isVisible={isImageVisible}
				/>
				{loader && <Loader size="large" />}
				{this.getHeader(isRTL)}
				{error ? (
					// Error component to show the error if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<ScrollViewComponent
							showsVerticalScrollIndicator={false}
							onRefresh={onRefresh}
							style={[
								styles.scrollView,
								status === purchaseReturnInvoiceStatus.rejected &&
									styles.bottomMargin,
							]}
							componentType={constants.scrollView}>
							{customer_organization ? (
								<ImageBackground
									source={IMAGES.iconGradientBackground}
									style={styles.imageViewEdit}>
									<Text style={styles.customerName}>
										{isRTL
											? customer_organization.name_ar
											: customer_organization.name}
									</Text>
								</ImageBackground>
							) : null}
							<ParallelFormatCardComponent
								isRTL={isRTL}
								detailsArray={this.getTransactionDetails()}
							/>
							<ParallelFormatCardComponent
								isRTL={isRTL}
								detailsArray={this.getReconciliationDetails()}
								containerStyle={styles.containerStyle}
							/>
							<View style={styles.invoiceContainer}>
								<Text style={styles.invoiceImage}>
									{localeString(keyConstants.INVOICE_IMAGE)}
								</Text>
								<TouchableOpacity
									onPress={() => showInvoiceImage(true)}
									activeOpacity={0.8}>
									<Text style={styles.invoiceLink}>
										{image ? invoiceImg : dash}
									</Text>
								</TouchableOpacity>
							</View>
							{reject_reason ? (
								<DetailCardComponent
									isRTL={isRTL}
									title={localeString(keyConstants.REASON_FOR_REJECTION)}
									titleValue={reject_reason}
									titleStyle={styles.titleStyle}
									containerStyle={styles.containerStyle}
								/>
							) : null}
						</ScrollViewComponent>

						{status === purchaseReturnInvoiceStatus.rejected ? (
							<ButtonComponent
								viewStyle={styles.buttonStyle}
								onPress={onReSubmit}
								text={localeString(keyConstants.RE_SUBMIT)}
							/>
						) : null}
					</>
				)}
			</View>
		);
	}
}

MadaTransactionDetailUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	transactionDetail: PropTypes.object.isRequired,
	loader: PropTypes.bool.isRequired,
	onReSubmit: PropTypes.func.isRequired,
	isImageVisible: PropTypes.bool.isRequired,
	showInvoiceImage: PropTypes.bool.isRequired,
	onRefresh: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
};

export default MadaTransactionDetailUI;
