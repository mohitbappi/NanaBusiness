// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import navigations
import collectorNavigations from '@routes/collectorNavigations';

// import components
import MadaTransactionDetailUI from './MadaTransactionDetailUI';

class MadaTransactionDetailComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.state = {
			isImageVisible: false,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onGetDetail();
		});
		pullToRefreshActions.onHandlePullToRefresh(false); // Will hide the pull to refresh loader
	}

	componentDidUpdate(prevProps) {
		const { madaTransactionDetailInfo, pullToRefreshActions } = this.props;
		const { success } = madaTransactionDetailInfo;
		if (success && prevProps.madaTransactionDetailInfo.success !== success) {
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onGetDetail = () => {
		// API call to get the mada transaction detail.
		const { route, onGetTransactionDetail, pullToRefreshActions } = this.props;
		const { id, index } = route.params || {};
		pullToRefreshActions.onSetSelectIndex(index);
		const queryParams = {
			id,
		};
		onGetTransactionDetail(queryParams);
	};

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onReSubmit = () => {
		/** Will navigate the user to resubmit the mada transaction request.
		 * Containing navigation Params :-
		 *	1. isNewMadaPayment - Boolean to check it is new mada payment or not.
		 *	2. id - transaction id.
		 *	3. transactionDetail - Contains mada transaction details.
		 *	4. isResubmit - Boolean to check it resubmit or not.
		 */
		const { route, madaTransactionDetailInfo, navigation } = this.props;
		const { id } = route.params || {};
		const { transactionDetail } = madaTransactionDetailInfo;
		const { terminal_id, rrn, amount } = transactionDetail || {};
		navigation.navigate(collectorNavigations.PAYMENT_RECEIVED_NAVIGATION, {
			isNewMadaPayment: true,
			extraParams: { terminal_id, rrn, amount },
			isResubmit: true,
			id,
			transactionDetail,
		});
	};

	showInvoiceImage = value => {
		// Will show/hide the image viewer.
		this.setState({
			isImageVisible: value,
		});
	};

	render() {
		const { languageInfo, refreshControlComponentInfo, madaTransactionDetailInfo } = this.props;
		const { isRTL } = languageInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { loader, transactionDetail, error, errorCode } = madaTransactionDetailInfo;
		const { isImageVisible } = this.state;
		return (
			<MadaTransactionDetailUI
				isRTL={isRTL}
				loader={loader && !isFetchingForPullToRefresh}
				onGoBack={this.onGoBack}
				transactionDetail={transactionDetail}
				onReSubmit={this.onReSubmit}
				isImageVisible={isImageVisible} // Boolean to show the image viewer
				showInvoiceImage={this.showInvoiceImage}
				onRefresh={this.onGetDetail}
				error={error}
				errorCode={errorCode}
			/>
		);
	}
}

MadaTransactionDetailComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	onGetTransactionDetail: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	madaTransactionDetailInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
};

export default MadaTransactionDetailComponent;
