import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
			paddingHorizontal: normalScale(16),
		},
		header: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			justifyContent: 'space-between',
		},
		scrollView: {
			marginBottom: verticalScale(10),
		},
		bottomMargin: {
			marginBottom: verticalScale(65),
		},
		imageViewEdit: {
			marginTop: verticalScale(16),
			paddingVertical: verticalScale(13),
			marginBottom: verticalScale(4),
		},
		customerName: {
			fontSize: normalize(18),
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			textAlign: 'center',
		},
		containerStyle: {
			backgroundColor: colors.lightGreen,
			marginTop: verticalScale(4),
		},
		invoiceContainer: {
			borderRadius: normalScale(8),
			backgroundColor: colors.lightSkyBlue,
			paddingHorizontal: normalScale(16),
			paddingVertical: verticalScale(18),
			marginTop: verticalScale(4),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			justifyContent: 'space-between',
		},
		invoiceImage: {
			fontSize: normalize(10),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		invoiceLink: {
			fontSize: normalize(12),
			color: colors.blue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
		},
		titleStyle: {
			fontSize: normalize(10),
		},
		buttonStyle: {
			position: 'absolute',
			left: normalScale(16),
			right: normalScale(16),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(16),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
