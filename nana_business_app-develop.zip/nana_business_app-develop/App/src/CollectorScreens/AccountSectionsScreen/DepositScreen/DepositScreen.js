// import libraries
import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import Input from '@Input/Input';
import ImageInputComponent from '@ImageInputComponent/ImageInputComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';

// import constants
import { localeString } from '@Localization/index';
import { normalScale } from '@device/normalize';
import { keyConstants } from '@Constants/KeyConstants';
import {
	invoiceImg,
	isEnableReferenceNumberFeature,
	noSpecialCharacterRegexEx,
	noSpecialCharacterRegexExArabic,
} from '@Constants/Constants';

// import utils
import { checkStringWith } from '@Util/CheckStringWith';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getImageUrl } from '@Util/GetImageUrl';
import { currencyFormatter } from '@Util/CurrencyFormatter';

// import actions
import * as DepositScreenAction from './DepositScreenAction';

// import styles
import { createStyleSheet } from './DepositScreenStyle';

class DepositScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isReferenceNumberError: false,
		};
	}

	componentDidUpdate(prevProps) {
		const { depositInfo } = this.props;
		const { success, error, errorCode } = depositInfo;
		if (success && prevProps.depositInfo.success !== success) {
			this.onPressBack();
		}
		if (error && prevProps.depositInfo.error !== error) {
			if (errorCode.error === keyConstants.REFERENCE_NUMBER_EXIST) {
				this.setState({
					// if error code is of reference number exist then set reference number error as true
					isReferenceNumberError: true,
				});
			} else {
				ErrorAlertComponent(errorCode, this.payNow);
			}
		}
	}

	componentWillUnmount() {
		const { depositScreenAction } = this.props;
		depositScreenAction.onResetDepositState(); // reset deposit redux state
	}

	// go back to previous screen
	onPressBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	payNow = () => {
		const { imageInputComponentInfo, route, depositInfo, depositScreenAction } = this.props;
		const { image: txnSlip } = imageInputComponentInfo;
		const { walletTransactions } = route.params;
		const { referenceNumber } = depositInfo;
		const queryParams = {};
		queryParams.transactions_ids = walletTransactions;
		queryParams.image_url = getImageUrl(txnSlip);
		if (isEnableReferenceNumberFeature) {
			queryParams.reference_number = referenceNumber;
		}
		depositScreenAction.submitTxnSlip(queryParams);
	};

	// sets 'referenceNumber' value to 'text' in redux state using onChangeText action (if reference number is valid)
	onChangeText = text => {
		const { languageInfo, depositScreenAction } = this.props;
		const { isRTL } = languageInfo;
		if (
			checkStringWith(
				text,
				noSpecialCharacterRegexEx,
				noSpecialCharacterRegexExArabic,
				isRTL,
			) ||
			text === ''
		) {
			depositScreenAction.onChangeText(text, 'referenceNumber');
			this.setState({ isReferenceNumberError: false });
		}
	};

	isButtonDisable = () => {
		const { imageInputComponentInfo, depositInfo } = this.props;
		const { image: txnSlip } = imageInputComponentInfo;
		const { referenceNumber } = depositInfo;
		const { documentLoader, isReferenceNumberError } = this.state;
		return (
			// any one of below conditions should be true to disable button
			!txnSlip ||
			documentLoader ||
			// if reference number feature is enabled only then check for it's errors
			(isEnableReferenceNumberFeature &&
				// check for refernce number length(empty string not permitted) error & reference number exist error from API
				(!referenceNumber || isReferenceNumberError))
		);
	};

	render() {
		const { languageInfo, route, depositInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { totalAmount } = route.params;
		const { loader, referenceNumber } = depositInfo;
		const { isReferenceNumberError } = this.state;
		const isButtonDisable = this.isButtonDisable();
		return (
			<KeyboardAwareScrollView
				contentContainerStyle={styles.container}
				keyboardShouldPersistTaps="handled">
				{loader && <Spinner size="large" />}
				<Header
					hasIconBack
					onPressBack={this.onPressBack}
					text={localeString(keyConstants.DEPOSIT_AMOUNT)}
				/>
				<Text style={styles.totalDepositAmount}>
					{`${currencyFormatter(getValueInDecimal(totalAmount))} ${localeString(
						keyConstants.SAR,
					)}`}
				</Text>
				<ImageInputComponent
					isRTL={isRTL}
					label={`${localeString(keyConstants.INVOICE_IMAGE)}*`}
					placeholder={localeString(keyConstants.UPLOAD_INVOICE_IMAGE)}
					selectedImageTitle={invoiceImg}
				/>
				{isEnableReferenceNumberFeature && (
					<Input
						width={normalScale(288)}
						value={referenceNumber}
						label={`${localeString(keyConstants.REFERENCE_NUMBER)}*`}
						placeholder={localeString(keyConstants.REFERENCE_NUMBER)}
						blurOnSubmit
						returnKeyType="done"
						isRTL={isRTL}
						onChangeText={this.onChangeText}
						autoCapitalize="none"
						isError={isReferenceNumberError}
						errorMessage={localeString(keyConstants.REFERENCE_NUMBER_EXIST)}
					/>
				)}
				<View style={styles.buttonViewDeposit}>
					<ButtonComponent
						text={`${localeString(keyConstants.DEPOSIT)} (${currencyFormatter(
							getValueInDecimal(totalAmount),
						)} ${localeString(keyConstants.SAR)})`}
						onPress={this.payNow}
						isButtonDisable={isButtonDisable}
					/>
				</View>
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		depositInfo: state.DepositScreenReducer,
		imageInputComponentInfo: state.ImageInputComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		depositScreenAction: bindActionCreators({ ...DepositScreenAction }, dispatch),
	};
};

DepositScreen.propTypes = {
	depositScreenAction: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	depositInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	imageInputComponentInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(DepositScreen);
