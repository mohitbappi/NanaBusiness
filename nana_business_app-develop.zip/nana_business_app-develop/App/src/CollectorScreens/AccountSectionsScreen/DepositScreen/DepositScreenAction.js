import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import DepositAmountService from '@Wallet/DepositAmountService';
import * as ActionTypes from './ActionType';

/**
 * Action to deposit the transactions.
 * @param {object} props
 * @returns
 */

export const submitTxnSlip = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SUBMIT_TRANSACTION_SLIP_SUCCESS,
		ActionTypes.SUBMIT_TRANSACTION_SLIP_FAILURE,
		ActionTypes.SUBMIT_TRANSACTION_SLIP_LOADER,
	);
	const depositAmountService = new DepositAmountService(dispatchedActions);
	addBasicInterceptors(depositAmountService);
	depositAmountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(depositAmountService.makeRequest(props));
};

export const onChangeText = (text, field) => {
	// This sets 'field' value as 'text' in redux state
	return {
		type: ActionTypes.ON_CHANGE_DEPOSIT_SCREEN_TEXT,
		payload: text,
		field,
	};
};

// Resets redux state to initial state
export const onResetDepositState = () => ({ type: ActionTypes.RESET_DEPOSIT_STATE });
