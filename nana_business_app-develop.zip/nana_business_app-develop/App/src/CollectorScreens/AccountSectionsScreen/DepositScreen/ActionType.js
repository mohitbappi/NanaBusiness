export const SUBMIT_TRANSACTION_SLIP_SUCCESS = 'submit_transaction_slip_success';
export const SUBMIT_TRANSACTION_SLIP_FAILURE = 'submit_transaction_slip_failure';
export const SUBMIT_TRANSACTION_SLIP_LOADER = 'submit_transaction_slip_loader';
export const RESET_DEPOSIT_STATE = 'reset_deposit_state';
export const ON_CHANGE_DEPOSIT_SCREEN_TEXT = 'on_change_deposit_screen_text';
