import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	referenceNumber: '',
};

const DepositScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.SUBMIT_TRANSACTION_SLIP_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
			};
		case ActionTypes.SUBMIT_TRANSACTION_SLIP_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
			};
		case ActionTypes.SUBMIT_TRANSACTION_SLIP_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: true,
			};
		case ActionTypes.ON_CHANGE_DEPOSIT_SCREEN_TEXT: {
			// sets 'action.field' value to 'action.payload'
			return {
				...state,
				[action.field]: action.payload,
			};
		}
		// resets redux state to initial state
		case ActionTypes.RESET_DEPOSIT_STATE:
			return initialState;
		default:
			return state;
	}
};

export default DepositScreenReducer;
