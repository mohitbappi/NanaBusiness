import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import { renderFlexDirectionBasedOnRtl } from '@lib/helpers';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(16),
		},
		totalDepositAmount: {
			fontSize: normalize(24),
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			color: colors.darkBlue,
			alignSelf: 'center',
			marginTop: verticalScale(29),
		},
		invoiceDepositText: {
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
			marginTop: verticalScale(16),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
		},
		amountDepositCameraContainer: {
			marginTop: verticalScale(8),
			height: verticalScale(44),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
			borderWidth: moderateScale(1),
			borderRadius: moderateScale(8),
			borderStyle: 'dashed',
			borderColor: colors.grey,
		},
		imgDepositText: {
			color: colors.blue,
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			marginLeft: isRTL ? null : normalScale(12),
			marginRight: isRTL ? normalScale(16) : null,
			width: normalScale(250),
		},
		cameraDepositContainer: {
			marginRight: isRTL ? null : normalScale(16),
			marginLeft: isRTL ? normalScale(16) : null,
		},
		cameraDeposit: {
			height: verticalScale(15),
			width: normalScale(18),
		},
		crossDeposit: {
			height: verticalScale(16),
			width: normalScale(16),
		},
		buttonViewDeposit: {
			position: 'absolute',
			width: '100%',
			bottom: verticalScale(16),
			marginHorizontal: normalScale(16),
		},
		hitSlop: {
			top: verticalScale(10),
			bottom: verticalScale(10),
			right: normalScale(10),
			left: normalScale(10),
		},
	});
};

export default createStyleSheet;
