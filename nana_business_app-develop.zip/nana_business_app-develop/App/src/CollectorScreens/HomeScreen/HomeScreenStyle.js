import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import fonts from '@assets/fonts';
import { renderFlexDirectionBasedOnRtl } from '@lib/helpers';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@assets/Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(16),
		},
		header: {
			height: verticalScale(40),
			backgroundColor: colors.white,
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(20),
		},
		iconPin: {
			width: normalScale(15),
			height: verticalScale(18),
		},
		iconNotification: {
			height: verticalScale(28),
			width: normalScale(28),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		notificationViewStyle: {
			position: 'absolute',
			top: -verticalScale(1),
			left: normalScale(20),
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: colors.red,
			borderRadius: normalScale(6),
			width: normalScale(12),
			height: normalScale(12),
			borderColor: colors.white,
			borderWidth: normalScale(1),
		},
		notifCount: {
			fontSize: normalize(8),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.white,
		},
		locationText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		locationView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		locationNotificationContainer: {
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
		},
		notificationContainer: {
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
	});
};

export default createStyleSheet;
