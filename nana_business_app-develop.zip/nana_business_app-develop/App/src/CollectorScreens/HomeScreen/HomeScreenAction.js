import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import WalletDetailsService from '@Wallet/WalletDetailsService';
import GetPendingRequestsService from '@HomeCollectorServices/GetPendingRequestsService';
import GetNotificationCountService from '@Notification/GetNotificationCountService';
import * as ActionTypes from './ActionType';

export const getWalletDetails = () => dispatch => {
	// Action to get the wallet details.
	const dispatchedActions = actions(
		ActionTypes.GET_WALLET_DETAILS_SUCCESS,
		ActionTypes.GET_WALLET_DETAILS_FAILURE,
		ActionTypes.GET_WALLET_DETAILS_LOADER,
	);
	const walletDetailsService = new WalletDetailsService(dispatchedActions);
	addBasicInterceptors(walletDetailsService);
	walletDetailsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(walletDetailsService.makeRequest());
};

/**
 * Action to store the user detail.
 * @param {object} userDetails
 * @returns
 */

export const onStoreUserDetails = userDetails => {
	return {
		type: ActionTypes.STORE_USER_DETAILS,
		payload: userDetails,
	};
};

/**
 * This will fetch all the pending requests list.
 * @param {object} props
 * @returns
 */

export const onGetPendingRequests = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.COLLECTOR_GET_PENDING_REQUESTS_SUCCESS,
		ActionTypes.COLLECTOR_GET_PENDING_REQUESTS_FAILURE,
		ActionTypes.COLLECTOR_GET_PENDING_REQUESTS_LOADER,
	);
	const getPendingRequestsService = new GetPendingRequestsService(dispatchedActions);
	addBasicInterceptors(getPendingRequestsService);
	getPendingRequestsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPendingRequestsService.makeRequest(props));
};

export const onGetNotificationCount = () => dispatch => {
	// Action to fetch the unread notification count.
	const dispatchedActions = actions(
		ActionTypes.GET_NOTIFICATION_COUNT_SUCCESS,
		ActionTypes.GET_NOTIFICATION_COUNT_FAILURE,
		ActionTypes.GET_NOTIFICATION_COUNT_LOADER,
	);
	const getNotificationCountService = new GetNotificationCountService(dispatchedActions);
	addBasicInterceptors(getNotificationCountService);
	getNotificationCountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getNotificationCountService.makeRequest());
};
