import * as ActionTypes from './ActionType';

const initialState = {
	userDetails: null,
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	pendingRequestsList: [],
	walletDetails: null,
	notificationCount: 0,
	isWalletApi: false,
};

const CollectorHomeScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.STORE_USER_DETAILS:
			return {
				...state,
				userDetails: action.payload,
			};
		case ActionTypes.GET_WALLET_DETAILS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				walletDetails: action.payload,
				isWalletApi: true,
			};
		case ActionTypes.GET_WALLET_DETAILS_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				isWalletApi: true,
			};
		case ActionTypes.GET_WALLET_DETAILS_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: true,
			};
		case ActionTypes.COLLECTOR_GET_PENDING_REQUESTS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				pendingRequestsList: action.payload.accounts_requests
					? action.payload.accounts_requests
					: [],
				isWalletApi: false,
			};
		case ActionTypes.COLLECTOR_GET_PENDING_REQUESTS_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				isWalletApi: false,
			};
		case ActionTypes.GET_NOTIFICATION_COUNT_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCategory: false,
				invoiceLoader: false,
				notificationCount: action.payload.pending_notifications,
				isWalletApi: false,
			};
		default:
			return state;
	}
};

export default CollectorHomeScreenReducer;
