import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import IMAGES from '@Images/index';
import Loader from '@Loader/Loader';
import {
	nanaDirectAddress,
	fetchCollectorPendingRequestsData,
	ninePlus,
} from '@Constants/Constants';
import collectorNavigations from '@routes/collectorNavigations';
import CollectorHomeCard from '@Components/CollectorHomeCard';
import PendingRequestComponent from '@Components/PendingRequestComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import * as HomeScreenActions from './HomeScreenAction';
import { createStyleSheet } from './HomeScreenStyle';

class HomeScreen extends Component {
	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.onStoreUserDetails();
		this.willFocusListener = navigation.addListener('focus', () => {
			this.getUpdatedData();
			pullToRefreshActions.onHandlePullToRefresh(false);
			this.onGetWalletDetails();
		});
	}

	componentDidUpdate(prevProps) {
		const { homeScreenInfo, pullToRefreshActions } = this.props;
		const { success } = homeScreenInfo;
		if (success && prevProps.homeScreenInfo.success !== success) {
			// Will hide the pull to refresh loader.
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	getUpdatedData = () => {
		this.onGetNotificationCount();
		this.onGetPendingRequests();
		this.onGetWalletDetails();
	};

	onGetWalletDetails = () => {
		// API call to get the collector amount summary.
		const { homeScreenActions } = this.props;
		homeScreenActions.getWalletDetails();
	};

	onGetPendingRequests = () => {
		// API call to get pending requests.
		const { homeScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = fetchCollectorPendingRequestsData.limit;
		queryParams.page = fetchCollectorPendingRequestsData.page;
		homeScreenActions.onGetPendingRequests(queryParams);
	};

	onStoreUserDetails = async () => {
		// Will store user details into async storage.
		const { homeScreenActions } = this.props;
		const userDetails = await AsyncStorage.getItem('user_details');
		homeScreenActions.onStoreUserDetails(JSON.parse(userDetails));
	};

	onGetNotificationCount = () => {
		// API call to get notification count.
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetNotificationCount();
	};

	viewAllPendingRequests = () => {
		// Will navigate to the pending request screen.
		const { navigation } = this.props;
		navigation.navigate(collectorNavigations.PENDING_REQUESTS_NAVIGATION);
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { homeScreenInfo, navigation } = this.props;
		const { notificationCount } = homeScreenInfo;
		navigation.navigate(collectorNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	onRefresh = () => {
		// Will call all the API's while pull to refresh.
		this.getUpdatedData();
	};

	render() {
		const { languageInfo, homeScreenInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			loader,
			pendingRequestsList,
			walletDetails,
			notificationCount,
			error,
			errorCode,
			isWalletApi,
		} = homeScreenInfo;
		const { total_wallet, deposit, pending_transaction, approved_transaction } =
			walletDetails || {};
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		if (loader && !isFetchingForPullToRefresh) {
			return <Loader size="large" />;
		}
		return (
			<View style={styles.container}>
				<View style={styles.header}>
					<View style={styles.locationView}>
						<ImageLoadComponent source={IMAGES.iconPin} style={styles.iconPin} />
						<Text style={styles.locationText}>{nanaDirectAddress}</Text>
					</View>
					<View style={styles.locationNotificationContainer}>
						<TouchableOpacity
							activeOpacity={0.8}
							style={styles.notificationContainer}
							onPress={this.onPressNotification}>
							<ImageLoadComponent
								source={IMAGES.iconNotification}
								style={styles.iconNotification}
							/>
							{notificationCount !== 0 && (
								<View style={styles.notificationViewStyle}>
									<Text style={styles.notifCount}>
										{notificationCount > 9 ? ninePlus : notificationCount}
									</Text>
								</View>
							)}
						</TouchableOpacity>
					</View>
				</View>
				<ScrollViewComponent
					showsVerticalScrollIndicator={false}
					onRefresh={this.onRefresh}
					componentType={constants.scrollView}>
					<CollectorHomeCard
						isRTL={isRTL}
						error={error && isWalletApi}
						errorCode={errorCode}
						totalWallet={total_wallet}
						approvedTransaction={approved_transaction}
						amountDeposited={deposit - approved_transaction}
						pendingAmount={pending_transaction}
						onGetWalletDetails={this.onGetWalletDetails}
					/>
					{error && !isWalletApi ? (
						<ErrorComponent
							isRTL={isRTL}
							errorCode={errorCode}
							onCallApi={this.onGetPendingRequests}
							isSectionComponent
						/>
					) : (
						pendingRequestsList.length !== 0 && (
							<PendingRequestComponent
								isRTL={isRTL}
								pendingRequestsList={pendingRequestsList}
								viewAllPendingRequests={this.viewAllPendingRequests}
							/>
						)
					)}
				</ScrollViewComponent>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		homeScreenInfo: state.CollectorHomeScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

HomeScreen.propTypes = {
	homeScreenActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen);
