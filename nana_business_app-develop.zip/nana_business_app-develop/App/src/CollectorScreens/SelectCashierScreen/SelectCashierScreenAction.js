import GetCashierListingService from '@CollectorServices/Cashier/GetCashierListingService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import APIActionsBuilder from '@libapi/APIActionsBuilder';
import * as ActionTypes from './ActionType';

/**
 * Action to set the selected cashier.
 * @param {number} id
 * @returns
 */

export const onSelectCashier = id => {
	return {
		type: ActionTypes.ON_SELECT_CASHIER,
		payload: id,
	};
};

/**
 * Action to get the cashier listing.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */
export const onGetCashiersListing = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_CASHIER_LISTING_SUCCESS,
		ActionTypes.GET_CASHIER_LISTING_FAILURE,
		ActionTypes.GET_CASHIER_LISTING_LOADER,
	)
		.addSuccessExtra({ isAppendInExistingList })
		.build();
	const getCashierListingService = new GetCashierListingService(dispatchedActions);
	addBasicInterceptors(getCashierListingService);
	getCashierListingService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCashierListingService.makeRequest(props));
};
