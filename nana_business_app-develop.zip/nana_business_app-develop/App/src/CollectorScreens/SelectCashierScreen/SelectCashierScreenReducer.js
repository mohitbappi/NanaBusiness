import * as ActionTypes from './ActionType';

const initialState = {
	cashierListing: [],
	count: 0,
	cashierId: null,
	success: false,
	error: false,
	errorCode: '',
	loader: false,
};

const SelectCashierScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_SELECT_CASHIER: {
			return {
				...state,
				cashierId: action.payload,
			};
		}
		case ActionTypes.GET_CASHIER_LISTING_SUCCESS: {
			const { isAppendInExistingList } = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				cashierListing: isAppendInExistingList
					? [...state.cashierListing, ...action.payload.cahier_users]
					: action.payload.cahier_users,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_CASHIER_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_CASHIER_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return { ...state };
	}
};

export default SelectCashierScreenReducer;
