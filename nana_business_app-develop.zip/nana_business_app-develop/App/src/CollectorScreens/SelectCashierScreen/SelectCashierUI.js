// import libraries
import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import Header from '@Header/Header';
import PropTypes from 'prop-types';

// import components
import Search from '@Search/Search';
import Loader from '@Loader/Loader';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ListEmpty from '@ListEmpty/ListEmpty';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';

// import utils
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import IMAGES from '@Images/index';

// import constants
import { fetchDataWithPagination, IMAGE_TYPE } from '@assets/Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import styles
import { createStyleSheet } from './SelectCashierScreenStyle';

class SelectCashierUI extends Component {
	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		// Will show loader while pagination.
		const { isRTL, cashierListing, count } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached = count === cashierListing.length || count < cashierListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	renderItem = ({ item }) => {
		const { isRTL, cashierId, onChooseCustomer } = this.props;
		const styles = createStyleSheet(isRTL);
		const { name, id, profile_pic } = item;
		return (
			<View style={styles.cardContainer}>
				<TouchableOpacity activeOpacity={0.8} onPress={() => onChooseCustomer(id)}>
					<ImageLoadComponent
						source={
							cashierId === id ? IMAGES.iconCheckCircle : IMAGES.iconUnCheckCircle
						}
						style={styles.icon}
					/>
				</TouchableOpacity>
				<ImageLoadComponent
					isUrl
					imageType={IMAGE_TYPE.account}
					source={profile_pic}
					style={styles.image}
				/>
				<Text style={styles.companyName}>{name}</Text>
			</View>
		);
	};

	render() {
		const {
			isRTL,
			loader,
			cashierOtpLoader,
			cashierListing,
			count,
			error,
			errorCode,
			searchText,
			onRefresh,
			onSearch,
			onGoBack,
			onEndReached,
			onSelectCustomer,
			cashierId,
			onPressNotification,
			notificationCount,
			isApiError,
			toastMessage,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				{cashierOtpLoader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.SELECT_CASHIER_NAME)}
						hasIconNotification
						hasIconBack
						onPressBack={onGoBack}
						onPressNotification={onPressNotification}
						notificationCount={notificationCount}
					/>
				</View>
				{error ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.searchContainer}>
							<Search
								hasSearchIcon
								placeholder={localeString(keyConstants.SEARCH_BY_CASHIER_NAME)}
								onChangeText={text => onSearch(text)}
								value={searchText}
							/>
						</View>
						{cashierListing.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_CASHIERS_FOUND)} />
						) : (
							<FlatListComponent
								data={cashierListing}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								onEndReached={() =>
									cashierListing.length !== count && onEndReached()
								}
								ListFooterComponent={
									cashierListing.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								ListEmptyComponent={() => (
									<ListEmpty text={localeString(keyConstants.NO_USERS_FOUND)} />
								)}
								contentContainerStyle={
									cashierListing.length === 0 ? styles.scrollViewStyle : null
								}
								onRefresh={onRefresh}
								componentType={constants.flatList}
								onRef={ref => {
									this.cashierListRef = ref;
								}}
								getItemLayout={this.getLayout}
							/>
						)}
						<View style={styles.nextButton}>
							<ButtonComponent
								text={localeString(keyConstants.PROCEED)}
								onPress={onSelectCustomer}
								isButtonDisable={cashierId === null}
							/>
						</View>
					</>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

SelectCashierUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	searchText: PropTypes.string.isRequired,
	onSearch: PropTypes.func.isRequired,
	cashierId: PropTypes.number.isRequired,
	cashierListing: PropTypes.array.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	count: PropTypes.any.isRequired,
	onSelectCustomer: PropTypes.func.isRequired,
	onChooseCustomer: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	onPressNotification: PropTypes.func.isRequired,
	notificationCount: PropTypes.number.isRequired,
	cashierOtpLoader: PropTypes.bool.isRequired,
	isApiError: PropTypes.bool.isRequired,
	toastMessage: PropTypes.string.isRequired,
};

export default SelectCashierUI;
