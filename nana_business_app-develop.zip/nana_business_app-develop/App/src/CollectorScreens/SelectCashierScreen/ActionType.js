export const GET_CASHIER_LISTING_SUCCESS = 'get_cashier_listing_success';
export const GET_CASHIER_LISTING_FAILURE = 'get_cashier_listing_failure';
export const GET_CASHIER_LISTING_LOADER = 'get_cashier_listing_loader';

export const ON_SELECT_CASHIER = 'on_select_cashier';
