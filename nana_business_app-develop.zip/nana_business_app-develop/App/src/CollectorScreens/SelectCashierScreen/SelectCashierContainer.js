// import libraries
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as CashierOtpScreenActions from '@CashierOTPScreen/CashierOTPScreenAction';
import * as SelectCashierScreenActions from './SelectCashierScreenAction';

// import components
import SelectCashierComponent from './SelectCashierComponent';

const SelectCashierContainer = props => {
	const customProps = { ...props }; // Will store all the props like navigation, reducer state and actions.
	return <SelectCashierComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer, // Language screen reducer
		refreshControlComponentInfo: state.RefreshControlComponentReducer, // Pull to refresh screen reducer
		selectCashierInfo: state.SelectCashierScreenReducer,
		homeScreenInfo: state.CollectorHomeScreenReducer,
		cashierOtpInfo: state.CashierOTPScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch), // Pull to refresh actions
		selectCashierActions: bindActionCreators({ ...SelectCashierScreenActions }, dispatch),
		cashierOtpScreenActions: bindActionCreators({ ...CashierOtpScreenActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectCashierContainer);
