import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		cardContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			paddingVertical: verticalScale(12),
			paddingHorizontal: normalScale(16),
			borderBottomColor: colors.whitishGrey,
			borderBottomWidth: normalScale(1),
			borderRadius: normalScale(8),
			alignItems: 'center',
		},
		icon: {
			height: verticalScale(17),
			width: normalScale(17),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 17),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 17),
		},
		image: {
			height: normalScale(36),
			width: normalScale(36),
			borderRadius: normalScale(18),
		},
		companyName: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			width: normalScale(250),
			marginRight: rtlFunctions.getMarginRight(isRTL, 8),
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		searchContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(5),
		},
		nextButton: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			left: normalScale(8),
			right: normalScale(8),
			position: 'absolute',
			paddingTop: verticalScale(10),
			bottom: verticalScale(0),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
