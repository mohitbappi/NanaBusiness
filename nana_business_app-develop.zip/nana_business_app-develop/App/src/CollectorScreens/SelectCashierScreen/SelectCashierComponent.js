// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { fetchDataWithPagination, toastShowTime } from '@assets/Constants/Constants';
import collectorNavigations from '@config/routes/collectorNavigations';
import { keyConstants } from '@assets/Constants/KeyConstants';

// import assets
import { localeString } from '@assets/Localization';

// import components
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import SelectCashierUI from './SelectCashierUI';

class SelectCashierComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			searchText: '',
			bottomLoader: false,
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.page = fetchDataWithPagination.page;
			this.onFetchData(false);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			selectCashierInfo,
			pullToRefreshActions,
			cashierOtpInfo,
			navigation,
			route,
			cashierOtpScreenActions,
		} = this.props;
		const { success, cashierListing, cashierId } = selectCashierInfo;
		const { success: cashierOtpSuccess, isOtpSend, error, errorCode } = cashierOtpInfo;
		const { totalAmount, walletTransactions } = route.params;
		if (success && prevProps.selectCashierInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (
			cashierOtpSuccess &&
			isOtpSend &&
			prevProps.cashierOtpInfo.success !== cashierOtpSuccess
		) {
			navigation.navigate(collectorNavigations.CASHIER_OTP_NAVIGATION, {
				cashierDetails: this.getCashierDetail(cashierListing, cashierId),
				totalAmount,
				walletTransactions,
			});
			cashierOtpScreenActions.onResetOtpScreenState();
		}
		if (error && prevProps.cashierOtpInfo.error !== error) {
			if (keyConstants[errorCode.error]) {
				this.onShowToast(errorCode.error);
			} else {
				// Will show alert if send otp api fails.
				ErrorAlertComponent(errorCode, this.onSelectCustomer);
			}
			cashierOtpScreenActions.onResetOtpScreenState();
		}
	}

	getCashierDetail = (cashierListing, cashierId) => {
		const index = cashierListing.findIndex(element => element.id === cashierId);
		return cashierListing[index];
	};

	onShowToast = message => {
		// Will show toast.
		this.setState({
			toastMessage: localeString(message),
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	onSearch = text => {
		// Will search customer using name.
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => this.onFetchData(false),
		);
	};

	onFetchData = isAppendInExistingList => {
		// API call to get the cashier listing.
		const { selectCashierActions } = this.props;
		const { searchText } = this.state;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			queryParams.name = searchText; // If search is done by name.
		}
		selectCashierActions.onGetCashiersListing(queryParams, isAppendInExistingList);
	};

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation, selectCashierActions } = this.props;
		selectCashierActions.onSelectCashier(null);
		navigation.goBack();
	};

	onEndReached = () => {
		const { selectCashierInfo } = this.props;
		const { loader } = selectCashierInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onRefresh = () => {
		// Will call api after pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	onChooseCustomer = id => {
		const { selectCashierActions } = this.props;
		selectCashierActions.onSelectCashier(id);
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { homeScreenInfo, navigation } = this.props;
		const { notificationCount } = homeScreenInfo;
		navigation.navigate(collectorNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	onSelectCustomer = () => {
		// Action to set selected customer.
		const { selectCashierInfo, route, cashierOtpScreenActions } = this.props;
		const { cashierId } = selectCashierInfo;
		const { totalAmount, walletTransactions } = route.params;
		const cashierDetails = {
			cashier_id: cashierId,
			amount: totalAmount,
			payment_received_ids: walletTransactions,
		};
		cashierOtpScreenActions.onSendOtp(cashierDetails);
	};

	render() {
		const {
			languageInfo,
			selectCashierInfo,
			refreshControlComponentInfo,
			cashierOtpInfo,
			homeScreenInfo,
		} = this.props;
		const { searchText, bottomLoader, isApiError, toastMessage } = this.state;
		const { isRTL } = languageInfo;
		const { cashierListing, count, loader, error, errorCode, cashierId } = selectCashierInfo;
		const { loader: cashierOtpLoader } = cashierOtpInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { notificationCount } = homeScreenInfo;
		return (
			<SelectCashierUI
				isRTL={isRTL}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				cashierOtpLoader={cashierOtpLoader}
				cashierListing={cashierListing}
				count={count}
				error={error}
				errorCode={errorCode}
				searchText={searchText}
				cashierId={cashierId}
				onRefresh={this.onRefresh}
				onSearch={this.onSearch}
				onGoBack={this.onGoBack}
				onEndReached={this.onEndReached}
				onChooseCustomer={this.onChooseCustomer}
				onSelectCustomer={this.onSelectCustomer}
				onPressNotification={this.onPressNotification}
				notificationCount={notificationCount}
				isApiError={isApiError}
				toastMessage={toastMessage}
			/>
		);
	}
}

SelectCashierComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	selectCashierInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	selectCashierActions: PropTypes.func.isRequired,
	route: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	cashierOtpScreenActions: PropTypes.object.isRequired,
	cashierOtpInfo: PropTypes.object.isRequired,
};

export default SelectCashierComponent;
