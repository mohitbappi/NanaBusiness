import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';
import { center } from './Constant';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: center,
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		cardView: {
			paddingHorizontal: normalScale(16),
		},
		dateStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		statusViewStyle: {
			marginTop: verticalScale(18),
		},
		pendingViewStyle: {
			backgroundColor: colors.lightYellow,
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			paddingHorizontal: normalScale(16),
		},
		card: {
			paddingHorizontal: verticalScale(16),
		},
		tabContainer: {
			marginTop: verticalScale(16),
			marginHorizontal: normalScale(8),
		},
		searchContainer: {
			paddingHorizontal: normalScale(16),
			marginBottom: verticalScale(5),
			marginTop: verticalScale(16),
		},
		scrollViewStyle: {
			flex: 1,
		},
		marginStyle: {
			paddingBottom: verticalScale(55),
		},
		bankButtonView: {
			position: 'absolute',
			bottom: verticalScale(56),
			backgroundColor: colors.white,
			left: normalScale(16),
			right: normalScale(16),
		},
		buttonView: {
			position: 'absolute',
			bottom: verticalScale(10),
			backgroundColor: colors.white,
			left: normalScale(16),
			right: normalScale(16),
		},
		depositButtonStyle: {
			backgroundColor: colors.white,
			borderColor: colors.darkBlue,
			borderWidth: normalScale(1),
		},
		cancelText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			marginTop: verticalScale(5),
		},
		activityIndicatorStyle: {
			alignItems: center,
			flex: 1,
		},
		madaContainer: {
			position: 'absolute',
			bottom: 0,
			right: isRTL ? 0 : null,
			left: isRTL ? null : 0,
			zIndex: 1000,
		},
		iconAddYellow: {
			height: verticalScale(60),
			width: normalScale(60),
		},
	});
};

export default createStyleSheet;
