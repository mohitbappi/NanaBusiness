export const GET_MY_COLLECTION_SUCCESS = 'get_my_collection_success';
export const GET_MY_COLLECTION_FAILURE = 'get_my_collection_failure';
export const GET_MY_COLLECTION_LOADER = 'get_my_collection_loader';

export const GET_MADA_TRANSACTIONS_LISTING_SUCCESS = 'get_mada_transaction_listing_success';
export const GET_MADA_TRANSACTIONS_LISTING_FAILURE = 'get_mada_transaction_listing_failure';
export const GET_MADA_TRANSACTIONS_LISTING_LOADER = 'get_mada_transaction_listing_loader';

export const GET_WALLET_DETAILS_SUCCESS = 'get_wallet_details';
export const GET_WALLET_DETAILS_FAILURE = 'get_wallet_failure';
export const GET_WALLET_DETAILS_LOADER = 'get_wallet_loader';

export const SET_TAB_INDEX = 'set_tab_index';
