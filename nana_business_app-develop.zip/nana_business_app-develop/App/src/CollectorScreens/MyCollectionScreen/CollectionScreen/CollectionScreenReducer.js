import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	collectionListing: [],
	count: 0,
	activeTabIndex: 0,
};

const CollectionScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_MY_COLLECTION_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				collectionListing: isOverwriteExistingList
					? [...state.collectionListing, ...action.payload.invoices]
					: action.payload.invoices,
				count: parseInt(action.payload.count, 10),
			};
		}
		case ActionTypes.GET_MADA_TRANSACTIONS_LISTING_SUCCESS: {
			const isOverwriteExistingMadaList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				collectionListing: isOverwriteExistingMadaList
					? [...state.collectionListing, ...action.payload.txn_requests]
					: action.payload.txn_requests,
				count: parseInt(action.payload.count, 10),
			};
		}
		case ActionTypes.GET_WALLET_DETAILS_SUCCESS: {
			const isOverwriteExistingWalletList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				collectionListing: isOverwriteExistingWalletList
					? [...state.collectionListing, ...action.payload.transactions]
					: action.payload.transactions,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_MY_COLLECTION_LOADER:
		case ActionTypes.GET_MADA_TRANSACTIONS_LISTING_LOADER:
		case ActionTypes.GET_WALLET_DETAILS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_MY_COLLECTION_FAILURE:
		case ActionTypes.GET_MADA_TRANSACTIONS_LISTING_FAILURE:
		case ActionTypes.GET_WALLET_DETAILS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.SET_TAB_INDEX:
			return {
				...state,
				activeTabIndex: action.payload,
			};
		default:
			return state;
	}
};

export default CollectionScreenReducer;
