import APIActionsBuilder from '@libapi/APIActionsBuilder';
import MyCollectionService from '@MyCollection/MyCollectionService';
import GetMadaTransactionsService from '@MadaPayments/GetMadaTransactionsService';
import WalletDetailsService from '@Wallet/WalletDetailsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to fetch the collection requests list.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetMyCollection = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_MY_COLLECTION_SUCCESS,
		ActionTypes.GET_MY_COLLECTION_FAILURE,
		ActionTypes.GET_MY_COLLECTION_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const myCollectionService = new MyCollectionService(dispatchedActions);
	addBasicInterceptors(myCollectionService);
	myCollectionService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(myCollectionService.makeRequest(props));
};

/**
 * Action to get the mada transactions.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetMadaTransactions = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_MADA_TRANSACTIONS_LISTING_SUCCESS,
		ActionTypes.GET_MADA_TRANSACTIONS_LISTING_FAILURE,
		ActionTypes.GET_MADA_TRANSACTIONS_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getMadaTransactionsService = new GetMadaTransactionsService(dispatchedActions);
	addBasicInterceptors(getMadaTransactionsService);
	getMadaTransactionsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getMadaTransactionsService.makeRequest(props));
};

/**
 * Action to get the collection requests list.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const getWalletDetails = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_WALLET_DETAILS_SUCCESS,
		ActionTypes.GET_WALLET_DETAILS_FAILURE,
		ActionTypes.GET_WALLET_DETAILS_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const walletDetailsService = new WalletDetailsService(dispatchedActions);
	addBasicInterceptors(walletDetailsService);
	walletDetailsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(walletDetailsService.makeRequest(props));
};

export const onSetTabIndex = index => {
	// Action to set the selected tab index.
	return {
		type: ActionTypes.SET_TAB_INDEX,
		payload: index,
	};
};
