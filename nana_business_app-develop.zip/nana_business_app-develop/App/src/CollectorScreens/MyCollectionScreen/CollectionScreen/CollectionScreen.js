import React, { Component } from 'react';
import { View, Text, Keyboard, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import {
	driver,
	fetchDataWithPagination,
	madaTransactionType,
	paymentReceivedStatus,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import { getFormattedDate } from '@Util/GetFormattedDate';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import collectorNavigations from '@routes/collectorNavigations';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import Search from '@Search/Search';
import ListEmpty from '@ListEmpty/ListEmpty';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import TabComponent from '@Components/TabComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import IMAGES from '@Images/index';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import * as HomeScreenActions from '@CollectorHomeScreen/HomeScreenAction';
import CollectorHomeCard from '@Components/CollectorHomeCard';
import driverNavigations from '@config/routes/driverNavigations';
import { verticalScale } from '@device/normalize';
import { getScrollingIndex, getPage } from '@Util/GetScrollingIndex';
import * as MyCollectionActions from './CollectionScreenAction';
import { createStyleSheet } from './CollectionScreenStyle';

class CollectionScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.roles = props.userDetails.user.roles;
		this.id = props.userDetails.user.id;
		this.state = {
			bottomLoader: false,
			searchText: '',
			tabsArray: [
				keyConstants.COLLECTIONS,
				keyConstants.PAYMENTS,
				keyConstants.TO_BE_DEPOSIT,
			],
			walletTransactions: [],
			totalAmount: 0,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const {
				pullToRefreshActions,
				myCollectionInfo,
				refreshControlComponentInfo,
			} = this.props;
			const { activeTabIndex } = myCollectionInfo;
			const { scrollIndex } = refreshControlComponentInfo;
			this.limit = getScrollingIndex(scrollIndex);
			this.initialApiCall(activeTabIndex);
			pullToRefreshActions.onHandlePullToRefresh(false);
			this.onGetWalletDetails();
		});
		this.willFocusListener = navigation.addListener('blur', () => {
			this.onSetIndexTo();
		});
	}

	componentDidUpdate(prevProps) {
		const { myCollectionInfo, pullToRefreshActions } = this.props;
		const { success } = myCollectionInfo;
		if (success && prevProps.myCollectionInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.page === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	initialApiCall = index => {
		// Will reset this.page and searchText.
		const { myCollectionActions } = this.props;
		this.page = fetchDataWithPagination.page;
		myCollectionActions.onSetTabIndex(index);
		this.setState(
			{
				searchText: '',
				walletTransactions: [],
				totalAmount: 0,
			},
			() => this.onFetchData(false, index),
		);
	};

	onFetchData = (isOverwriteExistingList, index) => {
		// API call to get the collections list.
		const queryParams = {};
		const { searchText } = this.state;
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			if (index !== 1) {
				queryParams.organization = searchText;
			} else {
				queryParams.customer_name_rrn = searchText;
			}
		}
		this.onCallApi(index, queryParams, isOverwriteExistingList);
	};

	onCallApi = (index, queryParams, isOverwriteExistingList) => {
		const { myCollectionActions } = this.props;
		if (index === 0) {
			// API call to get the collection requests.
			if (this.roles.includes(driver)) {
				// Adding driver_id in params if role is driver.
				// eslint-disable-next-line no-param-reassign
				queryParams.driver_id = this.id;
			}
			myCollectionActions.onGetMyCollection(queryParams, isOverwriteExistingList);
		} else if (index === 1) {
			// API call to get the mada transactions.
			myCollectionActions.onGetMadaTransactions(queryParams, isOverwriteExistingList);
		} else {
			// API call to ge the wallet transactions.
			myCollectionActions.getWalletDetails(queryParams, isOverwriteExistingList);
		}
	};

	onGetWalletDetails = () => {
		// API call to get the collector amount summary.
		const { homeScreenActions } = this.props;
		homeScreenActions.getWalletDetails();
	};

	onGoBack = () => {
		// Will go back to the previous screen.
		const { route, navigation } = this.props;
		const { backActionShipment } = route.params || {};
		if (backActionShipment) {
			navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
		} else {
			navigation.goBack();
		}
	};

	onSetIndexTo = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponent = () => {
		const { languageInfo, myCollectionInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { collectionListing, count } = myCollectionInfo;
		const endReached = count === collectionListing.length || count < collectionListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { myCollectionInfo } = this.props;
		const { activeTabIndex, loader } = myCollectionInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onFetchData(true, activeTabIndex);
		}
	};

	onCreateMadaTransaction = (isNewMadaPayment, extraParams) => {
		// Will navigate to the create payment received screen.
		const { navigation } = this.props;
		navigation.navigate(collectorNavigations.PAYMENT_RECEIVED_NAVIGATION, {
			isNewMadaPayment,
			extraParams,
			isResubmit: false,
		});
	};

	getLayout = (data, index) => ({
		// Will Calculate the Length and offset of container for ScrollToInsex Functionality.
		length: verticalScale(60),
		offset: verticalScale(60) * index,
		index,
	});

	renderItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			retailer_org_name,
			retailer_org_name_ar,
			invoice_total,
			due,
			status,
			id,
			created_by,
			pending_transactions_counts,
		} = item;
		return (
			<View style={styles.cardView}>
				<InvoiceCardComponent
					name={isRTL ? retailer_org_name_ar || retailer_org_name : retailer_org_name}
					dateLabel={`${localeString(keyConstants.CREATED_DATE)}: `}
					date={getFormattedDate(due)}
					amount={`${currencyFormatter(getValueInDecimal(invoice_total))} ${localeString(
						keyConstants.SAR,
					)}`}
					isShowStatus // Boolean to show status
					status={status}
					isDisable={false}
					onPress={() => this.onGetDetail(id, index, `${retailer_org_name}`, created_by)}
					dateStyle={styles.dateStyle}
					pendingInvoices={pending_transactions_counts}
					pendingViewStyle={styles.pendingViewStyle}
				/>
			</View>
		);
	};

	renderMadaItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { id, status, type, amount, created_at } = item;
		return (
			<View style={styles.cardView}>
				<InvoiceCardComponent
					name={this.getParameters(isRTL, item).name[type]}
					invoiceId={this.getParameters(isRTL, item).invoiceId[type]}
					dateLabel={this.getParameters(isRTL, item).dateLabel[type]}
					date={getFormattedDate(created_at)}
					amount={`${currencyFormatter(getValueInDecimal(amount))} ${localeString(
						keyConstants.SAR,
					)}`}
					isShowStatus={this.getParameters(isRTL, item).isShowStatus[type]} // Boolean to show status
					status={status}
					isDisable={false}
					onPress={() => this.onGetMadaDetail(id, index, type, item)}
					dateStyle={styles.dateStyle}
					statusViewStyle={styles.statusViewStyle}
				/>
			</View>
		);
	};

	renderWalletItem = ({ item }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			created_at,
			amount,
			id,
			status,
			customer_organization_name,
			customer_organization_name_ar,
		} = item || {};
		const { walletTransactions } = this.state;
		return (
			<View style={styles.cardView}>
				<InvoiceCardComponent
					name={
						isRTL
							? customer_organization_name_ar || customer_organization_name
							: customer_organization_name
					}
					dateLabel={`${localeString(keyConstants.CREATED_DATE)}: `}
					date={getFormattedDate(created_at)}
					amount={`${currencyFormatter(getValueInDecimal(amount))} ${localeString(
						keyConstants.SAR,
					)}`}
					isShowStatus // Boolean to show status
					status={status.toLowerCase()}
					isDisable
					dateStyle={styles.dateStyle}
					showCheckBox={
						status.toLowerCase() === paymentReceivedStatus.collected ||
						status.toLowerCase() === paymentReceivedStatus.rejected
					} // Boolean to show radio button to select value.
					selectedItem={walletTransactions}
					id={id}
					onSelect={() => this.onSelect(id, amount)}
				/>
			</View>
		);
	};

	onSelect = (id, amount) => {
		// Function to select the multiple transactions.
		const { walletTransactions } = this.state;
		const transactionsCopy = walletTransactions;
		let { totalAmount } = this.state;
		if (transactionsCopy.includes(id)) {
			const itemIndex = transactionsCopy.indexOf(id);
			transactionsCopy.splice(itemIndex, 1);
			totalAmount -= amount;
		} else {
			transactionsCopy.push(id);
			totalAmount += amount;
		}
		this.setState({
			walletTransactions: transactionsCopy,
			totalAmount,
		});
	};

	onGetDetail = (id, index, headerTitle, ownerName) => {
		// Will navigate to the invoice detail screen.
		const { navigation } = this.props;
		navigation.navigate(collectorNavigations.INVOICE_DETAIL_NAVIGATION, {
			id,
			index,
			headerTitle,
			ownerName,
			isPayNowButton: true,
		});
	};

	getParameters = (isRTL, item) => {
		// Will return data according to transaction type.
		const { rrn, customer_org_name, customer_org_name_ar } = item;
		return {
			name: {
				[`${madaTransactionType.request}`]: isRTL
					? customer_org_name_ar || customer_org_name
					: customer_org_name,
				[`${madaTransactionType.txn}`]: `${localeString(keyConstants.RRN)}-${rrn}`,
			},
			invoiceId: {
				[`${madaTransactionType.request}`]: `(${rrn})`,
				[`${madaTransactionType.txn}`]: '',
			},
			isShowStatus: {
				[`${madaTransactionType.request}`]: true,
				[`${madaTransactionType.txn}`]: false,
			},
			dateLabel: {
				[`${madaTransactionType.request}`]: `${localeString(keyConstants.CREATED_DATE)}: `,
				[`${madaTransactionType.txn}`]: `${localeString(keyConstants.TXN_DATE)}: `,
			},
		};
	};

	payNow = () => {
		// Will navigate to the deposit amount screen.
		const { navigation } = this.props;
		const { totalAmount, walletTransactions } = this.state;
		navigation.navigate(collectorNavigations.DEPOSIT_AMOUNT_NAVIGATION, {
			totalAmount,
			walletTransactions,
		});
	};

	depositToCashier = () => {
		// Will navigate to the select cashier screen.
		const { navigation } = this.props;
		const { totalAmount, walletTransactions } = this.state;
		navigation.navigate(collectorNavigations.SELECT_CASHIER_NAVIGATION, {
			totalAmount,
			walletTransactions,
		});
	};

	onGetMadaDetail = (id, index, type, item) => {
		const { navigation } = this.props;
		const { terminal_id, rrn, amount } = item;
		if (type === madaTransactionType.txn) {
			// Will navigate the user to create the mada transaction request.
			this.onCreateMadaTransaction(false, {
				terminal_id,
				rrn,
				amount,
				madaId: item.id,
				index,
			});
		} else {
			// Will navigate to the mada transaction detail.
			navigation.navigate(collectorNavigations.MADA_TRANSACTION_DETAIL_NAVIGATION, {
				id,
				index,
			});
		}
	};

	onSelectTab = index => {
		// Function to swtich the tabs.
		this.onSetIndexTo();
		const { myCollectionActions } = this.props;
		this.onDissmissKeyboard();
		myCollectionActions.onSetTabIndex(index);
		this.setState(
			{
				searchText: '',
				walletTransactions: [],
				totalAmount: 0,
			},
			() => {
				this.page = 1;
				this.onFetchData(false, index);
			},
		);
	};

	onSearch = text => {
		// API call to search by using organization id.
		const { myCollectionInfo } = this.props;
		const { activeTabIndex } = myCollectionInfo;
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onFetchData(false, activeTabIndex);
			},
		);
	};

	renderComponent = () => {
		const { languageInfo, myCollectionInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(!isRTL);
		const { bottomLoader, searchText, walletTransactions, totalAmount } = this.state;
		const {
			loader,
			collectionListing,
			count,
			error,
			errorCode,
			activeTabIndex,
		} = myCollectionInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		if (loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === '') {
			return (
				<Loader
					size="large"
					isSmallLoader
					activityIndicatorStyle={styles.activityIndicatorStyle}
				/>
			);
		}
		if (error) {
			// Will return error component.
			return (
				<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={this.onRefresh} />
			);
		}
		return (
			<>
				{activeTabIndex === 1 ? (
					<TouchableOpacity
						onPress={() => this.onCreateMadaTransaction(true, null)}
						style={styles.madaContainer}
						activeOpacity={0.8}>
						<ImageLoadComponent
							source={IMAGES.iconAddYellow}
							style={styles.iconAddYellow}
						/>
					</TouchableOpacity>
				) : null}
				<FlatListComponent
					keyboardShouldPersistTaps="handled"
					data={collectionListing}
					renderItem={
						activeTabIndex === 0
							? this.renderItem
							: activeTabIndex === 1
							? this.renderMadaItem
							: this.renderWalletItem
					}
					keyExtractor={this.keyExtractor}
					showsVerticalScrollIndicator={false}
					onEndReached={() => collectionListing.length !== count && this.onEndReached()}
					ListFooterComponent={
						collectionListing.length !== 0 &&
						count > fetchDataWithPagination.limit &&
						this.listFooterComponent()
					}
					onEndReachedThreshold={0.5}
					ListEmptyComponent={() => (
						<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
					)}
					contentContainerStyle={
						collectionListing.length === 0
							? styles.scrollViewStyle
							: activeTabIndex === 2 && styles.marginStyle
					}
					onRefresh={this.onRefresh}
					componentType={constants.flatList}
					onRef={ref => {
						this.itemListRef = ref;
					}}
					getItemLayout={this.getLayout}
				/>
				{activeTabIndex === 2 ? (
					<>
						<View style={styles.bankButtonView}>
							<ButtonComponent
								text={`${localeString(
									keyConstants.DEPOSIT_TO_BANK,
								)} (${currencyFormatter(
									getValueInDecimal(totalAmount),
								)} ${localeString(keyConstants.SAR)})`}
								onPress={this.payNow}
								isButtonDisable={!walletTransactions.length}
							/>
						</View>
						<View style={styles.buttonView}>
							<ButtonComponent
								buttonStyle={walletTransactions.length && styles.depositButtonStyle}
								text={`${localeString(
									keyConstants.DEPOSIT_TO_CASHIER,
								)} (${currencyFormatter(
									getValueInDecimal(totalAmount),
								)} ${localeString(keyConstants.SAR)})`}
								onPress={this.depositToCashier}
								isButtonDisable={!walletTransactions.length}
								textStyle={styles.cancelText}
							/>
						</View>
					</>
				) : null}
			</>
		);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onRefresh = () => {
		// API call while pull to refresh.
		const { myCollectionInfo } = this.props;
		const { activeTabIndex } = myCollectionInfo;
		this.onSetIndexTo();
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false, activeTabIndex);
	};

	render() {
		const { languageInfo, myCollectionInfo, homeScreenInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(!isRTL);
		const { searchText, tabsArray } = this.state;
		const { activeTabIndex } = myCollectionInfo;
		const { walletDetails, error, errorCode, isWalletApi } = homeScreenInfo;
		const { total_wallet, deposit, pending_transaction, approved_transaction } =
			walletDetails || {};
		const { isDriverRole } = route.params || {};
		return (
			<View style={styles.container}>
				<View style={styles.headerContainer}>
					<Header
						hasIconBack={isDriverRole}
						onPressBack={this.onGoBack}
						hasIconCollection={!isDriverRole}
						text={localeString(keyConstants.COLLECTION)}
					/>
				</View>
				{isDriverRole ? (
					<View style={styles.card}>
						<CollectorHomeCard
							isRTL={isRTL}
							error={error && isWalletApi}
							errorCode={errorCode}
							totalWallet={total_wallet}
							approvedTransaction={approved_transaction}
							amountDeposited={deposit - approved_transaction}
							pendingAmount={pending_transaction}
							onGetWalletDetails={this.onGetWalletDetails}
							hasCollapsableView
						/>
					</View>
				) : null}
				<View style={styles.tabContainer}>
					<TabComponent
						isRTL={isRTL}
						data={tabsArray}
						activeTabIndex={activeTabIndex}
						onPressTab={this.onSelectTab}
						inverted={isRTL}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasSearchIcon
						placeholder={localeString(
							activeTabIndex !== 1
								? keyConstants.SEARCH_BY_CUSTOMER
								: keyConstants.SEARCH_BY_CUSTOMER_NAME_RRN_NUMBER,
						)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
					/>
				</View>
				{this.renderComponent()}
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		myCollectionInfo: state.CollectionScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		homeScreenInfo: state.CollectorHomeScreenReducer,
		userDetails: state.ShipmentScreenReducer.userDetails,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		myCollectionActions: bindActionCreators({ ...MyCollectionActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
	};
};

CollectionScreen.propTypes = {
	pullToRefreshActions: PropTypes.object.isRequired,
	myCollectionInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	myCollectionActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(CollectionScreen);
