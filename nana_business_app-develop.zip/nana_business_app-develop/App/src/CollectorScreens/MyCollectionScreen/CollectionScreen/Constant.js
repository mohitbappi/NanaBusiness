export const center = 'center';

export default center;
