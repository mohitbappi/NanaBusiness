export const full = 'full';
export const partial = 'partial';
