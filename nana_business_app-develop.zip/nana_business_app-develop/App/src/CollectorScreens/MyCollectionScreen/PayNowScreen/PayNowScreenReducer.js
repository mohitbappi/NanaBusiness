import * as ActionTypes from './ActionType';

const initialState = {
	amount: 0,
};

const PayNowScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_AMOUNT:
			return {
				[action.field]: action.payload,
			};
		case ActionTypes.PAY_MONEY_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
			};
		case ActionTypes.PAY_MONEY_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.PAY_MONEY_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_PAY_NOW_STATE:
			return initialState;
		default:
			return { ...state };
	}
};

export default PayNowScreenReducer;
