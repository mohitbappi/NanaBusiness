export const ON_CHANGE_AMOUNT = 'on_change_AMOUNT';
export const PAY_MONEY_SUCCESS = 'pay_money_success';
export const PAY_MONEY_FAILURE = 'pay_money_failure';
export const PAY_MONEY_LOADER = 'pay_money_loader';
export const RESET_PAY_NOW_STATE = 'reset_pay_now_state';
