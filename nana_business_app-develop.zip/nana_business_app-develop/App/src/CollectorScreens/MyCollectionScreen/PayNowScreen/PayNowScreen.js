import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Text, View, TouchableOpacity, Keyboard } from 'react-native';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Header from '@Header/Header';
import IMAGES from '@Images/index';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import { numericRegexWithDecimalEx, spaceRegexEx, toastShowTime } from '@Constants/Constants';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { full, partial } from './constant';
import { createStyleSheet } from './PayNowScreenStyle';
import * as PayNowAction from './PayNowAction';

class PayNowScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			amountType: full,
			isApiError: false,
			toastMessage: '',
			isAmountError: false,
			amountErrorMessage: '',
		};
	}

	componentDidUpdate(prevProps) {
		const { payNowInfo, payNowActions } = this.props;
		const { amount, success, error, errorCode } = payNowInfo;
		if (success && prevProps.payNowInfo.success !== success) {
			this.onPressBack();
			payNowActions.onResetPayNowState();
		}
		if (error && prevProps.payNowInfo.error !== error) {
			this.setState({
				toastMessage: localeString(`${errorCode.error}`),
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
		if (
			payNowInfo.amount !== prevProps.payNowInfo.amount &&
			numericRegexWithDecimalEx.test(String(amount).toLowerCase())
		) {
			this.setState({
				isAmountError: false,
				amountErrorMessage: '',
			});
		}
	}

	componentWillUnmount() {
		const { payNowActions } = this.props;
		payNowActions.onResetPayNowState();
	}

	onPressBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onPressAmountType = type => {
		this.setState({
			amountType: type,
		});
	};

	onChangeText = (text, field) => {
		const { payNowActions } = this.props;
		payNowActions.onChangeAmount(text, field);
	};

	payNow = () => {
		const { route, payNowInfo, payNowActions } = this.props;
		const { id, payableAmount } = route.params;
		const { amount } = payNowInfo;
		const { amountType } = this.state;
		this.onDissmissKeyboard();
		const paymentDetails = {
			amount: amountType === partial ? parseFloat(amount) : payableAmount,
			invoice_id: id,
		};
		payNowActions.onPayMoney(paymentDetails);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onBlur = () => {
		const { payNowInfo } = this.props;
		const { amount } = payNowInfo;
		if (!numericRegexWithDecimalEx.test(String(amount).toLowerCase())) {
			this.setState({
				isAmountError: true,
				amountErrorMessage: localeString(keyConstants.ONLY_TWO_DIGIT_AFTER_DECIMAL),
			});
		}
	};

	render() {
		const { languageInfo, payNowInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			amountType,
			isApiError,
			toastMessage,
			isAmountError,
			amountErrorMessage,
		} = this.state;
		const { amount, loader } = payNowInfo;
		const { payableAmount, invoiceTotal } = route.params;
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						hasIconBack
						onPressBack={this.onPressBack}
						text={localeString(keyConstants.PAY_NOW)}
					/>
				</View>
				<View style={styles.totalAmountContainer}>
					<Text style={styles.totalAmountText}>
						{localeString(keyConstants.TOTAL_AMOUNT)}
					</Text>
					<Text style={styles.totalAmount}>
						{`${getValueInDecimal(invoiceTotal)} ${localeString(keyConstants.SAR)}`}
					</Text>
				</View>
				<View style={styles.remainingAmountOutterContainer}>
					<View style={styles.remainingAmountContainer}>
						<Text style={styles.totalAmountText}>
							{localeString(keyConstants.REMAINING_AMOUNT)}
						</Text>
						<Text style={styles.totalAmount}>
							{`${getValueInDecimal(payableAmount)} ${localeString(
								keyConstants.SAR,
							)}`}
						</Text>
					</View>
				</View>
				<Text style={styles.amount}>{localeString(keyConstants.AMOUNT)}</Text>
				<View style={styles.amountContainer}>
					<View style={styles.fullCheckContainer}>
						<TouchableOpacity
							activeOpacity={0.8}
							onPress={() => this.onPressAmountType(full)}
							style={styles.checkUnCheckContainer}>
							<ImageLoadComponent
								style={styles.checkUncheck}
								source={
									amountType === full
										? IMAGES.iconCheckCircle
										: IMAGES.iconUnCheckCircle
								}
							/>
						</TouchableOpacity>
						<Text style={styles.fullPartial}>{localeString(keyConstants.FULL)}</Text>
					</View>
					<View style={styles.partialCheckContainer}>
						<TouchableOpacity
							activeOpacity={0.8}
							onPress={() => this.onPressAmountType(partial)}
							style={styles.checkUnCheckContainer}>
							<ImageLoadComponent
								style={styles.checkUncheck}
								source={
									amountType === partial
										? IMAGES.iconCheckCircle
										: IMAGES.iconUnCheckCircle
								}
							/>
						</TouchableOpacity>
						<Text style={styles.fullPartial}>{localeString(keyConstants.PARTIAL)}</Text>
					</View>
				</View>
				<View style={styles.inputContainer}>
					{amountType === partial && (
						<Input
							value={amount}
							width={normalScale(288)}
							label={localeString(keyConstants.AMOUNT)}
							placeholder={localeString(keyConstants.AMOUNT)}
							blurOnSubmit
							returnKeyType="done"
							keyboardType="decimal-pad"
							isRTL={isRTL}
							onChangeText={text =>
								(spaceRegexEx.test(String(text).toLowerCase()) || text === '') &&
								this.onChangeText(text, 'amount')
							}
							autoCapitalize="none"
							isError={isAmountError}
							errorMessage={amountErrorMessage}
							onBlur={this.onBlur}
						/>
					)}
				</View>
				<View style={styles.buttonView}>
					<ButtonComponent
						text={
							amountType === full
								? `${localeString(keyConstants.PAY)} (${getValueInDecimal(
										payableAmount,
								  )} ${localeString(keyConstants.SAR)})`
								: `${localeString(keyConstants.PAY)} (${getValueInDecimal(
										amount,
								  )} ${localeString(keyConstants.SAR)})`
						}
						onPress={this.payNow}
						isButtonDisable={
							!(
								numericRegexWithDecimalEx.test(String(amount).toLowerCase()) &&
								!isAmountError &&
								(amountType === partial ? parseFloat(amount) > 0 : true)
							)
						}
					/>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}
const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		payNowInfo: state.PayNowScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		payNowActions: bindActionCreators({ ...PayNowAction }, dispatch),
	};
};

PayNowScreen.propTypes = {
	payNowInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	payNowActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(PayNowScreen);
