import { actions } from '@libapi/APIActionsBuilder';
import PayMoneyService from '@PaymentCollectorServices/PayMoneyService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

export const onChangeAmount = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_AMOUNT,
		payload: text,
		field,
	};
};

export const onPayMoney = userDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.PAY_MONEY_SUCCESS,
		ActionTypes.PAY_MONEY_FAILURE,
		ActionTypes.PAY_MONEY_LOADER,
	);
	const payMoneyService = new PayMoneyService(dispatchedActions);
	addBasicInterceptors(payMoneyService);
	payMoneyService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(payMoneyService.makeRequest(userDetails));
};

export const onResetPayNowState = () => ({ type: ActionTypes.RESET_PAY_NOW_STATE });
