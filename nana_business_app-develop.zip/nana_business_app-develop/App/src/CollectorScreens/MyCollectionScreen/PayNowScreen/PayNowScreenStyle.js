import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import { renderFlexDirectionBasedOnRtl } from '@lib/helpers';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			justifyContent: 'flex-start',
			borderBottomWidth: verticalScale(1),
			borderBottomColor: colors.grey,
			paddingBottom: verticalScale(8),
			marginHorizontal: normalScale(16),
		},
		amount: {
			marginTop: verticalScale(16),
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			marginHorizontal: normalScale(16),
		},
		amountContainer: {
			marginTop: verticalScale(22),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			marginHorizontal: normalScale(16),
		},
		fullCheckContainer: {
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			alignItems: 'center',
		},
		fullPartial: {
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			color: colors.black,
			marginLeft: isRTL ? null : normalScale(8),
			marginRight: isRTL ? normalScale(8) : null,
		},
		partialCheckContainer: {
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			marginLeft: normalScale(101),
			alignItems: 'center',
		},
		checkUncheck: {
			height: verticalScale(14),
			width: normalScale(14),
		},
		amountText: {
			marginTop: verticalScale(29),
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		buttonView: {
			position: 'absolute',
			width: '100%',
			bottom: verticalScale(16),
			paddingHorizontal: normalScale(16),
		},
		totalAmountContainer: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			height: verticalScale(36),
			justifyContent: 'space-between',
			alignItems: 'center',
			borderBottomColor: colors.grey,
			borderBottomWidth: verticalScale(1),
			marginHorizontal: normalScale(16),
		},
		totalAmountText: {
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
		},
		totalAmount: {
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			color: colors.black,
		},
		remainingAmountContainer: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			height: verticalScale(40),
			justifyContent: 'space-between',
			alignItems: 'center',
			marginHorizontal: normalScale(16),
		},
		remainingAmountOutterContainer: {
			borderBottomColor: colors.grey,
			borderBottomWidth: verticalScale(4),
		},
		inputContainer: {
			marginHorizontal: normalScale(16),
		},
	});
};

export default createStyleSheet;
