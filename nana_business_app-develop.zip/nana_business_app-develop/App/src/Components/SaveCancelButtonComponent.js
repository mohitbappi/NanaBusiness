import React from 'react';
import { View, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import { verticalScale, normalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';
import ButtonComponent from '@ButtonComponent/ButtonComponent';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		buttonView: {
			flex: 1,
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
		button: {
			flex: 1,
			alignItems: 'center',
			justifyContent: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(36),
		},
		cancelButton: {
			backgroundColor: colors.white,
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
		},
		cancelText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
		},
		buttonContainerReject: {
			flex: 1,
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 8),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 8),
		},
		buttonContainerAccept: {
			flex: 1,
			marginRight: rtlFunctions.getMarginRight(isRTL, 8),
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
		},
	});
};

const SaveCancelButtonComponent = props => {
	// Bottom sticky button with two actions.
	const {
		isRTL,
		isButtonDisable,
		cancelText,
		onPressCancel,
		saveText,
		onPressSave,
		cancelButtonStyles,
		saveButtonStyles,
	} = props;
	const styles = createStyleSheet(isRTL);
	return (
		<View style={styles.buttonView}>
			<View style={styles.buttonContainerReject}>
				<ButtonComponent
					buttonStyle={[styles.button, styles.cancelButton, cancelButtonStyles]}
					text={cancelText}
					textStyle={styles.cancelText}
					onPress={onPressCancel}
				/>
			</View>
			<View style={styles.buttonContainerAccept}>
				<ButtonComponent
					buttonStyle={[styles.button, saveButtonStyles]}
					text={saveText}
					onPress={onPressSave}
					isButtonDisable={isButtonDisable}
				/>
			</View>
		</View>
	);
};

SaveCancelButtonComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	isButtonDisable: PropTypes.bool.isRequired,
	saveButtonStyles: PropTypes.object.isRequired,
	onPressCancel: PropTypes.func.isRequired,
	cancelText: PropTypes.string.isRequired,
	saveText: PropTypes.string.isRequired,
	onPressSave: PropTypes.func.isRequired,
	cancelButtonStyles: PropTypes.object.isRequired,
};

export default SaveCancelButtonComponent;
