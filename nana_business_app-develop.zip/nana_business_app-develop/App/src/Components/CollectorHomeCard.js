import React, { useState } from 'react';
import { Text, View, StyleSheet, Dimensions } from 'react-native';
import PropTypes from 'prop-types';
import Accordion from 'react-native-collapsible/Accordion';
import * as colors from '@assets/colors';
import normalize, { verticalScale, normalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';
import { keyConstants } from '@assets/Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import IMAGES from '@Images/index';

const rtlFunctions = new RTLFunctions();
const { width } = Dimensions.get('window');

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		card: {
			paddingTop: verticalScale(16),
			paddingBottom: verticalScale(16),
			borderTopLeftRadius: moderateScale(8),
			borderTopRightRadius: moderateScale(8),
			backgroundColor: colors.skyBlue,
			paddingHorizontal: verticalScale(16),
			marginTop: verticalScale(16),
		},
		innerCard: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			justifyContent: 'center',
		},
		amountCard: {
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 33),
			marginRight: rtlFunctions.getMarginRight(isRTL, 33),
		},
		totalText: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			alignSelf: 'center',
		},
		amountText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			alignSelf: 'center',
			marginTop: verticalScale(4),
		},
		iconArrowDown: {
			width: normalScale(10),
			height: verticalScale(6),
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 33),
			marginRight: rtlFunctions.getMarginRight(isRTL, 33),
		},
		iconArrowUp: {
			transform: [{ rotate: '180deg' }],
		},
		newCard: {
			paddingBottom: verticalScale(16),
			borderBottomLeftRadius: moderateScale(8),
			borderBottomRightRadius: moderateScale(8),
			backgroundColor: colors.skyBlue,
			paddingHorizontal: verticalScale(16),
		},
		dueAmountView: {
			paddingVertical: verticalScale(2),
			paddingHorizontal: verticalScale(8),
			borderColor: colors.darkOrange,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(4),
			marginBottom: verticalScale(6),
			alignSelf: 'center',
		},
		dueText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		progressBar: {
			width: width - normalScale(64),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			height: verticalScale(4),
			borderRadius: moderateScale(4.5),
			backgroundColor: colors.lightBlueShadowGrey,
		},
		pendingAmount: {
			backgroundColor: colors.darkOrange,
		},
		detailView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(6),
		},
		rejectedText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		rejectedAmountStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			marginTop: verticalScale(2),
		},
		text: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
			textAlign: rtlFunctions.getTextAlignOpposite(isRTL),
		},
		amountStyle: {
			fontSize: normalize(10),
			marginTop: verticalScale(2),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
	});
};

const CollectorHomeCard = props => {
	// Component to show the payment details in form of card.

	const [activeSections, setActiveSections] = useState([]);

	const {
		isRTL,
		error,
		errorCode,
		totalWallet,
		approvedTransaction,
		amountDeposited,
		pendingAmount,
		onGetWalletDetails,
		hasCollapsableView,
	} = props;
	const styles = createStyleSheet(isRTL);

	const getHeader = (section = null) => {
		return (
			<View style={styles.card}>
				<View style={styles.innerCard}>
					<View style={hasCollapsableView && styles.amountCard}>
						<Text style={styles.totalText}>
							{localeString(keyConstants.DEPOSITED_BALANCE)}
						</Text>
						<Text style={styles.amountText}>
							{`${currencyFormatter(
								getValueInDecimal(approvedTransaction),
							)} ${localeString(keyConstants.SAR)}`}
						</Text>
					</View>
					{hasCollapsableView ? (
						<ImageLoadComponent
							source={IMAGES.iconArrowDown}
							style={[
								styles.iconArrowDown,
								activeSections.includes(section.index) && styles.iconArrowUp,
							]}
						/>
					) : null}
				</View>
			</View>
		);
	};

	const getContent = () => {
		return (
			<View style={styles.newCard}>
				<View>
					<View style={styles.dueAmountView}>
						<Text style={styles.dueText}>
							{`${localeString(keyConstants.TO_BE_DEPOSIT)} ${currencyFormatter(
								getValueInDecimal(pendingAmount),
							)}`}
						</Text>
					</View>
				</View>
				<View style={styles.progressBar}>
					<View
						style={[
							styles.pendingAmount,
							{
								width: `${
									(getValueInDecimal(pendingAmount) /
										getValueInDecimal(totalWallet)) *
									100
								}%`,
							},
						]}
					/>
				</View>
				<View style={styles.detailView}>
					<View>
						<Text style={styles.rejectedText}>
							{localeString(keyConstants.APPROVAL_PENDING)}
						</Text>
						<Text style={styles.rejectedAmountStyle}>
							{`${currencyFormatter(
								getValueInDecimal(amountDeposited),
							)} ${localeString(keyConstants.SAR)}`}
						</Text>
					</View>
					<View>
						<Text style={styles.text}>{localeString(keyConstants.TOTAL_AMOUNT)}</Text>
						<Text style={styles.amountStyle}>
							{`${currencyFormatter(getValueInDecimal(totalWallet))} ${localeString(
								keyConstants.SAR,
							)}`}
						</Text>
					</View>
				</View>
			</View>
		);
	};

	const renderContent = section => {
		return section.content;
	};

	const updateSections = sections => {
		setActiveSections(sections);
	};

	return error ? (
		<ErrorComponent
			isRTL={isRTL}
			errorCode={errorCode}
			onCallApi={onGetWalletDetails}
			isSectionComponent
		/>
	) : hasCollapsableView ? (
		<Accordion
			sections={[
				{
					content: getContent(),
					index: 0,
				},
			]}
			activeSections={activeSections}
			renderHeader={getHeader}
			renderContent={renderContent}
			onChange={updateSections}
			underlayColor={colors.white}
		/>
	) : (
		<>
			{getHeader()}
			{getContent()}
		</>
	);
};

CollectorHomeCard.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	totalWallet: PropTypes.number.isRequired,
	approvedTransaction: PropTypes.number.isRequired,
	amountDeposited: PropTypes.number.isRequired,
	pendingAmount: PropTypes.number.isRequired,
	onGetWalletDetails: PropTypes.func.isRequired,
	hasCollapsableView: PropTypes.bool.isRequired,
};

export default CollectorHomeCard;
