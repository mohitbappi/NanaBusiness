import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import { localeString } from '@assets/Localization';
import { passwordMaxLength, spaceRegexEx } from '@Constants/Constants';
import IMAGES from '@Images/index';
import Input from '@Input/Input';
import { keyConstants } from '@Constants/KeyConstants';
import RTLFunctions from '@Util/RTLFunctions';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		informationView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(9),
		},
		iconInformation: {
			height: verticalScale(12),
			width: normalScale(12),
		},
		passwordText: {
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			fontSize: normalize(10),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.black,
			letterSpacing: normalScale(0),
		},
	});
};

const SetNewPasswordComponent = props => {
	const {
		isRTL,
		isShowPasswordInformation,
		newPassword,
		errorPasswordValidationMessage,
		confirmNewPassword,
		errorConfirmPasswordValidationMessage,
		onChangeText,
		showPasswordInformation,
		onBlur,
		onMatchPassword,
		onSubmitRef,
		refCallback,
		newPasswordRef,
		confirmPasswordRef,
	} = props;
	const styles = createStyleSheet(isRTL);
	return (
		<>
			<Input
				maxLength={passwordMaxLength}
				value={newPassword}
				width={normalScale(260)}
				label={`${localeString(keyConstants.NEW_PASSWORD)}*`}
				placeholder={localeString(keyConstants.NEW_PASSWORD)}
				blurOnSubmit={false}
				returnKeyType="next"
				isRTL={isRTL}
				onChangeText={text =>
					(spaceRegexEx.test(String(text).toLocaleLowerCase()) || text === '') &&
					onChangeText(text, 'newPassword')
				}
				isError={errorPasswordValidationMessage}
				onSubmitEditing={() => onSubmitRef(confirmPasswordRef)}
				autoCapitalize="none"
				errorMessage={localeString(keyConstants.INVALID_PASSWORD_FORMAT)}
				refs={refCallback(newPasswordRef)}
				onFocus={() => showPasswordInformation(true)}
				onBlur={() => {
					showPasswordInformation(false);
					onBlur();
				}}
				hasIconPassword
			/>
			{isShowPasswordInformation && (
				<View style={styles.informationView}>
					<ImageLoadComponent
						source={IMAGES.iconInformation}
						style={styles.iconInformation}
					/>
					<Text style={styles.passwordText}>
						{localeString(keyConstants.PASSWORD_INFORMATION)}
					</Text>
				</View>
			)}
			<Input
				maxLength={passwordMaxLength}
				value={confirmNewPassword}
				width={normalScale(260)}
				label={`${localeString(keyConstants.CONFIRM_NEW_PASSWORD)}*`}
				placeholder={localeString(keyConstants.CONFIRM_NEW_PASSWORD)}
				blurOnSubmit
				returnKeyType="done"
				isRTL={isRTL}
				onChangeText={text =>
					(spaceRegexEx.test(String(text).toLocaleLowerCase()) || text === '') &&
					onChangeText(text, 'confirmNewPassword')
				}
				isError={errorConfirmPasswordValidationMessage}
				onBlur={onMatchPassword}
				refs={refCallback(confirmPasswordRef)}
				autoCapitalize="none"
				errorMessage={localeString(keyConstants.PASSWORD_DOES_NOT_MATCH)}
				hasIconPassword
			/>
		</>
	);
};

SetNewPasswordComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	isShowPasswordInformation: PropTypes.bool.isRequired,
	errorPasswordValidationMessage: PropTypes.bool.isRequired,
	errorConfirmPasswordValidationMessage: PropTypes.bool.isRequired,
	onChangeText: PropTypes.func.isRequired,
	confirmNewPassword: PropTypes.string.isRequired,
	newPassword: PropTypes.string.isRequired,
	showPasswordInformation: PropTypes.func.isRequired,
	onBlur: PropTypes.func.isRequired,
	onMatchPassword: PropTypes.func.isRequired,
	onSubmitRef: PropTypes.func.isRequired,
	refCallback: PropTypes.func.isRequired,
	newPasswordRef: PropTypes.object.isRequired,
	confirmPasswordRef: PropTypes.object.isRequired,
};

export default SetNewPasswordComponent;
