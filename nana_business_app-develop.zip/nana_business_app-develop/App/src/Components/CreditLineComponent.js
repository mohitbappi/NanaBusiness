import React from 'react';
import { View, StyleSheet, ImageBackground, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import normalize, { verticalScale, normalScale, moderateScale } from '@device/normalize';
import IMAGES from '@Images/index';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';
import Loader from '@Loader/Loader';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		creditLineView: {
			backgroundColor: colors.skyBlue,
			height: normalScale(80),
			borderRadius: normalScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			paddingHorizontal: normalScale(16),
			justifyContent: 'space-between',
		},
		activityIndicatorStyle: {
			flex: 1,
		},
		creditView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		creditBackground: {
			height: normalScale(48),
			width: normalScale(48),
			resizeMode: 'contain',
			justifyContent: 'center',
			alignItems: 'center',
		},
		creditShadow: {
			shadowColor: colors.pureBlack,
			shadowOffset: {
				width: normalScale(12),
				height: verticalScale(11),
			},
			shadowRadius: moderateScale(21),
			shadowOpacity: 0.3,
			elevation: verticalScale(11),
			height: verticalScale(28),
			width: normalScale(20),
		},
		iconLoan: {
			height: verticalScale(23),
			width: normalScale(29),
			marginLeft: -normalScale(2),
		},
		credit: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			marginLeft: isRTL ? 0 : normalScale(7),
			marginRight: isRTL ? normalScale(7) : 0,
		},
		creditLine: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
			marginTop: verticalScale(2),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
	});
};

const CreditLineComponent = props => {
	// Component to show Used/Total Amount of credit line.
	const { isRTL, title, amount, onPress, titleStyle, loader } = props;
	const styles = createStyleSheet(isRTL);
	return (
		<TouchableOpacity style={styles.creditLineView} activeOpacity={1} onPress={onPress}>
			{loader ? (
				<Loader
					isSmallLoader
					activityIndicatorStyle={styles.activityIndicatorStyle}
					color={colors.lightBlueShadowGrey}
				/>
			) : (
				<View style={styles.creditView}>
					<ImageBackground
						source={IMAGES.iconGreenBackground}
						style={styles.creditBackground}>
						<View style={styles.creditShadow}>
							<ImageLoadComponent source={IMAGES.iconLoan} style={styles.iconLoan} />
						</View>
					</ImageBackground>
					<View>
						<Text style={styles.credit}>{amount}</Text>
						<Text style={[styles.creditLine, titleStyle]}>{title}</Text>
					</View>
				</View>
			)}
		</TouchableOpacity>
	);
};

CreditLineComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onPress: PropTypes.func.isRequired,
	titleStyle: PropTypes.object.isRequired,
	loader: PropTypes.bool.isRequired,
	title: PropTypes.string.isRequired,
	amount: PropTypes.string.isRequired,
};

export default CreditLineComponent;
