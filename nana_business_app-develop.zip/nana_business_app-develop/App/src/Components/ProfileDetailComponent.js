import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import normalize, { verticalScale, normalScale } from '@device/normalize';
import { localeString } from '@assets/Localization';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		menuView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			height: verticalScale(48),
			alignItems: 'center',
			marginBottom: verticalScale(16),
		},
		mainContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			flex: 1,
		},
		innerContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		iconImage: {
			height: verticalScale(30),
			width: normalScale(30),
		},
		label: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		value: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
			marginTop: verticalScale(4),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		socialContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
	});
};

const ProfileDetailComponent = props => {
	// Component to show the my account screen attributes.
	const { isRTL, item, onPressContact, socialIconsArray, hasSocialMediaIcons } = props;
	const styles = createStyleSheet(isRTL);
	return (
		<TouchableOpacity activeOpacity={0.8} style={styles.menuView} onPress={onPressContact}>
			<View style={styles.mainContainer}>
				<View style={styles.innerContainer}>
					<ImageLoadComponent source={item.image} style={styles.iconImage} />
					<View>
						<Text style={styles.label}>{localeString(item.label)}</Text>
						<Text style={styles.value}>{item.value}</Text>
					</View>
				</View>
				{/* Will give functionality to call, sms and whatsapp to the given number. */}
				{hasSocialMediaIcons ? (
					<View style={styles.socialContainer}>
						{socialIconsArray.map(element => {
							return (
								<TouchableOpacity activeOpacity={0.8} onPress={element.action}>
									<ImageLoadComponent
										source={element.iconImage}
										style={element.style}
									/>
								</TouchableOpacity>
							);
						})}
					</View>
				) : null}
			</View>
		</TouchableOpacity>
	);
};

ProfileDetailComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	item: PropTypes.object.isRequired,
	onPressContact: PropTypes.func.isRequired,
	socialIconsArray: PropTypes.array.isRequired,
	hasSocialMediaIcons: PropTypes.bool.isRequired,
};

export default ProfileDetailComponent;
