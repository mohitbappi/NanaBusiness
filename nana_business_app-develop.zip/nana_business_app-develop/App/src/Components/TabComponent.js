import React, { Component } from 'react';
import { Text, View, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import { localeString } from '@assets/Localization';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		tabView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			marginBottom: verticalScale(12),
		},
		activeTabView: {
			height: verticalScale(24),
			paddingHorizontal: normalScale(12),
			borderRadius: moderateScale(12),
			backgroundColor: colors.black,
			shadowColor: colors.pureBlack,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(4),
			shadowOpacity: 0.16,
			elevation: verticalScale(2),
			marginHorizontal: normalScale(8),
			justifyContent: 'center',
		},
		inactiveTabView: {
			height: verticalScale(24),
			paddingHorizontal: normalScale(12),
			borderRadius: moderateScale(12),
			backgroundColor: colors.greenShadow,
			marginHorizontal: normalScale(8),
			justifyContent: 'center',
		},
		activeText: {
			color: colors.white,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		inactiveText: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
		},
	});
};
class TabComponent extends Component {
	// Component to create a multiple tabs.
	keyExtractor = (item, index) => index.toString();

	render() {
		const { isRTL, activeTabIndex, data, onPressTab, inverted } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.tabView}>
				<FlatList
					data={data}
					inverted={inverted}
					renderItem={({ item, index }) => {
						return (
							<TouchableOpacity
								style={
									activeTabIndex === index
										? styles.activeTabView
										: styles.inactiveTabView
								}
								activeOpacity={0.8}
								onPress={() => onPressTab(index)}>
								<Text
									style={
										activeTabIndex === index
											? styles.activeText
											: styles.inactiveText
									}>
									{localeString(item)}
								</Text>
							</TouchableOpacity>
						);
					}}
					keyExtractor={this.keyExtractor}
					showsHorizontalScrollIndicator={false}
					horizontal
				/>
			</View>
		);
	}
}

TabComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	activeTabIndex: PropTypes.element.isRequired,
	data: PropTypes.array.isRequired,
	onPressTab: PropTypes.func.isRequired,
	inverted: PropTypes.bool.isRequired,
};

export default TabComponent;
