import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import MapView, { Marker } from 'react-native-maps';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import Input from '@Input/Input';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import { addressMaxLength } from '@Constants/Constants';
import IMAGES from '@Images/index';
import fonts from '@assets/fonts';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		signUpFinalMapView: {
			marginTop: verticalScale(24),
		},
		mapSmall: {
			width: normalScale(288),
			height: verticalScale(120),
			borderRadius: normalScale(8),
		},
		mapButton: {
			height: verticalScale(36),
			backgroundColor: colors.white,
			alignItems: 'center',
			justifyContent: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			borderColor: colors.darkBlue,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(8),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(15),
			},
			shadowRadius: moderateScale(14),
			shadowOpacity: 0.6,
			elevation: verticalScale(15),
			marginTop: verticalScale(16),
		},
		iconMap: {
			height: verticalScale(20),
			width: normalScale(20),
		},
		buttonText: {
			color: colors.darkBlue,
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		textStyle: {
			color: colors.lightWhite,
			paddingVertical: verticalScale(5),
		},
	});
};

const SmallMapComponent = props => {
	// Component to select the location or show the map preview.
	const {
		region,
		isRTL,
		addressLine1,
		addressLine2,
		onSelectLocation,
		onChangeText,
		onSubmitRef,
		nameRef,
		mapStyle,
		notExistsInputFields,
	} = props;
	const styles = createStyleSheet(isRTL);
	return (
		<>
			{region ? (
				<TouchableOpacity style={[styles.signUpFinalMapView, mapStyle]}>
					<MapView
						style={styles.mapSmall}
						initialRegion={region}
						showsUserLocation
						onPress={onSelectLocation}
						zoomEnabled={false}>
						<Marker
							coordinate={{
								latitude: region.latitude,
								longitude: region.longitude,
							}}
							draggable={false}
							onLoad={null}
							image={IMAGES.iconLocationPin}
						/>
					</MapView>
				</TouchableOpacity>
			) : (
				<TouchableOpacity
					style={styles.mapButton}
					activeOpacity={0.8}
					onPress={onSelectLocation}>
					<ImageLoadComponent source={IMAGES.iconMap} style={styles.iconMap} />
					<Text style={styles.buttonText}>
						{localeString(keyConstants.SELECT_LOACATION_VIA_MAP)}
					</Text>
				</TouchableOpacity>
			)}
			{!notExistsInputFields && (
				<>
					<Input
						maxLength={addressMaxLength}
						value={addressLine1}
						height={verticalScale(64)}
						width={normalScale(288)}
						label={`${localeString(keyConstants.ADDRESS_LINE_1)}*`}
						placeholder={localeString(keyConstants.ADDRESS_LINE_1)}
						isRTL={isRTL}
						editable={false}
						hasNoShadow
						textInputStyle={styles.textStyle}
						multiline
						textAlignVertical="center"
					/>
					<Input
						maxLength={addressMaxLength}
						value={addressLine2}
						width={normalScale(288)}
						label={localeString(keyConstants.ADDRESS_LINE_2)}
						placeholder={localeString(keyConstants.OPTIONAL)}
						blurOnSubmit
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => onChangeText(text, 'addressLine2')}
						autoCapitalize="none"
						onSubmitEditing={nameRef ? () => onSubmitRef(nameRef) : null}
					/>
				</>
			)}
		</>
	);
};

SmallMapComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	notExistsInputFields: PropTypes.bool.isRequired,
	onChangeText: PropTypes.func.isRequired,
	addressLine1: PropTypes.string.isRequired,
	addressLine2: PropTypes.string.isRequired,
	onSelectLocation: PropTypes.func.isRequired,
	onSubmitRef: PropTypes.func.isRequired,
	nameRef: PropTypes.func.isRequired,
	region: PropTypes.object.isRequired,
	mapStyle: PropTypes.object.isRequired,
};

export default SmallMapComponent;
