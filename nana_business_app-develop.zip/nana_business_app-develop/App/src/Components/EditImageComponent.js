import React from 'react';
import {
	View,
	StyleSheet,
	ImageBackground,
	TouchableOpacity,
	ActivityIndicator,
} from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import { verticalScale, normalScale, moderateScale } from '@device/normalize';
import IMAGES from '@Images/index';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import RTLFunctions from '@Util/RTLFunctions';
import { IMAGE_TYPE } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		imageViewEdit: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(24),
			paddingVertical: verticalScale(16),
			justifyContent: 'center',
		},
		innerImageView: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
			justifyContent: 'center',
			shadowColor: colors.shadowGreen,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(10),
			},
			shadowRadius: moderateScale(14),
			shadowOpacity: 0.4,
		},
		defaultImage: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
		},
		iconCameraContainer: {
			position: 'absolute',
			right: -normalScale(10),
			bottom: -normalScale(10),
			height: normalScale(42),
			width: normalScale(42),
		},
		imageSmallCamera: {
			height: normalScale(28),
			width: normalScale(28),
			position: 'absolute',
			right: normalScale(0),
			bottom: normalScale(0),
		},
	});
};

const EditImageComponent = props => {
	// Image Component to upload the image.
	const { isRTL, imageLoader, profile_pic, onImageSelectorVisible } = props;
	const styles = createStyleSheet(isRTL);
	return (
		<ImageBackground source={IMAGES.imageBackgroundGradient} style={styles.imageViewEdit}>
			<View style={styles.innerImageView}>
				{imageLoader ? (
					<ActivityIndicator size="small" color={colors.darkBlue} />
				) : (
					<ImageLoadComponent
						imageType={IMAGE_TYPE.account}
						isUrl={profile_pic}
						source={profile_pic || IMAGES.iconProfileBorder}
						style={styles.defaultImage}
					/>
				)}
				<TouchableOpacity
					activeOpacity={0.8}
					onPress={onImageSelectorVisible}
					style={styles.iconCameraContainer}>
					<ImageLoadComponent
						imageType={IMAGE_TYPE.account}
						source={IMAGES.iconCameraGreenFilled}
						style={styles.imageSmallCamera}
					/>
				</TouchableOpacity>
			</View>
		</ImageBackground>
	);
};

EditImageComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	imageLoader: PropTypes.bool.isRequired,
	onImageSelectorVisible: PropTypes.func.isRequired,
	profile_pic: PropTypes.string.isRequired,
};

export default EditImageComponent;
