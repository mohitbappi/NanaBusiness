import React, { Component } from 'react';
import { View, StyleSheet } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import * as SalesInvoiceActions from '@SalesInvoiceScreen/SalesInvoiceScreenAction';
import * as colors from '@assets/colors';
import { normalScale, verticalScale } from '@device/normalize';
import { languageConstants, toastShowTime } from '@Constants/Constants';
import { downloadFile } from '@Util/DownloadFile';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@assets/Constants/KeyConstants';
import ToastComponent from '@ToastComponent/ToastComponent';

const createStyleSheet = () => {
	return StyleSheet.create({
		driverButtonView: {
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
		},
	});
};

class DownloadSalesInvoice extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isShowToast: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { onRef } = this.props;
		if (onRef) {
			onRef(this); // Will set ref this
		}
	}

	componentDidUpdate(prevProps) {
		const { salesInvoiceInfo } = this.props;
		const { success, isDownload, downloadUrl } = salesInvoiceInfo;
		const { downloadFileName } = this.props;
		if (
			success &&
			isDownload &&
			downloadFileName &&
			prevProps.salesInvoiceInfo.success !== salesInvoiceInfo.success
		) {
			// Will download the invoice after successful response of the api.
			downloadFile(
				downloadUrl, // Url of the invoice.
				downloadFileName, // File name of the downloaded invoice.
				() => {
					this.onShowDownloadFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
				},
				() => {
					this.onShowDownloadFileStatus(
						localeString(keyConstants.SUCCESSFULLY_DOWNLOADED),
					);
				},
				() => {
					this.onShowDownloadFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
				},
			);
		}
	}

	componentWillUnmount() {
		const { onRef } = this.props;
		if (onRef) {
			onRef(null); // Will set ref null
		}
	}

	onShowDownloadFileStatus = message => {
		// Function to show downloading status as a toast.
		this.setState({
			toastMessage: message,
			isShowToast: true,
		});
		setTimeout(() => {
			this.setState({
				isShowToast: false,
			});
		}, toastShowTime);
	};

	onDownloadSalesInvoice = id => {
		// API call to download the invoice.
		const { isRTL, salesInvoiceActions } = this.props;
		const queryParams = {};
		queryParams.sales_invoice_ids = id;
		queryParams.invoice_language = isRTL ? languageConstants.ar : languageConstants.en;
		salesInvoiceActions.onDownloadTemplate(queryParams);
	};

	renderToastComponent = isRTL => {
		// Component to show the downloading status.
		const { isShowToast, toastMessage } = this.state;
		return (
			<ToastComponent isRTL={isRTL} isApiError={isShowToast} toastMessage={toastMessage} />
		);
	};

	render() {
		const { salesInvoiceId, title, isRTL, hasButton } = this.props;
		const styles = createStyleSheet();
		if (hasButton) {
			return (
				<>
					<View style={styles.driverButtonView}>
						<ButtonComponent
							text={title}
							onPress={() => this.onDownloadSalesInvoice(salesInvoiceId)}
						/>
					</View>
					{this.renderToastComponent(isRTL)}
				</>
			);
		}
		return this.renderToastComponent(isRTL);
	}
}

const mapStateToProps = state => {
	return {
		salesInvoiceInfo: state.SalesInvoiceScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		salesInvoiceActions: bindActionCreators({ ...SalesInvoiceActions }, dispatch),
	};
};

DownloadSalesInvoice.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	hasButton: PropTypes.func.isRequired,
	salesInvoiceId: PropTypes.any.isRequired,
	onRef: PropTypes.object.isRequired,
	salesInvoiceInfo: PropTypes.object.isRequired,
	salesInvoiceActions: PropTypes.object.isRequired,
	title: PropTypes.string.isRequired,
	downloadFileName: PropTypes.string.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(DownloadSalesInvoice);
