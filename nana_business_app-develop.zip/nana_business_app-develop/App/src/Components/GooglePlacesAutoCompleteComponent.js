import React from 'react';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import Config from 'react-native-config';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import { normalScale } from '@device/normalize';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { noOfMinCharToSearch } from '@Constants/Constants';

const GooglePlacesAutoCompleteComponent = props => {
	const GooglePlacesAutocompleteStyles = {
		description: {
			backgroundColor: colors.white,
		},
		predefinedPlacesDescription: {
			color: colors.lightGrey,
			backgroundColor: colors.white,
		},
		textInputContainer: {
			zIndex: 500,
		},
		textInput: {
			backgroundColor: colors.white,
			borderBottomWidth: normalScale(0.5),
			borderColor: colors.grey,
		},
		listView: {
			elevation: 1,
			backgroundColor: colors.white,
			zIndex: 500,
		},
	};

	const { onSelectAddressSearch, predefinedPlaces } = props;
	return (
		<GooglePlacesAutocomplete
			placeholder={localeString(keyConstants.SEARCH)}
			minLength={noOfMinCharToSearch}
			fetchDetails
			listViewDisplayed={false}
			enablePoweredByContainer={false}
			returnKeyType="search"
			onPress={(data, details = null) => {
				const { location } = details.geometry;
				onSelectAddressSearch(location);
			}}
			query={{
				key: Config.GOOGLE_API_KEY,
				language: 'en',
			}}
			predefinedPlaces={predefinedPlaces}
			textInputProps={{ placeholderTextColor: colors.blackGreyWhite }}
			styles={GooglePlacesAutocompleteStyles}
		/>
	);
};

GooglePlacesAutoCompleteComponent.propTypes = {
	predefinedPlaces: PropTypes.array.isRequired,
	onSelectAddressSearch: PropTypes.func.isRequired,
};

export default GooglePlacesAutoCompleteComponent;
