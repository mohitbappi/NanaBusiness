import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import { getFormattedDate } from '@Util/GetFormattedDate';
import * as colors from '@assets/colors';
import normalize, { verticalScale } from '@device/normalize';
import RectangleCard from '@RectangleCard/RectangleCard';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import fonts from '@assets/fonts';

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		userInfoContainer: {
			borderBottomWidth: verticalScale(1),
			borderColor: colors.grey,
			justifyContent: 'center',
		},
		pendingView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
		},
		pending: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(12),
		},
		viewInvoices: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(12),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(12),
		},
	});
};

const PendingRequestComponent = props => {
	// Component to show the list of the pending requests.
	const { isRTL, pendingRequestsList, viewAllPendingRequests } = props;
	const styles = createStyleSheet(isRTL);
	return (
		<>
			<View style={styles.pendingView}>
				<Text style={styles.pending}>{localeString(keyConstants.PENDING_REQUESTS)}</Text>
				<TouchableOpacity activeOpacity={0.8} onPress={viewAllPendingRequests}>
					<Text style={styles.viewInvoices}>
						{localeString(keyConstants.VIEW_ALL_REQUESTS)}
					</Text>
				</TouchableOpacity>
			</View>
			{pendingRequestsList.map(item => {
				return (
					<View style={styles.userInfoContainer}>
						<RectangleCard
							name={item.name}
							isCompany
							userDetails={item.org_name}
							date={getFormattedDate(item.created_at)}
							isStatus
						/>
					</View>
				);
			})}
		</>
	);
};

PendingRequestComponent.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	pendingRequestsList: PropTypes.array.isRequired,
	viewAllPendingRequests: PropTypes.string.isRequired,
};

export default PendingRequestComponent;
