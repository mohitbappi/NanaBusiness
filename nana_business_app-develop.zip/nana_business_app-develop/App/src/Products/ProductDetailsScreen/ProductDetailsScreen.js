import React, { Component } from 'react';
import { Text, View, ScrollView, FlatList } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import * as ItemListScreenAction from '@ItemListScreen/ItemListScreenAction';
import {
	CART_OPERATION,
	toastShowTime,
	productMaxQuantity,
	fetchDataWithPagination,
	locatorConstants,
} from '@Constants/Constants';
import * as CartDetailActions from '@CartScreen/CartScreenAction';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import navigations from '@routes/navigations';
import CartFloater from '@CartFloater/CartFloater';
import ProductDetailCardComponent from '@Products/ProductDetailCardComponent';
import HomeItemComponent from '@HomeItemComponent/HomeItemComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import Loader from '@Loader/Loader';
import * as ProductListScreenAction from '@ProductListScreen/ProductListScreenAction';
import ListEmpty from '@ListEmpty/ListEmpty';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import getTestIdProps from '@Util/GetTestIdProps';
import { createStyleSheet } from './ProductDetailsScreenStyle';
import * as ProductDetailsScreenAction from './ProductDetailsScreenAction';

class ProductDetailsScreen extends Component {
	constructor(props) {
		super(props);
		const { id } = props.route.params;
		this.itemId = id;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.cartFloater = React.createRef(null);
		this.state = {
			item: {},
			itemCountToUpdate: null,
			isShowDetail: false,
			productListItems: [],
			changeQuantityCount: 0,
			itemIndexToUpdate: null,
			isItemDeleted: false,
			isItemInWishlist: null,
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.getProductDetail();
			this.onGetMoreDetails();
			this.onGetCartCount();
		});
	}

	componentDidUpdate(prevProps) {
		const { productDetailsInfo, itemListScreenInfo, cartDetailInfo } = this.props;
		const {
			successCart,
			updateSuccess,
			errorCart,
			success,
			relatedProducts,
			itemDetail,
			isRelatedProduct,
			errorCodeCart,
		} = productDetailsInfo;
		const { isDeletedFromWishList, success: successAddWishlist } = itemListScreenInfo;
		const {
			itemCountToUpdate,
			itemIndexToUpdate,
			changeQuantityCount,
			isItemDeleted,
			item,
			productListItems,
		} = this.state;
		if (success && prevProps.productDetailsInfo !== productDetailsInfo) {
			if (isRelatedProduct) {
				this.setState({
					productListItems: relatedProducts,
				});
			} else {
				this.setState(
					{
						item: itemDetail,
						isItemInWishlist: itemDetail ? itemDetail.is_wishlisted : null,
					},
					() => {
						if (itemDetail) {
							this.getRelatedProducts();
						}
					},
				);
			}
		}
		if (
			successAddWishlist &&
			!isDeletedFromWishList &&
			prevProps.itemListScreenInfo.success !== itemListScreenInfo.success
		) {
			// if item is added to wishlist successfully
			this.setState(
				{
					isItemInWishlist: true,
					toastMessage: `${localeString(keyConstants.ADDED_TO_WISHLIST)}`,
					isApiError: true,
				},
				() => {
					setTimeout(() => {
						this.setState({
							isApiError: false,
						});
					}, toastShowTime);
				},
			);
		}
		if (
			isDeletedFromWishList &&
			prevProps.itemListScreenInfo.success !== itemListScreenInfo.success
		) {
			// if item is removed from wishlist successfully
			this.setState(
				{
					isItemInWishlist: false,
					toastMessage: `${localeString(keyConstants.REMOVED_FROM_WISHLIST)}`,
					isApiError: true,
				},
				() => {
					setTimeout(() => {
						this.setState({
							isApiError: false,
						});
					}, toastShowTime);
				},
			);
		}
		if (
			successCart &&
			prevProps.productDetailsInfo.successCart !== productDetailsInfo.successCart
		) {
			// if item is added to cart successfully
			let itemCopy = { ...item };
			itemCopy = { ...itemCopy, count_in_cart: itemCountToUpdate };
			this.setState(
				{
					item: itemCopy,
				},
				() => {
					this.onGetCartCount();
					this.cartFloater.current.handleCartFloater();
				},
			);
		}
		if (
			updateSuccess &&
			itemIndexToUpdate !== null &&
			prevProps.productDetailsInfo.updateSuccess !== productDetailsInfo.updateSuccess
		) {
			// if item quantity in cart updated successfully
			this.setState(
				{
					itemIndexToUpdate: null,
				},
				() => {
					this.getRelatedProducts();
					this.onGetCartCount();
					this.cartFloater.current.handleCartFloater();
				},
			);
		}
		if (
			cartDetailInfo.successCart &&
			prevProps.cartDetailInfo.successCart !== cartDetailInfo.successCart
		) {
			if (isItemDeleted) {
				// if item is removed from cart successfully
				let itemCopy = { ...item };
				itemCopy = { ...itemCopy, count_in_cart: itemCountToUpdate };
				this.setState(
					{
						item: itemCopy,
					},
					() => {
						this.onGetCartCount();
						this.cartFloater.current.handleCartFloater();
					},
				);
			} else {
				this.getRelatedProducts();
			}
		}
		if (errorCart && prevProps.productDetailsInfo.errorCart !== productDetailsInfo.errorCart) {
			if (errorCodeCart.error === keyConstants.ADD_ITEM_ERROR) {
				this.setState(
					{
						toastMessage: localeString(keyConstants.ADD_ITEM_ERROR),
						isApiError: true,
					},
					() => {
						setTimeout(() => {
							this.setState({
								isApiError: false,
							});
						}, toastShowTime);
					},
				);
			}
			if (itemIndexToUpdate !== null) {
				// if item add to cart return failure
				const productListItemsCopy = [...productListItems];
				productListItemsCopy[itemIndexToUpdate].count_in_cart = changeQuantityCount;
				this.setState({
					productListItems: productListItemsCopy,
					itemIndexToUpdate: null,
				});
			}
		}
	}

	componentWillUnmount() {
		// Reset product details screen reducer when unmount
		const { productDetailsScreenAction } = this.props;
		productDetailsScreenAction.onResetState();
	}

	getActionType = (count, action) => {
		switch (action) {
			case 0: // TODO to increase item quantity
				return count + 1;
			case 1: // TODO to decrease item quantity
				return count - 1;
			case 2: // TODO to replace item quantity
				return count;
			default:
				return null;
		}
	};

	navigateTo = item => {
		const { navigation } = this.props;
		navigation.push(navigations.PRODUCT_DETAILS_NAVIGATION, { id: item.id });
	};

	renderItem = ({ item }) => {
		// render related product list item component
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		return (
			<HomeItemComponent
				onPress={() => this.navigateTo(item)}
				isRTL={isRTL}
				image={item.images && item.images.large}
				name={isRTL ? item.name_ar : item.name}
				price={item.price_with_vat}
				offerPrice={item.offer_price_with_vat}
				itemsPerPacket={item.items_per_packet}
				valueOfItem={item.value_of_item}
				unit={isRTL ? item.unit_ar : item.unit}
			/>
		);
	};

	keyExtractor = index => index.toString();

	onPressCart = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.CART_NAVIGATION);
	};

	onPressBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onPressPlus = action => {
		const { item } = this.state;
		const { id, count_in_cart, warehouse_id, vendor_organization_id, minimum_quantity } = item;
		const { productDetailsScreenAction, route, productListScreenActions } = this.props;
		const { itemIndex } = route.params || {};
		if (action === CART_OPERATION.REMOVE && count_in_cart === minimum_quantity) {
			// if remove item from cart
			this.onRemoveItemFromCart();
		} else if (action === CART_OPERATION.ADD && count_in_cart === productMaxQuantity) {
			// if add item to cart above max quantity
			this.setState({
				toastMessage: `${localeString(
					keyConstants.MAXIMUM_QUANTITY,
				)} ${productMaxQuantity}`,
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		} else {
			// add and update item quantity in cart
			if (count_in_cart === null) {
				logCustomEventOnBraze('productAddedToCart', { itemId: id });
			}
			const quantity = this.getUpdatedCount(count_in_cart, action, minimum_quantity);
			const queryparam = {};
			queryparam.item_id = id;
			queryparam.quantity = quantity;
			queryparam.warehouse_id = warehouse_id;
			queryparam.vendor_id = vendor_organization_id;
			this.setState(
				{
					itemCountToUpdate: quantity,
				},
				() => {
					if (itemIndex) {
						productListScreenActions.onUpdateItem(itemIndex, quantity);
					}
					productDetailsScreenAction.onUpdateCart(queryparam);
				},
			);
		}
	};

	getUpdatedCount = (countInCart, action, minimumQuantity) => {
		if (action === CART_OPERATION.ADD) {
			return countInCart !== null && countInCart > 0 ? countInCart + 1 : minimumQuantity;
		}
		return countInCart - 1;
	};

	onChangeText = text => {
		const { item } = this.state;
		this.setState({
			item: { ...item, count_in_cart: text },
		});
	};

	updateCart = () => {
		const { item } = this.state;
		const { id, count_in_cart, warehouse_id, vendor_organization_id, minimum_quantity } = item;
		const { productDetailsScreenAction, productListScreenActions, route } = this.props;
		const { itemIndex } = route.params || {};
		if (count_in_cart >= minimum_quantity) {
			// call api to update cart
			const queryparam = {};
			queryparam.item_id = id;
			queryparam.quantity = parseInt(count_in_cart, 10);
			queryparam.warehouse_id = warehouse_id;
			queryparam.vendor_id = vendor_organization_id;
			this.setState(
				{
					itemCountToUpdate: parseInt(count_in_cart, 10),
				},
				() => {
					if (itemIndex) {
						productListScreenActions.onUpdateItem(itemIndex, count_in_cart);
					}
					productDetailsScreenAction.onUpdateCart(queryparam);
				},
			);
		} else {
			// remove item from cart
			this.onRemoveItemFromCart();
		}
	};

	onRemoveItemFromCart = () => {
		// Will delete item from the cart
		const { item } = this.state;
		const {
			id, // item id
			vendor_organization_id, // vendor organization id
		} = item;
		const itemDetail = {
			item_id: id,
			vendor_organization_id,
		};
		this.setState(
			{
				itemCountToUpdate: 0,
			},
			this.onDeleteItem(itemDetail, true),
		);
	};

	onDeleteItem = (itemDetail, deleteFlag) => {
		// call api to delete item from cart
		const { cartDetailActions } = this.props;
		this.setState({
			isItemDeleted: deleteFlag,
		});
		cartDetailActions.onDeleteItem(itemDetail);
	};

	onUpdateItemWishList = id => {
		// Call api to update item in wishlist
		const { isItemInWishlist } = this.state;
		const { itemListScreenAction } = this.props;
		const queryparam = {
			id,
		};
		if (isItemInWishlist) {
			itemListScreenAction.onDeleteFromWishlist(queryparam);
		} else {
			itemListScreenAction.onAddToWishlist(queryparam);
		}
	};

	onIncreaseQuantity = (item, index) => {
		const { productDetailsScreenAction } = this.props;
		if (item.count_in_cart < productMaxQuantity) {
			// if item quantity in cart is less than item's allowed max quantity
			const queryparam = {};
			queryparam.item_id = item.id;
			queryparam.quantity = item.count_in_cart
				? item.count_in_cart + 1
				: item.minimum_quantity
				? item.minimum_quantity
				: 1;
			queryparam.warehouse_id = item.warehouse_id;
			queryparam.vendor_id = item.vendor_organization_id;
			this.setState(
				{
					itemIndexToUpdate: index,
				},
				() => productDetailsScreenAction.onUpdateRelatedItem(queryparam),
			);
		} else {
			// show toast message if user try adding item above max quantity
			this.setState({
				toastMessage: `${localeString(
					keyConstants.MAXIMUM_QUANTITY,
				)} ${productMaxQuantity}`,
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	};

	onDecreaseQuantity = (item, index) => {
		const { productDetailsScreenAction } = this.props;
		if (item.count_in_cart > item.minimum_quantity) {
			// if item quantity in cart is more than item's allowed minimum quantity
			const queryparam = {};
			queryparam.item_id = item.id;
			queryparam.quantity = item.count_in_cart - 1;
			queryparam.warehouse_id = item.warehouse_id;
			queryparam.vendor_id = item.vendor_organization_id;
			this.setState(
				{
					itemIndexToUpdate: index,
				},
				() => {
					productDetailsScreenAction.onUpdateRelatedItem(queryparam);
				},
			);
		} else {
			// show toast message if user try removing item less than min quantity
			this.setState({
				toastMessage: `${localeString(keyConstants.MINIMUM_QUANTITY)} ${
					item.minimum_quantity
				}`,
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	};

	onUpdateQuantity = (text, index) => {
		const { productListItems } = this.state;
		const productListItemsCopy = [...productListItems];
		if (text === '') {
			// if item quantity textfield is empty
			productListItemsCopy[index].count_in_cart = '';
		} else {
			productListItemsCopy[index].count_in_cart = parseInt(text, 10);
		}
		this.setState({
			productListItems: productListItemsCopy,
			itemIndexToUpdate: null,
		});
	};

	onFocus = value => {
		this.setState({
			changeQuantityCount: parseInt(value, 10),
		});
	};

	updateRelatedItem = index => {
		const { productListItems } = this.state;
		const productListItemsCopy = [...productListItems];
		const {
			id,
			count_in_cart,
			warehouse_id,
			vendor_organization_id,
			minimum_quantity,
		} = productListItemsCopy[index];
		const { productDetailsScreenAction } = this.props;
		if (count_in_cart === '' || count_in_cart === 0) {
			const itemDetail = {
				item_id: id,
				vendor_organization_id,
			};
			this.setState(
				{
					itemIndexToUpdate: index,
				},
				this.onDeleteItem(itemDetail, false),
			);
		} else if (count_in_cart >= minimum_quantity) {
			const queryparam = {};
			queryparam.item_id = id;
			queryparam.quantity = count_in_cart;
			queryparam.warehouse_id = warehouse_id;
			queryparam.vendor_id = vendor_organization_id;
			this.setState(
				{
					itemIndexToUpdate: index,
				},
				() => {
					productDetailsScreenAction.onUpdateRelatedItem(queryparam);
				},
			);
		} else {
			productListItemsCopy[index].count_in_cart = parseInt(minimum_quantity, 10);
			const queryparam = {};
			queryparam.item_id = id;
			queryparam.quantity = minimum_quantity;
			queryparam.warehouse_id = warehouse_id;
			queryparam.vendor_id = vendor_organization_id;
			this.setState(
				{
					toastMessage: `${localeString(
						keyConstants.MINIMUM_QUANTITY,
					)} ${minimum_quantity}`,
					isApiError: true,
					productListItems: productListItemsCopy,
					itemIndexToUpdate: index,
				},
				() => {
					productDetailsScreenAction.onUpdateRelatedItem(queryparam);
				},
			);
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	};

	getProductDetail = () => {
		// API call to get the product detail.
		const { productDetailsScreenAction } = this.props;
		const queryParams = {};
		queryParams.id = this.itemId;
		productDetailsScreenAction.onGetProductDetail(queryParams);
	};

	onGetMoreDetails = () => {
		const { productDetailsScreenAction } = this.props;
		const queryParams = {};
		queryParams.id = this.itemId;
		productDetailsScreenAction.onGetMoreDetails(queryParams);
	};

	getRelatedProducts = () => {
		// CAll api to get related product listing
		const { item } = this.state;
		const { sub_category_id, brand_id, category_id, id } = item;
		const { productDetailsScreenAction } = this.props;
		const queryParams = {
			category_id,
			brand_id,
			sub_category_id,
		};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		productDetailsScreenAction.onGetRelatedProducts(queryParams, id);
	};

	onGetCartCount = () => {
		// Call api to get cart count
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetCartCount();
	};

	showHideDetail = () => {
		this.setState(prevState => {
			return {
				isShowDetail: !prevState.isShowDetail,
			};
		});
	};

	render() {
		const {
			languageInfo,
			productDetailsInfo,
			homeScreenInfo,
			cartDetailInfo,
			configurableFileInfo,
		} = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			toastMessage,
			isApiError,
			isShowDetail,
			productListItems,
			isItemInWishlist,
			item,
		} = this.state;
		const {
			cartLoader,
			metaDetails,
			errorCart,
			errorCodeCart,
			isRelatedProduct,
			loader,
			error,
			errorCode,
		} = productDetailsInfo;
		const { cartCount, cartAmount } = homeScreenInfo;
		return (
			<KeyboardAwareScrollView
				keyboardShouldPersistTaps="handled"
				contentContainerStyle={styles.container}>
				{loader && <Loader size="large" />}
				{(cartLoader || cartDetailInfo.cartLoader) && !loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						onPressCart={this.onPressCart}
						cartCount={cartCount}
						hasIconSmallCart
						hasIconBack
						onPressBack={this.onPressBack}
						extraProps={{ cartIcon: getTestIdProps(locatorConstants.basket) }}
					/>
				</View>
				{error ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.getProductDetail}
					/>
				) : item ? (
					<ScrollView showsVerticalScrollIndicator={false}>
						<>
							<ProductDetailCardComponent
								isRTL={isRTL}
								item={item}
								isShowDetail={isShowDetail}
								metaDetails={metaDetails}
								isInWishlist={isItemInWishlist}
								onAddToWishList={this.onUpdateItemWishList}
								onPressPlus={this.onPressPlus}
								onChangeText={this.onChangeText}
								updateCart={this.updateCart}
								showHideDetail={this.showHideDetail}
								addToCart={remoteConfigData?.addToCart}
								extraProps={{
									addItem: getTestIdProps(locatorConstants.addItem),
									increase: getTestIdProps(locatorConstants.increase),
									decrease: getTestIdProps(locatorConstants.decrease),
									addSpecificItemAmount: getTestIdProps(
										locatorConstants.addSpecificItemAmount,
									),
									addItemWishList: getTestIdProps(
										locatorConstants.addItemWishList,
									),
								}}
							/>
							<View style={styles.relatedProductsContainer}>
								{errorCart && isRelatedProduct ? (
									<ErrorComponent
										isRTL={isRTL}
										errorCode={errorCodeCart}
										onCallApi={this.getRelatedProducts}
										isSectionComponent
									/>
								) : (
									productListItems &&
									productListItems.length !== 0 && (
										<>
											<Text style={styles.relatedProducts}>
												{localeString(keyConstants.RELATED_PRODUCTS)}
											</Text>
											<FlatList
												data={productListItems}
												renderItem={this.renderItem}
												keyExtractor={this.keyExtractor}
												showsHorizontalScrollIndicator={false}
												horizontal
												inverted={isRTL}
											/>
										</>
									)
								)}
							</View>
						</>
					</ScrollView>
				) : (
					<ListEmpty text={localeString(keyConstants.ITEM_DISABLE_MESSAGE)} />
				)}
				<CartFloater
					isRTL={isRTL}
					cartAmount={cartAmount}
					ref={this.cartFloater}
					onPressToast={this.onPressCart}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		productDetailsInfo: state.ProductDetailsScreenReducer,
		cartDetailInfo: state.CartScreenReducer,
		homeScreenInfo: state.HomeScreenReducer,
		itemListScreenInfo: state.ItemListScreenReducer,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		productDetailsScreenAction: bindActionCreators({ ...ProductDetailsScreenAction }, dispatch),
		itemListScreenAction: bindActionCreators({ ...ItemListScreenAction }, dispatch),
		cartDetailActions: bindActionCreators({ ...CartDetailActions }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		productListScreenActions: bindActionCreators({ ...ProductListScreenAction }, dispatch),
	};
};

ProductDetailsScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	productDetailsInfo: PropTypes.object.isRequired,
	cartDetailInfo: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	itemListScreenInfo: PropTypes.object.isRequired,
	productDetailsScreenAction: PropTypes.object.isRequired,
	itemListScreenAction: PropTypes.object.isRequired,
	cartDetailActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	productListScreenActions: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductDetailsScreen);
