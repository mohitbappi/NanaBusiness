import * as ActionTypes from './ActionType';

const initialState = {
	successAddWishlist: false,
	errorAddWishlist: false,
	errorCodeAddWishlist: '',
	successCart: false,
	metaDetails: [],
	errorCart: false,
	errorCodeCart: '',
	cartLoader: false,
	relatedProducts: [],
	updateSuccess: false,
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	isRelatedProduct: false,
	itemDetail: null,
};

const ProductDetailsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_UPDATE_CART_SUCCESS:
			return {
				...state,
				successCart: true,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: false,
			};
		case ActionTypes.GET_UPDATE_CART_LOADER:
			return {
				...state,
				successCart: false,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: true,
			};
		case ActionTypes.GET_UPDATE_CART_FAILURE:
			return {
				...state,
				errorCart: true,
				errorCodeCart: action.payload,
				successCart: false,
				cartLoader: false,
				isRelatedProduct: false,
			};
		case ActionTypes.GET_META_DATA_SUCCESS:
			return {
				...state,
				metaDetails: action.payload.item.item_metas,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: false,
			};
		case ActionTypes.GET_META_DATA_LOADER:
			return {
				...state,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: true,
			};
		case ActionTypes.GET_META_DATA_FAILURE:
			return {
				...state,
				errorCart: true,
				errorCodeCart: action.payload,
				cartLoader: false,
				isRelatedProduct: false,
			};
		case ActionTypes.GET_RELATED_PRODUCT_SUCCESS: {
			const itemId = action.extra;
			const { items } = action.payload;
			for (let index = 0; index < items.length; index += 1) {
				if (items[index].id === itemId) {
					items.splice(index, 1);
					break;
				}
			}
			return {
				...state,
				relatedProducts: items,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: false,
				success: true,
				isRelatedProduct: true,
			};
		}
		case ActionTypes.GET_RELATED_PRODUCT_FAILURE:
			return {
				...state,
				success: false,
				errorCart: true,
				errorCodeCart: action.payload,
				cartLoader: false,
				isRelatedProduct: true,
			};
		case ActionTypes.GET_UPDATE_RELATED_ITEM_SUCCESS:
			return {
				...state,
				updateSuccess: true,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: false,
			};
		case ActionTypes.GET_UPDATE_RELATED_ITEM_LOADER:
			return {
				...state,
				updateSuccess: false,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: true,
			};
		case ActionTypes.GET_UPDATE_RELATED_ITEM_FAILURE:
			return {
				...state,
				updateSuccess: false,
				errorCart: true,
				errorCodeCart: action.payload,
				cartLoader: false,
				isRelatedProduct: false,
			};
		case ActionTypes.RESET_PRODUCT_DETAIL_STATE:
			return initialState;
		case ActionTypes.GET_PRODUCT_DETAIL_SUCCESS:
			return {
				...state,
				itemDetail: action.payload.item,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isRelatedProduct: false,
			};
		case ActionTypes.GET_PRODUCT_DETAIL_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
				isRelatedProduct: false,
			};
		case ActionTypes.GET_PRODUCT_DETAIL_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				isRelatedProduct: false,
			};
		default:
			return state;
	}
};

export default ProductDetailsScreenReducer;
