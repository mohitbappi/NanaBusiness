import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import UpdateCartService from '@Cart/UpdateCartService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetMetaDataService from '@MetaData/GetMetaDataService';
import GetSubCategoryItemsService from '@SubCategoryListing/GetSubCategoryItemsService';
import GetProductDetailService from '@Product/GetProductDetailService';
import EndPointHeaderInterceptor from '@interceptor/EndPointHeaderInterceptor';
import { endpointAddCart } from '@assets/Constants/Constants';
import * as ActionTypes from './ActionType';

// Action to reset product listing screen reducer
export const onResetProductListingScreenState = () => ({
	type: ActionTypes.RESET_PRODUCT_LISTING_SCREEN_STATE,
});

/**
 * Action to call update cart api
 * @param {object} addCartItemDetail
 */
export const onUpdateCart = addCartItemDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_UPDATE_CART_SUCCESS,
		ActionTypes.GET_UPDATE_CART_FAILURE,
		ActionTypes.GET_UPDATE_CART_LOADER,
	);
	const updateCartService = new UpdateCartService(dispatchedActions);
	addBasicInterceptors(updateCartService);
	updateCartService.addRequestInterceptor(
		new EndPointHeaderInterceptor(endpointAddCart.productDetail),
	);
	updateCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(updateCartService.makeRequest(addCartItemDetail));
};

/**
 * Action to call Get Meta data of product api
 * @param {object} getMetaDataItemDetail
 */
export const onGetMoreDetails = getMetaDataItemDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_META_DATA_SUCCESS,
		ActionTypes.GET_META_DATA_FAILURE,
		ActionTypes.GET_META_DATA_LOADER,
	);
	const getMetaDataService = new GetMetaDataService(dispatchedActions);
	addBasicInterceptors(getMetaDataService);
	getMetaDataService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getMetaDataService.makeRequest(getMetaDataItemDetail));
};

/**
 * Action to call related product listing api
 * @param {object} props
 * @param {integer} id
 */
export const onGetRelatedProducts = (props, id) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_RELATED_PRODUCT_SUCCESS,
		ActionTypes.GET_RELATED_PRODUCT_FAILURE,
		ActionTypes.GET_RELATED_PRODUCT_LOADER,
	)
		.addSuccessExtra(id)
		.build();
	const getSubCategoryItemsService = new GetSubCategoryItemsService(dispatchedActions);
	addBasicInterceptors(getSubCategoryItemsService);
	getSubCategoryItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getSubCategoryItemsService.makeRequest(props));
};

/**
 * Action to update related item in cart
 * @param {object} addCartItemDetail
 */
export const onUpdateRelatedItem = addCartItemDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_UPDATE_RELATED_ITEM_SUCCESS,
		ActionTypes.GET_UPDATE_RELATED_ITEM_FAILURE,
		ActionTypes.GET_UPDATE_RELATED_ITEM_LOADER,
	);
	const updateCartService = new UpdateCartService(dispatchedActions);
	addBasicInterceptors(updateCartService);
	updateCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(updateCartService.makeRequest(addCartItemDetail));
};

// Action to reset product detail screen reducer
export const onResetState = () => ({ type: ActionTypes.RESET_PRODUCT_DETAIL_STATE });

/**
 * Action to get the product detail.
 * @param {integer} id
 * @returns
 */

export const onGetProductDetail = id => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_PRODUCT_DETAIL_SUCCESS,
		ActionTypes.GET_PRODUCT_DETAIL_FAILURE,
		ActionTypes.GET_PRODUCT_DETAIL_LOADER,
	);
	const getProductDetailService = new GetProductDetailService(dispatchedActions);
	addBasicInterceptors(getProductDetailService);
	getProductDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getProductDetailService.makeRequest(id));
};
