export const GET_UPDATE_CART_SUCCESS = 'get_update_cart_success';
export const GET_UPDATE_CART_FAILURE = 'get_update_cart_failure';
export const GET_UPDATE_CART_LOADER = 'get_update_cart_loader';

export const GET_META_DATA_SUCCESS = 'get_meta_data_success';
export const GET_META_DATA_FAILURE = 'get_meta_data_failure';
export const GET_META_DATA_LOADER = 'get_meta_data_loader';

export const GET_RELATED_PRODUCT_SUCCESS = 'get_related_product_success';
export const GET_RELATED_PRODUCT_FAILURE = 'get_related_product_failure';
export const GET_RELATED_PRODUCT_LOADER = 'get_related_product_loader';

export const GET_UPDATE_RELATED_ITEM_SUCCESS = 'get_update_related_item_success';
export const GET_UPDATE_RELATED_ITEM_FAILURE = 'get_update_related_item_failure';
export const GET_UPDATE_RELATED_ITEM_LOADER = 'get_update_related_item_loader';

export const RESET_PRODUCT_DETAIL_STATE = 'reset_product_detail_state';

export const GET_PRODUCT_DETAIL_SUCCESS = 'get_product_detail_success';
export const GET_PRODUCT_DETAIL_LOADER = 'get_product_detail_loader';
export const GET_PRODUCT_DETAIL_FAILURE = 'get_product_detail_failure';
