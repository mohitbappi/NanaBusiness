import React, { Component } from 'react';
import { View, Text, TouchableOpacity, FlatList, Keyboard, RefreshControl } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import * as colors from '@assets/colors';
import {
	accountManager,
	salesExecutive,
	fetchDataWithPagination,
	ninePlus,
	productMaxQuantity,
	toastShowTime,
} from '@Constants/Constants';
import ToastComponent from '@ToastComponent/ToastComponent';
import IMAGES from '@Images/index';
import navigations from '@routes/navigations';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import * as CartDetailActions from '@CartScreen/CartScreenAction';
import Search from '@Search/Search';
import OptionPicker from '@OptionPicker/OptionPicker';
import CartFloater from '@CartFloater/CartFloater';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { verticalScale } from '@device/normalize';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import HomeItemComponent from '@HomeItemComponent/HomeItemComponent';
import FilterScreenComponent from '@FilterScreen/index';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import * as ProductListScreenAction from './ProductListScreenAction';
import { createStyleSheet } from './ProductListScreenStyle';

class ProductListScreen extends Component {
	constructor(props) {
		super(props);
		const { category_id, activeCategoryIndex, brand_id, subCategoryId } = props.route.params;
		this.category_id = category_id || null;
		this.brand_id = brand_id || null;
		this.sub_category_id = subCategoryId || null;
		this.activeCategoryIndex = activeCategoryIndex;
		this.subCategoryLimit = fetchDataWithPagination.limit;
		this.subCategoryPage = fetchDataWithPagination.page;
		this.subCategoryItemLimit = fetchDataWithPagination.limit;
		this.subCategoryItemPage = fetchDataWithPagination.page;
		this.categoryLimit = fetchDataWithPagination.limit;
		this.categoryPage = fetchDataWithPagination.page;
		this.brandLimit = fetchDataWithPagination.limit;
		this.brandPage = fetchDataWithPagination.page;
		this.cartFloater = React.createRef(null);
		this.itemListRef = React.createRef(null);
		this.state = {
			activeTab: 0,
			productListItems: [],
			changeQuantityCount: 0,
			itemIndexToUpdate: null,
			trackAction: null,
			isApiError: false,
			toastMessage: '',
			searchText: '',
			isPickerVisible: false,
			activePickerIndex: 0, // By default search will work for item name
			scrollIndex: 0,
			bottomLoader: false,
			isFilterEnable: false, // Boolean to enable/disable the filter.
			// eslint-disable-next-line react/no-unused-state
			isPriceLowToHigh: false,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		logCustomEventOnBraze('productListViewed', null);
		this.willFocusListener = navigation.addListener('focus', () => {
			const { productListScreenInfo, pullToRefreshActions } = this.props;
			const { itemIndex, itemSubCategoryIndex, isApiCall } = productListScreenInfo;
			if (isApiCall) {
				this.onGetCartCount();
				this.onGetNotificationCount();
				this.setState(
					{
						activeTab: itemSubCategoryIndex || 0,
						productListItems: [],
						changeQuantityCount: 0,
						itemIndexToUpdate: null,
						trackAction: null,
						isApiError: false,
						toastMessage: '',
					},
					() => {
						this.subCategoryItemPage = fetchDataWithPagination.page;
						this.subCategoryLimit = itemSubCategoryIndex
							? this.getDynamicItemListingLimit(itemSubCategoryIndex)
							: fetchDataWithPagination.limit;
						this.subCategoryItemLimit = itemIndex
							? this.getDynamicItemListingLimit(itemIndex)
							: fetchDataWithPagination.limit;
						if (this.brand_id && !this.category_id) {
							// if load product listing for selected brand
							this.onGetBrands(false);
						} else {
							// if load product listing for selected category
							this.onGetCategories(false);
						}
					},
				);
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { productListScreenInfo, pullToRefreshActions, cartDetailInfo } = this.props;
		const {
			success,
			subCategoryListing,
			isSubCategory,
			isSubCategoryItems,
			subCategoryItemListing,
			successCart,
			errorCart,
			itemIndex,
			itemSubCategoryIndex,
			isCategory,
			isBrand,
			errorCodeCart,
		} = productListScreenInfo;
		const {
			itemIndexToUpdate,
			trackAction,
			changeQuantityCount,
			activeTab,
			isFilterEnable,
			productListItems,
		} = this.state;
		if (subCategoryItemListing !== prevProps.productListScreenInfo.subCategoryItemListing) {
			// Will set the product list when it will get update.
			this.setState({
				productListItems: subCategoryItemListing,
			});
		}
		if (success && prevProps.productListScreenInfo.success !== productListScreenInfo.success) {
			if (
				isCategory &&
				!isFilterEnable &&
				this.category_id &&
				prevProps.productListScreenInfo.categoryListing !==
					productListScreenInfo.categoryListing
			) {
				// if category listing fetched, will call sub category api
				this.onGetSubCategories(false);
			}
			if (
				isBrand &&
				!isFilterEnable &&
				this.brand_id &&
				prevProps.productListScreenInfo.brandListing !== productListScreenInfo.brandListing
			) {
				// if brand fetched, will call sub category api
				this.onGetSubCategoriesForBrands(false);
			}
			if (subCategoryListing.length >= 1 && isSubCategory) {
				// Will call items api if sub category fetched.
				if (this.sub_category_id === null || this.category_id || this.brand_id) {
					this.onGetSubCategoriesItems(false);
				}
				if (subCategoryListing) {
					for (let index = 0; index < subCategoryListing.length; index += 1) {
						if (subCategoryListing[index].id === this.sub_category_id) {
							this.setState(
								{
									activeTab: index,
									scrollIndex: index,
								},
								() => this.onGetSubCategoriesItems(false),
							);
							return;
						}
					}
				}
			}
		}
		if (
			success &&
			subCategoryItemListing &&
			isSubCategoryItems &&
			prevProps.productListScreenInfo.subCategoryItemListing !==
				productListScreenInfo.subCategoryItemListing
		) {
			// if item listing api return success
			this.setState(
				{
					productListItems: subCategoryItemListing,
					bottomLoader: false,
				},
				() => {
					if (itemIndex && activeTab === itemSubCategoryIndex) {
						if (this.itemListRef !== null && this.itemListRef.current !== null) {
							if (typeof this.itemListRef.current.scrollToIndex === 'function') {
								try {
									setTimeout(() => {
										this.itemListRef.current.scrollToIndex({
											animated: false,
											index:
												itemIndex % 2 === 0
													? itemIndex / 2
													: (itemIndex - 1) / 2,
										});
									});
								} catch (error) {
									// Error
								}
							}
						}
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (
			successCart &&
			itemIndexToUpdate !== null &&
			prevProps.productListScreenInfo.successCart !== productListScreenInfo.successCart
		) {
			// if update cart api return success
			const productListItemsCopy = productListItems;
			productListItemsCopy[itemIndexToUpdate].count_in_cart =
				productListItemsCopy[itemIndexToUpdate].count_in_cart === ''
					? 0
					: this.getActionType(
							productListItemsCopy[itemIndexToUpdate].count_in_cart
								? productListItemsCopy[itemIndexToUpdate].count_in_cart
								: productListItemsCopy[itemIndexToUpdate].minimum_quantity,
							trackAction,
					  );
			this.setState(
				{
					productListItems: productListItemsCopy,
					itemIndexToUpdate: null,
					trackAction: null,
				},
				() => {
					this.onGetCartCount();
					this.onGetNotificationCount();
					this.cartFloater.current.handleCartFloater();
				},
			);
		}
		if (
			cartDetailInfo.successCart &&
			prevProps.cartDetailInfo.successCart !== cartDetailInfo.successCart
		) {
			const productListItemsCopy = productListItems;
			if (productListItemsCopy[itemIndexToUpdate]) {
				productListItemsCopy[itemIndexToUpdate].count_in_cart =
					productListItemsCopy[itemIndexToUpdate].count_in_cart === '' || // If the quantity of the item is empty string.
					productListItemsCopy[itemIndexToUpdate].count_in_cart === 0 // If the quantity of the item is 0.
						? 0
						: this.getActionType(
								productListItemsCopy[itemIndexToUpdate].count_in_cart,
								trackAction,
						  );
				this.setState(
					{
						productListItems: productListItemsCopy,
						itemIndexToUpdate: null,
						trackAction: null,
					},
					() => {
						this.onGetCartCount();
						this.onGetNotificationCount();
						this.cartFloater.current.handleCartFloater();
					},
				);
			}
		}
		if (
			errorCart &&
			prevProps.productListScreenInfo.errorCart !== productListScreenInfo.errorCart
		) {
			// if update item quantity in cart return error
			if (errorCodeCart.error === keyConstants.ADD_ITEM_ERROR) {
				this.setState({
					toastMessage: localeString(keyConstants.ADD_ITEM_ERROR),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				const productListItemsCopy = productListItems;
				productListItemsCopy[itemIndexToUpdate].count_in_cart = changeQuantityCount;
				this.setState({
					productListItems: productListItemsCopy,
					itemIndexToUpdate: null,
					trackAction: null,
				});
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	componentWillUnmount() {
		this.onCleanListData();
	}

	getDynamicItemListingLimit = itemIndex => {
		return itemIndex - (itemIndex % 10) + fetchDataWithPagination.limit;
	};

	getActionType = (count, action) => {
		switch (action) {
			case 0: // TODO to increase item quantity
				return count + 1;
			case 1: // TODO to decrease item quantity
				return count - 1;
			case 2: // TODO to replace item quantity
				return count;
			default:
				return null;
		}
	};

	onGetCategories = isOverwriteExistingList => {
		// Call api to get categories listing
		const { homeScreenInfo, userDetails, productListScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization;
		const queryParams = {};
		queryParams.limit = this.categoryLimit;
		queryParams.page = this.categoryPage;
		queryParams.branch_id = id;
		productListScreenActions.onGetCategories(queryParams, isOverwriteExistingList);
	};

	onGetBrands = isOverwriteExistingList => {
		// Call api to get brands listing
		const { homeScreenInfo, userDetails, productListScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization;
		const queryParams = {};
		queryParams.limit = this.brandLimit;
		queryParams.page = this.brandPage;
		queryParams.branch_id = id;
		productListScreenActions.onGetBrands(queryParams, isOverwriteExistingList);
	};

	onGetSubCategories = isOverwriteExistingList => {
		// Call api to get sub-categories listing
		const { homeScreenInfo, userDetails, productListScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization;
		const subCategoryData = {
			category_id: this.category_id,
			queryParams: {
				limit: this.subCategoryLimit,
				page: this.subCategoryPage,
				branch_id: id,
			},
		};
		productListScreenActions.onGetSubCategories(subCategoryData, isOverwriteExistingList);
	};

	onGetSubCategoriesForBrands = isOverwriteExistingList => {
		// Call api to get sub-categories listing for branch
		const { productListScreenActions } = this.props;
		const subCategoryData = {
			brand_id: this.brand_id,
			queryParams: {
				limit: this.subCategoryLimit,
				page: this.subCategoryPage,
			},
		};
		productListScreenActions.onGetSubCategoriesForBrands(
			subCategoryData,
			isOverwriteExistingList,
		);
	};

	onGetCartCount = () => {
		// Call api to get cart count
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetCartCount();
	};

	onGetNotificationCount = () => {
		// Call api to get notification count
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetNotificationCount();
	};

	onGetSubCategoriesItems = isOverwriteExistingList => {
		// Call api to get items listing
		const { homeScreenInfo, userDetails, productListScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { searchText, activePickerIndex } = this.state;
		const { id } = branchDetail || userDetails.user.organization;
		const subCategoryItemData = {};
		subCategoryItemData.limit = this.subCategoryItemLimit;
		subCategoryItemData.page = this.subCategoryItemPage;
		subCategoryItemData.branch = id;
		if (searchText) {
			if (activePickerIndex === 0) {
				subCategoryItemData.name = searchText;
			} else {
				subCategoryItemData.carton_barcode = searchText;
			}
		}
		if (this.category_id) {
			subCategoryItemData.category_id = this.category_id;
		}
		if (this.brand_id) {
			subCategoryItemData.brand_id = this.brand_id;
		}
		if (this.sub_category_id) {
			subCategoryItemData.sub_category_id = this.sub_category_id;
		}
		// Todo:- Will remove this comment when we use this sorting.
		// if (isPriceLowToHigh) {
		// 	subCategoryItemData.sort_by = 'price-lth';
		// } else {
		// 	subCategoryItemData.sort_by = 'price-htl';
		// }
		productListScreenActions.onGetSubCategoriesItems(
			subCategoryItemData,
			isOverwriteExistingList,
		);
	};

	onPressTab = (index, item) => {
		this.onDissmissKeyboard();
		this.setState({
			activeTab: index,
		});
		this.onCleanListData();
		this.sub_category_id = item.id;
		this.onGetSubCategoriesItems(false);
	};

	navigateTo = (item, index) => {
		const { activeTab } = this.state;
		const { navigation, productListScreenActions } = this.props;
		const data = {};
		data.itemIndex = index;
		data.itemLimit = this.subCategoryItemLimit;
		data.itemSubCategoryIndex = activeTab;
		data.itemSubCategoryLimit = this.subCategoryLimit;
		data.itemSubCategoryId = item.sub_category_id;
		productListScreenActions.onHandleListState(data);
		productListScreenActions.onHandleApiCall(false);
		navigation.navigate(navigations.PRODUCT_DETAILS_NAVIGATION, {
			id: item.id,
			itemIndex: index,
		});
	};

	onPressBack = () => {
		const { navigation, productListScreenActions } = this.props;
		navigation.goBack();
		productListScreenActions.onResetProductListingScreenState();
	};

	onPressCart = () => {
		const { navigation, productListScreenActions } = this.props;
		productListScreenActions.onHandleApiCall(true);
		navigation.navigate(navigations.CART_NAVIGATION);
	};

	onPressNotification = () => {
		const { navigation, homeScreenInfo, productListScreenActions } = this.props;
		const { notificationCount } = homeScreenInfo;
		productListScreenActions.onHandleApiCall(true);
		navigation.navigate(navigations.NOTIFICATION_NAVIGATION, { notificationCount });
	};

	onSearch = text => {
		// call item listing api on the basis of text entered in search filter
		this.page = fetchDataWithPagination.page;
		this.onCleanListData();
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onGetSubCategoriesItems(false);
			},
		);
	};

	handlePicker = value => {
		this.setState({
			isPickerVisible: value,
		});
	};

	onCleanListData = (isPageUpdate = true) => {
		const { productListScreenActions } = this.props;
		const data = {};
		data.itemIndex = null;
		data.itemLimit = null;
		data.itemSubCategoryIndex = null;
		data.itemSubCategoryLimit = null;
		data.itemSubCategoryId = null;
		productListScreenActions.onHandleListState(data);
		if (isPageUpdate) {
			this.subCategoryItemPage = fetchDataWithPagination.page;
		}
	};

	onSelectOption = index => {
		this.setState(
			{
				activePickerIndex: index,
			},
			() => this.handlePicker(false),
		);
	};

	onEndReachedCategory = () => {
		this.categoryPage += 1;
		this.onGetCategories(true);
	};

	onEndReachedBrand = () => {
		this.brandPage += 1;
		this.onGetBrands(true);
	};

	getItemLayout = (data, index) => ({
		length: verticalScale(266),
		offset: verticalScale(266) * index,
		index,
	});

	onEndReachedSubCategory = () => {
		this.subCategoryPage += 1;
		if (this.brand_id) {
			this.onGetSubCategoriesForBrands(true);
		} else {
			this.onGetSubCategories(true);
		}
	};

	onEndReachedCategoryItem = () => {
		const { productListScreenInfo } = this.props;
		const { loader, isSubCategoryItems } = productListScreenInfo;
		if (!loader && isSubCategoryItems) {
			this.setState(
				{
					bottomLoader: true,
				},
				() => {
					this.subCategoryItemPage =
						this.subCategoryItemLimit > 10
							? this.subCategoryItemLimit / fetchDataWithPagination.limit + 1
							: this.subCategoryItemPage + 1;
					this.subCategoryItemLimit = fetchDataWithPagination.limit;
					this.onGetSubCategoriesItems(true);
					this.onCleanListData(false);
				},
			);
		}
	};

	listFooterComponent = () => {
		const { languageInfo, productListScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { subCategoryItemListing, subCategoryItemCount } = productListScreenInfo;
		const endReached =
			subCategoryItemCount === subCategoryItemListing.length ||
			subCategoryItemCount < subCategoryItemListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onPressPlus = (item, index) => {
		const { productListScreenActions } = this.props;
		if (item.count_in_cart === null) {
			logCustomEventOnBraze('productAddedToCart', { itemId: item.id });
		}
		if (item.count_in_cart < productMaxQuantity) {
			// if item quantity in cart is less than allowed maximum quantity
			const queryparam = {};
			queryparam.item_id = item.id;
			queryparam.quantity = item.count_in_cart
				? item.count_in_cart + 1
				: item.minimum_quantity
				? item.minimum_quantity
				: 1;
			queryparam.warehouse_id = item.warehouse_id;
			queryparam.vendor_id = item.vendor_organization_id;
			this.setState(
				{
					itemIndexToUpdate: index,
					trackAction: item.count_in_cart ? 0 : 2, // for increase item count
				},
				() => productListScreenActions.onUpdateCart(queryparam),
			);
		} else {
			// if item quantity in cart is equal or greater than allowed maximum quantity show toast message
			this.setState({
				toastMessage: `${localeString(
					keyConstants.MAXIMUM_QUANTITY,
				)} ${productMaxQuantity}`,
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	};

	onPressMinus = (item, index) => {
		const { productListScreenActions } = this.props;
		if (item.count_in_cart > item.minimum_quantity) {
			// if item quantity in cart is more than allowed minimum quantity
			const queryparam = {};
			queryparam.item_id = item.id;
			queryparam.quantity = item.count_in_cart - 1;
			queryparam.warehouse_id = item.warehouse_id;
			queryparam.vendor_id = item.vendor_organization_id;
			this.setState(
				{
					itemIndexToUpdate: index,
					trackAction: 1, // for decreasing item count
				},
				() => {
					productListScreenActions.onUpdateCart(queryparam);
				},
			);
		} else {
			// if item quantity in cart is equal or less than allowed minimum quantity then remove item from cart
			this.onRemoveItemFromCart(index);
		}
	};

	onChangeText = (text, index) => {
		const { productListItems } = this.state;
		const productListItemsCopy = productListItems;
		if (text === '') {
			productListItemsCopy[index].count_in_cart = '';
		} else {
			productListItemsCopy[index].count_in_cart = parseInt(text, 10);
		}
		this.setState({
			productListItems: productListItemsCopy,
			itemIndexToUpdate: null,
			trackAction: null,
		});
	};

	onFocus = value => {
		this.setState({
			changeQuantityCount: parseInt(value, 10),
		});
	};

	updateCart = index => {
		const { productListItems } = this.state;
		const productListItemsCopy = [...productListItems];
		const {
			id,
			count_in_cart,
			warehouse_id,
			vendor_organization_id,
			minimum_quantity,
		} = productListItemsCopy[index];
		const { productListScreenActions } = this.props;
		if (count_in_cart >= minimum_quantity) {
			// if quantity of item in cart is greater than or equal to allowed min quantity
			const queryparam = {};
			queryparam.item_id = id;
			queryparam.quantity = count_in_cart;
			queryparam.warehouse_id = warehouse_id;
			queryparam.vendor_id = vendor_organization_id;
			this.setState(
				{
					itemIndexToUpdate: index,
					trackAction: 2,
				},
				() => {
					productListScreenActions.onUpdateCart(queryparam);
				},
			);
		} else {
			this.onRemoveItemFromCart(index);
		}
	};

	onRemoveItemFromCart = index => {
		// Will delete item from the cart
		const { productListItems } = this.state;
		const productListItemsCopy = productListItems;
		productListItemsCopy[index].count_in_cart = 0;
		const {
			id, // item id
			vendor_organization_id, // vendor organization id
		} = productListItemsCopy[index];
		const itemDetail = {
			item_id: id,
			vendor_organization_id,
		};
		this.setState(
			{
				productListItems: productListItemsCopy,
				itemIndexToUpdate: index, // Index of the item which is updated.
				trackAction: 2, // Will replace existing quantity with the new quantity.
			},
			this.onDeleteItem(itemDetail),
		);
	};

	onDeleteItem = itemDetail => {
		// Call api to delete item from cart
		const { cartDetailActions } = this.props;
		cartDetailActions.onDeleteItem(itemDetail);
	};

	onPressOption = (categoryId, brandId) => {
		this.onDissmissKeyboard();
		if (categoryId) {
			this.category_id = categoryId;
			this.brand_id = null;
		} else {
			this.category_id = null;
			this.brand_id = brandId;
		}
		this.setState(
			{
				activeTab: 0,
				searchText: '',
				isPickerVisible: false,
				activePickerIndex: null,
			},
			() => {
				this.onCleanListData();
				this.sub_category_id = null;
				this.subCategoryPage = fetchDataWithPagination.page;
				if (this.category_id) {
					this.onGetSubCategories(false);
				} else {
					this.onGetSubCategoriesForBrands(false);
				}
			},
		);
	};

	onGetCategoryDefaultImage = id => {
		if (id === this.category_id) {
			return IMAGES.iconDefaultCategoryActive;
		}
		return IMAGES.iconDefaultCategoryInactive;
	};

	renderItem = ({ item, index }) => {
		const { languageInfo, configurableFileInfo } = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			images,
			name_ar,
			name,
			price_with_vat,
			offer_price_with_vat,
			count_in_cart,
			items_per_packet,
			value_of_item,
			unit,
			unit_ar,
			status_out_of_stock,
			price_per_item,
			category_id,
		} = item;
		return (
			<HomeItemComponent
				isRTL={isRTL}
				image={images && images.large}
				name={isRTL ? name_ar : name}
				itemsPerPacket={items_per_packet}
				valueOfItem={value_of_item}
				unit={isRTL ? unit_ar : unit}
				pricePerItem={price_per_item}
				offerPrice={offer_price_with_vat}
				price={price_with_vat}
				isProductList
				isPlusButton={
					remoteConfigData?.addToCart &&
					!status_out_of_stock &&
					(count_in_cart === null || count_in_cart === 0)
				}
				statusOutOfStock={status_out_of_stock}
				onPressAdd={() => this.onPressPlus(item, index)}
				isPlusMinusButton={
					remoteConfigData?.addToCart &&
					!!(
						((count_in_cart && parseInt(count_in_cart, 10) > 0) ||
							count_in_cart === '') &&
						!status_out_of_stock
					)
				}
				onPressMinus={() => this.onPressMinus(item, index)}
				itemCount={count_in_cart || 0}
				onChangeText={text => this.onChangeText(text, index)}
				updateCart={() => this.updateCart(index)}
				onPressPlus={() => this.onPressPlus(item, index)}
				onFocus={() => this.onFocus(count_in_cart)}
				onPress={() => this.navigateTo(item, index)}
				containerStyle={styles.containerStyle}
				imageStyle={styles.imageStyle}
				unitStyle={styles.unitStyle}
				titleStyle={styles.titleStyle}
				priceStyle={styles.priceStyle}
				numberOfLines={2}
				noPerUnitPrice
				categoryId={category_id}
			/>
		);
	};

	getProductItemLayout = (data, index) => ({
		length: verticalScale(276),
		offset: verticalScale(276) * index,
		index,
	});

	keyExtractor = (item, index) => index.toString();

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onCheckInternet = () => {
		// function to check internet connectivity
		const { isConnected, pullToRefreshActions } = this.props;
		if (isConnected) {
			pullToRefreshActions.onHandlePullToRefresh(true);
			this.onRefresh();
		}
	};

	onRefresh = () => {
		const { productListScreenInfo } = this.props;
		this.onGetCartCount();
		this.onGetNotificationCount();
		const { itemIndex, itemSubCategoryIndex } = productListScreenInfo;
		this.subCategoryItemPage = fetchDataWithPagination.page;
		this.subCategoryLimit = itemSubCategoryIndex
			? this.getDynamicItemListingLimit(itemSubCategoryIndex)
			: fetchDataWithPagination.limit;
		this.subCategoryItemLimit = itemIndex
			? this.getDynamicItemListingLimit(itemIndex)
			: fetchDataWithPagination.limit;
		if (this.brand_id && !this.category_id) {
			this.onGetSubCategoriesForBrands(false);
		} else {
			this.onGetCategories(false);
			this.onGetSubCategories(false);
		}
	};

	onFilter = () => {
		this.categoryPage = 1;
		this.brandPage = 1;
		this.onHandleFilter(true);
	};

	onHandleFilter = value => {
		// Enable/disable the filter.
		this.setState({
			isFilterEnable: value,
		});
	};

	onPressApply = (categoryId, brandId, isPriceLowToHigh) => {
		this.onHandleFilter(false);
		this.onPressOption(categoryId, brandId);
		this.setState({
			// eslint-disable-next-line react/no-unused-state
			isPriceLowToHigh: !!isPriceLowToHigh,
		});
	};

	onGetFilterOptions = selectedTab => {
		this.categoryPage = 1;
		this.brandPage = 1;
		if (selectedTab === 0) {
			this.onGetCategories(false);
		} else {
			this.onGetBrands(false);
		}
	};

	render() {
		const {
			languageInfo,
			productListScreenInfo,
			homeScreenInfo,
			refreshControlComponentInfo,
			userDetails,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			loader,
			subCategoryListing,
			subCategoryCount,
			subCategoryItemCount,
			categoryListing,
			categoryCount,
			isSubCategory,
			isSubCategoryItems,
			error,
			errorCode,
			isCategory,
			brandListing,
			brandCount,
			isBrand,
		} = productListScreenInfo;
		const {
			activeTab,
			productListItems,
			toastMessage,
			searchText,
			isApiError,
			isPickerVisible,
			activePickerIndex,
			bottomLoader,
			isFilterEnable,
			scrollIndex,
		} = this.state;
		const { cartCount, notificationCount, cartAmount } = homeScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		if (isFilterEnable) {
			return (
				// Component to apply filter on item listing
				<FilterScreenComponent
					isRTL={isRTL}
					categoryListing={categoryListing}
					onPressCancel={() => this.onHandleFilter(false)}
					onPressApply={this.onPressApply}
					onEndReached={() =>
						categoryListing.length !== categoryCount && this.onEndReachedCategory()
					}
					onEndReachedBrand={() =>
						brandListing.length !== brandCount && this.onEndReachedBrand()
					}
					error={error && (isCategory || isBrand)}
					errorCode={errorCode}
					onCallApi={() =>
						isCategory ? this.onGetCategories(false) : this.onGetBrands(false)
					}
					selectedCategoryId={this.category_id}
					selectedBrandId={this.brand_id}
					brandListing={brandListing}
					onSwitchTab={selectedTab => this.onGetFilterOptions(selectedTab)}
				/>
			);
		}
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && isCategory && <Loader size="large" />}
				<OptionPicker
					isVisible={isPickerVisible}
					options={[
						{ name: localeString(keyConstants.ITEM_NAME) },
						{ name: localeString(keyConstants.BARCODE) },
					]}
					title={localeString(keyConstants.SEARCH_BY)}
					isRTL={isRTL}
					onClose={() => this.handlePicker(false)}
					onSelectOption={this.onSelectOption}
					activeIndex={activePickerIndex}
				/>
				<View style={styles.header}>
					<View style={styles.locationView}>
						<TouchableOpacity
							activeOpacity={0.8}
							hitSlop={styles.backHitSlop}
							onPress={this.onPressBack}>
							<ImageLoadComponent
								source={IMAGES.iconRightArrow}
								style={styles.iconBack}
							/>
						</TouchableOpacity>
						<Text style={styles.headingText}>
							{localeString(keyConstants.PRODUCTS)}
						</Text>
					</View>
					<View style={styles.iconsView}>
						<TouchableOpacity activeOpacity={0.8} onPress={this.onPressCart}>
							<ImageLoadComponent source={IMAGES.iconCart} style={styles.iconCart} />
							{cartCount ? (
								<View style={styles.notificationContainerStyle}>
									<Text style={styles.notificationCountStyle}>
										{cartCount > 9 ? ninePlus : cartCount}
									</Text>
								</View>
							) : null}
						</TouchableOpacity>
						<TouchableOpacity activeOpacity={0.8} onPress={this.onPressNotification}>
							{role !== accountManager && role !== salesExecutive ? (
								<ImageLoadComponent
									source={IMAGES.iconNotification}
									style={styles.iconNotification}
								/>
							) : null}
							{notificationCount !== 0 ? (
								<View style={styles.notificationContainerStyle}>
									<Text style={styles.notificationCountStyle}>
										{notificationCount > 9 ? ninePlus : notificationCount}
									</Text>
								</View>
							) : null}
						</TouchableOpacity>
					</View>
				</View>
				<View style={styles.searchContainer}>
					<Search
						placeholder={localeString(keyConstants.SEARCH_BY_ITEM_NAME)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
					/>
				</View>
				{error && isSubCategory ? (
					<ErrorComponent // Error component if subcategory api fails.
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={() =>
							this.brand_id && !this.category_id
								? this.onGetSubCategoriesForBrands(false)
								: this.onGetSubCategories(false)
						}
					/>
				) : (
					<>
						<View style={styles.horizontalItemsContainer}>
							{subCategoryListing.length !== 0 && (
								<>
									<FlatList
										data={subCategoryListing}
										horizontal
										inverted={isRTL}
										showsHorizontalScrollIndicator={false}
										renderItem={({ item, index }) => {
											return (
												<TouchableOpacity
													onPress={() => this.onPressTab(index, item)}
													style={
														index === activeTab
															? styles.activeView
															: styles.view
													}
													activeOpacity={0.8}
													hitSlop={styles.hitSlop}>
													<Text
														style={
															activeTab === index
																? styles.activeText
																: styles.text
														}>
														{isRTL ? item.name_ar : item.name}
													</Text>
												</TouchableOpacity>
											);
										}}
										keyExtractor={this.keyExtractor}
										onEndReached={() =>
											subCategoryListing.length !== subCategoryCount + 1 &&
											this.onEndReachedSubCategory()
										}
										onEndReachedThreshold={0.5}
										getItemLayout={this.getItemLayout}
										ref={ref => {
											this.flatListRef = ref;
										}}
										initialScrollIndex={scrollIndex}
									/>
								</>
							)}
						</View>
						{error && isSubCategoryItems ? (
							<ErrorComponent // Error component if item listing api fails.
								isRTL={isRTL}
								errorCode={errorCode}
								onCallApi={() => this.onGetSubCategoriesItems(false)}
							/>
						) : (
							<>
								<View style={styles.productListContainer}>
									{loader &&
									!isFetchingForPullToRefresh &&
									isSubCategoryItems &&
									!bottomLoader &&
									searchText === '' ? (
										<Loader
											size="large"
											isSmallLoader
											activityIndicatorStyle={styles.activityIndicatorStyle}
										/>
									) : (
										<FlatList
											ref={this.itemListRef}
											showsVerticalScrollIndicator={false}
											data={productListItems}
											numColumns={2}
											renderItem={this.renderItem}
											getItemLayout={this.getProductItemLayout}
											keyExtractor={this.keyExtractor}
											ListFooterComponent={
												productListItems.length !== 0 &&
												subCategoryItemCount >
													fetchDataWithPagination.limit &&
												this.listFooterComponent()
											}
											onEndReached={() =>
												productListItems.length !== subCategoryItemCount &&
												this.onEndReachedCategoryItem()
											}
											onEndReachedThreshold={0.8}
											ListEmptyComponent={() => (
												<ListEmpty
													text={localeString(keyConstants.NO_ITEMS_FOUND)}
												/>
											)}
											contentContainerStyle={
												productListItems.length === 0
													? styles.scrollViewStyle
													: null
											}
											refreshControl={
												<RefreshControl
													refreshing={isFetchingForPullToRefresh}
													onRefresh={this.onCheckInternet}
													colors={[colors.darkBlue]}
													tintColor={colors.darkBlue}
												/>
											}
										/>
									)}
								</View>
								{productListItems.length !== 0 ? (
									<View style={styles.itemCountContainer}>
										<Text style={styles.itemCountText}>
											{`${productListItems.length} ${localeString(
												keyConstants.OF,
											)} ${subCategoryItemCount} ${localeString(
												keyConstants.ITEMS,
											)}`}
										</Text>
									</View>
								) : null}
								{productListItems.length !== 0 ? (
									<TouchableOpacity
										onPress={this.onFilter}
										style={styles.filterContainer}
										activeOpacity={0.8}>
										<ImageLoadComponent
											source={IMAGES.iconFilterWhite}
											style={styles.iconFilterWhite}
										/>
									</TouchableOpacity>
								) : null}
							</>
						)}
					</>
				)}
				<CartFloater
					isRTL={isRTL}
					cartAmount={cartAmount}
					ref={this.cartFloater}
					onPressToast={this.onPressCart}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		productListScreenInfo: state.ProductListScreenReducer,
		homeScreenInfo: state.HomeScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		cartDetailInfo: state.CartScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		isConnected: state.NoConnectionHandleReducer.isConnected,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		productListScreenActions: bindActionCreators({ ...ProductListScreenAction }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		cartDetailActions: bindActionCreators({ ...CartDetailActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

ProductListScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	productListScreenInfo: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	cartDetailInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	productListScreenActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	cartDetailActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	isConnected: PropTypes.bool.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductListScreen);
