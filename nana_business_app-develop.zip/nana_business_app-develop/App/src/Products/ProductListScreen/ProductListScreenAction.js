import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import GetSubCategoryService from '@SubCategoryListing/GetSubCategoryService';
import GetSubCategoryItemsService from '@SubCategoryListing/GetSubCategoryItemsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import UpdateCartService from '@Cart/UpdateCartService';
import GetCategoryService from '@CategoryListing/GetCategoryService';
import BrandListingService from '@BrandListing/BrandListingService';
import GetSubCategoryForBrandsService from '@SubCategoryListing/GetSubCategoryForBrandsService';
import EndPointHeaderInterceptor from '@interceptor/EndPointHeaderInterceptor';
import { endpointAddCart } from '@assets/Constants/Constants';
import * as ActionTypes from './ActionType';

// Action to reset Product List screen reducer
export const onResetProductListingScreenState = () => ({
	type: ActionTypes.RESET_PRODUCT_LISTING_SCREEN_STATE,
});

/**
 * Action to handle product list scroll position
 * @param {object} data
 */
export const onHandleListState = data => {
	return {
		type: ActionTypes.HANDLE_LIST_STATE,
		payload: data,
	};
};

/**
 * Action to call Sub categories item listing api
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetSubCategories = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_SUB_CATEGORIES_SUCCESS,
		ActionTypes.GET_SUB_CATEGORIES_FAILURE,
		ActionTypes.GET_SUB_CATEGORIES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getSubCategoryService = new GetSubCategoryService(dispatchedActions);
	addBasicInterceptors(getSubCategoryService);
	getSubCategoryService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getSubCategoryService.makeRequest(props));
};

/**
 * Action to call Sub categories for brands api
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetSubCategoriesForBrands = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_SUB_CATEGORIES_SUCCESS,
		ActionTypes.GET_SUB_CATEGORIES_FAILURE,
		ActionTypes.GET_SUB_CATEGORIES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getSubCategoryForBrandsService = new GetSubCategoryForBrandsService(dispatchedActions);
	addBasicInterceptors(getSubCategoryForBrandsService);
	getSubCategoryForBrandsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getSubCategoryForBrandsService.makeRequest(props));
};

/**
 * Action to call items listing api
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetSubCategoriesItems = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_SUB_CATEGORIES_ITEM_SUCCESS,
		ActionTypes.GET_SUB_CATEGORIES_ITEM_FAILURE,
		ActionTypes.GET_SUB_CATEGORIES_ITEM_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getSubCategoryItemService = new GetSubCategoryItemsService(dispatchedActions);
	addBasicInterceptors(getSubCategoryItemService);
	getSubCategoryItemService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getSubCategoryItemService.makeRequest(props));
};

/**
 * Action to Update items in cart
 * @param {object} addCartItemDetail
 */
export const onUpdateCart = addCartItemDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_UPDATE_CART_ITEM_SUCCESS,
		ActionTypes.GET_UPDATE_CART_ITEM_FAILURE,
		ActionTypes.GET_UPDATE_CART_ITEM_LOADER,
	);
	const updateCartService = new UpdateCartService(dispatchedActions);
	addBasicInterceptors(updateCartService);
	updateCartService.addRequestInterceptor(
		new EndPointHeaderInterceptor(endpointAddCart.productList),
	);
	updateCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(updateCartService.makeRequest(addCartItemDetail));
};

/**
 * Action to get categories listing
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetCategories = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_PRODUCT_CATEGORIES_SUCCESS,
		ActionTypes.GET_PRODUCT_CATEGORIES_FAILURE,
		ActionTypes.GET_PRODUCT_CATEGORIES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getCategoryService = new GetCategoryService(dispatchedActions);
	addBasicInterceptors(getCategoryService);
	getCategoryService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCategoryService.makeRequest(props));
};

/**
 * Action to get brands listing
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetBrands = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_PRODUCT_BRAND_SUCCESS,
		ActionTypes.GET_PRODUCT_BRAND_FAILURE,
		ActionTypes.GET_PRODUCT_BRAND_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const brandListingService = new BrandListingService(dispatchedActions);
	addBasicInterceptors(brandListingService);
	brandListingService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(brandListingService.makeRequest(props));
};

/**
 * Action to update the item quantity.
 * @param {number} index
 * @param {number} quantity
 */
export const onUpdateItem = (index, quantity) => {
	return {
		type: ActionTypes.UPDATE_ITEM,
		payload: { index, quantity },
	};
};

/**
 * Action to handle api call of product listing.
 * @param {boolean} value
 * @returns
 */

export const onHandleApiCall = value => {
	return {
		type: ActionTypes.HANDLE_ITEM_API_CALL,
		payload: value,
	};
};
