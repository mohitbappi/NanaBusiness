export const RESET_PRODUCT_LISTING_SCREEN_STATE = 'reset_product_listing_screen_state';

export const HANDLE_LIST_STATE = 'handle_list_state';

export const GET_SUB_CATEGORIES_SUCCESS = 'get_sub_categories_success';
export const GET_SUB_CATEGORIES_FAILURE = 'get_sub_categories_failure';
export const GET_SUB_CATEGORIES_LOADER = 'get_sub_categories_loader';

export const GET_SUB_CATEGORIES_ITEM_SUCCESS = 'get_sub_categories_item_success';
export const GET_SUB_CATEGORIES_ITEM_FAILURE = 'get_sub_categories_item_failure';
export const GET_SUB_CATEGORIES_ITEM_LOADER = 'get_sub_categories_item_loader';

export const GET_UPDATE_CART_ITEM_SUCCESS = 'get_update_cart_item_success';
export const GET_UPDATE_CART_ITEM_FAILURE = 'get_update_cart_item_failure';
export const GET_UPDATE_CART_ITEM_LOADER = 'get_update_cart_item_loader';

export const GET_PRODUCT_CATEGORIES_SUCCESS = 'get_product_categories_success';
export const GET_PRODUCT_CATEGORIES_FAILURE = 'get_product_categories_failure';
export const GET_PRODUCT_CATEGORIES_LOADER = 'get_product_categories_loader';

export const GET_PRODUCT_BRAND_SUCCESS = 'get_product_brand_success';
export const GET_PRODUCT_BRAND_FAILURE = 'get_product_brand_failure';
export const GET_PRODUCT_BRAND_LOADER = 'get_product_brand_loader';

export const UPDATE_ITEM = 'update_item';

export const HANDLE_ITEM_API_CALL = 'handle_item_api_call';
