import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import * as ActionTypes from './ActionType';

const initialState = {
	subCategoryListing: [
		{
			name: localeString(keyConstants.ALL),
			name_ar: localeString(keyConstants.ALL),
		},
	],
	subCategoryCount: 0,
	isSubCategory: false,
	subCategoryItemListing: [],
	isSubCategoryItems: false,
	subCategoryItemCount: 0,
	isCategory: false,
	categoryListing: [],
	categoryCount: 0,
	itemIndex: null,
	itemLimit: null,
	itemSubCategoryIndex: null,
	itemSubCategoryLimit: null,
	itemSubCategoryId: null,
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	successCart: false,
	errorCart: false,
	errorCodeCart: '',
	categoryLoader: false,
	isBrand: false,
	brandListing: [],
	brandCount: 0,
	isApiCall: true,
};

const ProductListScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.RESET_PRODUCT_LISTING_SCREEN_STATE:
			return initialState;
		case ActionTypes.HANDLE_LIST_STATE:
			return {
				...state,
				itemIndex: action.payload.itemIndex,
				itemLimit: action.payload.itemLimit,
				itemSubCategoryIndex: action.payload.itemSubCategoryIndex,
				itemSubCategoryLimit: action.payload.itemSubCategoryLimit,
				itemSubCategoryId: action.payload.itemSubCategoryId,
			};
		case ActionTypes.GET_SUB_CATEGORIES_SUCCESS: {
			const isOverwriteExistingCategoryList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				subCategoryListing: isOverwriteExistingCategoryList
					? [...state.subCategoryListing, ...action.payload.sub_categories]
					: [
							...[
								{
									name: localeString(keyConstants.ALL),
									name_ar: localeString(keyConstants.ALL),
								},
							],
							...action.payload.sub_categories,
					  ],
				subCategoryCount: action.payload.count,
				isSubCategory: true,
				isSubCategoryItems: false,
				isCategory: false,
				isBrand: false,
			};
		}
		case ActionTypes.GET_SUB_CATEGORIES_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isSubCategory: true,
				isSubCategoryItems: false,
				isCategory: false,
				isBrand: false,
			};
		case ActionTypes.GET_SUB_CATEGORIES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isSubCategory: true,
				isSubCategoryItems: false,
				isCategory: false,
				isBrand: false,
			};
		case ActionTypes.GET_SUB_CATEGORIES_ITEM_SUCCESS: {
			const isOverwriteExistingCategoryItemList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				subCategoryItemListing: isOverwriteExistingCategoryItemList
					? [...state.subCategoryItemListing, ...action.payload.items]
					: action.payload.items,
				subCategoryItemCount: action.payload.count,
				isSubCategory: false,
				isSubCategoryItems: true,
				isCategory: false,
				isBrand: false,
			};
		}
		case ActionTypes.GET_SUB_CATEGORIES_ITEM_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isSubCategory: false,
				isSubCategoryItems: true,
				isCategory: false,
				isBrand: false,
			};
		case ActionTypes.GET_SUB_CATEGORIES_ITEM_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isSubCategory: false,
				isSubCategoryItems: true,
				categoryLoader: false,
				isCategory: false,
				isBrand: false,
			};
		case ActionTypes.GET_UPDATE_CART_ITEM_SUCCESS:
			return {
				...state,
				successCart: true,
				errorCart: false,
				errorCodeCart: '',
			};
		case ActionTypes.GET_UPDATE_CART_ITEM_LOADER:
			return {
				...state,
				successCart: false,
				errorCart: false,
				errorCodeCart: '',
			};
		case ActionTypes.GET_UPDATE_CART_ITEM_FAILURE:
			return {
				...state,
				errorCart: true,
				errorCodeCart: action.payload,
				successCart: false,
			};
		case ActionTypes.GET_PRODUCT_CATEGORIES_SUCCESS: {
			const isOverwriteExistingProdCategoryList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				categoryListing: isOverwriteExistingProdCategoryList
					? [...state.categoryListing, ...action.payload.categories]
					: action.payload.categories,
				isCategory: true,
				categoryCount: action.payload.count,
				isSubCategory: false,
				isSubCategoryItems: false,
				isBrand: false,
			};
		}
		case ActionTypes.GET_PRODUCT_CATEGORIES_LOADER:
		case ActionTypes.GET_PRODUCT_BRAND_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isSubCategory: false,
				isSubCategoryItems: false,
				isCategory: true,
				isBrand: false,
			};
		case ActionTypes.GET_PRODUCT_CATEGORIES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isSubCategory: false,
				isSubCategoryItems: false,
				categoryLoader: false,
				isCategory: true,
				isBrand: false,
			};
		case ActionTypes.GET_PRODUCT_BRAND_SUCCESS: {
			const isOverwriteExistingProdBrandList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				brandListing: isOverwriteExistingProdBrandList
					? [...state.brandListing, ...action.payload.brands]
					: action.payload.brands,
				brandCount: action.payload.count,
				isCategory: false,
				isSubCategory: false,
				isSubCategoryItems: false,
				isBrand: true,
			};
		}
		case ActionTypes.GET_PRODUCT_BRAND_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isSubCategory: false,
				isSubCategoryItems: false,
				categoryLoader: false,
				isBrand: true,
				isCategory: false,
			};
		case ActionTypes.UPDATE_ITEM: {
			const { index, quantity } = action.payload;
			const { subCategoryItemListing } = state;
			subCategoryItemListing[index].count_in_cart = quantity;
			return {
				...state,
				subCategoryItemListing,
			};
		}
		case ActionTypes.HANDLE_ITEM_API_CALL:
			return {
				...state,
				isApiCall: action.payload,
			};
		default:
			return state;
	}
};

export default ProductListScreenReducer;
