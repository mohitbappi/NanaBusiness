import React, { Component } from 'react';
import { Text, TextInput, View, TouchableOpacity, FlatList } from 'react-native';
import PropTypes from 'prop-types';
import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import {
	CART_OPERATION,
	noSpaceAtStartRegexEx,
	productMaxLength,
	IMAGE_TYPE,
	multiplyString,
	palletCategoryId,
} from '@Constants/Constants';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getUnitsAndPricing } from '@Util/GetUnitsAndPricing';
import CustomToast from '@CustomToast/CustomToast';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { createStyleSheet } from './ProductDetailsScreen/ProductDetailsScreenStyle';

class ProductDetailCardComponent extends Component {
	renderMetaData = () => {
		const { isRTL, isShowDetail, metaDetails, showHideDetail } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.metaDataMainContainer}>
				{metaDetails && metaDetails.length !== 0 && (
					<TouchableOpacity
						style={styles.showDetailsContainer}
						activeOpacity={0.8}
						onPress={() => showHideDetail()}>
						<Text style={styles.showDetailsText}>
							{isShowDetail
								? `${localeString(keyConstants.VIEW_LESS_DETAILS)}`
								: `${localeString(keyConstants.VIEW_MORE_DETAILS)}`}
						</Text>
						<ImageLoadComponent
							source={
								isShowDetail ? IMAGES.iconGreenUpArrow : IMAGES.iconArrowDownGreen
							}
							style={styles.imageDownUpArrow}
						/>
					</TouchableOpacity>
				)}
				{isShowDetail ? (
					<FlatList
						renderItem={this.renderMetaItem}
						keyExtractor={this.keyExtractor}
						data={metaDetails}
						showsVerticalScrollIndicator={false}
					/>
				) : null}
			</View>
		);
	};

	renderMetaItem = ({ item }) => {
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		const { meta_key, meta_value } = item;
		return (
			<View style={styles.productDetailContainer}>
				<Text style={styles.metaDetailKey}>{meta_key}</Text>
				<Text style={styles.metaDetailValue}>{meta_value}</Text>
			</View>
		);
	};

	renderProductDetail = () => {
		const {
			isRTL,
			item,
			isInWishlist,
			onAddToWishList,
			isAcceptItem,
			isFirstItem,
			isLastItem,
			itemQuantity,
			isShowItemAcceptedToast,
			numberOfItemsAccepted,
			onPress,
			itemsListing,
			extraProps,
		} = this.props;
		const {
			name, // Item English name.
			name_ar, // Item Arabic name.
			images,
			items_per_packet,
			unit,
			unit_ar,
			value_of_item,
			price_per_item,
			carton_barcode, // Barcode of the carton.
			price,
			vat_amount,
			category_id,
		} = item;
		const styles = createStyleSheet(isRTL);
		// pricePerItem will store price of the one item in the carton.
		const pricePerItem = isAcceptItem
			? (price + vat_amount) / items_per_packet
			: price_per_item;
		return (
			<View>
				<ImageLoadComponent
					imageType={IMAGE_TYPE.itemDetail}
					notCheckError
					isUrl
					source={images && images.large}
					style={styles.productAcceptImg}
				/>
				{category_id === palletCategoryId ? (
					<ImageLoadComponent source={IMAGES.iconPallet} style={styles.iconPallet} />
				) : null}
				{isAcceptItem && (
					<View>
						{
							// Will show swipe left indicator for 2 seconds.
							isLastItem && (
								<View style={styles.viewSwipeLeft}>
									<Text style={styles.textSwipeLeft}>
										{localeString(keyConstants.SWIPE_LEFT)}
									</Text>
								</View>
							)
						}
						{
							// Will show swipe right indicator for 2 seconds.
							isFirstItem && (
								<View style={styles.viewSwipeRight}>
									<Text style={styles.textSwipeLeft}>
										{localeString(keyConstants.SWIPE_RIGHT)}
									</Text>
								</View>
							)
						}
					</View>
				)}
				<View
					style={
						isAcceptItem
							? styles.productInfoCenterOuterContainer
							: styles.productInfoOuterContainer
					}>
					<View
						style={
							isAcceptItem
								? styles.productInfoCenterContainer
								: styles.productInfoContainer
						}>
						<Text
							style={isAcceptItem ? styles.productCenterTitle : styles.productTitle}>
							{isRTL ? name_ar : name}
						</Text>
						{
							// Will show carton barcode for accept items screen only.
							isAcceptItem && carton_barcode ? (
								<Text style={styles.barcodeCenterTitle}>
									{`${localeString(keyConstants.BARCODE_NO)}: ${carton_barcode}`}
								</Text>
							) : null
						}
						{items_per_packet && unit && value_of_item ? (
							<Text style={[styles.qtyStyle, isAcceptItem && styles.qtyCenterStyle]}>
								{getUnitsAndPricing(
									items_per_packet,
									value_of_item,
									isRTL ? unit_ar : unit,
									pricePerItem,
								)}
							</Text>
						) : null}
					</View>
					{!isAcceptItem ? (
						<TouchableOpacity
							activeOpacity={0.8}
							onPress={() => onAddToWishList(item.id)}
							{...extraProps?.addItemWishList}>
							<ImageLoadComponent
								source={
									isInWishlist ? IMAGES.iconWishlistFilled : IMAGES.iconWishlist
								}
								style={styles.iconWishlist}
							/>
						</TouchableOpacity>
					) : null}
				</View>
				{isAcceptItem && (
					<>
						{/* Will show increase decrease counter to update the item quantity. */}
						{this.renderAcceptedProductCount()}
						{/* Will show updated quantity with price. */}
						{this.renderFooterView(0, price + vat_amount, itemQuantity)}
						{/* Will show item accepted toast. */}
						{isShowItemAcceptedToast && this.renderIsAcceptedView()}
						<View style={styles.bottomView}>
							<ButtonComponent
								text={`${localeString(
									keyConstants.ACCEPTED_ITEMS,
								)}: ${numberOfItemsAccepted}/${itemsListing.length}`}
								onPress={onPress}
							/>
						</View>
					</>
				)}
			</View>
		);
	};

	getCategoryBrandName = item => {
		const { isRTL } = this.props;
		const {
			brand_name, // brand english name
			brand_name_ar, // brand arabic name
			category_name, // category english name
			category_name_ar, // category arabic name
			sub_category_name, // sub-category english name
			sub_category_name_ar, // sub-category arabic name
		} = item;
		let catBrandText = `${isRTL ? brand_name_ar : brand_name} | ${
			isRTL ? category_name_ar : category_name
		}`;
		catBrandText += sub_category_name
			? ` | ${isRTL ? sub_category_name_ar : sub_category_name}`
			: '';
		return catBrandText;
	};

	renderFooterView = (price, offerPrice, quantity) => {
		const { isRTL, isAcceptItem } = this.props;
		const styles = createStyleSheet(isRTL);
		const showFooter = isAcceptItem ? true : quantity !== null && quantity !== 0;
		// If offer price exists then finalPrice will be offer price otherwise price.
		const finalPrice = parseFloat(offerPrice) ? parseFloat(offerPrice) : parseFloat(price);
		const totalPrice = (parseInt(quantity, 10) ? parseInt(quantity, 10) : 0) * finalPrice; // Total price is finalPrice * quantity.
		const priceDivisionText = `${parseInt(quantity, 10)} ${multiplyString} ${currencyFormatter(
			getValueInDecimal(finalPrice),
		)} ${localeString(keyConstants.SAR)}`;
		return showFooter ? (
			<View style={[styles.footerView, styles.footerAcceptedView]}>
				<Text style={styles.quantity}>{priceDivisionText}</Text>
				<Text style={styles.finalPrice}>
					{`${currencyFormatter(getValueInDecimal(totalPrice))} ${localeString(
						keyConstants.SAR,
					)}`}
				</Text>
			</View>
		) : null;
	};

	renderIsAcceptedView = () => {
		const { isRTL } = this.props;
		return (
			<CustomToast // Component to show toast.
				isRTL={isRTL}
				toastMessage={localeString(keyConstants.ITEM_ACCEPTED)}
			/>
		);
	};

	renderItemOutOfStock = () => {
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.outStockContainer}>
				<Text style={styles.outStockText}>{localeString(keyConstants.OUT_OF_STOCK)}</Text>
			</View>
		);
	};

	renderAcceptedProductCount = () => {
		const {
			isRTL,
			item,
			onUpdateItemQuantity, // Function to perform actions like increase, decrease and update quantity.
			onChangeItemQuantity, // Function to update quantity using textbox.
			itemQuantity, // Updated item quantity.
			isItemAccepted,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		const { quantity, returned_qty } = item;
		return (
			<View style={styles.orderQuantityContainer}>
				<View>
					<Text style={styles.qtyOrdered}>
						{`${localeString(keyConstants.QTY_ORDERED)}: ${quantity}`}
					</Text>
					<Text style={[styles.qtyOrdered, styles.qtyAccepted]}>
						{`${localeString(keyConstants.QTY_ACCEPTED)}: ${
							returned_qty
								? quantity - returned_qty
								: isItemAccepted
								? quantity
								: returned_qty
						}`}
					</Text>
				</View>
				<View style={styles.itemCountContainerStyle}>
					<TouchableOpacity
						disabled={itemQuantity === 0}
						style={styles.iconPlusMinusContainer}
						onPress={() => onUpdateItemQuantity(CART_OPERATION.REMOVE)}>
						<ImageLoadComponent
							source={
								itemQuantity === 0 ? IMAGES.iconMinusWhite : IMAGES.iconMinusGreen
							}
							style={styles.iconPlusMinus}
						/>
					</TouchableOpacity>
					<View style={styles.countContainer}>
						<TextInput
							style={styles.countStyle}
							keyboardType="number-pad"
							autoCapitalize="none"
							value={itemQuantity ? `${itemQuantity}` : '0'}
							returnKeyType="done"
							maxLength={productMaxLength}
							onChangeText={text =>
								(noSpaceAtStartRegexEx.test(String(text).toLocaleLowerCase()) ||
									text === '') &&
								onChangeItemQuantity(text)
							}
							onBlur={() => onUpdateItemQuantity(CART_OPERATION.UPDATE)}
						/>
					</View>
					<TouchableOpacity
						disabled={itemQuantity === quantity}
						style={styles.iconPlusMinusContainer}
						onPress={() => onUpdateItemQuantity(CART_OPERATION.ADD)}>
						<ImageLoadComponent
							source={
								itemQuantity === quantity
									? IMAGES.iconPlusWhite
									: IMAGES.iconPlusGreen
							}
							style={styles.iconPlusMinus}
						/>
					</TouchableOpacity>
				</View>
			</View>
		);
	};

	renderProductCount = () => {
		const { isRTL, item, onPressPlus, onChangeText, updateCart, extraProps } = this.props;
		const styles = createStyleSheet(isRTL);
		const { count_in_cart } = item;
		return (
			<>
				{count_in_cart !== null && (count_in_cart !== 0 || count_in_cart === '') ? (
					<>
						<View style={styles.itemCountContainerStyle}>
							<TouchableOpacity
								style={styles.iconPlusMinusContainer}
								onPress={() =>
									count_in_cart && count_in_cart > 0
										? onPressPlus(CART_OPERATION.REMOVE)
										: null
								}
								{...extraProps?.decrease}>
								<ImageLoadComponent
									source={IMAGES.iconMinusGreen}
									style={styles.iconPlusMinus}
								/>
							</TouchableOpacity>
							<View style={styles.countContainer}>
								<TextInput
									style={styles.countStyle}
									keyboardType="number-pad"
									autoCapitalize="none"
									value={count_in_cart ? `${count_in_cart}` : '0'}
									returnKeyType="done"
									maxLength={productMaxLength}
									onChangeText={text =>
										(noSpaceAtStartRegexEx.test(
											String(text).toLocaleLowerCase(),
										) ||
											text === '') &&
										onChangeText(text)
									}
									onBlur={() => updateCart()}
									{...extraProps?.addSpecificItemAmount}
								/>
							</View>
							<TouchableOpacity
								style={styles.iconPlusMinusContainer}
								onPress={() => onPressPlus(CART_OPERATION.ADD)}
								{...extraProps?.increase}>
								<ImageLoadComponent
									source={IMAGES.iconPlusGreen}
									style={styles.iconPlusMinus}
								/>
							</TouchableOpacity>
						</View>
					</>
				) : (
					<>
						<View />
						<View style={styles.itemCountAddContainerStyle}>
							<TouchableOpacity
								style={styles.buttonDetailContainer}
								onPress={() => onPressPlus(CART_OPERATION.ADD)}
								{...extraProps?.addItem}>
								<View style={styles.addDetailContainer}>
									<Text style={styles.addDetailText}>
										{localeString(keyConstants.ADD)}
									</Text>
								</View>
								<ImageLoadComponent
									source={IMAGES.iconPlusBlue}
									style={styles.plus}
								/>
							</TouchableOpacity>
						</View>
					</>
				)}
			</>
		);
	};

	keyExtractor = index => index.toString();

	render() {
		const { isRTL, item, isAcceptItem, addToCart } = this.props;
		const styles = createStyleSheet(isRTL);
		const {
			price_with_vat,
			offer_price_with_vat,
			minimum_quantity,
			status_out_of_stock,
			count_in_cart,
		} = item;
		let perc;
		if (price_with_vat && offer_price_with_vat) {
			perc = Number(((price_with_vat - offer_price_with_vat) / price_with_vat) * 100).toFixed(
				2,
			);
		} else {
			perc = 0;
		}
		return (
			<>
				{this.renderProductDetail()}
				{!isAcceptItem ? (
					<>
						<Text style={styles.minQuantity}>
							{`${localeString(keyConstants.MIN_QTY)}: ${minimum_quantity}`}
						</Text>
						<View style={styles.productBottomMainContainer}>
							<View style={styles.productCountInfoOuterContainer}>
								<View>
									<Text style={styles.originalPrice}>
										{`${currencyFormatter(
											parseFloat(offer_price_with_vat)
												? offer_price_with_vat
												: price_with_vat,
										)} ${localeString(keyConstants.SAR)} `}
										<Text style={styles.incVat}>
											{`(${localeString(keyConstants.INC_OF_VAT)})`}
										</Text>
									</Text>
									{perc !== 0 ? (
										<View style={styles.priceContainer}>
											<Text style={styles.discountedPrice}>
												{`${currencyFormatter(
													price_with_vat,
												)} ${localeString(keyConstants.SAR)}`}
											</Text>
											<Text style={styles.discountedPercentage}>
												{`${perc}% ${localeString(keyConstants.OFF)}`}
											</Text>
										</View>
									) : null}
								</View>
								<View>
									{status_out_of_stock
										? this.renderItemOutOfStock()
										: addToCart
										? this.renderProductCount()
										: null}
								</View>
							</View>
						</View>
					</>
				) : null}
				{!isAcceptItem &&
					this.renderFooterView(price_with_vat, offer_price_with_vat, count_in_cart)}
				{!isAcceptItem && this.renderMetaData()}
			</>
		);
	}
}

ProductDetailCardComponent.propTypes = {
	isRTL: PropTypes.object.isRequired,
	isShowDetail: PropTypes.object.isRequired,
	metaDetails: PropTypes.object.isRequired,
	showHideDetail: PropTypes.bool.isRequired,
	item: PropTypes.object.isRequired,
	isInWishlist: PropTypes.bool.isRequired,
	onAddToWishList: PropTypes.func.isRequired,
	isAcceptItem: PropTypes.bool.isRequired,
	isFirstItem: PropTypes.bool.isRequired,
	isLastItem: PropTypes.bool.isRequired,
	itemQuantity: PropTypes.number.isRequired,
	isShowItemAcceptedToast: PropTypes.bool.isRequired,
	numberOfItemsAccepted: PropTypes.number.isRequired,
	onPress: PropTypes.func.isRequired,
	itemsListing: PropTypes.array.isRequired,
	onUpdateItemQuantity: PropTypes.func.isRequired,
	onChangeItemQuantity: PropTypes.func.isRequired,
	isItemAccepted: PropTypes.bool.isRequired,
	onPressPlus: PropTypes.bool.isRequired,
	onChangeText: PropTypes.bool.isRequired,
	updateCart: PropTypes.bool.isRequired,
	addToCart: PropTypes.bool.isRequired,
	extraProps: PropTypes.object.isRequired,
};

export default ProductDetailCardComponent;
