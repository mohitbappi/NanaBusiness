import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		wishlistHeader: {
			marginHorizontal: normalScale(16),
		},
		iconClose: {
			height: verticalScale(12),
			width: normalScale(12),
			marginLeft: isRTL ? 0 : normalScale(18),
			marginRight: isRTL ? normalScale(18) : 0,
		},
		buttonContainer: {
			marginHorizontal: normalScale(16),
			borderRadius: moderateScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			borderColor: colors.whitishGrey,
			borderWidth: moderateScale(2),
			height: verticalScale(38),
			alignItems: 'center',
		},
		icon: {
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			width: normalScale(14),
			height: verticalScale(14),
			justifyContent: 'center',
		},
		productListContainer: {
			flex: 1,
		},
		listConatiner: {
			marginHorizontal: normalScale(16),
		},
		productContainer: {
			paddingBottom: verticalScale(16),
			paddingTop: verticalScale(16),
			borderBottomColor: colors.whitishGrey,
			borderBottomWidth: normalScale(1),
		},
		withoutBorder: {
			borderBottomWidth: normalScale(0),
			paddingBottom: verticalScale(0),
			paddingTop: verticalScale(16),
		},
		containerStyle: {
			borderRadius: moderateScale(8),
			paddingHorizontal: normalScale(6),
			borderColor: colors.whitishGrey,
			borderWidth: normalScale(1.5),
			paddingVertical: verticalScale(12),
			alignItems: 'center',
			width: normalScale(136),
			marginEnd: normalScale(16),
			marginBottom: verticalScale(16),
			marginLeft: 0,
			marginRight: 0,
		},
		priceStyle: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(8),
			marginBottom: verticalScale(12),
			maxWidth: normalScale(150),
		},
		titleStyle: {
			textAlign: 'center',
			marginTop: verticalScale(14),
			fontSize: normalize(10),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			height: normalScale(24),
		},
		unitStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
			marginTop: verticalScale(8),
		},
		imageStyle: {
			width: normalScale(110),
			height: normalScale(110),
		},
		scrollViewStyle: {
			flex: 1,
			justifyContent: 'center',
		},
	});
};

export default createStyleSheet;
