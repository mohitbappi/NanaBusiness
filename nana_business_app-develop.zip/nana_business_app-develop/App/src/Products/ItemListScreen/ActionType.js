export const GET_LIST_UPDATE_CART_ITEM_SUCCESS = 'get_list_update_cart_item_success';
export const GET_LIST_UPDATE_CART_ITEM_FAILURE = 'get_list_update_cart_item_failure';
export const GET_LIST_UPDATE_CART_ITEM_LOADER = 'get_list_update_cart_item_loader';

export const GET_WISHLISTED_ITEM_SUCCESS = 'get_wishlisted_item_success';
export const GET_WISHLISTED_ITEM_FAILURE = 'get_wishlisted_item_failure';
export const GET_WISHLISTED_ITEM_LOADER = 'get_wishlisted_item_loader';

export const ADD_TO_WISHLIST_SUCCESS = 'add_to_wishlist_success';
export const ADD_TO_WISHLIST_FAILURE = 'add_to_wishlist_failure';
export const ADD_TO_WISHLIST_LOADER = 'add_to_wishlist_loader';

export const DELETE_FROM_WISHLIST_SUCCESS = 'delete_from_wishlist_success';
export const DELETE_FROM_WISHLIST_FAILURE = 'delete_from_wishlist_failure';
export const DELETE_FROM_WISHLIST_LOADER = 'delete_from_wishlist_loader';

export const RESET_WISHLIST = 'reset_wishlist';

export const GET_MOST_SELLING_ITEMS_LIST_SUCCESS = 'get_most_selling_items_list_success';
export const GET_MOST_SELLING_ITEMS_LIST_FAILURE = 'get_most_selling_items_list_failure';
export const GET_MOST_SELLING_ITEMS_LIST_LOADER = 'get_most_selling_items_list_loader';

export const UPDATE_ITEM_QUANTITY = 'update_item_quantity';

export const DELETE_CURRENT_ITEM_FROM_LIST = 'delete_current_item_from_list';

export const GET_NEWLY_ADDED_ITEMS_LIST_SUCCESS = 'get_newly_added_items_list_success';
export const GET_NEWLY_ADDED_ITEMS_LIST_FAILURE = 'get_newly_added_items_list_failure';
export const GET_NEWLY_ADDED_ITEMS_LIST_LOADER = 'get_newly_added_items_list_loader';

export const GET_DISCOUNT_ITEMS_LIST_SUCCESS = 'get_discount_items_list_success';
export const GET_DISCOUNT_ITEMS_LIST_FAILURE = 'get_discount_items_list_failure';
export const GET_DISCOUNT_ITEMS_LIST_LOADER = 'get_discount_items_list_loader';
