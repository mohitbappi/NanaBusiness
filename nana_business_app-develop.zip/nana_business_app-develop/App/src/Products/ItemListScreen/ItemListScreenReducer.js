import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	isUpdateList: false,
	isUpdateCart: false,
	isDeletedFromWishList: false,
	isAddedToWishList: false,
	itemList: [],
	itemListCount: 0,
	isSubCategoryItems: false,
	isItemAddedToCArt: false,
};

const ItemListScreenReducer = (state = initialState, action = {}) => {
	const itemListCopy = state.itemList;
	switch (action.type) {
		case ActionTypes.RESET_WISHLIST:
			return initialState;
		case ActionTypes.GET_WISHLISTED_ITEM_SUCCESS:
		case ActionTypes.GET_MOST_SELLING_ITEMS_LIST_SUCCESS:
		case ActionTypes.GET_NEWLY_ADDED_ITEMS_LIST_SUCCESS:
		case ActionTypes.GET_DISCOUNT_ITEMS_LIST_SUCCESS: {
			const appendToExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isUpdateList: false,
				itemList: appendToExistingList
					? [...state.itemList, ...action.payload.items]
					: action.payload.items,
				itemListCount: action.payload.count,
				isSubCategoryItems: true,
				isItemAddedToCArt: false,
			};
		}
		case ActionTypes.GET_WISHLISTED_ITEM_LOADER:
		case ActionTypes.GET_MOST_SELLING_ITEMS_LIST_LOADER:
		case ActionTypes.GET_NEWLY_ADDED_ITEMS_LIST_LOADER:
		case ActionTypes.GET_DISCOUNT_ITEMS_LIST_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isUpdateList: false,
				isSubCategoryItems: false,
			};
		case ActionTypes.DELETE_FROM_WISHLIST_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isUpdateList: false,
				isSubCategoryItems: false,
				isItemAddedToCArt: false,
				isDeletedFromWishList: true,
				isAddedToWishList: false,
			};
		case ActionTypes.GET_WISHLISTED_ITEM_FAILURE:
		case ActionTypes.GET_MOST_SELLING_ITEMS_LIST_FAILURE:
		case ActionTypes.GET_NEWLY_ADDED_ITEMS_LIST_FAILURE:
		case ActionTypes.GET_DISCOUNT_ITEMS_LIST_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isUpdateList: false,
				isSubCategoryItems: false,
				isItemAddedToCArt: false,
				isDeletedFromWishList: false,
				isAddedToWishList: false,
			};
		case ActionTypes.ADD_TO_WISHLIST_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isUpdateList: false,
				isSubCategoryItems: false,
				isItemAddedToCArt: false,
				isDeletedFromWishList: false,
				isAddedToWishList: true,
			};
		case ActionTypes.GET_LIST_UPDATE_CART_ITEM_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isUpdateList: true,
				isSubCategoryItems: true,
				isUpdateCart: true,
				isItemAddedToCArt: true,
			};
		case ActionTypes.GET_LIST_UPDATE_CART_ITEM_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
				isUpdateList: true,
				isSubCategoryItems: false,
				isUpdateCart: true,
				isItemAddedToCArt: false,
			};
		case ActionTypes.GET_LIST_UPDATE_CART_ITEM_FAILURE:
			return {
				...state,
				error: true,
				errorCodeCart: action.payload,
				successCart: false,
				isUpdateList: false,
				loader: false,
				isSubCategoryItems: false,
				isUpdateCart: true,
				isItemAddedToCArt: false,
			};
		case ActionTypes.ADD_TO_WISHLIST_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isUpdateList: true,
				isAddedToWishList: true,
				isDeletedFromWishList: false,
				isSubCategoryItems: false,
				isItemAddedToCArt: false,
			};
		case ActionTypes.DELETE_FROM_WISHLIST_LOADER:
		case ActionTypes.ADD_TO_WISHLIST_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: '',
				loader: true,
				isUpdateList: false,
				isSubCategoryItems: false,
				isItemAddedToCArt: false,
			};
		case ActionTypes.DELETE_FROM_WISHLIST_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isUpdateList: true,
				isAddedToWishList: false,
				isDeletedFromWishList: true,
				isSubCategoryItems: false,
				isItemAddedToCArt: false,
			};
		case ActionTypes.UPDATE_ITEM_QUANTITY:
			if (itemListCopy.length) {
				itemListCopy[action.payload.index].count_in_cart = action.payload.quantity;
			}
			return {
				...state,
				itemList: itemListCopy,
			};
		case ActionTypes.DELETE_CURRENT_ITEM_FROM_LIST: {
			const index = action.payload;
			itemListCopy.splice(index, 1);
			return {
				...state,
				itemList: itemListCopy,
			};
		}
		default:
			return state;
	}
};

export default ItemListScreenReducer;
