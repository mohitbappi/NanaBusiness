import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import UpdateCartService from '@Cart/UpdateCartService';
import AddToWishlistService from '@WishList/AddToWishlistService';
import GetWishListedItemsService from '@WishList/GetWishListedItemsService';
import DeleteFromWishlistService from '@WishList/DeleteFromWishlistService';
import GetMostSellingItemsService from '@Home/GetMostSellingItemsService';
import GetNewlyAddedItemsService from '@Home/GetNewlyAddedItemsService';
import GetDiscountItemsService from '@Home/GetDiscountItemsService';
import EndPointHeaderInterceptor from '@interceptor/EndPointHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to call Wishlisted item list api
 * @param {object} props
 * @param {boolean} appendToExistingList
 */
export const onGetWishListedItems = (props, appendToExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_WISHLISTED_ITEM_SUCCESS,
		ActionTypes.GET_WISHLISTED_ITEM_FAILURE,
		ActionTypes.GET_WISHLISTED_ITEM_LOADER,
	)
		.addSuccessExtra(appendToExistingList)
		.build();
	const getWishListedItemsService = new GetWishListedItemsService(dispatchedActions);
	addBasicInterceptors(getWishListedItemsService);
	getWishListedItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getWishListedItemsService.makeRequest(props));
};

/**
 * Action to call update cart api
 * @param {object} addCartItemDetail
 * @param {string} endpoint
 */
export const onUpdateCart = (addCartItemDetail, endpoint) => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_LIST_UPDATE_CART_ITEM_SUCCESS,
		ActionTypes.GET_LIST_UPDATE_CART_ITEM_FAILURE,
		ActionTypes.GET_LIST_UPDATE_CART_ITEM_LOADER,
	);
	const updateCartService = new UpdateCartService(dispatchedActions);
	addBasicInterceptors(updateCartService);
	updateCartService.addRequestInterceptor(new EndPointHeaderInterceptor(endpoint));
	updateCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(updateCartService.makeRequest(addCartItemDetail));
};

/**
 * Action to call Add item to wishlist api
 * @param {object} props
 */
export const onAddToWishlist = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ADD_TO_WISHLIST_SUCCESS,
		ActionTypes.ADD_TO_WISHLIST_FAILURE,
		ActionTypes.ADD_TO_WISHLIST_LOADER,
	);
	const addToWishlist = new AddToWishlistService(dispatchedActions);
	addBasicInterceptors(addToWishlist);
	addToWishlist.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(addToWishlist.makeRequest(props));
};

/**
 * Action to call api to remove item from wishlist
 * @param {object} props
 */
export const onDeleteFromWishlist = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.DELETE_FROM_WISHLIST_SUCCESS,
		ActionTypes.DELETE_FROM_WISHLIST_FAILURE,
		ActionTypes.DELETE_FROM_WISHLIST_LOADER,
	);
	const deleteFromWishlistService = new DeleteFromWishlistService(dispatchedActions);
	addBasicInterceptors(deleteFromWishlistService);
	deleteFromWishlistService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(deleteFromWishlistService.makeRequest(props));
};

/**
 * Action to locally updates single item quantity at a particular index
 * @param {int} index
 * @param {int} quantity
 */
export const onUpdateItemQuantity = (index, quantity) => {
	return {
		type: ActionTypes.UPDATE_ITEM_QUANTITY,
		payload: {
			quantity,
			index,
		},
	};
};

/**
 * Action to remove item from a particular index
 * @param {int} index
 */
export const onDeleteCurrentItem = index => {
	return {
		type: ActionTypes.DELETE_CURRENT_ITEM_FROM_LIST,
		payload: index,
	};
};

/**
 * Action to call Most selling items list api
 * @param {object} props
 * @param {boolean} appendToExistingList
 */
export const onGetMostSellingItems = (props, appendToExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_MOST_SELLING_ITEMS_LIST_SUCCESS,
		ActionTypes.GET_MOST_SELLING_ITEMS_LIST_FAILURE,
		ActionTypes.GET_MOST_SELLING_ITEMS_LIST_LOADER,
	)
		.addSuccessExtra(appendToExistingList)
		.build();
	const getMostSellingItemsService = new GetMostSellingItemsService(dispatchedActions);
	addBasicInterceptors(getMostSellingItemsService);
	getMostSellingItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getMostSellingItemsService.makeRequest(props));
};

/**
 * Action to call Newly added item list api
 * @param {object} props
 * @param {boolean} appendToExistingList
 */
export const onGetNewlyAddedItems = (props, appendToExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_NEWLY_ADDED_ITEMS_LIST_SUCCESS,
		ActionTypes.GET_NEWLY_ADDED_ITEMS_LIST_FAILURE,
		ActionTypes.GET_NEWLY_ADDED_ITEMS_LIST_LOADER,
	)
		.addSuccessExtra(appendToExistingList)
		.build();
	const getNewlyAddedItemsService = new GetNewlyAddedItemsService(dispatchedActions);
	addBasicInterceptors(getNewlyAddedItemsService);
	getNewlyAddedItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getNewlyAddedItemsService.makeRequest(props));
};

/**
 * Action to call discount item list api.
 * @param {object} props
 * @param {boolean} appendToExistingList
 */
export const onGetDiscountItems = (props, appendToExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_DISCOUNT_ITEMS_LIST_SUCCESS,
		ActionTypes.GET_DISCOUNT_ITEMS_LIST_FAILURE,
		ActionTypes.GET_DISCOUNT_ITEMS_LIST_LOADER,
	)
		.addSuccessExtra(appendToExistingList)
		.build();
	const getDiscountItemsService = new GetDiscountItemsService(dispatchedActions);
	addBasicInterceptors(getDiscountItemsService);
	getDiscountItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getDiscountItemsService.makeRequest(props));
};

// Action to reset item list reducer
export const onResetItemListState = () => ({ type: ActionTypes.RESET_WISHLIST });
