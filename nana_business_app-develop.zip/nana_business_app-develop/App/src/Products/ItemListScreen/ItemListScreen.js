import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { endpointAddCart, fetchDataWithPagination, toastShowTime } from '@Constants/Constants';
import ToastComponent from '@ToastComponent/ToastComponent';
import ProductCardComponent from '@Products/ProductCardComponent';
import IMAGES from '@Images/index';
import navigations from '@routes/navigations';
import Loader from '@Loader/Loader';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import * as CartDetailActions from '@CartScreen/CartScreenAction';
import CartFloater from '@CartFloater/CartFloater';
import Spinner from '@Spinner/Spinner';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import Header from '@Header/Header';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import HomeItemComponent from '@HomeItemComponent/HomeItemComponent';
import { verticalScale } from '@device/normalize';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import * as ItemListScreenAction from './ItemListScreenAction';
import { createStyleSheet } from './ItemListScreenStyle';

class ItemListScreen extends Component {
	constructor(props) {
		super(props);
		const { title } = props.route.params || {};
		this.title = title;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.cartFloater = React.createRef(null);
		this.state = {
			productListItems: [],
			productListCount: 0,
			changeSelectedItemQuantity: 0,
			itemIndexToUpdate: null,
			isApiError: false,
			toastMessage: '',
			bottomLoader: false,
			selectedItem: null,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { pullToRefreshActions, refreshControlComponentInfo } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.limit = getScrollingIndex(scrollIndex);
			this.onGetCartCount();
			this.onCallAPI();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			itemListScreenInfo,
			itemListScreenActions,
			pullToRefreshActions,
			cartDetailInfo,
		} = this.props;
		const {
			success,
			isUpdateList,
			isItemAddedToCArt,
			isSubCategoryItems,
			itemList,
			error,
			itemListCount,
			errorCode,
			isDeletedFromWishList,
			errorCodeCart,
		} = itemListScreenInfo;
		const {
			itemIndexToUpdate,
			changeSelectedItemQuantity,
			selectedItem,
			productListItems,
		} = this.state;
		if (success && prevProps.itemListScreenInfo.success !== itemListScreenInfo.success) {
			if (isItemAddedToCArt) {
				// if item is added to cart succesfully
				this.onGetCartCount();
				itemListScreenActions.onUpdateItemQuantity(
					itemIndexToUpdate,
					changeSelectedItemQuantity,
				);
				this.cartFloater.current.handleCartFloater();
			} else if (isUpdateList) {
				// if item is removed from wishlist succesfully
				this.setState(
					{
						toastMessage: `${localeString(keyConstants.REMOVED_FROM_WISHLIST)}`,
						isApiError: true,
					},
					() => {
						setTimeout(() => {
							this.setState({
								isApiError: false,
							});
						}, toastShowTime);
						itemListScreenActions.onDeleteCurrentItem(itemIndexToUpdate);
					},
				);
			} else if (itemList && isSubCategoryItems) {
				// if item listing return success
				this.setState(
					{
						productListItems: itemList,
						productListCount: itemListCount,
						bottomLoader: false,
					},
					() => {
						if (this.page === 1 && this.itemListRef) {
							this.itemListRef.onScroll(this.title !== keyConstants.WISHLIST ? 2 : 1);
						}
					},
				);
				pullToRefreshActions.onHandlePullToRefresh(false);
			}
		}
		if (
			cartDetailInfo.successCart &&
			prevProps.cartDetailInfo.successCart !== cartDetailInfo.successCart
		) {
			this.onGetCartCount(); // Will update the cart count.
			this.cartFloater.current.handleCartFloater(); // Will show the toast of the updated cart amount.
		}
		if (error && prevProps.itemListScreenInfo.error !== itemListScreenInfo.error) {
			if (itemIndexToUpdate !== null) {
				// if item add to cart return failure
				const productListItemsCopy = productListItems;
				productListItemsCopy[itemIndexToUpdate].count_in_cart = changeSelectedItemQuantity;
				this.setState({
					productListItems: productListItemsCopy,
					productListCount: itemListCount,
					itemIndexToUpdate: null,
				});
			}
			if (isDeletedFromWishList) {
				// Will show alert if delete from wishlist api fails.
				ErrorAlertComponent(errorCode, () =>
					this.onDeleteProduct(selectedItem, itemIndexToUpdate),
				);
			}
			if (errorCodeCart.error === keyConstants.ADD_ITEM_ERROR) {
				this.setState(
					{
						toastMessage: localeString(keyConstants.ADD_ITEM_ERROR),
						isApiError: true,
					},
					() => {
						setTimeout(() => {
							this.setState({
								isApiError: false,
							});
						}, toastShowTime);
					},
				);
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	componentWillUnmount() {
		this.resetScrollIndex();
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	onCallAPI = () => {
		this.setState(
			{
				changeSelectedItemQuantity: 0,
				itemIndexToUpdate: null,
			},
			() => {
				this.page = fetchDataWithPagination.page;
				this.onGetListItems(false);
			},
		);
	};

	// this fucntion calls API for whatever screen(wishlist/most selling items/newly added items) it is on & get their respective items list
	onGetListItems = appendToExistingList => {
		const { homeScreenInfo, userDetails, itemListScreenActions } = this.props;
		const { branchListing, activeBranchIndex } = homeScreenInfo;
		const id =
			activeBranchIndex !== null
				? branchListing &&
				  branchListing[activeBranchIndex] &&
				  branchListing[activeBranchIndex].id
				: userDetails &&
				  userDetails.user &&
				  userDetails.user.organization &&
				  userDetails.user.organization.id;
		const options = {};
		options.limit = this.limit;
		options.page = this.page;
		switch (this.title) {
			case keyConstants.NEWLY_ADDED_ITEMS:
				options.branch = id;
				return itemListScreenActions.onGetNewlyAddedItems(options, appendToExistingList);
			case keyConstants.MOST_SELLING_ITEMS:
				options.branch = id;
				return itemListScreenActions.onGetMostSellingItems(options, appendToExistingList);
			case keyConstants.DISCOUNTS:
				options.branch = id;
				return itemListScreenActions.onGetDiscountItems(options, appendToExistingList);
			case keyConstants.WISHLIST:
				return itemListScreenActions.onGetWishListedItems(options, appendToExistingList);
			default:
				return null;
		}
	};

	onGetCartCount = () => {
		// Call api to get cart count
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetCartCount();
	};

	navigateTo = (item, index) => {
		this.itemListRef.onSetIndex(index);
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_DETAILS_NAVIGATION, { id: item.id });
	};

	getWishlistLayout = (data, index) => ({
		length: verticalScale(160),
		offset: verticalScale(160) * index,
		index,
	});

	getLayout = (data, index) => ({
		length: verticalScale(280),
		offset: verticalScale(280) * index,
		index,
	});

	onPressBack = () => {
		// Function to go back and reset item list screen reducer
		const { navigation, itemListScreenActions } = this.props;
		navigation.goBack();
		itemListScreenActions.onResetItemListState();
	};

	onPressCart = () => {
		const { navigation, itemListScreenActions } = this.props;
		navigation.navigate(navigations.CART_NAVIGATION);
		itemListScreenActions.onResetItemListState();
	};

	onEndReachedListItem = () => {
		const { itemListScreenInfo } = this.props;
		const { loader } = itemListScreenInfo;
		if (!loader) {
			this.setState(
				{
					bottomLoader: true,
				},
				() => {
					this.page += getPage(this.limit);
					this.limit = fetchDataWithPagination.limit;
					this.onGetListItems(true);
				},
			);
		}
		return null;
	};

	listFooterComponent = () => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { productListItems, productListCount } = this.state;
		const endReached =
			productListCount === productListItems.length ||
			productListCount < productListItems.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onPressPlus = (item, index) => {
		// funtion to increase or add quantity of selected item in cart
		const updatedQuantity = item.count_in_cart
			? item.count_in_cart + 1
			: item.minimum_quantity
			? item.minimum_quantity
			: 1;
		if (item.count_in_cart === null) {
			logCustomEventOnBraze('productAddedToCart', { itemId: item.id });
		}
		this.onModifyItemQuantity(item, index, updatedQuantity);
	};

	onPressMinus = (item, index) => {
		// funtion to decrease or remove quantity of selected item from cart
		if (item.count_in_cart > item.minimum_quantity) {
			this.onModifyItemQuantity(item, index, item.count_in_cart - 1);
		} else {
			this.onRemoveWishlistItemFromCart(index);
		}
	};

	onChangeText = (text, index) => {
		// Will update the given in the text field.
		const { productListItems } = this.state;
		const productListItemsCopy = productListItems;
		if (text === '') {
			productListItemsCopy[index].count_in_cart = '';
		} else {
			productListItemsCopy[index].count_in_cart = parseInt(text, 10);
		}
		this.setState({
			productListItems: productListItemsCopy,
			itemIndexToUpdate: null,
		});
	};

	onModifyItemQuantity = (item, index, quantity) => {
		const { itemListScreenActions } = this.props;
		const queryparam = {};
		queryparam.item_id = item.id;
		queryparam.quantity = quantity;
		queryparam.warehouse_id = item.warehouse_id;
		queryparam.vendor_id = item.vendor_organization_id;
		this.setState(
			{
				itemIndexToUpdate: index,
				changeSelectedItemQuantity: quantity,
			},
			() => {
				itemListScreenActions.onUpdateCart(queryparam, this.getEndpoint());
			},
		);
	};

	getEndpoint = () => {
		switch (this.title) {
			case keyConstants.NEWLY_ADDED_ITEMS:
				return endpointAddCart.recentlyAdded;
			case keyConstants.MOST_SELLING_ITEMS:
				return endpointAddCart.mostSelling;
			case keyConstants.DISCOUNTS:
				return endpointAddCart.discount;
			case keyConstants.WISHLIST:
				return endpointAddCart.wishlist;
			default:
				return null;
		}
	};

	onChangeTextInput = (text, index) => {
		const { productListItems } = this.state;
		const productListItemsCopy = productListItems;
		if (text === '') {
			productListItemsCopy[index].count_in_cart = '';
		} else {
			productListItemsCopy[index].count_in_cart = parseInt(text, 10);
		}
		this.setState({
			productListItems: productListItemsCopy,
			itemIndexToUpdate: null,
		});
	};

	onDeleteProduct = (item, index) => {
		// Call api to remove item from wishlist
		const { itemListScreenActions } = this.props;
		const queryparam = {
			id: item.id,
		};
		this.setState({
			itemIndexToUpdate: index,
			selectedItem: item,
		});
		itemListScreenActions.onDeleteFromWishlist(queryparam);
	};

	updateCart = index => {
		const { productListItems } = this.state;
		const productListItemsCopy = [...productListItems];
		const { count_in_cart, minimum_quantity } = productListItemsCopy[index];
		if (count_in_cart >= minimum_quantity) {
			this.onModifyItemQuantity(productListItemsCopy[index], index, count_in_cart);
		} else {
			this.onRemoveWishlistItemFromCart(index);
		}
	};

	onRemoveWishlistItemFromCart = index => {
		// Will delete item from the cart
		const { productListItems } = this.state;
		const productListItemsCopy = productListItems;
		productListItemsCopy[index].count_in_cart = 0;
		const {
			id, // item id
			vendor_organization_id, // vendor organization id
		} = productListItemsCopy[index];
		const itemDetail = {
			item_id: id,
			vendor_organization_id,
		};
		this.setState(
			{
				productListItems: productListItemsCopy,
				itemIndexToUpdate: index,
			},
			this.onDeleteWishlistItem(itemDetail),
		);
	};

	onDeleteWishlistItem = itemDetail => {
		// API to delete the item from the cart.
		const { cartDetailActions } = this.props;
		cartDetailActions.onDeleteItem(itemDetail);
	};

	renderItem = ({ item, index }) => {
		// function to render wishlist row item
		const { languageInfo, configurableFileInfo } = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			images,
			name_ar,
			name,
			brand_name,
			sub_category_name,
			sub_category_name_ar,
			price,
			offer_price,
			count_in_cart,
			minimum_quantity,
			brand_name_ar,
			items_per_packet,
			value_of_item,
			unit,
			unit_ar,
			price_per_item,
			status_out_of_stock,
		} = item;
		let perc;
		if (price && offer_price) {
			perc = Number(((price - offer_price) / price) * 100).toFixed(2);
		} else {
			perc = 0;
		}
		const subTitleText = `${isRTL ? brand_name_ar : brand_name}${
			sub_category_name ? ` | ${isRTL ? sub_category_name_ar : sub_category_name}` : ''
		}`;
		return (
			<TouchableOpacity
				style={[
					styles.productContainer,
					items_per_packet && value_of_item && unit && styles.withoutBorder,
				]}
				activeOpacity={0.8}
				onPress={() => this.navigateTo(item, index)}>
				<ProductCardComponent
					image={images && images.small}
					title={isRTL ? name_ar : name}
					subtitle={subTitleText}
					price={price}
					statusOutOfStock={status_out_of_stock}
					discountPercentage={parseInt(perc, 10) !== 0 ? `${perc}%` : ''}
					discountedPrice={parseFloat(offer_price) ? offer_price : price}
					isPlusButton={
						remoteConfigData?.addToCart &&
						!status_out_of_stock &&
						(count_in_cart === null || count_in_cart === 0)
					}
					isPlusMinusButton={
						remoteConfigData?.addToCart &&
						!!(
							((count_in_cart && parseInt(count_in_cart, 10) > 0) ||
								count_in_cart === '') &&
							!status_out_of_stock
						)
					}
					onPressAdd={() => this.onPressPlus(item, index)}
					onPressPlus={() => this.onPressPlus(item, index)}
					onPressMinus={() => this.onPressMinus(item, index)}
					onDeleteProduct={() => this.onDeleteProduct(item, index)}
					itemCount={count_in_cart || 0}
					isPriceDiscountPercentage
					isDiscountedPrice
					onChangeText={text => this.onChangeTextInput(text, index)}
					updateCart={() => this.updateCart(index)}
					minimumQuantity={minimum_quantity}
					isMinimumQuantity
					hasFooterView
					hasMinimumQuantity
					itemsPerPacket={items_per_packet}
					isDelete={this.title === keyConstants.WISHLIST} // show delete icon only on wishlist screen
					valueOfItem={value_of_item}
					unit={isRTL ? unit_ar : unit}
					pricePerItem={price_per_item}
				/>
			</TouchableOpacity>
		);
	};

	renderProductItem = ({ item, index }) => {
		// function to render row component for most-selling item and newly added item list
		const { languageInfo, configurableFileInfo } = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			images,
			name_ar,
			name,
			price_with_vat,
			offer_price_with_vat,
			count_in_cart,
			items_per_packet,
			value_of_item,
			unit,
			unit_ar,
			status_out_of_stock,
			price_per_item,
		} = item;
		return (
			<HomeItemComponent
				isRTL={isRTL}
				image={images && images.large}
				name={isRTL ? name_ar : name}
				valueOfItem={value_of_item}
				itemsPerPacket={items_per_packet}
				unit={isRTL ? unit_ar : unit}
				offerPrice={offer_price_with_vat}
				pricePerItem={price_per_item}
				isProductList
				price={price_with_vat}
				isPlusButton={
					remoteConfigData?.addToCart && (count_in_cart === null || count_in_cart === 0)
				}
				onPressAdd={() => this.onPressPlus(item, index)}
				statusOutOfStock={status_out_of_stock}
				isPlusMinusButton={
					remoteConfigData?.addToCart &&
					!!((count_in_cart && parseInt(count_in_cart, 10) > 0) || count_in_cart === '')
				}
				onPressMinus={() => this.onPressMinus(item, index)}
				itemCount={count_in_cart || 0}
				onChangeText={text => this.onChangeText(text, index)}
				updateCart={() => this.updateCart(index)}
				onPressPlus={() => this.onPressPlus(item, index)}
				onPress={() => this.navigateTo(item, index)}
				containerStyle={styles.containerStyle}
				unitStyle={styles.unitStyle}
				imageStyle={styles.imageStyle}
				priceStyle={styles.priceStyle}
				titleStyle={styles.titleStyle}
				numberOfLines={2}
				noPerUnitPrice
			/>
		);
	};

	keyExtractor = (item, index) => index.toString();

	onRefresh = () => {
		this.resetScrollIndex();
		this.page = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		this.onCallAPI();
	};

	render() {
		const {
			languageInfo,
			itemListScreenInfo,
			homeScreenInfo,
			refreshControlComponentInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			loader,
			isUpdateList,
			error,
			errorCode,
			isAddedToWishList,
			isDeletedFromWishList,
		} = itemListScreenInfo;
		const {
			productListItems,
			toastMessage,
			isApiError,
			productListCount,
			bottomLoader,
		} = this.state;
		const { cartCount, cartAmount } = homeScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { title } = this;
		if (loader && !bottomLoader && !isFetchingForPullToRefresh && !isUpdateList) {
			return <Loader size="large" />; // Will show loader on the screen.
		}
		if (productListItems.length === 0 && title === keyConstants.WISHLIST) {
			// Will show empty list component if there is no items added in the wishlist.
			return (
				<ConfimationModal
					title={localeString(keyConstants.NO_ITEMS_IN_WISHLIST)}
					description={`${localeString(keyConstants.NO_ITEMS_ADDED_IN_WISHLIST)}`}
					buttonTitle={localeString(keyConstants.GO_TO_HOME)}
					hasIconCross // Boolean to show cross icon
					onGoBack={this.onPressBack} // Will go back to the previous screen
					imageSource={IMAGES.iconEmptyWishlist}
				/>
			);
		}
		return (
			<View style={styles.container}>
				{isUpdateList && loader && <Spinner size="large" />}
				<Header
					text={localeString(title)}
					hasIconBack
					onPressBack={this.onPressBack}
					hasIconSmallCart
					onPressCart={this.onPressCart}
					cartCount={cartCount}
					headerStyle={styles.wishlistHeader}
				/>
				{error && !isDeletedFromWishList && !isAddedToWishList ? (
					<ErrorComponent // Error component if api fails.
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<View
						style={[
							styles.productListContainer,
							title !== keyConstants.WISHLIST && styles.listConatiner,
						]}>
						<FlatListComponent
							showsVerticalScrollIndicator={false}
							data={productListItems}
							renderItem={
								title === keyConstants.WISHLIST
									? this.renderItem
									: this.renderProductItem
							}
							keyExtractor={this.keyExtractor}
							ListFooterComponent={
								productListItems.length !== 0 &&
								productListCount > fetchDataWithPagination.limit &&
								this.listFooterComponent()
							}
							onEndReached={() =>
								productListItems.length !== productListCount &&
								this.onEndReachedListItem()
							}
							onEndReachedThreshold={0.9}
							contentContainerStyle={
								productListItems.length === 0 ? styles.scrollViewStyle : null
							}
							onRefresh={this.onRefresh}
							componentType={constants.flatList}
							numColumns={title !== keyConstants.WISHLIST ? 2 : null}
							onRef={ref => {
								this.itemListRef = ref;
							}}
							getItemLayout={
								title === keyConstants.WISHLIST
									? this.getWishlistLayout
									: this.getLayout
							}
						/>
					</View>
				)}
				<CartFloater
					isRTL={isRTL}
					cartAmount={cartAmount}
					ref={this.cartFloater}
					onPressToast={this.onPressCart}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		itemListScreenInfo: state.ItemListScreenReducer,
		homeScreenInfo: state.HomeScreenReducer,
		cartDetailInfo: state.CartScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		itemListScreenActions: bindActionCreators({ ...ItemListScreenAction }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		cartDetailActions: bindActionCreators({ ...CartDetailActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

ItemListScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	itemListScreenInfo: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	cartDetailInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	itemListScreenActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	cartDetailActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ItemListScreen);
