import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { moderateScale, normalScale, verticalScale } from '@device/normalize';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import { renderFlexDirectionBasedOnRtl } from '@lib/helpers';
import { productMaxLength, fontsConstants, IMAGE_TYPE } from '@Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getUnitsAndPricing } from '@Util/GetUnitsAndPricing';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			marginHorizontal: normalScale(16),
		},
		productImgContainer: {
			height: normalScale(60),
			width: normalScale(60),
			backgroundColor: colors.white,
			borderColor: colors.grey,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(8),
			paddingVertical: verticalScale(5),
			paddingHorizontal: verticalScale(5),
			justifyContent: 'center',
			alignItems: 'center',
		},
		productImg: {
			height: normalScale(50),
			width: normalScale(50),
		},
		productInfoContainer: {
			flex: 1,
			paddingLeft: isRTL ? null : normalScale(10),
			paddingRight: isRTL ? normalScale(10) : null,
		},
		deleteProductContainer: {
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		title: {
			width: normalScale(200),
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			color: colors.black,
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		iconProductDelete: {
			width: normalScale(16),
			height: verticalScale(16),
		},
		quantityStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(10),
			marginTop: verticalScale(4),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		quantityContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		subTitle: {
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
			marginTop: verticalScale(4),
			width: normalScale(150),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		priceDetailsContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(13),
			marginLeft: isRTL ? null : -normalScale(3),
			marginRight: isRTL ? -normalScale(3) : null,
			alignItems: 'center',
		},
		discountedPrice: {
			fontSize: normalize(11),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.darkBlue,
		},
		price: {
			fontSize: normalize(10),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.black,
			textDecorationLine: 'line-through',
			marginLeft: isRTL ? null : normalScale(4),
			marginRight: isRTL ? normalScale(4) : null,
		},
		discountPercentage: {
			fontSize: normalize(10),
			marginLeft: isRTL ? null : normalScale(4),
			marginRight: isRTL ? normalScale(4) : null,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			color: colors.lightBlueShadowGrey,
		},
		driverContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
			marginTop: verticalScale(8),
		},
		driverPrice: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.darkBlue,
		},
		priceInfoContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(8),
			justifyContent: 'space-between',
			flex: 1,
			alignItems: 'center',
			marginHorizontal: normalScale(16),
		},
		minQuantity: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			color: colors.black,
			fontSize: normalize(12),
		},
		buttonContainer: {
			height: verticalScale(30),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			alignItems: 'center',
		},
		addProductContainer: {
			width: normalScale(72),
			height: verticalScale(22),
			borderTopLeftRadius: isRTL ? null : moderateScale(4),
			borderBottomLeftRadius: isRTL ? null : moderateScale(4),
			borderTopRightRadius: isRTL ? moderateScale(4) : null,
			borderBottomRightRadius: isRTL ? moderateScale(4) : null,
			backgroundColor: colors.white,
			alignItems: 'center',
			justifyContent: 'center',
			shadowColor: colors.darkBlue,
			shadowOffset: {
				width: normalScale(5),
				height: verticalScale(5),
			},
			shadowRadius: moderateScale(20),
			shadowOpacity: 0.1,
			elevation: verticalScale(15),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 1),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 1),
		},
		addText: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.darkBlue,
		},
		plusBlue: {
			height: verticalScale(20),
			width: normalScale(20),
		},
		buttonContainerPlusMinus: {
			flexDirection: 'row',
			height: verticalScale(30),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		plusMinusContainerStyle: {
			shadowColor: colors.darkBlue,
			shadowOffset: {
				width: normalScale(5),
				height: verticalScale(10),
			},
			shadowRadius: moderateScale(20),
			shadowOpacity: 0.2,
			elevation: verticalScale(15),
			borderRadius: moderateScale(4),
		},
		plus: {
			height: normalScale(22),
			width: normalScale(22),
		},
		countContainer: {
			width: normalScale(36),
			height: normalScale(30),
			backgroundColor: colors.white,
			justifyContent: 'center',
			alignItems: 'center',
			borderRadius: moderateScale(4),
			borderColor: colors.grey,
			borderWidth: normalize(1),
			marginHorizontal: normalScale(8),
		},
		itemCount: {
			width: normalScale(36),
			height: normalScale(30),
			fontSize: normalize(12),
			textAlign: 'center',
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.black,
			paddingVertical: verticalScale(5),
		},
		footerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			paddingHorizontal: normalScale(16),
			paddingVertical: verticalScale(3),
			backgroundColor: colors.lightGreen,
			marginTop: -verticalScale(10),
		},
		footerText: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.darkBlue,
		},
		footerAmount: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			color: colors.darkBlue,
		},
		outOfStockContainer: {
			width: normalScale(112),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			justifyContent: 'center',
			backgroundColor: colors.grey,
			paddingVertical: verticalScale(5),
			borderRadius: moderateScale(6),
		},
		outOfStockText: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.blackGreyWhite,
		},
	});
};

const ProductCardComponent = props => {
	const {
		image,
		title,
		subtitle,
		price,
		discountPercentage,
		itemCount,
		discountedPrice,
		isPlusButton,
		onPressAdd,
		isPlusMinusButton,
		onPressPlus,
		onPressMinus,
		isPriceDiscountPercentage,
		isDiscountedPrice,
		onChangeText,
		updateCart,
		isMinimumQuantity,
		minimumQuantity,
		hasFooterView,
		isDelete,
		onDeleteProduct,
		itemsPerPacket,
		valueOfItem,
		unit,
		pricePerItem,
		isDriverApp,
		orderedQuantity,
		containerStyle,
		titleStyle,
		subtitleStyle,
		originalQuantity,
		discountedPriceStyle,
		hasMinimumQuantity,
		statusOutOfStock,
		languageInfo,
		priceDetailsContainerStyle,
		...remainingProps
	} = props;
	const { isRTL } = languageInfo;
	const styles = createStyleSheet(isRTL);
	return (
		<View>
			<View style={[styles.container, containerStyle]}>
				<View style={styles.productImgContainer}>
					<ImageLoadComponent
						isUrl
						imageType={IMAGE_TYPE.item}
						source={image}
						style={styles.productImg}
					/>
				</View>
				<View style={styles.productInfoContainer}>
					<View>
						<View style={styles.deleteProductContainer}>
							<Text style={[styles.title, titleStyle]} numberOfLines={2}>
								{title}
							</Text>
							{isDelete && (
								<TouchableOpacity onPress={onDeleteProduct} activeOpacity={0.8}>
									<ImageLoadComponent
										source={IMAGES.iconDeleteRed}
										style={styles.iconProductDelete}
									/>
								</TouchableOpacity>
							)}
						</View>
						{hasFooterView && itemsPerPacket && valueOfItem && unit ? (
							<Text style={styles.quantityStyle}>
								{getUnitsAndPricing(
									itemsPerPacket,
									valueOfItem,
									unit,
									pricePerItem,
								)}
							</Text>
						) : null}
						<View style={styles.quantityContainer}>
							<Text style={[styles.subTitle, subtitleStyle]}>{subtitle}</Text>
						</View>
					</View>
					{isDriverApp && (
						<View style={styles.driverContainer}>
							<Text style={styles.driverPrice}>
								{`${currencyFormatter(
									getValueInDecimal(discountedPrice),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
							<View style={styles.buttonContainerPlusMinus}>
								<TouchableOpacity
									disabled={itemCount <= 1}
									style={styles.plusMinusContainerStyle}
									onPress={onPressMinus}>
									<ImageLoadComponent
										source={
											itemCount <= 1
												? IMAGES.iconMinusWhite
												: IMAGES.iconMinusGreen
										}
										style={styles.plus}
									/>
								</TouchableOpacity>
								<View style={styles.countContainer}>
									<TextInput
										style={styles.itemCount}
										keyboardType="number-pad"
										autoCapitalize="none"
										value={`${itemCount}`}
										returnKeyType="done"
										maxLength={productMaxLength}
										onChangeText={onChangeText}
										onBlur={updateCart}
										{...remainingProps}
									/>
								</View>
								<TouchableOpacity
									disabled={orderedQuantity === itemCount}
									style={styles.plusMinusContainerStyle}
									onPress={onPressPlus}>
									<ImageLoadComponent
										source={
											orderedQuantity === itemCount
												? IMAGES.iconPlusWhite
												: IMAGES.iconPlusGreen
										}
										style={styles.plus}
									/>
								</TouchableOpacity>
							</View>
						</View>
					)}
					<View style={[styles.priceDetailsContainer, priceDetailsContainerStyle]}>
						{isDiscountedPrice && (
							<Text style={[styles.discountedPrice, discountedPriceStyle]}>
								{`${currencyFormatter(
									getValueInDecimal(discountedPrice),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						)}
						{isPriceDiscountPercentage && discountPercentage !== '' && (
							<Text style={styles.price}>
								{`${currencyFormatter(getValueInDecimal(price))} ${localeString(
									keyConstants.SAR,
								)}`}
							</Text>
						)}
						<Text style={styles.discountPercentage}>{discountPercentage}</Text>
					</View>
				</View>
			</View>
			{isDriverApp && (
				<View style={styles.footerView}>
					<Text style={styles.footerText}>{localeString(keyConstants.QTY_ORDERED)}</Text>
					<Text style={styles.footerAmount}>{originalQuantity}</Text>
				</View>
			)}
			<View style={styles.priceInfoContainer}>
				{hasMinimumQuantity && (
					<Text style={styles.minQuantity}>
						{`${localeString(keyConstants.MIN_QTY)}: ${minimumQuantity}`}
					</Text>
				)}
				{isPlusButton && !statusOutOfStock && (
					<TouchableOpacity style={styles.buttonContainer} onPress={onPressAdd}>
						<View style={styles.addProductContainer}>
							<Text style={styles.addText}>{localeString(keyConstants.ADD)}</Text>
						</View>
						<ImageLoadComponent source={IMAGES.iconPlusBlue} style={styles.plusBlue} />
					</TouchableOpacity>
				)}
				{statusOutOfStock && (
					<View style={styles.outOfStockContainer}>
						<Text style={styles.outOfStockText}>
							{localeString(keyConstants.OUT_OF_STOCK)}
						</Text>
					</View>
				)}
				{isPlusMinusButton && (
					<View style={styles.buttonContainerPlusMinus}>
						<TouchableOpacity
							style={styles.plusMinusContainerStyle}
							onPress={onPressMinus}>
							<ImageLoadComponent
								source={IMAGES.iconMinusGreen}
								style={styles.plus}
							/>
						</TouchableOpacity>
						<View style={styles.countContainer}>
							<TextInput
								style={styles.itemCount}
								keyboardType="number-pad"
								autoCapitalize="none"
								value={`${itemCount}`}
								returnKeyType="done"
								maxLength={productMaxLength}
								onChangeText={onChangeText}
								onBlur={updateCart}
								{...remainingProps}
							/>
						</View>
						<TouchableOpacity
							style={styles.plusMinusContainerStyle}
							onPress={onPressPlus}>
							<ImageLoadComponent source={IMAGES.iconPlusGreen} style={styles.plus} />
						</TouchableOpacity>
					</View>
				)}
			</View>
		</View>
	);
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
	};
};

ProductCardComponent.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	image: PropTypes.string.isRequired,
	title: PropTypes.string.isRequired,
	subtitle: PropTypes.string.isRequired,
	price: PropTypes.number.isRequired,
	discountPercentage: PropTypes.number.isRequired,
	itemCount: PropTypes.number.isRequired,
	discountedPrice: PropTypes.number.isRequired,
	isPlusButton: PropTypes.bool.isRequired,
	onPressAdd: PropTypes.func.isRequired,
	isPlusMinusButton: PropTypes.bool.isRequired,
	onPressPlus: PropTypes.func.isRequired,
	onPressMinus: PropTypes.func.isRequired,
	isPriceDiscountPercentage: PropTypes.bool.isRequired,
	isDiscountedPrice: PropTypes.bool.isRequired,
	onChangeText: PropTypes.func.isRequired,
	updateCart: PropTypes.func.isRequired,
	isMinimumQuantity: PropTypes.bool.isRequired,
	minimumQuantity: PropTypes.number.isRequired,
	hasFooterView: PropTypes.bool.isRequired,
	isDelete: PropTypes.bool.isRequired,
	onDeleteProduct: PropTypes.func.isRequired,
	itemsPerPacket: PropTypes.number.isRequired,
	valueOfItem: PropTypes.number.isRequired,
	unit: PropTypes.string.isRequired,
	pricePerItem: PropTypes.number.isRequired,
	isDriverApp: PropTypes.bool.isRequired,
	orderedQuantity: PropTypes.number.isRequired,
	containerStyle: PropTypes.object.isRequired,
	titleStyle: PropTypes.object.isRequired,
	subtitleStyle: PropTypes.object.isRequired,
	originalQuantity: PropTypes.number.isRequired,
	discountedPriceStyle: PropTypes.object.isRequired,
	hasMinimumQuantity: PropTypes.bool.isRequired,
	statusOutOfStock: PropTypes.bool.isRequired,
	priceDetailsContainerStyle: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, null)(ProductCardComponent);
