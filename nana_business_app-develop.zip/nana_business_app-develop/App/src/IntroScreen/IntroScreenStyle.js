import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		nanaBusinessIconContainer: {
			justifyContent: 'flex-start',
			marginTop: verticalScale(25),
			marginLeft: normalScale(29),
			marginBottom: verticalScale(2),
		},
		nanaBusinessManContainer: {
			width: normalScale(320),
			height: verticalScale(328),
			alignSelf: 'center',
		},
		bottomContainer: {
			flex: 1,
			flexDirection: isRTL ? 'row-reverse' : 'row',
			alignItems: 'center',
			justifyContent: 'center',
			backgroundColor: colors.white,
			marginBottom: verticalScale(42),
			paddingHorizontal: normalScale(16),
			position: 'absolute',
			bottom: 0,
			left: 0,
			right: 0,
		},
		buttonContainerSignIn: {
			flex: 1,
			marginEnd: normalScale(8),
		},
		buttonContainerSignUp: {
			flex: 1,
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		btnSignIn: {
			flex: 1,
			borderRadius: normalScale(8),
			backgroundColor: colors.white,
			borderStyle: 'solid',
			borderWidth: normalScale(1),
			borderColor: colors.lightGrey,
			shadowColor: colors.lightShadowGrey,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.25,
			elevation: verticalScale(2),
		},
		btnSignUp: {
			flex: 1,
			borderRadius: normalScale(8),
			backgroundColor: colors.darkBlue,
		},
		btnLabelSignIn: {
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
			letterSpacing: normalScale(0),
			color: colors.darkBlack,
		},
		btnLabelSignUp: {
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
			letterSpacing: normalScale(0),
			color: colors.white,
		},
	});
};

export default createStyleSheet;
