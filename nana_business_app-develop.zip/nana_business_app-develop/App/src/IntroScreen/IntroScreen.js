import React, { Component } from 'react';
import { View } from 'react-native';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { localeString } from '@Localization/index';
import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';
import { USER_TYPE } from '@Constants/Constants';
import navigations from '@routes/navigations';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { createStyleSheet } from './IntroScreenStyle';

class IntroScreen extends Component {
	constructor(props) {
		super(props);
		const { route } = props;
		this.userType = route.params.userType;
	}

	onPressSignIn = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.SIGNIN_NAVIGATION, { userType: this.userType });
	};

	onPressSignUp = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.SIGN_UP_NAVIGATION, { userType: this.userType });
	};

	render() {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<ImageLoadComponent
					style={styles.nanaBusinessIconContainer}
					source={IMAGES.iconNanaBusiness}
				/>
				<ImageLoadComponent
					style={styles.nanaBusinessManContainer}
					source={IMAGES.iconNanaBusinessMan}
				/>
				<View style={styles.bottomContainer}>
					<View style={styles.buttonContainerSignIn}>
						<ButtonComponent
							buttonStyle={styles.btnSignIn}
							text={localeString(keyConstants.SIGN_IN)}
							textStyle={styles.btnLabelSignIn}
							onPress={this.onPressSignIn}
						/>
					</View>
					{this.userType === USER_TYPE.CUSTOMER ? (
						<View style={styles.buttonContainerSignUp}>
							<ButtonComponent
								buttonStyle={styles.btnSignUp}
								text={localeString(keyConstants.SIGN_UP)}
								textStyle={styles.btnLabelSignUp}
								onPress={this.onPressSignUp}
							/>
						</View>
					) : null}
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		roleInfo: state.RoleScreenReducer,
		languageInfo: state.LanguageScreenReducer,
	};
};

IntroScreen.propTypes = {
	route: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, null)(IntroScreen);
