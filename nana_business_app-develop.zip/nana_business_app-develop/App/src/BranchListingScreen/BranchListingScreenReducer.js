import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	branchListing: [],
	count: 0,
};

const BranchListingScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.RESET_BRANCH_LISTING:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
				branchListing: [],
				count: 0,
			};
		case ActionTypes.GET_BRANCHES_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				branchListing: isOverwriteExistingList
					? [...state.branchListing, ...action.payload.branch_list]
					: action.payload.branch_list,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_BRANCHES_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_BRANCHES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default BranchListingScreenReducer;
