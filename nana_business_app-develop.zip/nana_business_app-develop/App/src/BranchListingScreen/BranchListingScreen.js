import React, { Component } from 'react';
import { View, TouchableOpacity, ActivityIndicator, Text } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import MapView, { Marker } from 'react-native-maps';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import IMAGES from '@Images/index';
import { fetchDataWithPagination, customerAdmin, toastShowTime } from '@Constants/Constants';
import * as colors from '@assets/colors';
import ListEmpty from '@ListEmpty/ListEmpty';
import Loader from '@Loader/Loader';
import navigations from '@routes/navigations';
import Search from '@Search/Search';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import * as AddBranchActions from '@AddNewBranchScreen/AddNewBranchScreenAction';
import { verticalScale } from '@device/normalize';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';
import * as BranchListingActions from './BranchListingScreenAction';
import { createStyleSheet } from './BranchListingScreenStyle';

class BranchListingScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			searchText: '',
			isToastMessage: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { refreshControlComponentInfo, pullToRefreshActions } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.page = fetchDataWithPagination.page;
			this.limit = getScrollingIndex(scrollIndex);
			this.setState(
				{
					searchText: '',
				},
				() => this.onLoadMoreBranches(false),
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			branchListingInfo,
			addBranchInfo,
			pullToRefreshActions,
			addBranchActions,
		} = this.props;
		const { success } = branchListingInfo;
		const { success: branchAddedSuccess, isEditBranch } = addBranchInfo;
		if (success && prevProps.branchListingInfo.success !== success) {
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.page === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
			// if branch is edited or new branch is added then show edited/added successfully toast message
			if (branchAddedSuccess) {
				// Will show toast and reset the reducer after successful adding/editing the branch.
				this.showToast(
					isEditBranch
						? localeString(keyConstants.BRANCH_EDITED_SUCCESSFULLY)
						: localeString(keyConstants.BRANCH_ADDED_SUCCESSFULLY),
				);
				// reset branch state in redux after returning to branch list screen
				addBranchActions.onResetBranchState();
			}
		}
	}

	componentWillUnmount() {
		this.resetScrollIndex();
	}

	resetScrollIndex = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	renderItem = ({ item }) => {
		const { languageInfo, userDetails } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		return (
			<>
				{item.latitude && item.longitude && (
					<View style={styles.userInfoContainer}>
						<MapView
							style={styles.mapImage}
							initialRegion={{
								latitude: parseFloat(item.latitude),
								longitude: parseFloat(item.longitude),
								latitudeDelta: 0.005,
								longitudeDelta: 0.005,
							}}
							zoomEnabled={false}>
							<Marker
								coordinate={{
									latitude: parseFloat(item.latitude),
									longitude: parseFloat(item.longitude),
								}}
								draggable={false}
								onLoad={() => this.forceUpdate()}
								image={IMAGES.iconSmallPin}
							/>
						</MapView>
						<View
							style={role === customerAdmin ? styles.detailView : styles.extraSpace}>
							<Text style={styles.branch}>
								{isRTL ? item.name_ar || item.name : item.name}
							</Text>
							<Text style={styles.address}>
								{`${item.address_one}${
									item.address_two ? `, ${item.address_two}` : ''
								}`}
							</Text>
						</View>
						{role === customerAdmin ? (
							<TouchableOpacity
								onPress={() => this.onEditBranch(item)}
								activeOpacity={0.8}>
								<ImageLoadComponent
									source={IMAGES.iconEdit}
									style={styles.iconEdit}
								/>
							</TouchableOpacity>
						) : null}
					</View>
				)}
			</>
		);
	};

	onEditBranch = (branchData, index) => {
		// Will navigate to the edit branch screen and reset the reducer.
		this.itemListRef.onSetIndex(index);
		const { branchListingActions, navigation } = this.props;
		branchListingActions.onResetBranchListing();
		navigation.navigate(navigations.ADD_NEW_BRANCH_NAVIGATION, { branchData });
	};

	keyExtractor = (item, index) => index.toString();

	onPressClose = () => {
		// Will go back to the previous screen and reset the reducer.
		this.resetScrollIndex();
		const { branchListingActions, navigation } = this.props;
		branchListingActions.onResetBranchListing();
		navigation.goBack();
	};

	onSearch = text => {
		// Function to search the branch using branch name.
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onLoadMoreBranches(false);
			},
		);
	};

	listFooterComponent = () => {
		const { languageInfo, branchListingInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { branchListing, count } = branchListingInfo;
		const endReached = count === branchListing.length || count < branchListing.length;
		if (!endReached) {
			return <ActivityIndicator size="large" color={colors.darkBlue} />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onLoadMoreBranches = isOverwriteExistingList => {
		// API call to get the branches.
		const { branchListingActions } = this.props;
		const { searchText } = this.state;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			queryParams.name = searchText;
		}
		branchListingActions.onGetBranches(queryParams, isOverwriteExistingList);
	};

	onEndReached = () => {
		const { branchListingInfo } = this.props;
		const { loader } = branchListingInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onLoadMoreBranches(true);
		}
	};

	onAddBranch = () => {
		// Will navigate to the add branch screen and reset the reducer.
		this.resetScrollIndex();
		const { branchListingActions, navigation } = this.props;
		branchListingActions.onResetBranchListing();
		navigation.navigate(navigations.ADD_NEW_BRANCH_NAVIGATION);
	};

	onRefresh = () => {
		// Will call while pull to refresh.
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
		this.page = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		this.onLoadMoreBranches(false);
	};

	getLayout = (data, index) => ({
		length: verticalScale(67),
		offset: verticalScale(67) * index,
		index,
	});

	showToast = message => {
		// show 'message' to user in a toast
		this.setState({
			toastMessage: message,
			isToastMessage: true,
		});
		setTimeout(() => {
			this.setState({ isToastMessage: false });
		}, toastShowTime);
	};

	render() {
		const {
			languageInfo,
			branchListingInfo,
			userDetails,
			refreshControlComponentInfo,
		} = this.props;
		const { bottomLoader, searchText, isToastMessage, toastMessage } = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, branchListing, count, error, errorCode } = branchListingInfo;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === '' && (
					<Loader size="large" />
				)}
				<View style={styles.header}>
					<Header
						text={localeString(keyConstants.BRANCHES)}
						hasIconClose
						hasIconPin
						onPressClose={this.onPressClose}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasSearchIcon
						placeholder={localeString(keyConstants.SEARCH_BY_BRANCH)}
						onChangeText={text => this.onSearch(text)}
						value={searchText}
					/>
				</View>
				{error ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<>
						{branchListing.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_BRANCHES_FOUND)} />
						) : (
							<FlatListComponent
								data={branchListing}
								renderItem={this.renderItem}
								keyExtractor={this.keyExtractor}
								showsVerticalScrollIndicator={false}
								onEndReached={() =>
									branchListing.length !== count && this.onEndReached()
								}
								ListFooterComponent={
									branchListing.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								style={styles.listContainer}
								onRefresh={this.onRefresh}
								componentType={constants.flatList}
								onRef={ref => {
									this.itemListRef = ref;
								}}
								getItemLayout={this.getLayout}
							/>
						)}
						{role === customerAdmin && (
							<TouchableOpacity
								onPress={this.onAddBranch}
								style={styles.addBranchContainer}
								activeOpacity={0.8}>
								<ImageLoadComponent
									source={IMAGES.iconAddYellow}
									style={styles.iconBranchAdd}
								/>
							</TouchableOpacity>
						)}
					</>
				)}
				<ToastComponent
					isRTL={isRTL}
					isApiError={isToastMessage}
					toastMessage={toastMessage}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		branchListingInfo: state.BranchListingScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		addBranchInfo: state.AddNewBranchScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		branchListingActions: bindActionCreators({ ...BranchListingActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		addBranchActions: bindActionCreators({ ...AddBranchActions }, dispatch),
	};
};

BranchListingScreen.propTypes = {
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	branchListingInfo: PropTypes.object.isRequired,
	addBranchInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	branchListingActions: PropTypes.object.isRequired,
	addBranchActions: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(BranchListingScreen);
