export const GET_BRANCHES_SUCCESS = 'get_branches_success';
export const GET_BRANCHES_FAILURE = 'get_branches_failure';
export const GET_BRANCHES_LOADER = 'get_branches_loader';
export const RESET_BRANCH_LISTING = 'reset_branch_listing';
