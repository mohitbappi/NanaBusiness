import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		userInfoContainer: {
			borderBottomWidth: verticalScale(1),
			borderColor: colors.greenShadow,
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingVertical: verticalScale(12),
			justifyContent: 'space-between',
		},
		mapImage: {
			width: normalScale(60),
			height: normalScale(60),
			borderRadius: normalScale(8),
		},
		iconSmallPin: {
			height: verticalScale(260),
			width: normalScale(221),
		},
		detailView: {
			marginLeft: isRTL ? 0 : normalScale(10),
			marginRight: isRTL ? normalScale(10) : 0,
			width: normalScale(160),
		},
		extraSpace: {
			marginLeft: isRTL ? 0 : normalScale(10),
			marginRight: isRTL ? normalScale(10) : 0,
			width: normalScale(210),
		},
		branch: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		address: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
			marginTop: verticalScale(6),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		iconEdit: {
			width: normalScale(30),
			height: normalScale(30),
			resizeMode: 'contain',
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginHorizontal: normalScale(16),
		},
		searchContainer: {
			marginBottom: verticalScale(5),
			marginHorizontal: normalScale(16),
		},
		listContainer: {
			flex: 1,
			marginHorizontal: normalScale(16),
		},
		addBranchContainer: {
			position: 'absolute',
			bottom: 0,
			right: isRTL ? null : 0,
			left: isRTL ? 0 : null,
		},
		iconBranchAdd: {
			height: verticalScale(60),
			width: normalScale(60),
		},
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
	});
};

export default createStyleSheet;
