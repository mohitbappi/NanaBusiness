import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetBranchesService from '@Branch/GetBranchesService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

export const onResetBranchListing = () => ({ type: ActionTypes.RESET_BRANCH_LISTING });

/**
 * Action to get the branches.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetBranches = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_BRANCHES_SUCCESS,
		ActionTypes.GET_BRANCHES_FAILURE,
		ActionTypes.GET_BRANCHES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getBranchesService = new GetBranchesService(dispatchedActions);
	addBasicInterceptors(getBranchesService);
	getBranchesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getBranchesService.makeRequest(props));
};
