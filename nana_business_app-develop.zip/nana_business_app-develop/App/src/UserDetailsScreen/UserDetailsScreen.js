import React, { Component } from 'react';
import { View, TouchableOpacity, Text, ScrollView } from 'react-native';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import Header from '@Header/Header';
import navigations from '@routes/navigations';
import { toastShowTime, IMAGE_TYPE, customerAdmin, retailer } from '@Constants/Constants';
import ToastComponent from '@ToastComponent/ToastComponent';
import Spinner from '@Spinner/Spinner';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import * as UserDetailActions from './UserDetailsScreenAction';
import { createStyleSheet } from './UserDetailsScreenStyle';

class UserDetailsScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			userDetailsArr: [
				{
					title: localeString(keyConstants.BRANCH_NAME),
					value: '',
					imgSrc: IMAGES.iconBranchName,
				},
				{
					title: localeString(keyConstants.EMAIL_ADDRESS),
					value: '',
					imgSrc: IMAGES.iconEmail,
				},
				{
					title: localeString(keyConstants.MOBILE_NUMBER),
					value: '',
					imgSrc: IMAGES.iconCall,
				},
			],
			roleArr: [
				{
					title: localeString(keyConstants.ADMIN),
					active: true,
				},
			],
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { route } = this.props;
		const { userDetailsArr, roleArr } = this.state;
		const { mobile, email_address, organization_name, role } = route.params.userDetails;
		const userDetailsArrCopy = userDetailsArr;
		userDetailsArrCopy[0].value = organization_name;
		userDetailsArrCopy[1].value = email_address;
		userDetailsArrCopy[2].value = mobile;
		const roleArrCopy = roleArr;
		roleArrCopy[0].active = !!(role && role === customerAdmin);
		this.setState({
			userDetailsArr: userDetailsArrCopy,
		});
	}

	componentDidUpdate(prevProps) {
		const { userDetailInfo, userDetailActions } = this.props;
		const { roleArr } = this.state;
		const { success, isSetCustomerRole, error, errorCode } = userDetailInfo;
		if (success && prevProps.userDetailInfo.success !== userDetailInfo.success) {
			if (isSetCustomerRole) {
				// if change customer role api returns success
				const roleArrCopy = roleArr;
				this.setState({
					roleArr: [
						(roleArrCopy[0] = {
							...roleArrCopy[0],
							active: !roleArrCopy[0].active,
						}),
					],
				});
			} else {
				// if activation mail sent successfully
				userDetailActions.onResetUserDetails();
				this.setState({
					toastMessage: localeString(keyConstants.MAIL_SENT_SUCCESSFULLY),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			}
		}
		if (error && prevProps.userDetailInfo.error !== userDetailInfo.error) {
			ErrorAlertComponent(errorCode, this.onChangeUserRole); // Will show alert if api fails.
		}
	}

	onBackPress = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onPressEdit = () => {
		// Navigate to edit user detail
		const { route, navigation } = this.props;
		const { userDetails } = route.params;
		navigation.navigate(navigations.ADD_USER_DETAILS_NAVIGATION, {
			userDetails,
			isEditProfile: true,
		});
	};

	getUserRole = () => {
		const { route } = this.props;
		const { role } = route.params.userDetails;
		return role === customerAdmin
			? localeString(keyConstants.CUSTOMER_ADMIN)
			: localeString(keyConstants.CUSTOMER);
	};

	handleRoleChange = role => {
		if (role === customerAdmin) {
			this.onChangeUserRole();
		} else {
			this.setState({
				toastMessage: localeString(keyConstants.EDIT_RIGHTS),
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	};

	onSendActivationMail = () => {
		const { route, userDetailActions } = this.props;
		const { id } = route.params.userDetails;
		const queryParams = {
			id,
		};
		userDetailActions.onSendActivationMail(queryParams);
	};

	onChangeUserRole = () => {
		// Function to change user role
		const { route, userDetailActions } = this.props;
		const { roleArr } = this.state;
		const { id } = route.params.userDetails;
		const roleArrCopy = roleArr;
		const queryParams = {
			id,
		};
		const data = {};
		data.role = roleArrCopy[0].active ? retailer : customerAdmin;
		queryParams.data = data;
		userDetailActions.onUpdateUserRole(queryParams);
	};

	render() {
		const { languageInfo, route, userDetailInfo, userDetails } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { userDetailsArr, roleArr, isApiError, toastMessage } = this.state;
		const { name, profile_images, is_active } = route.params.userDetails;
		const { loader } = userDetailInfo;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						hasIconBack
						onPressBack={this.onBackPress}
						hasIconEdit={role === customerAdmin}
						onPressEdit={this.onPressEdit}
					/>
				</View>
				<ScrollView showsVerticalScrollIndicator={false}>
					<View style={styles.imageView}>
						<View style={styles.innerImageView}>
							<ImageLoadComponent
								imageType={IMAGE_TYPE.account}
								isUrl={profile_images}
								source={
									profile_images && profile_images.medium
										? profile_images.medium
										: IMAGES.iconProfileDefault
								}
								style={styles.defaultImageUser}
							/>
						</View>
						<View style={styles.detailViewUser}>
							<Text style={styles.nameText}>{name}</Text>
							<Text style={styles.roleUser}>{this.getUserRole()}</Text>
							<Text style={styles.activeInactive}>
								{is_active
									? localeString(keyConstants.ACTIVE)
									: localeString(keyConstants.NOT_ACTIVE)}
							</Text>
						</View>
					</View>
					<View style={styles.userInfoOuterContainer}>
						{userDetailsArr.map((item, index) => (
							<View style={styles.userInfoContainer} key={index.toString()}>
								<ImageLoadComponent
									source={item.imgSrc}
									style={styles.userInfoTypeImg}
								/>
								<View style={styles.titleInfoContainer}>
									<Text style={styles.title}>{item.title}</Text>
									<Text style={styles.value}>{item.value}</Text>
								</View>
							</View>
						))}
					</View>
					<View style={styles.roleOuterContainer}>
						<Text style={styles.roleText}>{localeString(keyConstants.ROLES)}</Text>
						{roleArr.map((item, index) => (
							<View style={styles.roleContainer} key={index.toString()}>
								<Text style={styles.roleStyle}>{item.title}</Text>
								<TouchableOpacity
									activeOpacity={0.8}
									onPress={() => this.handleRoleChange(role)}>
									<ImageLoadComponent
										source={
											item.active ? IMAGES.iconActive : IMAGES.iconInActive
										}
										style={styles.activeInActive}
									/>
								</TouchableOpacity>
							</View>
						))}
					</View>
				</ScrollView>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

UserDetailsScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	userDetailInfo: PropTypes.object.isRequired,
	userDetailActions: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		userDetailInfo: state.UserDetailsScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		userDetailActions: bindActionCreators({ ...UserDetailActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(UserDetailsScreen);
