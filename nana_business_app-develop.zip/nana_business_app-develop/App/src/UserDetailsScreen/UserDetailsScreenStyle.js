import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginTop: verticalScale(20),
		},
		imageView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			marginTop: verticalScale(24),
			marginBottom: verticalScale(18),
			marginHorizontal: normalScale(16),
		},
		innerImageView: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
			justifyContent: 'center',
		},
		defaultImageUser: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
		},
		detailViewUser: {
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		nameText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(16),
		},
		roleUser: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(14),
			marginTop: verticalScale(8),
		},
		activeInactive: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
			marginTop: verticalScale(8),
		},
		userInfoOuterContainer: {
			borderBottomWidth: verticalScale(4),
			borderBottomColor: colors.grey,
		},
		userInfoContainer: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			alignItems: 'center',
			justifyContent: 'center',
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			marginBottom: verticalScale(16),
			height: verticalScale(48),
			marginHorizontal: normalScale(16),
		},
		userInfoTypeImg: {
			height: verticalScale(30),
			width: normalScale(30),
		},
		titleInfoContainer: {
			marginLeft: isRTL ? null : normalScale(12),
			marginRight: isRTL ? normalScale(12) : null,
		},
		title: {
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
		},
		value: {
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			color: colors.black,
		},
		activeInActive: {
			height: verticalScale(27),
			width: normalScale(36),
		},
		roleContainer: {
			height: verticalScale(27),
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		roleStyle: {
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
		},
		roleOuterContainer: {
			marginHorizontal: normalScale(16),
		},
		roleText: {
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			color: colors.black,
			marginVertical: verticalScale(16),
		},
		buttonView: {
			flex: 1,
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(16),
		},
		sendActivationButton: {
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			color: colors.white,
		},
	});
};

export default createStyleSheet;
