import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	isSetCustomerRole: false,
};

const UserDetailsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.SEND_ACTIVATION_MAIL_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				isSetCustomerRole: false,
			};
		case ActionTypes.SEND_ACTIVATION_MAIL_LOADER:
		case ActionTypes.SET_CUSTOMER_ROLE_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: true,
			};
		case ActionTypes.SEND_ACTIVATION_MAIL_FAILURE:
		case ActionTypes.SET_CUSTOMER_ROLE_FAILURE:
			return {
				...state,
				error: true,
				success: false,
				loader: false,
				errorCode: action.payload,
			};
		case ActionTypes.SET_CUSTOMER_ROLE_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				isSetCustomerRole: true,
			};
		case ActionTypes.RESET_USER_DETAIL_STATE:
			return initialState;
		default:
			return { ...state };
	}
};

export default UserDetailsScreenReducer;
