export const SEND_ACTIVATION_MAIL_SUCCESS = 'send_activation_mail_success';
export const SEND_ACTIVATION_MAIL_FAILURE = 'send_activation_mail_failure';
export const SEND_ACTIVATION_MAIL_LOADER = 'send_activation_mail_loader';

export const SET_CUSTOMER_ROLE_SUCCESS = 'set_customer_role_success';
export const SET_CUSTOMER_ROLE_FAILURE = 'set_customer_role_failure';
export const SET_CUSTOMER_ROLE_LOADER = 'set_customer_role_loader';

export const RESET_USER_DETAIL_STATE = 'reset_user_detail_state';
