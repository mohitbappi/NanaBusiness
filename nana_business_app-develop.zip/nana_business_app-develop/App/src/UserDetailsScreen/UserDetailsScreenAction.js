import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import SendActivationMailService from '@Users/SendActivationMailService';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import EditCustomerRoleService from '@Users/EditCustomerRoleService';
import * as ActionTypes from './ActionType';

// Action to reset user detail screen reducer
export const onResetUserDetails = () => ({ type: ActionTypes.RESET_USER_DETAIL_STATE });

/**
 * Action to call send activation mail api
 * @param {object} data
 */
export const onSendActivationMail = data => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SEND_ACTIVATION_MAIL_SUCCESS,
		ActionTypes.SEND_ACTIVATION_MAIL_FAILURE,
		ActionTypes.SEND_ACTIVATION_MAIL_LOADER,
	);
	const sendActivationMailService = new SendActivationMailService(dispatchedActions);
	addBasicInterceptors(sendActivationMailService);
	sendActivationMailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(sendActivationMailService.makeRequest(data));
};

/**
 * Action to call update user role api
 * @param {object} props
 */
export const onUpdateUserRole = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SET_CUSTOMER_ROLE_SUCCESS,
		ActionTypes.SET_CUSTOMER_ROLE_FAILURE,
		ActionTypes.SET_CUSTOMER_ROLE_LOADER,
	);
	const editCustomerRoleService = new EditCustomerRoleService(dispatchedActions);
	addBasicInterceptors(editCustomerRoleService);
	editCustomerRoleService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(editCustomerRoleService.makeRequest(props));
};
