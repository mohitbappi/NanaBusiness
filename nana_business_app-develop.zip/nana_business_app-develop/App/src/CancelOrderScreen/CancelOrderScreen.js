import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { View, Keyboard, TouchableOpacity, Text } from 'react-native';
import Spinner from '@Spinner/Spinner';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { addressMaxLength } from '@Constants/Constants';
import { normalScale, verticalScale } from '@device/normalize';
import Input from '@Input/Input';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import { createStyleSheet } from './CancelOrderScreenStyle';
import * as CancelOrderActions from './CancelOrderScreenAction';

class CancelOrderScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			reasonSelectedIndex: null,
			message: '',
			reasonsList: [],
			isApiError: false,
			toastMessage: '',
			isDropdownVisible: false,
		};
	}

	componentDidUpdate(prevProps) {
		const { cancelOrderInfo, languageInfo } = this.props;
		const { isCancelOrder, success, reasonsList, error, errorCode } = cancelOrderInfo;
		const { isRTL } = languageInfo;
		if (error && isCancelOrder && prevProps.cancelOrderInfo.error !== error) {
			// Will show alert if any api fails.
			ErrorAlertComponent(errorCode, this.onCancel);
		}
		if (error && !isCancelOrder && prevProps.cancelOrderInfo.error !== error) {
			// Will show alert if any api fails.
			this.setState(
				{
					isDropdownVisible: false,
				},
				() => ErrorAlertComponent(errorCode, this.onPressDropdown),
			);
		}
		if (success && prevProps.cancelOrderInfo.success !== success) {
			if (isCancelOrder) {
				// Will go back if order canceled successfully.
				logCustomEventOnBraze('orderCancelled', null);
				this.onGoBack();
			} else {
				// Will add cancel reasons in the dropdown.
				const tempReasonsArray = [];
				reasonsList.map(item => {
					const key = Object.keys(item)[0];
					const reasonObj = {
						key,
						name: isRTL ? item[`${key}`].ar : item[`${key}`].en,
					};
					tempReasonsArray.push(reasonObj);
				});
				this.setState({
					reasonsList: tempReasonsArray,
				});
			}
		}
	}

	getReasons = () => {
		// API call to get the reasons.
		const { cancelOrderActions } = this.props;
		cancelOrderActions.onGetReasons();
	};

	onGoBack = () => {
		// Will navigate to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onDismissKeyboard = () => {
		Keyboard.dismiss();
	};

	onCloseDropdown = () => {
		// Will close dropdown.
		this.setState({
			isDropdownVisible: false,
		});
	};

	onSelectOption = index => {
		// Will select reason from the dropdown.
		this.onCloseDropdown();
		this.setState({
			reasonSelectedIndex: index,
		});
	};

	onPressDropdown = () => {
		this.setState({
			isDropdownVisible: true,
		});
		this.onDismissKeyboard();
		this.getReasons();
	};

	onChangeText = text => {
		// Function to save the input fields values.
		this.setState({
			message: text,
		});
	};

	onCancel = () => {
		// API call to cancel the order.
		const { route, cancelOrderActions } = this.props;
		const { reasonSelectedIndex, message, reasonsList } = this.state;
		const { id, branchId } = route.params || {};
		const queryParams = {};
		queryParams.id = id;
		queryParams.data = {
			reason: reasonsList[reasonSelectedIndex].key,
			message,
			branch_id: branchId,
		};
		cancelOrderActions.onCancelOrder(queryParams);
	};

	render() {
		const {
			reasonSelectedIndex,
			message,
			reasonsList,
			isApiError,
			toastMessage,
			isDropdownVisible,
		} = this.state;
		const { languageInfo, cancelOrderInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, isCancelOrder } = cancelOrderInfo;
		return (
			<View style={styles.container}>
				{loader && isCancelOrder && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.CANCEL_ORDER)}
						hasIconBack
						onPressBack={this.onGoBack}
					/>
				</View>
				<OptionPicker
					title={localeString(keyConstants.SELECT_REASON)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={reasonsList}
					onClose={this.onCloseDropdown}
					onSelectOption={this.onSelectOption}
					activeIndex={reasonSelectedIndex}
					loader={loader && !isCancelOrder && reasonsList && reasonsList.length === 0}
				/>
				<TouchableOpacity
					onPress={this.onDismissKeyboard}
					activeOpacity={1}
					style={styles.innerContainer}>
					<DropdownFieldComponent
						isRTL={isRTL}
						onPress={this.onPressDropdown}
						value={
							reasonSelectedIndex !== null
								? reasonsList[reasonSelectedIndex].name
								: ''
						}
						label={`${localeString(keyConstants.SELECT_REASON)}*`}
						placeholder={`${localeString(keyConstants.SELECT)}`}
					/>
					<Input
						maxLength={addressMaxLength}
						value={message}
						width={normalScale(288)}
						label={`${localeString(keyConstants.MESSAGE)}`}
						placeholder={`${localeString(keyConstants.TYPE_HERE)}...`}
						returnKeyType="done"
						multiline
						isRTL={isRTL}
						onChangeText={this.onChangeText}
						autoCapitalize="none"
						textInputStyle={styles.textInputStyle}
						height={verticalScale(88)}
						textAlignVertical="top"
					/>
					<Text style={styles.maxCharacters}>
						{localeString(keyConstants.MAX_CHARACTERS)}
					</Text>
				</TouchableOpacity>
				<View style={styles.cancelButtonView}>
					<ButtonComponent
						text={localeString(keyConstants.SUBMIT)}
						onPress={this.onCancel}
						isButtonDisable={reasonSelectedIndex === null}
					/>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		cancelOrderInfo: state.CancelOrderScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		cancelOrderActions: bindActionCreators({ ...CancelOrderActions }, dispatch),
	};
};

CancelOrderScreen.propTypes = {
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	cancelOrderInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	cancelOrderActions: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(CancelOrderScreen);
