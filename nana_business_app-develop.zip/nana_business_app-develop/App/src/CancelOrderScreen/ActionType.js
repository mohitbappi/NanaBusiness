export const CANCEL_ORDER_SUCCESS = 'cancel_order_success';
export const CANCEL_ORDER_FAILURE = 'cancel_order_failure';
export const CANCEL_ORDER_LOADER = 'cancel_order_loader';
export const GET_REASON_LIST_SUCCESS = 'get_reason_list_success';
export const GET_REASON_LIST_FAILURE = 'get_reason_list_failure';
export const GET_REASON_LIST_LOADER = 'get_reason_list_loader';
