import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(5),
		},
		innerContainer: {
			marginHorizontal: normalScale(16),
			flex: 1,
		},
		textInputStyle: {
			height: verticalScale(88),
		},
		maxCharacters: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
			color: colors.blackGreyWhite,
			marginTop: verticalScale(7),
			alignSelf: rtlFunctions.getAlignmentInFlex(isRTL),
		},
		cancelButtonView: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
