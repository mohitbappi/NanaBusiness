import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	reasonsList: [],
	isCancelOrder: false,
};

const CancelOrderScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_REASON_LIST_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				reasonsList: action.payload.rows,
				isCancelOrder: false,
			};
		case ActionTypes.GET_REASON_LIST_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCancelOrder: false,
			};
		case ActionTypes.GET_REASON_LIST_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCancelOrder: false,
			};
		case ActionTypes.CANCEL_ORDER_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCancelOrder: true,
			};
		case ActionTypes.CANCEL_ORDER_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCancelOrder: true,
			};
		case ActionTypes.CANCEL_ORDER_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCancelOrder: true,
			};
		default:
			return state;
	}
};

export default CancelOrderScreenReducer;
