import { actions } from '@libapi/APIActionsBuilder';
import GetReasonsService from '@Orders/GetReasonsService';
import CancelOrderService from '@Orders/CancelOrderService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

export const onGetReasons = () => dispatch => {
	// Action to get the cancel order reasons.
	const dispatchedActions = actions(
		ActionTypes.GET_REASON_LIST_SUCCESS,
		ActionTypes.GET_REASON_LIST_FAILURE,
		ActionTypes.GET_REASON_LIST_LOADER,
	);
	const getReasonsService = new GetReasonsService(dispatchedActions);
	addBasicInterceptors(getReasonsService);
	getReasonsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getReasonsService.makeRequest());
};

/**
 * Action to cancel the order.
 * @param {object} props
 * @returns
 */

export const onCancelOrder = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.CANCEL_ORDER_SUCCESS,
		ActionTypes.CANCEL_ORDER_FAILURE,
		ActionTypes.CANCEL_ORDER_LOADER,
	);
	const cancelOrderService = new CancelOrderService(dispatchedActions);
	addBasicInterceptors(cancelOrderService);
	cancelOrderService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(cancelOrderService.makeRequest(props));
};
