import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	invoiceDetail: null,
	isCancelRequest: false,
};

const InvoiceDetailScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_INVOICE_DETAIL_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				invoiceDetail: action.payload.invoice,
				isCancelRequest: false,
			};
		case ActionTypes.GET_INVOICE_DETAIL_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCancelRequest: false,
			};
		case ActionTypes.GET_INVOICE_DETAIL_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCancelRequest: false,
			};
		case ActionTypes.CANCEL_INVOICE_REQUEST_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCancelRequest: true,
			};
		case ActionTypes.CANCEL_INVOICE_REQUEST_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCancelRequest: true,
			};
		case ActionTypes.CANCEL_INVOICE_REQUEST_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCancelRequest: true,
			};
		case ActionTypes.RESET_INVOICE_DETAIL_STATE:
			return initialState;
		default:
			return state;
	}
};

export default InvoiceDetailScreenReducer;
