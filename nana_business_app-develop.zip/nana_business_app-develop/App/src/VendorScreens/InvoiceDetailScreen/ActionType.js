export const GET_INVOICE_DETAIL_SUCCESS = 'get_invoice_detail_success';
export const GET_INVOICE_DETAIL_FAILURE = 'get_invoice_detail_failure';
export const GET_INVOICE_DETAIL_LOADER = 'get_invoice_detail_loader';
export const CANCEL_INVOICE_REQUEST_SUCCESS = 'cancel_invoice_request_success';
export const CANCEL_INVOICE_REQUEST_FAILURE = 'cancel_invoice_request_failure';
export const CANCEL_INVOICE_REQUEST_LOADER = 'cancel_invoice_request_loader';
export const RESET_INVOICE_DETAIL_STATE = 'reset_invoice_detail_state';
