import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import ImageView from 'react-native-image-view';
import Pdf from 'react-native-pdf';
import PropTypes from 'prop-types';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import Loader from '@Loader/Loader';
import Header from '@Header/Header';
import {
	pending,
	retailer,
	vendor,
	rejected,
	invoiceHeader,
	accepted,
	paid,
	canceled,
	customerAdmin,
	salesInvoice,
	languageConstants,
	accountManager,
	salesExecutive,
} from '@Constants/Constants';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { getFormattedDate } from '@Util/GetFormattedDate';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import collectorNavigations from '@routes/collectorNavigations';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import * as InvoicesScreenActions from '@InvoicesScreen/InvoicesScreenAction';
import Images from '@Images/index';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import * as SalesInvoiceActions from '@SalesInvoiceScreen/SalesInvoiceScreenAction';
import { getFormattedTime } from '@Util/GetFormattedTime';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import { createStyleSheet } from './InvoiceDetailScreenStyle';
import * as InvoiceDetailActions from './InvoiceDetailScreenAction';

class InvoiceDetailScreen extends Component {
	constructor(props) {
		super(props);
		const { userDetails } = props;
		this.role = userDetails.userDetails.user.role;
		this.state = {
			isImageVisible: false,
			isPdfVisible: false,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onGetInvoiceDetail();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			invoiceDetailInfo,
			invoiceScreenInfo,
			salesInvoiceInfo,
			invoiceDetailActions,
			invoicesScreenActions,
			pullToRefreshActions,
		} = this.props;
		const {
			success,
			isCancelRequest,
			error: invoiceDetailError,
			errorCode: invoiceDetailErrorCode,
		} = invoiceDetailInfo;
		const {
			error,
			errorCode,
			isRejectInvoicesSuccess,
			isApproveInvoicesSuccess,
			isApproveInvoices,
			isRejectInvoices,
		} = invoiceScreenInfo;
		const { isDownload, success: salesInvoiceSuccess } = salesInvoiceInfo;
		if (
			salesInvoiceSuccess &&
			isDownload &&
			prevProps.salesInvoiceInfo.success !== salesInvoiceInfo.success
		) {
			// After getting successful response the invoice image will visible.
			this.showInvoiceImage(true);
		}
		if (
			(isRejectInvoicesSuccess &&
				invoiceScreenInfo.isRejectInvoicesSuccess !==
					prevProps.invoiceScreenInfo.isRejectInvoicesSuccess) ||
			(isApproveInvoicesSuccess &&
				invoiceScreenInfo.isApproveInvoicesSuccess !==
					prevProps.invoiceScreenInfo.isApproveInvoicesSuccess)
		) {
			// Will go back to the previous screen and reset the reducer.
			invoicesScreenActions.onResetInvoiceState();
			this.onGoBack();
		}
		if (success && prevProps.invoiceDetailInfo.success !== success) {
			if (isCancelRequest) {
				// Will go back to the previous screen and reset the reducer.
				invoiceDetailActions.onResetInvoiceDetailState();
				this.onGoBack();
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (
			error &&
			(isApproveInvoices || isRejectInvoices) &&
			prevProps.invoiceScreenInfo.error !== invoiceScreenInfo.error
		) {
			// Will show alert if api fails.
			ErrorAlertComponent(
				errorCode,
				isApproveInvoices ? this.onApproveInvoice : this.onRejectInvoice,
			);
		}
		if (
			invoiceDetailError &&
			isCancelRequest &&
			prevProps.invoiceDetailInfo.error !== invoiceDetailInfo.error
		) {
			// Will show alert if api fails.
			ErrorAlertComponent(invoiceDetailErrorCode, this.onCancelRequest);
		}
	}

	onGetInvoiceDetail = () => {
		// API call to get the invoice detail.
		const { route, invoiceDetailActions, pullToRefreshActions } = this.props;
		const { id, index } = route.params;
		const queryParams = {};
		queryParams.id = id;
		pullToRefreshActions.onSetSelectIndex(index);
		if (
			this.role === retailer ||
			this.role === customerAdmin ||
			this.role === accountManager ||
			this.role === salesExecutive
		) {
			invoiceDetailActions.onGetRetailerInvoiceDetail(queryParams);
		} else if (this.role === vendor) {
			invoiceDetailActions.onGetInvoiceDetail(queryParams);
		} else {
			invoiceDetailActions.onGetCollectorInvoiceDetail(queryParams);
		}
	};

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onOpenCollectionRequest = id => {
		// Will show collection request in form of either pdf or image.
		const { route } = this.props;
		const { invoiceType } = route.params;
		if (invoiceType === salesInvoice) {
			this.onGetSalesInvoice(id);
		} else {
			this.showInvoiceImage(true);
		}
	};

	onGetSalesInvoice = id => {
		// API call to download the sales invoice.
		const { languageInfo, salesInvoiceActions } = this.props;
		const { isRTL } = languageInfo;
		const queryParams = {};
		queryParams.sales_invoice_ids = id;
		queryParams.invoice_language = isRTL ? languageConstants.ar : languageConstants.en;
		salesInvoiceActions.onDownloadTemplate(queryParams);
	};

	onShowPdf = value => {
		this.setState({
			isPdfVisible: value,
		});
	};

	showInvoiceImage = value => {
		this.setState({
			isImageVisible: value,
		});
	};

	onCancelRequest = () => {
		const { route } = this.props;
		const { invoiceDetailActions } = this.props;
		// API call to cancel the request of collection request for vendor.
		Alert.alert(
			'',
			localeString(keyConstants.ARE_YOU_SURE),
			[
				{
					text: localeString(keyConstants.NO),
				},
				{
					text: localeString(keyConstants.YES),
					onPress: () => {
						const { id } = route.params;
						const queryParams = {};
						queryParams.id = id;
						invoiceDetailActions.onCancelInvoiceRequest(queryParams);
					},
				},
			],
			{ cancelable: false },
		);
	};

	onRejectInvoice = () => {
		// API call to reject the invoice.
		const { route, invoicesScreenActions } = this.props;
		const { id } = route.params;
		const queryParams = {};
		queryParams.invoices_ids = id;
		invoicesScreenActions.onRejectInvoices(queryParams);
	};

	onApproveInvoice = () => {
		// API call to approve the invoice.
		const { route, invoicesScreenActions } = this.props;
		const { id } = route.params;
		const queryParams = {};
		queryParams.invoices_ids = id;
		invoicesScreenActions.onApproveInvoices(queryParams);
	};

	onPayNow = (invoiceTotal, amount) => {
		const { route, navigation } = this.props;
		const { id } = route.params;
		navigation.navigate(collectorNavigations.PAY_NOW_NAVIGATION, {
			invoiceTotal,
			payableAmount: amount,
			id,
		});
	};

	getInvoiceStatusValue = status => {
		// Will return the status label by given status.
		switch (status) {
			case pending:
				return localeString(keyConstants.PENDING);
			case accepted:
				return localeString(keyConstants.APPROVED);
			case paid:
				return localeString(keyConstants.SUBMITTED);
			case canceled:
				return localeString(keyConstants.CANCELLED);
			case rejected:
				return localeString(keyConstants.REJECTED);
			default:
				return null;
		}
	};

	getInvoiceStatusStyle = status => {
		// Will return the status style by given status.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case pending:
				return styles.pendingStyle;
			case accepted:
				return styles.approvedStyle;
			case paid:
				return styles.submittedStyle;
			case canceled:
				return styles.cancelledStyle;
			case rejected:
				return styles.rejectedStyle;
			default:
				return null;
		}
	};

	onRefresh = () => {
		// API call while pull to refresh.
		this.onGetInvoiceDetail();
	};

	render() {
		const {
			languageInfo,
			refreshControlComponentInfo,
			invoiceDetailInfo,
			salesInvoiceInfo,
			invoiceScreenInfo,
			route,
		} = this.props;
		const { isImageVisible, isPdfVisible } = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, invoiceDetail, isCancelRequest, error, errorCode } = invoiceDetailInfo;
		const { invoice_total, invoice_no, status, due, created_at, image, paid_amount } =
			invoiceDetail || {};
		const { headerTitle, ownerName, invoiceType } = route.params;
		const { isApproveInvoicesLoader, isRejectInvoicesLoader } = invoiceScreenInfo;
		const { downloadUrl, loader: salesInvoiceLoader } = salesInvoiceInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader &&
					!isFetchingForPullToRefresh &&
					(isCancelRequest ? <Spinner size="large" /> : <Loader size="large" />)}
				{salesInvoiceLoader && <Spinner size="large" />}
				{invoiceScreenInfo.loader &&
					(isApproveInvoicesLoader || isRejectInvoicesLoader) && <Spinner size="large" />}
				<View style={styles.header}>
					<Header
						text={
							headerTitle.length > invoiceHeader
								? `${headerTitle.split('', invoiceHeader).join('')}...`
								: headerTitle
						}
						hasIconBack
						onPressBack={this.onGoBack}
					/>
				</View>
				<ImageView
					images={[
						{
							source: { uri: invoiceType === salesInvoice ? downloadUrl : image },
						},
					]}
					animationType="fade"
					isTapZoomEnabled
					isPinchZoomEnabled
					onClose={() => this.showInvoiceImage(false)}
					isVisible={isImageVisible}
				/>
				{isPdfVisible && (
					<View style={styles.pdfContainer}>
						<View style={styles.pdfHeader}>
							<TouchableOpacity
								activeOpacity={0.8}
								hitSlop={styles.hitSlop}
								onPress={() => this.onShowPdf(false)}>
								<ImageLoadComponent
									source={Images.iconBack}
									style={styles.iconClose}
								/>
							</TouchableOpacity>
						</View>
						<Pdf source={{ uri: downloadUrl }} style={styles.pdf} />
					</View>
				)}
				{error && !isCancelRequest ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onGetInvoiceDetail}
					/>
				) : (
					<ScrollViewComponent
						contentContainerStyle={styles.scrollView}
						showsVerticalScrollIndicator={false}
						onRefresh={this.onRefresh}
						componentType={constants.scrollView}>
						<View style={styles.cardView}>
							<Text style={styles.title}>
								{localeString(keyConstants.INVOICE_NUMBER)}
							</Text>
							<Text style={styles.value}>{`#${invoice_no}`}</Text>
						</View>
						<View style={styles.cardView}>
							{/* Total amount of invoice */}
							<Text style={styles.title}>
								{localeString(keyConstants.TOTAL_AMOUNT)}
							</Text>
							<Text style={styles.value}>
								{`${currencyFormatter(
									getValueInDecimal(invoice_total),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<View style={styles.cardView}>
							{/* Paid amount of invoice */}
							<Text style={styles.title}>
								{localeString(keyConstants.PAID_AMOUNT)}
							</Text>
							<Text style={styles.value}>
								{`${currencyFormatter(
									getValueInDecimal(paid_amount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<View style={styles.cardView}>
							{/* Due amount of invoice */}
							<Text style={styles.title}>
								{localeString(keyConstants.DUE_AMOUNT)}
							</Text>
							<Text style={styles.dueValue}>
								{`${currencyFormatter(
									getValueInDecimal(invoice_total - paid_amount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<View style={styles.cardView}>
							<Text style={styles.title}>{localeString(keyConstants.DUE_DATE)}</Text>
							<Text style={styles.dueValue}>
								{`${getFormattedDate(due)}, ${getFormattedTime(due)}`}
							</Text>
						</View>
						<View style={styles.cardView}>
							<Text style={styles.title}>
								{localeString(keyConstants.USER_STATUS)}
							</Text>
							<Text style={[styles.statusStyle, this.getInvoiceStatusStyle(status)]}>
								{this.getInvoiceStatusValue(status)}
							</Text>
						</View>
						<View style={styles.cardView}>
							<Text style={styles.title}>{localeString(keyConstants.ISSUED_ON)}</Text>
							<Text style={styles.value}>{getFormattedDate(created_at)}</Text>
						</View>
						{this.role === retailer ||
						this.role === customerAdmin ||
						this.role === accountManager ||
						this.role === salesExecutive ? (
							<>
								<View style={styles.cardView}>
									<Text style={styles.title}>
										{localeString(keyConstants.OWNER)}
									</Text>
									<Text style={styles.value}>{ownerName}</Text>
								</View>
								<View style={styles.lastView}>
									<Text style={styles.title}>
										{localeString(keyConstants.COLLECTION_REQUEST_IMAGE)}
									</Text>
									<TouchableOpacity
										activeOpacity={0.8}
										onPress={() => this.onOpenCollectionRequest(invoice_no)}>
										<Text style={styles.viewImage}>
											{localeString(keyConstants.VIEW)}
										</Text>
									</TouchableOpacity>
								</View>
							</>
						) : (
							<View style={styles.lastView}>
								<Text style={styles.title}>{localeString(keyConstants.OWNER)}</Text>
								<Text style={styles.value}>{ownerName}</Text>
							</View>
						)}
					</ScrollViewComponent>
				)}
				{status === pending &&
					this.role !== retailer &&
					this.role !== accountManager &&
					this.role !== salesExecutive && (
						<View style={styles.buttonInvoiceDetailView}>
							<ButtonComponent
								buttonStyle={styles.cancelInvoiceDetailButton}
								text={localeString(keyConstants.BACK)}
								textStyle={styles.cancelInvoiceDetailText}
								onPress={this.onGoBack}
							/>
							<ButtonComponent
								buttonStyle={styles.saveInvoiceDetailButton}
								text={localeString(keyConstants.CANCEL_REQUEST)}
								onPress={this.onCancelRequest}
							/>
						</View>
					)}
				{status === pending && this.role === customerAdmin && (
					<View style={styles.buttonInvoiceDetailView}>
						<ButtonComponent
							buttonStyle={styles.cancelInvoiceDetailButton}
							text={localeString(keyConstants.REJECT)}
							textStyle={styles.cancelInvoiceDetailText}
							onPress={this.onRejectInvoice}
						/>
						<ButtonComponent
							buttonStyle={styles.approveButton}
							text={localeString(keyConstants.APPROVE)}
							onPress={this.onApproveInvoice}
						/>
					</View>
				)}
			</View>
		);
	}
}

InvoiceDetailScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	userDetails: PropTypes.object.isRequired,
	languageInfo: PropTypes.func.isRequired,
	route: PropTypes.func.isRequired,
	pullToRefreshActions: PropTypes.func.isRequired,
	invoiceDetailInfo: PropTypes.func.isRequired,
	invoiceScreenInfo: PropTypes.func.isRequired,
	salesInvoiceInfo: PropTypes.func.isRequired,
	invoicesScreenActions: PropTypes.func.isRequired,
	invoiceDetailActions: PropTypes.func.isRequired,
	salesInvoiceActions: PropTypes.func.isRequired,
	refreshControlComponentInfo: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		invoiceDetailInfo: state.InvoiceDetailScreenReducer,
		userDetails: state.HomeScreenReducer,
		invoiceScreenInfo: state.InvoicesScreenReducer,
		salesInvoiceInfo: state.SalesInvoiceScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		invoiceDetailActions: bindActionCreators({ ...InvoiceDetailActions }, dispatch),
		invoicesScreenActions: bindActionCreators({ ...InvoicesScreenActions }, dispatch),
		salesInvoiceActions: bindActionCreators({ ...SalesInvoiceActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(InvoiceDetailScreen);
