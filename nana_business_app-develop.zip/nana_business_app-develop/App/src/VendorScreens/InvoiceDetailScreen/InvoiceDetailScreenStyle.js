import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginHorizontal: normalScale(16),
		},
		scrollView: {
			marginTop: verticalScale(12),
			paddingBottom: verticalScale(71),
		},
		cardView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginHorizontal: normalScale(16),
			height: verticalScale(40),
			alignItems: 'center',
			borderBottomColor: colors.greenShadow,
			borderRadius: moderateScale(8),
			borderBottomWidth: normalScale(1),
			backgroundColor: colors.white,
		},
		title: {
			color: colors.lightBlack,
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		statusStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.boldItalic),
			fontSize: normalize(14),
		},
		value: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
		},
		dueValue: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
		},
		pendingStyle: {
			color: colors.darkOrange,
		},
		approvedStyle: {
			color: colors.darkBlue,
		},
		cancelledStyle: {
			color: colors.black,
		},
		rejectedStyle: {
			color: colors.red,
		},
		submittedStyle: {
			color: colors.lightShadowGrey,
		},
		viewImage: {
			color: colors.blue,
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			textDecorationLine: 'underline',
		},
		pending: {
			color: colors.darkOrange,
		},
		approved: {
			color: colors.darkBlue,
		},
		lastView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingHorizontal: normalScale(16),
			height: verticalScale(52),
			borderBottomColor: colors.grey,
			borderBottomWidth: verticalScale(4),
			backgroundColor: colors.white,
			paddingTop: verticalScale(12),
		},
		transactionsText: {
			marginTop: verticalScale(16),
			marginBottom: verticalScale(8),
			color: colors.black,
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			paddingHorizontal: normalScale(16),
			textAlign: isRTL ? 'right' : 'left',
		},
		buttonInvoiceDetailView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
		cancelInvoiceDetailButton: {
			paddingHorizontal: normalScale(47),
			backgroundColor: colors.white,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(36),
			justifyContent: 'center',
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
		},
		cancelInvoiceDetailText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
		},
		saveInvoiceDetailButton: {
			paddingHorizontal: normalScale(20),
			backgroundColor: colors.red,
			shadowColor: colors.red,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(15),
			},
			shadowRadius: moderateScale(14),
			shadowOpacity: 0.2,
			elevation: verticalScale(15),
		},
		approveButton: {
			paddingHorizontal: normalScale(42),
		},
		payButton: {
			paddingHorizontal: normalScale(40),
		},
		pdfHeader: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			alignItems: 'center',
			width: '100%',
			height: verticalScale(35),
			paddingHorizontal: normalScale(16),
			backgroundColor: colors.white,
		},
		hitSlop: {
			top: verticalScale(15),
			bottom: verticalScale(15),
			right: normalScale(15),
			left: normalScale(15),
		},
		iconClose: {
			width: normalScale(12),
			height: verticalScale(12),
			alignSelf: 'flex-end',
			justifyContent: 'flex-end',
		},
		pdfContainer: {
			backgroundColor: colors.blackWithOpacity,
			zIndex: 100,
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			justifyContent: 'center',
			alignItems: 'center',
			paddingVertical: verticalScale(60),
			paddingHorizontal: normalScale(16),
		},
		pdf: {
			flex: 1,
			width: '100%',
			height: '100%',
			backgroundColor: colors.white,
			padding: 0,
		},
	});
};

export default createStyleSheet;
