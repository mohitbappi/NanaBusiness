import { actions } from '@libapi/APIActionsBuilder';
import GetInvoiceDetailService from '@InvoicesVendorServices/GetInvoiceDetailService';
import GetRetailerInvoiceDetailService from '@Invoices/GetRetailerInvoiceDetailService';
import GetCollectorInvoiceDetailService from '@InvoicesCollectorServices/GetCollectorInvoiceDetailService';
import CancelInvoiceRequestService from '@InvoicesVendorServices/CancelInvoiceRequestService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to get the invoice detail.
 * @param {object} props
 * @returns
 */

export const onGetInvoiceDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_INVOICE_DETAIL_SUCCESS,
		ActionTypes.GET_INVOICE_DETAIL_FAILURE,
		ActionTypes.GET_INVOICE_DETAIL_LOADER,
	);
	const getInvoiceDetailService = new GetInvoiceDetailService(dispatchedActions);
	addBasicInterceptors(getInvoiceDetailService);
	getInvoiceDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getInvoiceDetailService.makeRequest(props));
};

/**
 * Action to get the invoice detail.
 * @param {object} props
 * @returns
 */

export const onGetRetailerInvoiceDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_INVOICE_DETAIL_SUCCESS,
		ActionTypes.GET_INVOICE_DETAIL_FAILURE,
		ActionTypes.GET_INVOICE_DETAIL_LOADER,
	);
	const getInvoiceDetailService = new GetRetailerInvoiceDetailService(dispatchedActions);
	addBasicInterceptors(getInvoiceDetailService);
	getInvoiceDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getInvoiceDetailService.makeRequest(props));
};

/**
 * Action to get the invoice detail.
 * @param {object} props
 * @returns
 */

export const onGetCollectorInvoiceDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_INVOICE_DETAIL_SUCCESS,
		ActionTypes.GET_INVOICE_DETAIL_FAILURE,
		ActionTypes.GET_INVOICE_DETAIL_LOADER,
	);
	const getCollectorInvoiceDetailService = new GetCollectorInvoiceDetailService(
		dispatchedActions,
	);
	addBasicInterceptors(getCollectorInvoiceDetailService);
	getCollectorInvoiceDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCollectorInvoiceDetailService.makeRequest(props));
};

/**
 * Action to cancel the created collection request.
 * @param {object} props
 * @returns
 */

export const onCancelInvoiceRequest = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.CANCEL_INVOICE_REQUEST_SUCCESS,
		ActionTypes.CANCEL_INVOICE_REQUEST_FAILURE,
		ActionTypes.CANCEL_INVOICE_REQUEST_LOADER,
	);
	const cancelInvoiceRequestService = new CancelInvoiceRequestService(dispatchedActions);
	addBasicInterceptors(cancelInvoiceRequestService);
	cancelInvoiceRequestService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(cancelInvoiceRequestService.makeRequest(props));
};

export const onResetInvoiceDetailState = () => ({ type: ActionTypes.RESET_INVOICE_DETAIL_STATE });
