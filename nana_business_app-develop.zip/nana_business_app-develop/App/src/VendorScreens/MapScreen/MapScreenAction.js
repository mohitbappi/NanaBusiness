import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetCustomerListingService from '@Customer/GetCustomerListingService';
import GetVendorCustomerListingService from '@CustomerVendorServices/GetCustomerListingService';
import { actions } from '@libapi/APIActionsBuilder';
import * as ActionTypes from './ActionType';

export const getCollectorCustomerList = () => dispatch => {
	// Action to the customers list if role is collector.
	const dispatchedActions = actions(
		ActionTypes.GET_CUSTOMER_LISTING_SUCCESS,
		ActionTypes.GET_CUSTOMER_LISTING_FAILURE,
		ActionTypes.GET_CUSTOMER_LISTING_LOADER,
	);
	const getCustomerListingService = new GetCustomerListingService(dispatchedActions);
	addBasicInterceptors(getCustomerListingService);
	getCustomerListingService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCustomerListingService.makeRequest());
};

export const getVendorCustomerList = () => dispatch => {
	// Action to the customers list if role is vendor.
	const dispatchedActions = actions(
		ActionTypes.GET_CUSTOMER_LISTING_SUCCESS,
		ActionTypes.GET_CUSTOMER_LISTING_FAILURE,
		ActionTypes.GET_CUSTOMER_LISTING_LOADER,
	);
	const getVendorCustomerListingService = new GetVendorCustomerListingService(dispatchedActions);
	addBasicInterceptors(getVendorCustomerListingService);
	getVendorCustomerListingService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getVendorCustomerListingService.makeRequest());
};
