import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import Config from 'react-native-config';
import Geolocation from '@react-native-community/geolocation';
import { View, Text, TouchableOpacity, Linking } from 'react-native';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import * as colors from '@assets/colors';
import vendorNavigations from '@routes/vendorNavigations';
import {
	collector,
	vendor,
	noOfMinCharToSearch,
	mapMovementDuration,
	dash,
	IMAGE_TYPE,
	saudiLatitude,
	saudiLongitude,
	latitudeDelta,
	longitudeDelta,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import EnableLocation from '@Util/EnableLocation';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { normalScale } from '@device/normalize';
import collectorNavigations from '@routes/collectorNavigations';
import OverlayComponent from '@OverlayComponent/OverlayComponent';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getStarUI } from '@Util/GetSatrUI';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import * as MapScreenActions from './MapScreenAction';
import { createStyleSheet } from './MapScreenStyle';

const GooglePlacesAutocompleteStyles = {
	description: {
		backgroundColor: colors.white,
	},
	predefinedPlacesDescription: {
		color: colors.lightGrey,
		backgroundColor: colors.white,
	},
	textInputContainer: {
		zIndex: 80,
	},
	textInput: {
		backgroundColor: colors.white,
		borderBottomWidth: normalScale(0.5),
		borderColor: colors.grey,
	},
	listView: {
		elevation: 1,
		backgroundColor: colors.white,
		zIndex: 80,
	},
};

class MapScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			region: {
				latitude: parseFloat(saudiLatitude), // latitude of the current location.
				longitude: parseFloat(saudiLongitude), // longitude of the current location.
				latitudeDelta,
				longitudeDelta,
			},
			currentLocation: {
				latitude: parseFloat(saudiLatitude),
				longitude: parseFloat(saudiLongitude),
			},
			selectedIndex: null,
			isEnable: false,
			isSetLocation: true,
			isVisible: false,
		};
		this._mapView = React.createRef(null);
		this.GooglePlacesRef = React.createRef(null);
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.setState({
				selectedIndex: null,
			});
			this.enableLocation();
			this.onCallApi();
		});
	}

	componentDidUpdate(prevProps) {
		const { mapScreenInfo } = this.props;
		const { loader, customerList } = mapScreenInfo;
		if (
			!loader &&
			prevProps.mapScreenInfo !== mapScreenInfo &&
			customerList &&
			customerList.length !== 0
		) {
			// Will clear search text field.
			this.clearPlacesMapSearchTextInput();
		}
	}

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	enableLocation = () => {
		// Will fetch the current location of the user.
		const { isSetLocation } = this.state;
		Geolocation.getCurrentPosition(
			info => {
				if (isSetLocation) {
					this.setState({
						region: {
							latitude: parseFloat(info.coords.latitude),
							longitude: parseFloat(info.coords.longitude),
							latitudeDelta: 0.005,
							longitudeDelta: 0.005,
						},
						currentLocation: {
							latitude: parseFloat(info.coords.latitude),
							longitude: parseFloat(info.coords.longitude),
						},
						isEnable: true,
						isSetLocation: false,
					});
				}
			},
			() => {
				this.setState({ isEnable: false, isSetLocation: true });
			},
		);
	};

	onCallApi = () => {
		const { userDetails, mapScreenAction } = this.props;
		// API call to locate the customers on the map.
		const { roles } = userDetails.user;
		if (roles.includes(collector)) {
			mapScreenAction.getCollectorCustomerList();
		} else {
			mapScreenAction.getVendorCustomerList();
		}
	};

	onPressList = () => {
		const { userDetails, navigation } = this.props;
		// Will navigate to the customer listing screen.
		const { role } = userDetails.user;
		if (role === vendor) {
			navigation.navigate(vendorNavigations.CUSTOMER_LISTING_NAVIGATION);
		} else {
			navigation.navigate(collectorNavigations.CUSTOMER_LISTING_NAVIGATION);
		}
	};

	onClose = value => {
		this.setState({
			isVisible: value,
		});
	};

	clearPlacesMapSearchTextInput = () => {
		// Will clear search text field.
		if (this.GooglePlacesRef.setAddressText) {
			this.GooglePlacesRef.setAddressText('');
		}
	};

	onMapReady = () => {
		this.setState({});
	};

	onMapRegionChange = region => {
		this.setState(
			{
				region,
			},
			() => this.fetchMapAddress(),
		);
	};

	onMapAddressSearch = location => {
		// Will search the address.
		this.setState(
			{
				region: {
					latitude: parseFloat(location.lat),
					longitude: parseFloat(location.lng),
					latitudeDelta: 0.005,
					longitudeDelta: 0.005,
				},
			},
			() => {
				this.fetchMapAddress();
				this.animateMapToLocation();
			},
		);
	};

	animateMapToLocation = () => {
		const { region } = this.state;
		const { latitude, longitude } = region;
		const temp_cordinate = {
			latitude,
			longitude,
		};
		this._mapView.animateCamera(
			{
				center: temp_cordinate,
			},
			mapMovementDuration,
		);
	};

	fetchMapAddress = () => {
		// Will fetch the address.
		const { region } = this.state;
		fetch(
			`https://maps.googleapis.com/maps/api/geocode/json?address=${region.latitude},${region.longitude}&key=${Config.GOOGLE_API_KEY}`,
		)
			.then(response => response.json())
			.then(() => {
				// response
			});
	};

	changeRetailerInfo = index => {
		this.setState({
			selectedIndex: index,
		});
	};

	getRetailerDetail = (id, image_url) => {
		const { userDetails, navigation } = this.props;
		// Will navigate to the retailer detail screen.
		const { roles } = userDetails.user;
		if (roles.includes(collector)) {
			navigation.navigate(collectorNavigations.RETAILER_DETAIL_NAVIGATION, {
				id,
				image_url,
			});
		} else {
			navigation.navigate(vendorNavigations.REATILER_DETAIL_NAVIGATION, {
				id,
				image_url,
			});
		}
	};

	getName = name => {
		return `${name.slice(0, 12)}${name.length > 12 ? '...' : ''}`;
	};

	getMobileNumber = (isRTL, mobileData) => {
		const styles = createStyleSheet(isRTL);
		return mobileData.map((item, index) => {
			return (
				<TouchableOpacity
					disabled={!item.isDialOpen}
					activeOpacity={0.8}
					onPress={() => this.onPressCall(item.number)}
					style={[
						styles.cardContainer,
						index === mobileData.length - 1 && styles.noBorder,
					]}>
					<Text style={styles.numberText}>{item.title}</Text>
					<View style={styles.card}>
						<ImageLoadComponent
							source={IMAGES.iconSmallPhone}
							style={styles.iconSmallPhone}
						/>
						<Text style={styles.number}>{item.number}</Text>
					</View>
				</TouchableOpacity>
			);
		});
	};

	onPressCall = num => {
		// Will navigate to the dial pad.
		Linking.openURL(`tel:${num}`).then(() => {
			// success
		});
	};

	render() {
		const { languageInfo, mapScreenInfo, route } = this.props;
		const { region } = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { customerList, loader, error, errorCode } = mapScreenInfo;
		const { selectedIndex, isEnable, isVisible, currentLocation } = this.state;
		const { latitude, longitude } = currentLocation;
		const { isDriverRole } = route.params || {};
		this.enableLocation();
		let mobileData = [];
		const homePlace = {
			description: localeString(keyConstants.CURRENT_LOCATION),
			geometry: {
				location: {
					lat: latitude,
					lng: longitude,
				},
			},
		};
		if (customerList && customerList.length !== 0) {
			mobileData = [
				{
					title: localeString(keyConstants.PRIMARY_MOBILE_NUMBER),
					number: customerList[selectedIndex === null ? 0 : selectedIndex].phone,
					isDialOpen: !!customerList[selectedIndex === null ? 0 : selectedIndex].phone,
				},
				{
					title: localeString(keyConstants.ALTERNATE_MOBILE_NUMBER),
					number: customerList[selectedIndex === null ? 0 : selectedIndex].phone_secondary
						? customerList[selectedIndex === null ? 0 : selectedIndex].phone_secondary
						: dash,
					isDialOpen: !!customerList[selectedIndex === null ? 0 : selectedIndex]
						.phone_secondary,
				},
			];
		}
		if (!isEnable) {
			return <EnableLocation onCancel={this.onGoBack} />;
		}
		return (
			<View style={styles.container}>
				<OverlayComponent
					isRTL={isRTL}
					isVisible={isVisible}
					onClose={() => this.onClose(false)}
					component={this.getMobileNumber(isRTL, mobileData)}
				/>
				{loader && <Loader size="large" />}
				<View style={styles.header}>
					<Header
						text={localeString(keyConstants.CUSTOMERS_NEARBY)}
						hasIconCustomer={!isDriverRole}
						hasIconList
						onPressList={this.onPressList}
						hasIconBack={isDriverRole}
						onPressBack={this.onGoBack}
					/>
				</View>
				{error ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onCallApi}
					/>
				) : (
					<>
						{customerList && customerList.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_CUSTOMERS_FOUND)} />
						) : (
							<View style={styles.mapContainer}>
								<MapView
									ref={mapView => {
										this._mapView = mapView;
									}}
									style={styles.map}
									initialRegion={region}
									showsUserLocation
									onMapReady={this.onMapReady}
									zoomControlEnabled
									showsMyLocationButton
									provider={PROVIDER_GOOGLE}
									onRegionChangeComplete={this.onMapRegionChange}>
									{customerList &&
										customerList.length !== 0 &&
										customerList.map((item, index) => (
											<Marker
												coordinate={{
													latitude: parseFloat(item.latitude),
													longitude: parseFloat(item.longitude),
												}}
												draggable
												onLoad={() => this.forceUpdate()}
												image={IMAGES.iconLocationPin}
												onPress={() => this.changeRetailerInfo(index)}
												onSelect={() => this.changeRetailerInfo(index)}
											/>
										))}
								</MapView>
								<>
									<View style={styles.searchBarContainer}>
										<GooglePlacesAutocomplete
											styles={GooglePlacesAutocompleteStyles}
											ref={instance => {
												this.GooglePlacesRef = instance;
											}}
											placeholder={localeString(keyConstants.SEARCH)}
											minLength={noOfMinCharToSearch}
											fetchDetails
											listViewDisplayed={false}
											enablePoweredByContainer={false}
											returnKeyType="search"
											onPress={(data, details = null) => {
												const { location } = details.geometry;
												this.onMapAddressSearch(location);
											}}
											query={{
												key: Config.GOOGLE_API_KEY,
												language: 'en',
											}}
											predefinedPlaces={[homePlace]}
											textInputProps={{
												placeholderTextColor: colors.blackGreyWhite,
											}}
										/>
									</View>
								</>
							</View>
						)}
						{customerList && customerList.length !== 0 && (
							<TouchableOpacity
								style={styles.bottomView}
								activeOpacity={0.8}
								onPress={() =>
									this.getRetailerDetail(
										customerList[selectedIndex === null ? 0 : selectedIndex].id,
										customerList[selectedIndex === null ? 0 : selectedIndex]
											.images &&
											customerList[selectedIndex === null ? 0 : selectedIndex]
												.images.medium,
									)
								}>
								<View style={styles.innerImageView}>
									<ImageLoadComponent
										imageType={IMAGE_TYPE.account}
										isUrl={
											customerList[selectedIndex === null ? 0 : selectedIndex]
												.images
										}
										source={
											customerList[selectedIndex === null ? 0 : selectedIndex]
												.images &&
											customerList[selectedIndex === null ? 0 : selectedIndex]
												.images.small
												? customerList[
														selectedIndex === null ? 0 : selectedIndex
												  ].images.small
												: IMAGES.iconProfileDefault
										}
										style={styles.defaultImage}
									/>
								</View>
								<View style={styles.innerView}>
									<View style={styles.detailView}>
										<View style={styles.nameView}>
											<Text style={styles.name}>
												{this.getName(
													customerList[
														selectedIndex === null ? 0 : selectedIndex
													].name,
												)}
											</Text>
											<View style={styles.progress}>
												<View style={styles.starView}>
													{getStarUI(
														customerList[
															selectedIndex === null
																? 0
																: selectedIndex
														].score
															? customerList[
																	selectedIndex === null
																		? 0
																		: selectedIndex
															  ].score
															: 0,
													)}
												</View>
											</View>
										</View>
										<View style={styles.buttonView}>
											<View>
												<Text style={styles.invoice}>
													{`${
														customerList[
															selectedIndex === null
																? 0
																: selectedIndex
														].total_invoices
													} ${localeString(keyConstants.COLL_REQUESTS)}`}
												</Text>
												<Text style={styles.amount}>
													{`${currencyFormatter(
														getValueInDecimal(
															customerList[
																selectedIndex === null
																	? 0
																	: selectedIndex
															].amount,
														),
													)} ${localeString(keyConstants.SAR)}`}
												</Text>
											</View>
											<TouchableOpacity
												style={styles.button}
												activeOpacity={0.8}
												onPress={() => this.onClose(true)}>
												<ImageLoadComponent
													source={IMAGES.iconPhoneWhite}
													style={styles.iconPhoneWhite}
												/>
												<Text style={styles.call}>
													{localeString(keyConstants.CALL)}
												</Text>
											</TouchableOpacity>
										</View>
									</View>
								</View>
							</TouchableOpacity>
						)}
					</>
				)}
			</View>
		);
	}
}

MapScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	userDetails: PropTypes.object.isRequired,
	languageInfo: PropTypes.func.isRequired,
	mapScreenInfo: PropTypes.func.isRequired,
	mapScreenAction: PropTypes.func.isRequired,
	route: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		mapScreenInfo: state.MapScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		mapScreenAction: bindActionCreators({ ...MapScreenActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(MapScreen);
