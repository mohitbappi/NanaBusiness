import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	customerList: [],
};

const MapScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_CUSTOMER_LISTING_SUCCESS:
			return {
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				customerList: action.payload.retailers,
			};
		case ActionTypes.GET_CUSTOMER_LISTING_FAILURE:
			return {
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				customerList: [],
			};
		case ActionTypes.GET_CUSTOMER_LISTING_LOADER:
			return {
				success: false,
				error: false,
				errorCode: null,
				loader: true,
			};
		default:
			return state;
	}
};

export default MapScreenReducer;
