export const GET_CUSTOMER_LISTING_SUCCESS = 'get_customer_listing_success';
export const GET_CUSTOMER_LISTING_FAILURE = 'get_customer_listing_failure';
export const GET_CUSTOMER_LISTING_LOADER = 'get_customer_listing_loader';
