import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		cardContainer: {
			paddingTop: verticalScale(12),
			paddingBottom: verticalScale(12),
			marginLeft: isRTL ? normalScale(38) : normalScale(16),
			marginRight: isRTL ? normalScale(16) : normalScale(38),
			borderBottomColor: colors.grey,
			borderBottomWidth: moderateScale(1),
		},
		noBorder: {
			borderBottomWidth: moderateScale(0),
			paddingBottom: verticalScale(0),
		},
		card: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(8),
			alignItems: 'center',
		},
		iconSmallPhone: {
			height: verticalScale(10),
			width: normalScale(10),
			resizeMode: 'contain',
		},
		number: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		numberText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
			zIndex: 1,
		},
		header: {
			marginTop: verticalScale(12),
			marginHorizontal: normalScale(16),
		},
		mapContainer: {
			flex: 1,
		},
		map: {
			flex: 1,
		},
		searchBarContainer: {
			zIndex: 90,
			flex: 1,
			paddingHorizontal: normalScale(10),
			paddingVertical: verticalScale(10),
			width: normalScale(320),
			position: 'absolute',
			left: normalScale(0),
			top: normalScale(0),
		},
		bottomView: {
			paddingVertical: verticalScale(16),
			backgroundColor: colors.white,
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingLeft: verticalScale(16),
			paddingRight: verticalScale(8),
		},
		innerImageView: {
			height: verticalScale(60),
			width: normalScale(60),
			borderRadius: moderateScale(6),
			justifyContent: 'center',
		},
		defaultImage: {
			height: verticalScale(60),
			width: normalScale(60),
			borderRadius: moderateScale(6),
		},
		innerView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			flex: 1,
		},
		detailView: {
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			flex: 1,
		},
		nameView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		name: {
			maxWidth: normalScale(150),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(16),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		buttonView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			flex: 1,
		},
		invoice: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(12),
			marginTop: verticalScale(4),
			textAlign: rtlFunctions.getTextAlign(isRTL),
			maxWidth: normalScale(140),
		},
		amount: {
			width: normalScale(140),
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
			marginTop: verticalScale(4),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		button: {
			backgroundColor: colors.darkBlue,
			paddingHorizontal: normalScale(19),
			paddingVertical: verticalScale(8),
			height: verticalScale(30),
			marginTop: verticalScale(8),
			borderRadius: normalScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		iconPhoneWhite: {
			height: verticalScale(13),
			width: normalScale(13),
			resizeMode: 'contain',
		},
		call: {
			color: colors.white,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginLeft: isRTL ? 0 : normalScale(11),
			marginRight: isRTL ? normalScale(11) : 0,
		},
		progress: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		liveLocationView: {
			backgroundColor: colors.white,
			height: verticalScale(36),
			width: normalScale(40),
			borderRadius: normalScale(20),
			shadowColor: colors.pureBlack,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(3),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.14,
			elevation: verticalScale(3),
			justifyContent: 'center',
			alignItems: 'center',
			position: 'absolute',
			bottom: verticalScale(108),
			right: normalScale(16),
		},
		iconGPS: {
			height: verticalScale(26),
			width: normalScale(26),
			resizeMode: 'contain',
		},
		starView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
		},
		star: {
			width: normalScale(9),
			height: verticalScale(9),
			resizeMode: 'contain',
			marginRight: normalScale(1),
		},
	});
};

export default createStyleSheet;
