import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import { renderFlexDirectionBasedOnRtl } from '@lib/helpers';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginVertical: verticalScale(8),
			marginHorizontal: normalScale(16),
			borderBottomColor: colors.grey,
			borderRadius: moderateScale(8),
			borderBottomWidth: normalScale(1),
		},
		innerContainer: {
			marginHorizontal: normalScale(16),
			flex: 1,
		},
		payment: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(8),
		},
		buttonView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
		},
		backButton: {
			width: normalScale(66),
			backgroundColor: colors.white,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(36),
			justifyContent: 'center',
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
		},
		greenButton: {
			width: normalScale(66),
		},
		backText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
		},
		invoiceText: {
			fontSize: normalize(12),
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			color: colors.lightBlack,
			marginTop: verticalScale(16),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
		},
		amountCameraContainer: {
			marginTop: verticalScale(8),
			height: verticalScale(44),
			flexDirection: renderFlexDirectionBasedOnRtl(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
			borderWidth: moderateScale(1),
			borderRadius: moderateScale(8),
			borderStyle: 'dashed',
			borderColor: colors.grey,
		},
		imgText: {
			color: colors.blue,
			fontSize: normalize(14),
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			marginLeft: isRTL ? null : normalScale(12),
			marginRight: isRTL ? normalScale(16) : null,
			width: normalScale(250),
		},
		cameraContainer: {
			marginRight: isRTL ? null : normalScale(16),
			marginLeft: isRTL ? normalScale(16) : null,
		},
		camera: {
			height: verticalScale(15),
			width: normalScale(18),
		},
		cross: {
			height: verticalScale(16),
			width: normalScale(16),
		},
		bottomButtonView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingBottom: verticalScale(16),
			justifyContent: 'space-between',
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
			alignItems: 'flex-end',
			paddingHorizontal: normalScale(16),
		},
		bottomBackButton: {
			paddingHorizontal: normalScale(53),
			backgroundColor: colors.white,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(36),
			justifyContent: 'center',
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
		},
		bottomBackText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
		},
		addButton: {
			paddingHorizontal: normalScale(46),
		},
	});
};

export default createStyleSheet;
