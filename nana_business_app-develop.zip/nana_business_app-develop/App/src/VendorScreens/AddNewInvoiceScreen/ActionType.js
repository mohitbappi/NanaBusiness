export const ADD_NEW_INVOICE_SUCCESS = 'add_new_invoice_success';
export const ADD_NEW_INVOICE_FAILURE = 'add_new_invoice_failure';
export const ADD_NEW_INVOICE_LOADER = 'add_new_invoice_loader';
