import { actions } from '@libapi/APIActionsBuilder';
import CreateInvoiceService from '@InvoicesVendorServices/CreateInvoiceService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to call create invoice api
 * @param {object} invoiceDetail
 */
export const onCreateInvoice = invoiceDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ADD_NEW_INVOICE_SUCCESS,
		ActionTypes.ADD_NEW_INVOICE_FAILURE,
		ActionTypes.ADD_NEW_INVOICE_LOADER,
	);
	const createInvoiceService = new CreateInvoiceService(dispatchedActions);
	addBasicInterceptors(createInvoiceService);
	createInvoiceService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(createInvoiceService.makeRequest(invoiceDetail));
};

export default onCreateInvoice;
