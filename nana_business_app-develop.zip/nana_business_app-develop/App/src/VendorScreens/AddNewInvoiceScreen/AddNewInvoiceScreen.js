// import libraries
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, Text, Keyboard } from 'react-native';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';

// import components
import Header from '@Header/Header';
import Input from '@Input/Input';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import ImageInputComponent from '@ImageInputComponent/ImageInputComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';

// import utils
import { onAddDaysInDate } from '@Util/GetFormattedDate';
import { getImageUrl } from '@Util/GetImageUrl';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { normalScale } from '@device/normalize';
import {
	numericRegexWithDecimalEx,
	spaceRegexEx,
	fourteenDays,
	twentyOneDays,
	sevenDays,
	toastShowTime,
	asterik,
	noOfDaysMaxLength,
	invoiceImg,
	numericalRegexExp,
} from '@Constants/Constants';

// import styles
import { createStyleSheet } from './AddNewInvoiceScreenStyle';

// import actions
import * as AddInvoiceActions from './AddNewInvoiceScreenAction';

class AddNewInvoiceScreen extends Component {
	constructor(props) {
		super(props);
		this.amount = React.createRef(null);
		this.state = {
			amount: 0,
			buttonValueArray: [
				sevenDays,
				fourteenDays,
				twentyOneDays,
				localeString(keyConstants.OTHER),
			],
			activeDateIndex: 0,
			isApiError: false,
			toastMessage: '',
			days: 0,
			isAmountError: false,
			amountErrorMessage: '',
			invoiceId: '',
		};
	}

	componentDidUpdate(prevProps, prevState) {
		const { addInvoiceInfo } = this.props;
		const { amount } = this.state;
		const { error, errorCode, success } = addInvoiceInfo;
		const errorArray = [
			keyConstants.ORG_NOT_FOUND,
			keyConstants.PERMISSION_DENIED,
			keyConstants.DATA_INTEGRITY_ERROR,
		];
		if (error && prevProps.addInvoiceInfo.error !== addInvoiceInfo.error) {
			if (errorArray.includes(errorCode && errorCode.error)) {
				// Will show toast if api error occurs.
				this.setState({
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				// Will show alert if api fails.
				ErrorAlertComponent(errorCode, this.onGenerateInvoice);
			}
		}
		if (success && prevProps.addInvoiceInfo.success !== addInvoiceInfo.success) {
			// if add new invoice api returns success
			this.setState({
				amount: 0,
				activeDateIndex: 0,
			});
			this.onGoBack();
		}
		if (
			amount !== prevState.amount &&
			numericRegexWithDecimalEx.test(String(amount).toLowerCase())
		) {
			this.setState({
				isAmountError: false,
				amountErrorMessage: '',
			});
		}
	}

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeInvoiceId = text => {
		this.setState({
			invoiceId: text,
		});
	};

	onChangeText = text => {
		this.setState({
			amount: text,
		});
	};

	onSelectDueDate = index => {
		this.setState({
			activeDateIndex: index,
		});
	};

	onGenerateInvoice = () => {
		// Call api to create new invoice
		const { route, imageInputComponentInfo, addInvoiceActions } = this.props;
		const { amount, activeDateIndex, buttonValueArray, days, invoiceId } = this.state;
		const { image: invoiceImage } = imageInputComponentInfo;
		const { id } = route.params;
		const invoiceDetails = {
			invoice_total: amount,
			retailer_id: id,
			invoice_no: invoiceId,
			due_date: onAddDaysInDate(
				new Date(),
				activeDateIndex === buttonValueArray.length - 1
					? days
					: buttonValueArray[activeDateIndex],
			),
			image: getImageUrl(invoiceImage),
		};
		addInvoiceActions.onCreateInvoice(invoiceDetails);
	};

	onChangeDays = days => {
		this.setState({
			days,
		});
	};

	onBlur = () => {
		const { amount } = this.state;
		if (!numericRegexWithDecimalEx.test(String(amount).toLowerCase())) {
			this.setState({
				isAmountError: true,
				amountErrorMessage: localeString(keyConstants.ONLY_TWO_DIGIT_AFTER_DECIMAL),
			});
		} else {
			this.setState({
				isAmountError: false,
				amountErrorMessage: '',
			});
		}
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const textInput = textInputRef;
		textInput.current = node;
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	render() {
		const { languageInfo, imageInputComponentInfo, addInvoiceInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			amount,
			buttonValueArray,
			activeDateIndex,
			isApiError,
			toastMessage,
			days,
			isAmountError,
			amountErrorMessage,
			invoiceId,
		} = this.state;
		const { image: invoiceImage } = imageInputComponentInfo;
		const { loader } = addInvoiceInfo;
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				<View style={styles.header}>
					<Header
						text={localeString(keyConstants.ADD_NEW_CR)}
						hasIconClose
						hasIconPin
						onPressClose={this.onGoBack}
					/>
				</View>
				<View style={styles.innerContainer}>
					<Input
						value={invoiceId}
						width={normalScale(288)}
						label={`${localeString(keyConstants.INVOICE_ID)}*`}
						placeholder={localeString(keyConstants.ENTER_INVOICE_ID)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => this.onChangeInvoiceId(text)}
						autoCapitalize="none"
						onSubmitEditing={() => this.onSubmitRef(this.amount)}
					/>
					<Input
						value={amount}
						width={normalScale(288)}
						label={`${localeString(keyConstants.AMOUNT)}*`}
						placeholder={localeString(keyConstants.AMOUNT)}
						blurOnSubmit
						returnKeyType="done"
						keyboardType="decimal-pad"
						isRTL={isRTL}
						onChangeText={text =>
							(spaceRegexEx.test(String(text).toLowerCase()) || text === '') &&
							this.onChangeText(text)
						}
						autoCapitalize="none"
						isError={isAmountError}
						errorMessage={amountErrorMessage}
						onBlur={this.onBlur}
						refs={this.refCallback(this.amount)}
					/>
					<Text style={styles.payment}>
						{`${localeString(keyConstants.PAYMENT_DUE)} (${
							activeDateIndex < buttonValueArray.length - 1
								? buttonValueArray[activeDateIndex]
								: days
						}) ${localeString(keyConstants.DAYS)}`}
					</Text>
					<View style={styles.buttonView}>
						{buttonValueArray.map((item, index) => {
							return (
								<ButtonComponent
									buttonStyle={
										activeDateIndex !== index
											? styles.backButton
											: styles.greenButton
									}
									text={item}
									textStyle={activeDateIndex !== index && styles.backText}
									onPress={() => this.onSelectDueDate(index)}
								/>
							);
						})}
					</View>
					{activeDateIndex === buttonValueArray.length - 1 && (
						<Input
							maxLength={noOfDaysMaxLength}
							value={days}
							width={normalScale(288)}
							label={`${localeString(keyConstants.DUE_DAYS)}${asterik}`}
							placeholder={localeString(keyConstants.DUE_DAYS)}
							returnKeyType="done"
							keyboardType="number-pad"
							blurOnSubmit
							isRTL={isRTL}
							onChangeText={text =>
								(numericalRegexExp.test(String(text).toLowerCase()) ||
									text === '') &&
								this.onChangeDays(text)
							}
							autoCapitalize="none"
						/>
					)}
					<ImageInputComponent
						isRTL={isRTL}
						label={`${localeString(keyConstants.INVOICE_IMAGE)}*`}
						placeholder={localeString(keyConstants.UPLOAD_INVOICE_IMAGE)}
						selectedImageTitle={invoiceImg}
					/>
				</View>
				<View style={styles.bottomButtonView}>
					<ButtonComponent
						buttonStyle={styles.bottomBackButton}
						text={localeString(keyConstants.BACK)}
						textStyle={styles.bottomBackText}
						onPress={this.onGoBack}
					/>
					<ButtonComponent
						buttonStyle={styles.addButton}
						text={localeString(keyConstants.GENERATE_CR)}
						onPress={this.onGenerateInvoice}
						isButtonDisable={
							!(
								numericRegexWithDecimalEx.test(String(amount).toLowerCase()) &&
								amount > 0 &&
								(activeDateIndex === buttonValueArray.length - 1
									? parseInt(days, 10)
									: true) &&
								!isAmountError &&
								invoiceId &&
								invoiceImage
							)
						}
					/>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

AddNewInvoiceScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	languageInfo: PropTypes.func.isRequired,
	addInvoiceInfo: PropTypes.func.isRequired,
	route: PropTypes.func.isRequired,
	imageInputComponentInfo: PropTypes.func.isRequired,
	addInvoiceActions: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		addInvoiceInfo: state.AddNewInvoiceScreenReducer,
		imageInputComponentInfo: state.ImageInputComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		addInvoiceActions: bindActionCreators({ ...AddInvoiceActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(AddNewInvoiceScreen);
