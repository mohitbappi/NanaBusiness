import { StyleSheet, Dimensions } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();
const { width } = Dimensions.get('window');

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(8),
		},
		header: {
			height: verticalScale(40),
			backgroundColor: colors.white,
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingHorizontal: normalScale(8),
		},
		locationView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		iconPin: {
			width: normalScale(15),
			height: verticalScale(18),
		},
		dropdownText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		notificationContainerStyle: {
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: colors.red,
			borderRadius: normalScale(6),
			width: normalScale(12),
			height: normalScale(12),
			borderColor: colors.white,
			borderWidth: normalScale(1),
			position: 'absolute',
			top: -verticalScale(1),
			left: normalScale(20),
		},
		notificationCountStyle: {
			color: colors.white,
			fontSize: normalize(8),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
		},
		iconNotification: {
			width: normalScale(28),
			height: verticalScale(28),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			resizeMode: 'contain',
		},
		scrollView: {
			paddingHorizontal: normalScale(8),
			paddingVertical: verticalScale(8),
			marginBottom: verticalScale(8),
		},
		invoiceView: {
			backgroundColor: colors.skyBlue,
			justifyContent: 'center',
			alignItems: 'center',
			paddingVertical: verticalScale(12),
			borderRadius: moderateScale(8),
			marginTop: verticalScale(16),
		},
		totalText: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
		},
		amountText: {
			color: colors.lightBlueShadowGrey,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			marginTop: verticalScale(4),
		},
		card: {
			paddingVertical: verticalScale(16),
			borderRadius: moderateScale(8),
			backgroundColor: colors.white,
			paddingHorizontal: verticalScale(16),
			marginTop: verticalScale(12),
			shadowColor: colors.inputShadow,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(6),
			shadowOpacity: 0.06,
			elevation: verticalScale(2),
		},
		amountContainer: {
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginBottom: verticalScale(4),
		},
		dueVendorAmountView: {
			paddingVertical: verticalScale(2),
			paddingHorizontal: verticalScale(8),
			borderColor: colors.darkOrange,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(4),
			marginBottom: verticalScale(6),
			alignSelf: 'center',
		},
		dueVendorText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		progressBar: {
			width: width - normalScale(64),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			height: verticalScale(4),
			borderRadius: moderateScale(4.5),
			backgroundColor: colors.lightBlueShadowGrey,
		},
		rejectedVendorAmount: {
			backgroundColor: colors.red,
			borderTopLeftRadius: moderateScale(4.5),
			borderBottomLeftRadius: moderateScale(4.5),
		},
		pendingAmount: {
			backgroundColor: colors.darkOrange,
		},
		detailView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(4),
		},
		rejectedText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(12),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		rejectedAmountStyle: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			marginTop: verticalScale(2),
		},
		text: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(12),
			textAlign: rtlFunctions.getTextAlignOpposite(isRTL),
		},
		amountTextStyle: {
			color: colors.lightBlueShadowGrey,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			marginTop: verticalScale(2),
		},
		pendingTextView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
		},
		pendingText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(12),
		},
		viewVendorInvoices: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(12),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(12),
		},
		userInfoContainer: {
			borderBottomWidth: verticalScale(1),
			borderColor: colors.grey,
			justifyContent: 'center',
		},
	});
};

export default createStyleSheet;
