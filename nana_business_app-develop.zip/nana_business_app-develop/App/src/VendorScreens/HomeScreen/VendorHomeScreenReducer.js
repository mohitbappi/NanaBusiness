import * as ActionTypes from './ActionType';

const initialState = {
	userDetails: null,
	invoicesList: [],
	pendingRequestsList: [],
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	invoiceData: null,
	notificationCount: 0,
	isVendorInvoice: false,
	isPendingRequest: false,
};

const VendorHomeScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.STORE_USER_DETAILS:
			return {
				...state,
				userDetails: action.payload,
			};
		case ActionTypes.GET_VENDOR_INVOICES_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				invoicesList: action.payload.invoices,
			};
		case ActionTypes.GET_VENDOR_INVOICES_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_VENDOR_INVOICES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isVendorInvoice: true,
				isPendingRequest: false,
			};
		case ActionTypes.GET_PENDING_REQUESTS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				pendingRequestsList: action.payload.accounts_requests
					? action.payload.accounts_requests
					: [],
			};
		case ActionTypes.GET_PENDING_REQUESTS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isVendorInvoice: false,
				isPendingRequest: true,
			};
		case ActionTypes.GET_INVOICE_DATA_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				invoiceData: action.payload,
			};
		case ActionTypes.GET_INVOICE_DATA_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isVendorInvoice: false,
				isPendingRequest: false,
			};
		case ActionTypes.GET_NOTIFICATION_COUNT_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCategory: false,
				invoiceLoader: false,
				notificationCount: action.payload.pending_notifications,
			};
		default:
			return state;
	}
};

export default VendorHomeScreenReducer;
