import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetPendingInvoicesService from '@InvoicesVendorServices/GetPendingInvoicesService';
import GetPendingRequestsService from '@PendingRequests/GetPendingRequestsService';
import GetInvoiceDataService from '@InvoicesVendorServices/GetInvoiceDataService';
import { actions } from '@libapi/APIActionsBuilder';
import GetNotificationCountService from '@Notification/GetNotificationCountService';
import * as ActionTypes from './ActionType';

/**
 * Action to store user details in home screen reducer
 * @param {object} userDetails
 */
export const onStoreUserDetails = userDetails => {
	return {
		type: ActionTypes.STORE_USER_DETAILS,
		payload: userDetails,
	};
};

/**
 * Action to call pending invoices api
 * @param {object} props
 */
export const onGetPendingInvoices = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_VENDOR_INVOICES_SUCCESS,
		ActionTypes.GET_VENDOR_INVOICES_FAILURE,
		ActionTypes.GET_VENDOR_INVOICES_LOADER,
	);
	const getPendingInvoicesService = new GetPendingInvoicesService(dispatchedActions);
	addBasicInterceptors(getPendingInvoicesService);
	getPendingInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPendingInvoicesService.makeRequest(props));
};

/**
 * Action to call fetch all pending requests api
 * @param {object} props
 */
export const onGetPendingRequests = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_PENDING_REQUESTS_SUCCESS,
		ActionTypes.GET_PENDING_REQUESTS_FAILURE,
		ActionTypes.GET_PENDING_REQUESTS_LOADER,
	);
	const getPendingRequestsService = new GetPendingRequestsService(dispatchedActions);
	addBasicInterceptors(getPendingRequestsService);
	getPendingRequestsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPendingRequestsService.makeRequest(props));
};

// Action to call get invoice data api
export const onGetInvoiceData = () => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_INVOICE_DATA_SUCCESS,
		ActionTypes.GET_INVOICE_DATA_FAILURE,
		ActionTypes.GET_INVOICE_DATA_LOADER,
	);
	const getInvoiceDataService = new GetInvoiceDataService(dispatchedActions);
	addBasicInterceptors(getInvoiceDataService);
	getInvoiceDataService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getInvoiceDataService.makeRequest());
};

// Action to get notification count
export const onGetNotificationCount = () => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_NOTIFICATION_COUNT_SUCCESS,
		ActionTypes.GET_NOTIFICATION_COUNT_FAILURE,
		ActionTypes.GET_NOTIFICATION_COUNT_LOADER,
	);
	const getNotificationCountService = new GetNotificationCountService(dispatchedActions);
	addBasicInterceptors(getNotificationCountService);
	getNotificationCountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getNotificationCountService.makeRequest());
};
