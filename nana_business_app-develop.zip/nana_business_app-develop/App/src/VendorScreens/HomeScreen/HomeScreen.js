import React, { Component } from 'react';
import { Text, View, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PropTypes from 'prop-types';
import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import { fetchPendingRequestsData, splitOrganizationLength, ninePlus } from '@Constants/Constants';
import Loader from '@Loader/Loader';
import { getFormattedDateWithoutYear } from '@Util/GetFormattedDate';
import vendorNavigations from '@routes/vendorNavigations';
import { getNoOfDays } from '@Util/GetNoOfDays';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import PendingRequestComponent from '@Components/PendingRequestComponent';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { createStyleSheet } from './HomeScreenStyle';
import * as HomeScreenActions from './HomeScreenAction';

class HomeScreen extends Component {
	constructor(props) {
		super(props);
		this.state = { activeBranchIndex: null };
	}

	componentDidMount() {
		this.onStoreUserDetails();
		const { pullToRefreshActions, navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onCallApis();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { homeScreenInfo, pullToRefreshActions } = this.props;
		const { success } = homeScreenInfo;
		if (success && prevProps.homeScreenInfo.success !== homeScreenInfo.success) {
			// if homescreen api return success
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onStoreUserDetails = async () => {
		const { homeScreenActions } = this.props;
		const userDetails = await AsyncStorage.getItem('user_details');
		homeScreenActions.onStoreUserDetails(JSON.parse(userDetails));
	};

	onCallApis = () => {
		this.onGetInvoices();
		this.onGetNotificationCount();
		this.onGetPendingRequests();
		this.onGetInvoiceData();
	};

	onGetInvoices = () => {
		// Call api to get pending invoices
		const { homeScreenActions, homeScreenInfo } = this.props;
		const { branchListing } = homeScreenInfo;
		const { activeBranchIndex } = this.state;
		const queryParams = {};
		queryParams.limit = 2;
		queryParams.page = 1;
		queryParams.id =
			activeBranchIndex !== null
				? branchListing &&
				  branchListing[activeBranchIndex] &&
				  branchListing[activeBranchIndex].id
				: 'None';
		homeScreenActions.onGetPendingInvoices(queryParams);
	};

	onGetNotificationCount = () => {
		// Call api to get notification count
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetNotificationCount();
	};

	viewAllInvoices = () => {
		// Navigate to my invoices screen
		const { navigation } = this.props;
		navigation.navigate(vendorNavigations.MY_INVOICES_NAVIGATION);
	};

	onGetPendingRequests = () => {
		// Call api to get pending request
		const { homeScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = fetchPendingRequestsData.limit;
		queryParams.page = fetchPendingRequestsData.page;
		homeScreenActions.onGetPendingRequests(queryParams);
	};

	viewAllPendingRequests = () => {
		// Navigate to my pending request screen
		const { navigation } = this.props;
		navigation.navigate(vendorNavigations.PENDING_REQUESTS_NAVIGATION);
	};

	onGetInvoiceData = () => {
		// Call api to get invoices
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetInvoiceData();
	};

	onGetDetail = (id, headerTitle, ownerName) => {
		const { navigation } = this.props;
		navigation.navigate(vendorNavigations.INVOICE_DETAIL_NAVIGATION, {
			id,
			headerTitle,
			ownerName,
			isPayNowButton: false,
		});
	};

	getInvoiceTotalAmount = (pendingAmount, acceptedAmount, rejectedAmount) => {
		return getValueInDecimal(pendingAmount + acceptedAmount + rejectedAmount);
	};

	onPressNotification = () => {
		const { homeScreenInfo, navigation } = this.props;
		const { notificationCount } = homeScreenInfo;
		navigation.navigate(vendorNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	onRefresh = () => {
		this.onCallApis();
	};

	render() {
		const { languageInfo, homeScreenInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			loader,
			invoicesList,
			userDetails,
			pendingRequestsList,
			invoiceData,
			notificationCount,
			error,
			errorCode,
			isVendorInvoice,
			isPendingRequest,
		} = homeScreenInfo;
		const { pending_collection, accepted_collection, rejected_collection } = invoiceData || {};
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && <Loader size="large" />}
				<View style={styles.header}>
					<View style={styles.locationView}>
						<ImageLoadComponent source={IMAGES.iconPin} style={styles.iconPin} />
						<Text style={styles.dropdownText}>
							{userDetails &&
								userDetails.user &&
								userDetails.user.organization &&
								userDetails.user.organization.name &&
								(userDetails.user.organization.name.length > splitOrganizationLength
									? `${userDetails.user.organization.name
											.split('', splitOrganizationLength)
											.join('')}...`
									: userDetails.user.organization.name)}
						</Text>
					</View>
					<TouchableOpacity activeOpacity={0.8} onPress={this.onPressNotification}>
						<ImageLoadComponent
							source={IMAGES.iconNotification}
							style={styles.iconNotification}
						/>
						{notificationCount !== 0 && (
							<View style={styles.notificationContainerStyle}>
								<Text style={styles.notificationCountStyle}>
									{notificationCount > 9 ? ninePlus : notificationCount}
								</Text>
							</View>
						)}
					</TouchableOpacity>
				</View>
				<ScrollViewComponent
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					onRefresh={this.onRefresh}
					componentType={constants.scrollView}>
					{error && !isVendorInvoice && !isPendingRequest ? (
						<ErrorComponent // Error component if api fails.
							isRTL={isRTL}
							errorCode={errorCode}
							onCallApi={this.onGetInvoiceData}
							isSectionComponent
						/>
					) : (
						invoiceData && (
							<>
								<View style={styles.invoiceView}>
									<Text style={styles.totalText}>
										{localeString(keyConstants.TOTAL_INVOICES_AMOUNT)}
									</Text>
									<Text style={styles.amountText}>
										{`${currencyFormatter(
											this.getInvoiceTotalAmount(
												pending_collection[0],
												accepted_collection[0],
												rejected_collection[0],
											),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
								</View>
								<View style={styles.card}>
									<View style={styles.amountContainer}>
										<View style={styles.dueVendorAmountView}>
											<Text style={styles.dueVendorText}>
												{`${localeString(
													keyConstants.PENDING_AMOUNT,
												)} ${currencyFormatter(
													getValueInDecimal(pending_collection[0]),
												)}`}
											</Text>
										</View>
									</View>
									<View style={styles.progressBar}>
										<View
											style={[
												styles.rejectedVendorAmount,
												{
													width: `${
														(getValueInDecimal(rejected_collection[0]) /
															this.getInvoiceTotalAmount(
																pending_collection[0],
																accepted_collection[0],
																rejected_collection[0],
															)) *
														100
													}%`,
												},
											]}
										/>
										<View
											style={[
												styles.pendingAmount,
												{
													width: `${
														(getValueInDecimal(pending_collection[0]) /
															this.getInvoiceTotalAmount(
																pending_collection[0],
																accepted_collection[0],
																rejected_collection[0],
															)) *
														100
													}%`,
												},
											]}
										/>
									</View>
									<View style={styles.detailView}>
										<View>
											<Text style={styles.rejectedText}>
												{localeString(keyConstants.REJECTED)}
											</Text>
											<Text style={styles.rejectedAmountStyle}>
												{`${currencyFormatter(
													getValueInDecimal(rejected_collection[0]),
												)} ${localeString(keyConstants.SAR)}`}
											</Text>
										</View>
										<View>
											<Text style={styles.text}>
												{localeString(keyConstants.APPROVED)}
											</Text>
											<Text style={styles.amountTextStyle}>
												{`${currencyFormatter(
													getValueInDecimal(accepted_collection[0]),
												)} ${localeString(keyConstants.SAR)}`}
											</Text>
										</View>
									</View>
								</View>
							</>
						)
					)}
					{error && isVendorInvoice ? (
						<ErrorComponent // Error component if vendor invoices api fails.
							isRTL={isRTL}
							errorCode={errorCode}
							onCallApi={this.onGetInvoices}
							isSectionComponent
						/>
					) : (
						invoicesList.length !== 0 && (
							<>
								<View style={styles.pendingTextView}>
									<Text style={styles.pendingText}>
										{localeString(keyConstants.PENDING_CRS)}
									</Text>
									<TouchableOpacity
										activeOpacity={0.8}
										onPress={this.viewAllInvoices}>
										<Text style={styles.viewVendorInvoices}>
											{localeString(keyConstants.VIEW_ALL)}
										</Text>
									</TouchableOpacity>
								</View>
								{invoicesList.map(item => {
									return (
										<InvoiceCardComponent
											name={item.vendor_org_name}
											invoiceId={`(${item.invoice_no})`}
											date={`${getFormattedDateWithoutYear(
												item.created_at,
											)} + ${getNoOfDays(
												item.created_at,
												item.due,
											)} ${localeString(keyConstants.DAYS)}`}
											amount={`${currencyFormatter(
												getValueInDecimal(item.invoice_total),
											)} ${localeString(keyConstants.SAR)}`}
											isShowStatus
											status={item.status}
											isDisable={false}
											onPress={() =>
												this.onGetDetail(
													item.id,
													`${item.vendor_org_name} (${item.invoice_no})`,
													item.owner_name,
												)
											}
										/>
									);
								})}
							</>
						)
					)}
					{error && isPendingRequest ? (
						<ErrorComponent // Error component if pending requests api fails.
							isRTL={isRTL}
							errorCode={errorCode}
							onCallApi={this.onGetPendingRequests}
							isSectionComponent
						/>
					) : (
						pendingRequestsList.length !== 0 && (
							<PendingRequestComponent
								isRTL={isRTL}
								pendingRequestsList={pendingRequestsList}
								viewAllPendingRequests={this.viewAllPendingRequests}
							/>
						)
					)}
				</ScrollViewComponent>
			</View>
		);
	}
}

HomeScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	pullToRefreshActions: PropTypes.func.isRequired,
	homeScreenActions: PropTypes.func.isRequired,
	homeScreenInfo: PropTypes.func.isRequired,
	languageInfo: PropTypes.func.isRequired,
	refreshControlComponentInfo: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		homeScreenInfo: state.VendorHomeScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen);
