import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		customerView: {
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			borderBottomWidth: verticalScale(1),
			borderColor: colors.greenShadow,
			paddingVertical: verticalScale(12),
			marginHorizontal: normalScale(16),
		},
		imageView: {
			height: normalScale(36),
			width: normalScale(36),
			borderRadius: normalScale(18),
		},
		image: {
			height: normalScale(36),
			width: normalScale(36),
			borderRadius: normalScale(18),
		},
		detailsView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			flex: 1,
		},
		name: {
			width: normalScale(140),
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		distance: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
			marginTop: verticalScale(6),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		amount: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		pendingView: {
			height: normalScale(18),
			width: normalScale(18),
			borderRadius: normalScale(9),
			backgroundColor: colors.red,
			alignSelf: isRTL ? 'flex-start' : 'flex-end',
			marginTop: verticalScale(4),
			justifyContent: 'center',
			alignItems: 'center',
		},
		count: {
			color: colors.white,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginTop: verticalScale(8),
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(5),
		},
		searchContainer: {
			marginBottom: verticalScale(5),
			marginHorizontal: normalScale(16),
		},
		listingView: {
			marginTop: verticalScale(8),
		},
		addContainer: {
			position: 'absolute',
			bottom: 0,
			right: isRTL ? null : 0,
			left: isRTL ? 0 : null,
		},
		iconAdd: {
			height: verticalScale(60),
			width: normalScale(60),
		},
		scrollViewStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
