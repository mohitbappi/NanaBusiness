import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	customerListing: [],
	count: 0,
};

const CustomerScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_RETAILERS_LISTING_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				customerListing: isOverwriteExistingList
					? [...state.customerListing, ...action.payload.organizations]
					: action.payload.organizations,
				count: parseInt(action.payload.count, 10),
			};
		}
		case ActionTypes.GET_RETAILERS_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_RETAILERS_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default CustomerScreenReducer;
