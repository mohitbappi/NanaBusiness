export const GET_RETAILERS_LISTING_SUCCESS = 'get_retailers_listing_success';
export const GET_RETAILERS_LISTING_FAILURE = 'get_retailers_listing_failure';
export const GET_RETAILERS_LISTING_LOADER = 'get_retailers_listing_loader';
