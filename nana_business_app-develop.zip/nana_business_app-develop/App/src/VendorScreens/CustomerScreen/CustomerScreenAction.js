import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetAllCustomersService from '@CustomerVendorServices/GetAllCustomersService';
import GetCustomersService from '@Customer/GetCustomersService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to get customer listing
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetAllCustomers = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_RETAILERS_LISTING_SUCCESS,
		ActionTypes.GET_RETAILERS_LISTING_FAILURE,
		ActionTypes.GET_RETAILERS_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getAllCustomersService = new GetAllCustomersService(dispatchedActions);
	addBasicInterceptors(getAllCustomersService);
	getAllCustomersService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getAllCustomersService.makeRequest(props));
};

/**
 * Action to get customer listing for collector
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetAllCollectorCustomers = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_RETAILERS_LISTING_SUCCESS,
		ActionTypes.GET_RETAILERS_LISTING_FAILURE,
		ActionTypes.GET_RETAILERS_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getCustomersService = new GetCustomersService(dispatchedActions);
	addBasicInterceptors(getCustomersService);
	getCustomersService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCustomersService.makeRequest(props));
};
