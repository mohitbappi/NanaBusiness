import React, { Component } from 'react';
import { Text, View, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import {
	fetchDataWithPagination,
	mi,
	collector,
	collectorLatitude,
	collectorLongitude,
	IMAGE_TYPE,
	driver,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import vendorNavigations from '@routes/vendorNavigations';
import { getDistanceInMiles } from '@Util/GetDistanceInMiles';
import collectorNavigations from '@routes/collectorNavigations';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import Search from '@Search/Search';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { verticalScale } from '@device/normalize';
import { getScrollingIndex, getPage } from '@Util/GetScrollingIndex';
import * as CustomerScreenActions from './CustomerScreenAction';
import { createStyleSheet } from './CustomerScreenStyle';

class CustomerScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.pageCustomer = fetchDataWithPagination.page;
		this.state = {
			searchCustomerText: '',
			bottomLoader: false,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { pullToRefreshActions, refreshControlComponentInfo } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.limit = getScrollingIndex(scrollIndex);
			this.pageCustomer = fetchDataWithPagination.page;
			this.setState(
				{
					searchCustomerText: '',
				},
				() => this.onLoadMore(false),
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
		this.willFocusListener = navigation.addListener('blur', () => {
			this.onSetIndexTo();
		});
	}

	componentDidUpdate(prevProps) {
		const { customerInfo, pullToRefreshActions } = this.props;
		const { success } = customerInfo;
		if (success && prevProps.customerInfo.success !== customerInfo.success) {
			// if customer detail api return success
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.pageCustomer === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onSetIndexTo = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	onFetchData = isOverwriteExistingList => {
		// Call api to get customer listing
		const { userDetails, customerScreenActions } = this.props;
		const { latitude, longitude } = userDetails.user.organization || {};
		const { role, roles } = userDetails.user;
		const queryParams = {};
		const { searchCustomerText } = this.state;
		queryParams.limit = this.limit;
		queryParams.page = this.pageCustomer;
		queryParams.lat = roles.includes(collector) ? collectorLatitude : latitude;
		queryParams.lon =
			roles.includes(collector) || role === driver ? collectorLongitude : longitude;
		if (searchCustomerText) {
			queryParams.organization = searchCustomerText;
		}
		if (roles.includes(collector)) {
			// if user is collector or driver.
			customerScreenActions.onGetAllCollectorCustomers(queryParams, isOverwriteExistingList);
		} else {
			// if user is vendor
			customerScreenActions.onGetAllCustomers(queryParams, isOverwriteExistingList);
		}
	};

	onGoToCustomerListing = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onSearch = text => {
		this.pageCustomer = fetchDataWithPagination.page;
		this.setState(
			{
				searchCustomerText: text,
			},
			() => {
				this.onLoadMore(false);
			},
		);
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponentCustomer = () => {
		const { languageInfo, customerInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { customerListing, count } = customerInfo;
		const endReached = count === customerListing.length || count < customerListing.length;
		if (!endReached) {
			return <Loader size="small" isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReachedCustomer = () => {
		const { customerInfo } = this.props;
		const { loader } = customerInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.pageCustomer += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onLoadMore(true);
		}
	};

	getLayout = (data, index) => ({
		// Will Calculate the Length and offset of container for ScrollToInsex Functionality
		length: verticalScale(55),
		offset: verticalScale(55) * index,
		index,
	});

	renderItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				style={styles.customerView}
				onPress={() =>
					this.getRetailerDetail(item.id, index, item.images && item.images.medium)
				}>
				<View style={styles.imageView}>
					<ImageLoadComponent
						imageType={IMAGE_TYPE.account}
						isUrl={item.images}
						source={
							item.images && item.images['x-small']
								? item.images['x-small']
								: IMAGES.iconProfileDefault
						}
						style={styles.image}
					/>
				</View>
				<View style={styles.detailsView}>
					<View>
						<Text style={styles.name} numberOfLines={2} ellipsizeMode="tail">
							{item.name}
						</Text>
						{item.distance !== null && (
							<Text style={styles.distance}>
								{`${getDistanceInMiles(item.distance)} ${mi}`}
							</Text>
						)}
					</View>
					<View>
						<Text style={styles.amount}>
							{`${currencyFormatter(
								getValueInDecimal(item.invoice_total),
							)} ${localeString(keyConstants.SAR)}`}
						</Text>
						{item.due_invoices > 0 && (
							<View style={styles.pendingView}>
								<Text style={styles.count}>
									{item.due_invoices > 9 ? '9+' : item.due_invoices}
								</Text>
							</View>
						)}
					</View>
				</View>
			</TouchableOpacity>
		);
	};

	getRetailerDetail = (id, index, image_url) => {
		// Navigate to customer detail screen
		const { userDetails, navigation } = this.props;
		const { roles } = userDetails.user;
		if (roles.includes(collector)) {
			// if user is collector
			navigation.navigate(collectorNavigations.RETAILER_DETAIL_NAVIGATION, {
				id,
				index,
				image_url,
			});
		} else {
			// if user is vendor
			navigation.navigate(vendorNavigations.REATILER_DETAIL_NAVIGATION, {
				id,
				index,
				image_url,
			});
		}
	};

	onAddRetailer = () => {
		const { userDetails, navigation } = this.props;
		// Navigate to add customer screen
		const { roles } = userDetails.user;
		if (roles.includes(collector)) {
			// if user is collector
			navigation.navigate(collectorNavigations.SELECT_LOCATION_NAVIGATION);
		} else {
			// if user is vendor
			navigation.navigate(vendorNavigations.SELECT_LOCATION_NAVIGATION);
		}
	};

	onRefresh = () => {
		// Refresh customer listing
		this.onSetIndexTo();
		this.limit = fetchDataWithPagination.limit;
		this.pageCustomer = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	render() {
		const { languageInfo, customerInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { bottomLoader, searchCustomerText } = this.state;
		const { loader, customerListing, count, error, errorCode } = customerInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader &&
					!isFetchingForPullToRefresh &&
					!bottomLoader &&
					searchCustomerText === '' && <Loader size="large" />}
				<View style={styles.header}>
					<Header
						text={localeString(keyConstants.CUSTOMER)}
						hasIconLocation
						hasIconCustomer
						onPressLocation={this.onGoToCustomerListing}
					/>
				</View>
				<View style={styles.searchContainer}>
					<Search
						hasSearchIcon
						placeholder={localeString(keyConstants.SEARCH_BY_CUSTOMER)}
						onChangeText={text => this.onSearch(text)}
						value={searchCustomerText}
					/>
				</View>
				{error ? (
					<ErrorComponent // Error component if api fails.
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<>
						<FlatListComponent
							data={customerListing}
							renderItem={this.renderItem}
							keyExtractor={this.keyExtractor}
							showsVerticalScrollIndicator={false}
							onEndReached={() =>
								customerListing.length !== count && this.onEndReachedCustomer()
							}
							ListFooterComponent={
								customerListing.length !== 0 &&
								count > fetchDataWithPagination.limit &&
								this.listFooterComponentCustomer()
							}
							onEndReachedThreshold={0.5}
							ListEmptyComponent={() => (
								<ListEmpty text={localeString(keyConstants.NO_CUSTOMERS_FOUND)} />
							)}
							contentContainerStyle={
								customerListing.length === 0 ? styles.scrollViewStyle : null
							}
							onRefresh={this.onRefresh}
							componentType={constants.flatList}
							onRef={ref => {
								this.itemListRef = ref;
							}}
							getItemLayout={this.getLayout}
						/>
						<TouchableOpacity
							onPress={this.onAddRetailer}
							style={styles.addContainer}
							activeOpacity={1}>
							<ImageLoadComponent
								source={IMAGES.iconAddYellow}
								style={styles.iconAdd}
							/>
						</TouchableOpacity>
					</>
				)}
			</View>
		);
	}
}

CustomerScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	pullToRefreshActions: PropTypes.func.isRequired,
	customerInfo: PropTypes.func.isRequired,
	userDetails: PropTypes.object.isRequired,
	customerScreenActions: PropTypes.func.isRequired,
	languageInfo: PropTypes.func.isRequired,
	isRTL: PropTypes.bool.isRequired,
	refreshControlComponentInfo: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		customerInfo: state.CustomerScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		customerScreenActions: bindActionCreators({ ...CustomerScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(CustomerScreen);
