import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import { normalScale, verticalScale, moderateScale } from '@device/normalize';

// Used for AddNewRetailer and AddNewBranch screens.
export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			paddingBottom: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: verticalScale(1),
		},
		scrollView: {
			paddingHorizontal: normalScale(16),
			paddingBottom: verticalScale(70),
		},
		signUpFinalMapView: {
			marginTop: verticalScale(24),
		},
		textStyle: {
			color: colors.lightWhite,
			paddingVertical: verticalScale(5),
		},
		buttonView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
		buttonContainerBack: {
			flex: 1,
			marginEnd: normalScale(8),
		},
		buttonContainerSubmit: {
			flex: 1,
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		backButton: {
			backgroundColor: colors.white,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(36),
			justifyContent: 'center',
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
		},
		backText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
		},
	});
};

export default createStyleSheet;
