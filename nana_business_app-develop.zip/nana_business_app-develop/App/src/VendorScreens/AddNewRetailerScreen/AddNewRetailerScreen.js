import React, { Component } from 'react';
import { View, ScrollView, Keyboard } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import Input from '@Input/Input';
import Spinner from '@Spinner/Spinner';
import { normalScale } from '@device/normalize';
import {
	toastShowTime,
	numericRegexExp,
	mobileNumberLength,
	emailRegexEx,
	collector,
	customMobileRegex,
	vendor,
	noSpaceAtStartRegexEx,
	noSpaceAtStartRegexExArabic,
	numericalRegexExp,
	crNumberRegex,
	crNumberLength,
} from '@Constants/Constants';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import vendorNavigations from '@routes/vendorNavigations';
import ToastComponent from '@ToastComponent/ToastComponent';
import collectorNavigations from '@routes/collectorNavigations';
import SmallMapComponent from '@Components/SmallMapComponent';
import { businessTypeConstants } from '@SignUpNextScreen/SignUpConstants';
import { constants } from '@EditProfileScreen/Constant';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import { checkStringWith } from '@Util/CheckStringWith';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import * as PersonalInfoScreenActions from '@PersonalInformationScreen/PersonalInformationScreenAction';
import * as AddRetailerActions from './AddNewRetailerScreenAction';
import { createStyleSheet } from './AddNewRetailerScreenStyle';

class AddNewRetailerScreen extends Component {
	constructor(props) {
		super(props);
		const { userDetails } = props;
		this.name = React.createRef(null);
		this.companyName = React.createRef(null);
		this.mobileNumber = React.createRef(null);
		this.alternateMobileNumber = React.createRef(null);
		this.emailAddress = React.createRef(null);
		this.crNumber = React.createRef(null);
		this.role = userDetails.user.role;
		this.roles = userDetails?.user.roles;
		this.state = {
			errorValidationMessage: false,
			errorEmailValidationMessage: false,
			isApiError: false,
			toastMessage: '',
			errorMobileValidationMessage: false,
			mobileErrorMessage: '',
			businessTypeSelectedIndex: null,
			isDropdownVisible: false,
			isCrNumberFocused: false,
			isErrorCRNumber: false,
			crErrorMessage: '',
		};
	}

	componentDidUpdate(prevProps) {
		const { addRetailerInfo, addRetailerActions, personalInfo } = this.props;
		const {
			success,
			mobileNumber,
			emailAddress,
			error,
			errorCode,
			alternateMobileNumber,
			companyRegNumber,
		} = addRetailerInfo;
		const { success: personalInfoSuccess } = personalInfo;
		const errorArray = [
			keyConstants.ACCOUNT_EXIST,
			keyConstants.MOBILE_SAME,
			keyConstants.PENDING_APPROVED_MODE,
			keyConstants.DUPLICATE_NAME,
		];
		if (success && prevProps.addRetailerInfo.success !== addRetailerInfo.success) {
			// if add new retailer return success
			addRetailerActions.onResetRetailerData();
			this.onGoToCustomerList();
		}
		if (error && prevProps.addRetailerInfo.error !== addRetailerInfo.error) {
			if (errorArray.includes(errorCode && errorCode.error)) {
				// Will show toast if api error occurs.
				this.setState({
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				// Will show alert if api fails.
				ErrorAlertComponent(errorCode, this.onAddCustomer);
			}
		}
		if (prevProps.addRetailerInfo !== addRetailerInfo) {
			// Error validation in add retailer screen fields
			if (customMobileRegex.test(mobileNumber)) {
				this.setState({
					errorValidationMessage: false,
				});
			}
			if (
				customMobileRegex.test(alternateMobileNumber) ||
				alternateMobileNumber === '' ||
				mobileNumber !== alternateMobileNumber
			) {
				this.setState({
					errorMobileValidationMessage: false,
					mobileErrorMessage: '',
				});
			}
			if (emailRegexEx.test(String(emailAddress).toLowerCase())) {
				this.setState({
					errorEmailValidationMessage: false,
				});
			}
			if (crNumberRegex.test(companyRegNumber)) {
				// if entered company registeration number is invalid
				this.setState({
					isErrorCRNumber: false,
					crErrorMessage: '',
				});
			}
		}
		if (personalInfoSuccess && prevProps.personalInfo.success !== personalInfoSuccess) {
			this.setState({
				isErrorCRNumber: true,
				crErrorMessage: localeString(keyConstants.CR_ERROR_MESSAGE),
			});
		}
	}

	onGoBack = () => {
		const { addRetailerActions, navigation } = this.props;
		addRetailerActions.onResetRetailerData();
		navigation.goBack();
	};

	onGoToCustomerList = () => {
		const { userDetails, navigation } = this.props;
		const { role } = userDetails.user;
		if (role === vendor) {
			navigation.navigate(vendorNavigations.CUSTOMER_LISTING_NAVIGATION);
		} else {
			navigation.navigate(collectorNavigations.CUSTOMER_LISTING_NAVIGATION);
		}
	};

	onChangeText = (text, field) => {
		const { addRetailerActions } = this.props;
		addRetailerActions.onChangeText(text, field);
	};

	onSelectLocation = () => {
		const { navigation } = this.props;
		if (this.roles.includes(collector)) {
			navigation.navigate(collectorNavigations.SELECT_LOCATION_NAVIGATION);
		} else {
			navigation.navigate(vendorNavigations.SELECT_LOCATION_NAVIGATION);
		}
	};

	onCloseDropdown = () => {
		this.setState({
			isDropdownVisible: false,
		});
	};

	onSelectOption = index => {
		const { addRetailerActions } = this.props;
		this.onCloseDropdown();
		this.setState(
			{
				businessTypeSelectedIndex: index,
			},
			() => {
				addRetailerActions.onChangeText(
					businessTypeConstants[index].key,
					constants.businessType,
				);
			},
		);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onPressDropdown = () => {
		this.onDissmissKeyboard();
		this.setState({
			isDropdownVisible: true,
		});
	};

	onAddCustomer = () => {
		// Call api to add new customer
		const { addRetailerInfo, route, userDetails, addRetailerActions } = this.props;
		const {
			addressLine1,
			addressLine2,
			name,
			companyName,
			mobileNumber,
			emailAddress,
			alternateMobileNumber,
			businessType,
			companyRegNumber,
		} = addRetailerInfo;
		const { region } = route.params ? route.params : {};
		const { id } = userDetails.user;
		const { isCrNumberFocused } = this.state;
		this.onDissmissKeyboard();
		if (isCrNumberFocused) {
			this.onBlur('companyRegNumber');
			return;
		}
		const retailerDetails = {
			name,
			orgName: companyName,
			mobile: mobileNumber,
			email_address: emailAddress,
			address_one: addressLine1,
			latitude: region.latitude,
			longitude: region.longitude,
			account_requested_by: id,
			terms_and_condition: true,
			mobile_secondary: alternateMobileNumber,
			business_type: businessType,
			cr: companyRegNumber,
		};
		if (addressLine2) {
			retailerDetails.address_two = addressLine2;
		}
		addRetailerActions.onAddNewRetailer(retailerDetails);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const textInput = textInputRef;
		textInput.current = node;
	};

	onFocus = () => {
		this.setState({
			isCrNumberFocused: true,
		});
	};

	onBlur = type => {
		const { addRetailerInfo } = this.props;
		const {
			mobileNumber,
			emailAddress,
			alternateMobileNumber,
			companyRegNumber,
		} = addRetailerInfo;
		if (type === 'mobileNumber' && !customMobileRegex.test(mobileNumber)) {
			this.setState({
				errorValidationMessage: true,
			});
		}
		if (type === 'alternateMobileNumber') {
			if (!customMobileRegex.test(alternateMobileNumber) && alternateMobileNumber !== '') {
				this.setState({
					errorMobileValidationMessage: true,
					mobileErrorMessage: localeString(keyConstants.MOBILE_NUMBER_VALIDATION_MESSAGE),
				});
			}
			if (mobileNumber === alternateMobileNumber) {
				this.setState({
					errorMobileValidationMessage: true,
					mobileErrorMessage: localeString(keyConstants.MOBILE_SAME),
				});
			}
		}
		if (type === 'emailAddress' && !emailRegexEx.test(String(emailAddress).toLowerCase())) {
			this.setState({
				errorEmailValidationMessage: true,
			});
		}
		if (type === 'companyRegNumber') {
			// Will check cr number validation.
			this.setState({
				isCrNumberFocused: false,
			});
			if (!crNumberRegex.test(String(companyRegNumber).toLowerCase())) {
				this.setState({
					isErrorCRNumber: true,
					crErrorMessage: localeString(keyConstants.MUST_BE_TEN_DIGITS),
				});
			} else {
				this.onGetCompanyDetails();
			}
		}
	};

	onGetCompanyDetails = () => {
		// Function to call API to check cr exists or not.
		const { addRetailerInfo, personalInfoScreenActions } = this.props;
		const { companyRegNumber } = addRetailerInfo;
		const crNumberData = {
			crNumber: companyRegNumber,
		};
		personalInfoScreenActions.onGetCompany(crNumberData);
	};

	render() {
		const { languageInfo, route, addRetailerInfo, personalInfo } = this.props;
		const { isRTL } = languageInfo;
		const {
			errorValidationMessage,
			errorEmailValidationMessage,
			isApiError,
			toastMessage,
			errorMobileValidationMessage,
			mobileErrorMessage,
			businessTypeSelectedIndex,
			isDropdownVisible,
			isErrorCRNumber,
			crErrorMessage,
		} = this.state;
		const styles = createStyleSheet(isRTL);
		const {
			loader,
			addressLine1,
			addressLine2,
			name,
			companyName,
			mobileNumber,
			emailAddress,
			alternateMobileNumber,
			companyRegNumber,
		} = addRetailerInfo;
		const { loader: personalInfoLoader } = personalInfo;
		const { region } = route.params ? route.params : {};
		return (
			<KeyboardAwareScrollView
				keyboardShouldPersistTaps="handled"
				contentContainerStyle={styles.container}>
				{(loader || personalInfoLoader) && <Spinner size="large" />}
				<OptionPicker
					title={localeString(keyConstants.SELECT_BUSINESS_TYPE)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={businessTypeConstants}
					provideLanguageSupport
					onClose={this.onCloseDropdown}
					onSelectOption={index => this.onSelectOption(index)}
					activeIndex={businessTypeSelectedIndex}
				/>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.ADD_NEW_CUSTOMER)}
						hasIconClose
						onPressClose={this.onGoBack}
						hasIconCustomer
					/>
				</View>
				<ScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					keyboardShouldPersistTaps="handled">
					<SmallMapComponent
						region={region}
						isRTL={isRTL}
						addressLine1={addressLine1}
						addressLine2={addressLine2}
						onSelectLocation={this.onSelectLocation}
						onChangeText={this.onChangeText}
						nameRef={this.name}
						onSubmitRef={this.onSubmitRef}
					/>
					<Input
						value={name}
						width={normalScale(288)}
						label={`${localeString(keyConstants.NAME)}*`}
						placeholder={localeString(keyConstants.YOUR_FULL_NAME)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => this.onChangeText(text, 'name')}
						onSubmitEditing={() => this.onSubmitRef(this.crNumber)}
						autoCapitalize="none"
						refs={this.refCallback(this.name)}
					/>
					<Input
						value={companyRegNumber}
						width={normalScale(288)}
						label={`${localeString(keyConstants.COMPANY_REG_NUMBER)}*`}
						placeholder={localeString(keyConstants.COMPANY_REG_NUMBER)}
						blurOnSubmit
						returnKeyType="done"
						isRTL={isRTL}
						onChangeText={text =>
							(numericalRegexExp.test(String(text).toLocaleLowerCase()) ||
								text === '') &&
							this.onChangeText(text, 'companyRegNumber')
						}
						onSubmitEditing={() => this.onSubmitRef(this.companyName)}
						refs={this.refCallback(this.crNumber)}
						autoCapitalize="none"
						maxLength={crNumberLength}
						keyboardType="number-pad"
						isError={isErrorCRNumber}
						errorMessage={crErrorMessage}
						onFocus={this.onFocus}
						onBlur={() => this.onBlur('companyRegNumber')}
					/>
					<Input
						value={companyName}
						width={normalScale(288)}
						label={`${localeString(keyConstants.COMPANY_NAME)}*`}
						placeholder={localeString(keyConstants.YOUR_COMPANY_NAME)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text =>
							(checkStringWith(
								String(text).toLocaleLowerCase(),
								noSpaceAtStartRegexEx,
								noSpaceAtStartRegexExArabic,
								isRTL,
							) ||
								text === '') &&
							this.onChangeText(text, 'companyName')
						}
						refs={this.refCallback(this.companyName)}
						onSubmitEditing={() => this.onSubmitRef(this.mobileNumber)}
						autoCapitalize="none"
					/>
					<DropdownFieldComponent
						isRTL={isRTL}
						onPress={this.onPressDropdown}
						value={
							businessTypeSelectedIndex !== null
								? localeString(
										businessTypeConstants[businessTypeSelectedIndex].name,
								  )
								: ''
						}
						label={`${localeString(keyConstants.BUSINESS_TYPE)}*`}
						placeholder={`${localeString(keyConstants.BUSINESS_TYPE)}`}
					/>
					<Input
						maxLength={mobileNumberLength}
						value={mobileNumber}
						width={normalScale(288)}
						label={`${localeString(keyConstants.MOBILE_NUMBER)}*`}
						placeholder={localeString(keyConstants.MOBILE_NUMBER_PLACEHOLDER)}
						blurOnSubmit={false}
						returnKeyType="done"
						keyboardType="number-pad"
						isRTL={isRTL}
						onChangeText={text =>
							(numericRegexExp.test(String(text).toLowerCase()) || text === '') &&
							this.onChangeText(text, 'mobileNumber')
						}
						autoCapitalize="none"
						refs={this.refCallback(this.mobileNumber)}
						onBlur={() => this.onBlur('mobileNumber')}
						onSubmitEditing={() => this.onSubmitRef(this.alternateMobileNumber)}
						isError={errorValidationMessage}
						errorMessage={localeString(keyConstants.PHONE_NUMBER_VALIDATION_MESSAGE)}
						hasMobilePrefix
					/>
					<Input
						maxLength={mobileNumberLength}
						value={alternateMobileNumber}
						width={normalScale(288)}
						label={`${localeString(keyConstants.ALTERNATE_MOBILE_NUMBER)}`}
						placeholder={localeString(keyConstants.MOBILE_NUMBER_PLACEHOLDER)}
						blurOnSubmit={false}
						returnKeyType="done"
						keyboardType="number-pad"
						isRTL={isRTL}
						onChangeText={text =>
							(numericRegexExp.test(String(text).toLowerCase()) || text === '') &&
							this.onChangeText(text, 'alternateMobileNumber')
						}
						autoCapitalize="none"
						refs={this.refCallback(this.alternateMobileNumber)}
						onBlur={() => this.onBlur('alternateMobileNumber')}
						onSubmitEditing={() => this.onSubmitRef(this.emailAddress)}
						isError={errorMobileValidationMessage}
						errorMessage={mobileErrorMessage}
						hasMobilePrefix
					/>
					<Input
						value={emailAddress}
						width={normalScale(288)}
						label={`${localeString(keyConstants.EMAIL_ADDRESS)}*`}
						placeholder={localeString(keyConstants.ABC_EMAIL)}
						returnKeyType="done"
						isRTL={isRTL}
						onChangeText={text => this.onChangeText(text, 'emailAddress')}
						autoCapitalize="none"
						blurOnSubmit
						refs={this.refCallback(this.emailAddress)}
						onBlur={() => this.onBlur('emailAddress')}
						isError={errorEmailValidationMessage}
						errorMessage={localeString(keyConstants.EMAIL_VALIDATION_MESSAGE)}
						keyboardType="email-address"
					/>
				</ScrollView>
				<View style={styles.buttonView}>
					<View style={styles.buttonContainerBack}>
						<ButtonComponent
							buttonStyle={styles.backButton}
							text={localeString(keyConstants.BACK)}
							textStyle={styles.backText}
							onPress={this.onGoBack}
						/>
					</View>
					<View style={styles.buttonContainerSubmit}>
						<ButtonComponent
							text={localeString(keyConstants.ADD_CUSTOMER)}
							onPress={this.onAddCustomer}
							isButtonDisable={
								!(
									addressLine1 &&
									name &&
									companyName &&
									customMobileRegex.test(mobileNumber) &&
									emailAddress &&
									businessTypeSelectedIndex !== null &&
									!isErrorCRNumber &&
									companyRegNumber
								)
							}
						/>
					</View>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

AddNewRetailerScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	addRetailerActions: PropTypes.func.isRequired,
	personalInfoScreenActions: PropTypes.func.isRequired,
	addRetailerInfo: PropTypes.func.isRequired,
	userDetails: PropTypes.object.isRequired,
	languageInfo: PropTypes.func.isRequired,
	route: PropTypes.func.isRequired,
	personalInfo: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		addRetailerInfo: state.AddNewRetailerScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		personalInfo: state.PersonalInformationScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		addRetailerActions: bindActionCreators({ ...AddRetailerActions }, dispatch),
		personalInfoScreenActions: bindActionCreators({ ...PersonalInfoScreenActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(AddNewRetailerScreen);
