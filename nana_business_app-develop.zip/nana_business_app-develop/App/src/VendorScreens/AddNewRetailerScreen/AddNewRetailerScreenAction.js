import { actions } from '@libapi/APIActionsBuilder';
import AddNewCustomerService from '@CustomerVendorServices/AddNewCustomerService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to set entered inputfield text in respective values in reducer
 * @param {string} text
 * @param {string} field
 */
export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_RETAILER_TEXT,
		payload: text,
		field,
	};
};

/**
 * Action to call add new Customer api
 * @param {object} retailerDetails
 */
export const onAddNewRetailer = retailerDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ADD_NEW_RETAILER_SUCCESS,
		ActionTypes.ADD_NEW_RETAILER_FAILURE,
		ActionTypes.ADD_NEW_RETAILER_LOADER,
	);
	const addNewCustomerService = new AddNewCustomerService(dispatchedActions);
	addBasicInterceptors(addNewCustomerService);
	addNewCustomerService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(addNewCustomerService.makeRequest(retailerDetails));
};

// Action to reset add new retailer screen reducer
export const onResetRetailerData = () => ({ type: ActionTypes.RESET_RETAILER_DATA });
