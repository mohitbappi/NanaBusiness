import * as ActionTypes from './ActionType';

const initialState = {
	addressLine1: '',
	addressLine2: '',
	name: '',
	companyName: '',
	mobileNumber: '',
	alternateMobileNumber: '',
	emailAddress: '',
	businessType: '',
	companyRegNumber: '',
};

const AddNewRetailerScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_RETAILER_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.ADD_NEW_RETAILER_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
			};
		case ActionTypes.ADD_NEW_RETAILER_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.ADD_NEW_RETAILER_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_RETAILER_DATA:
			return initialState;
		default:
			return state;
	}
};

export default AddNewRetailerScreenReducer;
