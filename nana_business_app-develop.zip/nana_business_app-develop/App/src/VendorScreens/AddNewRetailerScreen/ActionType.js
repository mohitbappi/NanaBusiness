export const ON_CHANGE_RETAILER_TEXT = 'on_edit_text';
export const ADD_NEW_RETAILER_SUCCESS = 'add_new_retailer_success';
export const ADD_NEW_RETAILER_FAILURE = 'add_new_retailer_failure';
export const ADD_NEW_RETAILER_LOADER = 'add_new_retailer_loader';
export const RESET_RETAILER_DATA = 'reset_retailer_data';
