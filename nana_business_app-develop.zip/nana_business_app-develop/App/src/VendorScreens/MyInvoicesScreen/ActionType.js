export const GET_INVOICES_DATA_SUCCESS = 'get_invoices_data_success';
export const GET_INVOICES_DATA_FAILURE = 'get_invoices_data_failure';
export const GET_INVOICES_DATA_LOADER = 'get_invoices_data_loader';
