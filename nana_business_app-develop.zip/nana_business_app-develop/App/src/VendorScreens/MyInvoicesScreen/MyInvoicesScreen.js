import React, { Component } from 'react';
import { Text, View, Keyboard } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { fetchDataWithPagination } from '@Constants/Constants';
import Loader from '@Loader/Loader';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Header from '@Header/Header';
import ListEmpty from '@ListEmpty/ListEmpty';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import { getFormattedDate } from '@Util/GetFormattedDate';
import vendorNavigations from '@routes/vendorNavigations';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import Search from '@Search/Search';
import TabComponent from '@Components/TabComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import { verticalScale } from '@device/normalize';
import { getScrollingIndex, getPage } from '@Util/GetScrollingIndex';
import * as InvoicesActions from './MyInvoicesScreenAction';
import { createStyleSheet } from './MyInvoicesScreenStyle';

class MyInvoicesScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			activeTabIndex: 0,
			tabsArray: [keyConstants.ALL, keyConstants.PENDING, keyConstants.APPROVED],
			searchText: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { activeTabIndex } = this.state;
			const { pullToRefreshActions, refreshControlComponentInfo } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			this.limit = getScrollingIndex(scrollIndex);
			this.page = fetchDataWithPagination.page;
			this.setState(
				{
					searchText: '',
				},
				() => this.onLoadMore(false, activeTabIndex),
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
		this.willFocusListener = navigation.addListener('blur', () => {
			this.onSetIndexTo();
		});
	}

	componentDidUpdate(prevProps) {
		const { invoicesInfo, pullToRefreshActions } = this.props;
		const { success } = invoicesInfo;
		if (success && prevProps.invoicesInfo.success !== invoicesInfo.success) {
			// Will hide the bottom loader.
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (this.page === 1 && this.itemListRef) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onLoadMore = (isOverwriteExistingList, activeTabIndex) => {
		this.onFetchData(isOverwriteExistingList, activeTabIndex);
	};

	onSetIndexTo = () => {
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
	};

	onFetchData = (isOverwriteExistingList, activeTabIndex) => {
		// API call to get the invoices listing.
		const queryParams = {};
		const { invoicesActions } = this.props;
		const { searchText } = this.state;
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			queryParams.organization = searchText;
		}
		if (activeTabIndex === 0) {
			invoicesActions.onGetAllInvoices(queryParams, isOverwriteExistingList);
		} else if (activeTabIndex === 1) {
			invoicesActions.onGetPendingInvoices(queryParams, isOverwriteExistingList);
		} else if (activeTabIndex === 2) {
			invoicesActions.onGetApprovedInvoices(queryParams, isOverwriteExistingList);
		}
	};

	onSelectTab = index => {
		// Will swtich between tabs.
		this.onSetIndexTo();
		this.onDissmissKeyboard();
		this.setState(
			{
				activeTabIndex: index,
				searchText: '',
			},
			() => {
				this.page = 1;
				this.onLoadMore(false, index);
			},
		);
	};

	onSearch = text => {
		// Will search invoice using invoice id.
		const { activeTabIndex } = this.state;
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onLoadMore(false, activeTabIndex);
			},
		);
	};

	getLayout = (data, index) => ({
		// Will Calculate the Length and offset of container for ScrollToInsex Functionality
		length: verticalScale(60),
		offset: verticalScale(60) * index,
		index,
	});

	renderScreen = () => {
		const { languageInfo, invoicesInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, invoicesListing, count, error, errorCode } = invoicesInfo;
		const { bottomLoader, searchText } = this.state;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		if (loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === '') {
			return (
				<Loader
					activityIndicatorStyle={styles.activityIndicator}
					size="large"
					isSmallLoader
				/>
			);
		}
		return error ? (
			// Error component if api fails.
			<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={this.onRefresh} />
		) : (
			<FlatListComponent
				data={invoicesListing}
				renderItem={this.renderItem}
				keyExtractor={this.keyExtractor}
				showsVerticalScrollIndicator={false}
				onEndReached={() => invoicesListing.length !== count && this.onEndReached()}
				ListFooterComponent={
					invoicesListing.length !== 0 &&
					count > fetchDataWithPagination.limit &&
					this.listFooterComponent()
				}
				onEndReachedThreshold={0.5}
				ListEmptyComponent={() => (
					<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
				)}
				contentContainerStyle={invoicesListing.length === 0 ? styles.scrollViewStyle : null}
				onRefresh={this.onRefresh}
				componentType={constants.flatList}
				onRef={ref => {
					this.itemListRef = ref;
				}}
				getItemLayout={this.getLayout}
			/>
		);
	};

	renderItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<InvoiceCardComponent
					name={item.retailer_organization}
					invoiceId={`(${item.invoice_no})`}
					date={getFormattedDate(item.due)}
					amount={`${currencyFormatter(
						getValueInDecimal(item.invoice_total),
					)} ${localeString(keyConstants.SAR)}`}
					isShowStatus
					pendingInvoices={item.Transaction_count ? item.Transaction_count : 0}
					status={item.status}
					isDisable={false}
					onPress={() =>
						this.onGetDetail(
							item.id,
							index,
							`${item.vendor_org_name} (${item.invoice_no})`,
							item.owner_name,
						)
					}
					dateStyle={styles.dateStyle}
				/>
			</View>
		);
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponent = () => {
		const { languageInfo, invoicesInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { invoicesListing, count } = invoicesInfo;
		const endReached = count === invoicesListing.length || count < invoicesListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { invoicesInfo } = this.props;
		const { loader } = invoicesInfo;
		if (!loader) {
			const { activeTabIndex } = this.state;
			this.setState({
				bottomLoader: true,
			});
			this.page += getPage(this.limit);
			this.limit = fetchDataWithPagination.limit;
			this.onLoadMore(true, activeTabIndex);
		}
	};

	onGetDetail = (id, index, headerTitle, ownerName) => {
		// Will navigate to the invoice detail screen.
		const { navigation } = this.props;
		navigation.navigate(vendorNavigations.INVOICE_DETAIL_NAVIGATION, {
			id,
			index,
			headerTitle,
			ownerName,
			isPayNowButton: false,
		});
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onRefresh = () => {
		// Will call API while pull to refresh.
		const { activeTabIndex } = this.state;
		this.onSetIndexTo();
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false, activeTabIndex);
	};

	render() {
		const { languageInfo } = this.props;
		const { tabsArray, activeTabIndex, searchText } = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<View style={styles.header}>
					<Header text={localeString(keyConstants.MY_CRS)} hasIconInvoices />
				</View>
				<View style={styles.innerContainer}>
					<View style={styles.tabView}>
						<TabComponent
							isRTL={isRTL}
							data={tabsArray}
							activeTabIndex={activeTabIndex}
							onPressTab={this.onSelectTab}
							inverted={isRTL}
						/>
					</View>
					<View style={styles.searchContainer}>
						<Search
							hasSearchIcon
							placeholder={localeString(keyConstants.SEARCH_BY_CUSTOMER)}
							onChangeText={text => this.onSearch(text)}
							value={searchText}
						/>
					</View>
					{this.renderScreen(activeTabIndex)}
				</View>
			</View>
		);
	}
}

MyInvoicesScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	pullToRefreshActions: PropTypes.func.isRequired,
	languageInfo: PropTypes.func.isRequired,
	refreshControlComponentInfo: PropTypes.func.isRequired,
	invoicesInfo: PropTypes.func.isRequired,
	invoicesActions: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		invoicesInfo: state.MyInvoicesScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		invoicesActions: bindActionCreators({ ...InvoicesActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(MyInvoicesScreen);
