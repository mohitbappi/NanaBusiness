import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		activityIndicator: {
			justifyContent: 'center',
			alignItems: 'center',
			flex: 1,
		},
		cardView: {
			marginHorizontal: normalScale(16),
		},
		dateStyle: {
			color: colors.red,
		},
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginHorizontal: normalScale(16),
		},
		innerContainer: {
			marginTop: verticalScale(16),
			flex: 1,
		},
		tabView: {
			marginHorizontal: normalScale(8),
		},
		searchContainer: {
			marginHorizontal: normalScale(16),
		},
		scrollViewStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
