import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetAllInvoicesService from '@InvoicesVendorServices/GetAllInvoicesService';
import GetPendingInvoicesService from '@InvoicesVendorServices/GetPendingInvoicesService';
import GetApprovedInvoicesService from '@InvoicesVendorServices/GetApprovedInvoicesService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to get all the invoices.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetAllInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_INVOICES_DATA_SUCCESS,
		ActionTypes.GET_INVOICES_DATA_FAILURE,
		ActionTypes.GET_INVOICES_DATA_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getAllInvoicesService = new GetAllInvoicesService(dispatchedActions);
	addBasicInterceptors(getAllInvoicesService);
	getAllInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getAllInvoicesService.makeRequest(props));
};

/**
 * Action to get the pending invoices.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetPendingInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_INVOICES_DATA_SUCCESS,
		ActionTypes.GET_INVOICES_DATA_FAILURE,
		ActionTypes.GET_INVOICES_DATA_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getPendingInvoicesService = new GetPendingInvoicesService(dispatchedActions);
	addBasicInterceptors(getPendingInvoicesService);
	getPendingInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPendingInvoicesService.makeRequest(props));
};

/**
 * Action to get the approved invoices.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetApprovedInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_INVOICES_DATA_SUCCESS,
		ActionTypes.GET_INVOICES_DATA_FAILURE,
		ActionTypes.GET_INVOICES_DATA_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getApprovedInvoicesService = new GetApprovedInvoicesService(dispatchedActions);
	addBasicInterceptors(getApprovedInvoicesService);
	getApprovedInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getApprovedInvoicesService.makeRequest(props));
};
