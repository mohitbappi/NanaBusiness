import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	invoicesListing: [],
	count: 0,
};

const MyInvoicesScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_INVOICES_DATA_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				invoicesListing: isOverwriteExistingList
					? [...state.invoicesListing, ...action.payload.invoices]
					: action.payload.invoices,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_INVOICES_DATA_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_INVOICES_DATA_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default MyInvoicesScreenReducer;
