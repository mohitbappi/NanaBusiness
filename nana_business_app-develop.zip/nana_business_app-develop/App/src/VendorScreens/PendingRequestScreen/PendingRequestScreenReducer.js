import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	pendingRequestsListing: [],
	count: 0,
};

const PendingRequestScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_VENDOR_PENDING_REQUESTS_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				pendingRequestsListing: isOverwriteExistingList
					? [...state.pendingRequestsListing, ...action.payload.accounts_requests]
					: action.payload.accounts_requests,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_VENDOR_PENDING_REQUESTS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_VENDOR_PENDING_REQUESTS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return { ...state };
	}
};

export default PendingRequestScreenReducer;
