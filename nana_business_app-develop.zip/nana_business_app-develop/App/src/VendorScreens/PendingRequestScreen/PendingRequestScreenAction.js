import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetPendingRequestsService from '@PendingRequests/GetPendingRequestsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetCollectorPendingRequestsService from '@HomeCollectorServices/GetPendingRequestsService';
import * as ActionTypes from './ActionType';

/**
 * This will fetch all the pending requests list for vendor role.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetPendingRequests = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_VENDOR_PENDING_REQUESTS_SUCCESS,
		ActionTypes.GET_VENDOR_PENDING_REQUESTS_FAILURE,
		ActionTypes.GET_VENDOR_PENDING_REQUESTS_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getPendingRequestsService = new GetPendingRequestsService(dispatchedActions);
	addBasicInterceptors(getPendingRequestsService);
	getPendingRequestsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getPendingRequestsService.makeRequest(props));
};

/**
 * This will fetch all the pending requests list for collector role.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetCollectorPendingRequests = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_VENDOR_PENDING_REQUESTS_SUCCESS,
		ActionTypes.GET_VENDOR_PENDING_REQUESTS_FAILURE,
		ActionTypes.GET_VENDOR_PENDING_REQUESTS_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getCollectorPendingRequestsService = new GetCollectorPendingRequestsService(
		dispatchedActions,
	);
	addBasicInterceptors(getCollectorPendingRequestsService);
	getCollectorPendingRequestsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCollectorPendingRequestsService.makeRequest(props));
};
