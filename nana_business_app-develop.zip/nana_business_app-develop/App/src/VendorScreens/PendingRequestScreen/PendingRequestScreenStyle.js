import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		cardView: {
			marginHorizontal: normalScale(16),
			borderBottomWidth: verticalScale(1),
			borderColor: colors.grey,
			justifyContent: 'center',
		},
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginTop: verticalScale(8),
			marginHorizontal: normalScale(16),
			paddingBottom: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: verticalScale(1),
		},
		scrollViewStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
