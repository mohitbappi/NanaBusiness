export const GET_VENDOR_PENDING_REQUESTS_SUCCESS = 'get_vendorpending_requests_success';
export const GET_VENDOR_PENDING_REQUESTS_FAILURE = 'get_vendorpending_requests_failure';
export const GET_VENDOR_PENDING_REQUESTS_LOADER = 'get_vendorpending_requests_loader';
