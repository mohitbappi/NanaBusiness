import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { fetchDataWithPagination, collector } from '@Constants/Constants';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import RectangleCard from '@RectangleCard/RectangleCard';
import { getFormattedDate } from '@Util/GetFormattedDate';
import ListEmpty from '@ListEmpty/ListEmpty';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import { createStyleSheet } from './PendingRequestScreenStyle';
import * as PendingRequestsActions from './PendingRequestScreenAction';

class PendingRequestScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
		};
	}

	componentDidMount() {
		const { pullToRefreshActions } = this.props;
		this.onLoadMore(false);
		pullToRefreshActions.onHandlePullToRefresh(false);
	}

	componentDidUpdate(prevProps) {
		const { pendingRequestsInfo, pullToRefreshActions } = this.props;
		const { success } = pendingRequestsInfo;
		if (success && prevProps.pendingRequestsInfo.success !== pendingRequestsInfo.success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		// API call to get the pending requests.
		const { role, pendingRequestsActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (role === collector) {
			pendingRequestsActions.onGetCollectorPendingRequests(
				queryParams,
				isOverwriteExistingList,
			);
		} else {
			pendingRequestsActions.onGetPendingRequests(queryParams, isOverwriteExistingList);
		}
	};

	onPressClose = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	renderItem = ({ item }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<RectangleCard
					name={item.name}
					isCompany
					userDetails={item.org_name}
					date={getFormattedDate(item.created_at)}
					isStatus
				/>
			</View>
		);
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponent = () => {
		const { languageInfo, pendingRequestsInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { pendingRequestsListing, count } = pendingRequestsInfo;
		const endReached =
			count === pendingRequestsListing.length || count < pendingRequestsListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { pendingRequestsInfo } = this.props;
		const { loader } = pendingRequestsInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onLoadMore(true);
		}
	};

	onRefresh = () => {
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	render() {
		const { bottomLoader } = this.state;
		const { languageInfo, pendingRequestsInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, pendingRequestsListing, count } = pendingRequestsInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && <Loader size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.PENDING_REQUESTS)}
						hasIconClose
						hasIconTeam
						onPressClose={this.onPressClose}
					/>
				</View>
				<FlatListComponent
					data={pendingRequestsListing}
					renderItem={this.renderItem}
					keyExtractor={this.keyExtractor}
					showsVerticalScrollIndicator={false}
					onEndReached={() =>
						pendingRequestsListing.length !== count && this.onEndReached()
					}
					ListFooterComponent={
						pendingRequestsListing.length !== 0 &&
						count > fetchDataWithPagination.limit &&
						this.listFooterComponent()
					}
					onEndReachedThreshold={0.5}
					ListEmptyComponent={() => (
						<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
					)}
					contentContainerStyle={styles.scrollViewStyle}
					onRefresh={this.onRefresh}
					componentType={constants.flatList}
				/>
			</View>
		);
	}
}

PendingRequestScreen.propTypes = {
	navigation: PropTypes.func.isRequired,
	pullToRefreshActions: PropTypes.func.isRequired,
	languageInfo: PropTypes.func.isRequired,
	refreshControlComponentInfo: PropTypes.func.isRequired,
	pendingRequestsInfo: PropTypes.func.isRequired,
	role: PropTypes.string.isRequired,
	pendingRequestsActions: PropTypes.func.isRequired,
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		pendingRequestsInfo: state.PendingRequestScreenReducer,
		role: state.CollectorHomeScreenReducer.userDetails.user.role,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		pendingRequestsActions: bindActionCreators({ ...PendingRequestsActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispacthToProps)(PendingRequestScreen);
