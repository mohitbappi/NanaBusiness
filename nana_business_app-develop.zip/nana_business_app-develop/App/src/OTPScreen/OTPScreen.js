// import libraries
import React, { Component } from 'react';
import { View, TouchableOpacity, Text, Keyboard, Platform } from 'react-native';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

// import component
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import OTPComponent from '@OTPComponent/OTPComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import SignUpHeader from '@SignUpHeader/SignUpHeader';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';

// import utils
import IMAGES from '@Images/index';
import { localeString } from '@assets/Localization';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

// import constants
import { keyConstants } from '@Constants/KeyConstants';
import {
	otpLength,
	deliveryCodeLength,
	toastShowTime,
	mobilePrefix,
	vendor,
	retailer,
	collector,
	customerAdmin,
	saudiMobilePrefix,
	driver,
	languageConstants,
	plus,
	accountManager,
	cashier,
	salesExecutive,
} from '@Constants/Constants';

// import navigations
import navigations from '@routes/navigations';
import driverNavigations from '@routes/driverNavigations';
import collectorNavigations from '@config/routes/collectorNavigations';

// import actions
import * as SignInScreenActions from '@SignInScreen/SignInScreenAction';
import * as ShipmentDetailActions from '@ShipmentDetailScreen/ShipmentDetailScreenAction';
import * as InvoiceDetailActions from '@SalesInvoiceDetailScreen/SalesInvoiceDetailScreenAction';
import * as SignUpScreenActions from '@SignUpNextScreen/SignUpScreenAction';
import * as OtpScreenActions from './OTPScreenAction';

// import styles
import { createStyleSheet } from './OTPScreenStyle';

class OTPScreen extends Component {
	constructor(props) {
		super(props);
		this.mobileNumber = props.route.params.mobileNumber;
		this.isSignIn = props.route.params.isSignIn;
		this.isDriver = props.route.params.isDriver;
		this.isPartialRefund = props.route.params.isPartialRefund;
		this.state = {
			otpValue: '',
			otpValidation: true,
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidUpdate(prevProps, prevState) {
		const { otpValue } = this.state;
		const {
			otpScreenInfo,
			signInInfo,
			shipmentDetailInfo,
			invoiceDetailInfo,
			route,
			otpScreenActions,
			navigation,
			signUpScreenActions,
		} = this.props;
		const { error, errorCode, success, isResendOtp, signUpToken } = otpScreenInfo;
		const { error: signInError, errorCode: signInErrorCode } = signInInfo;
		const {
			error: shipmentError,
			errorCode: shipmentErrorCode,
			isShipmentDelivered,
		} = shipmentDetailInfo;
		const {
			error: refundError,
			errorCode: refundErrorCode,
			isPartialRefund,
		} = invoiceDetailInfo;
		const { isRegistrationRequest } = route.params || {};
		if (!this.isDriver && otpValue.length === otpLength && prevState.otpValue !== otpValue) {
			// if user is not driver
			this.onVerify();
		}
		if (success && prevProps.otpScreenInfo.success !== otpScreenInfo.success) {
			if (isResendOtp) {
				// If resend otp.
				this.setState({
					toastMessage: localeString(keyConstants.OTP_SENT_SUCCESSFULLY),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({ isApiError: false });
				}, toastShowTime);
				otpScreenActions.onResetOtpScreenState();
			} else if (isRegistrationRequest) {
				// If request type is registration request.
				navigation.navigate(navigations.SIGN_UP_MAP_NAVIGATION);
			} else {
				// If request type is user request.
				signUpScreenActions.onSetSignUpToken(signUpToken);
			}
		}
		if (error && prevProps.otpScreenInfo.error !== error) {
			if (keyConstants[errorCode.error]) {
				// Will show toast if api error occurs.
				this.showToast(errorCode.error);
			} else {
				// Will show alert if api fails.
				ErrorAlertComponent(errorCode, isResendOtp ? this.onResend : this.onVerify);
			}
		}
		if (signInError && prevProps.signInInfo.error !== signInError) {
			// Will show toast if error occurs in signin api.
			this.showToast(signInErrorCode.error);
		}
		if (
			shipmentError &&
			isShipmentDelivered &&
			prevProps.shipmentDetailInfo.error !== shipmentError
		) {
			if (keyConstants.DELIVERY_CODE_NOT_MATCHED === shipmentErrorCode.error) {
				// Will show toast if error occurs in shipment api-delivery code mismatched.
				this.showToast(shipmentErrorCode.error);
			} else {
				// Will show alert if shipment api fails.
				ErrorAlertComponent(shipmentErrorCode, this.onVerify);
			}
		}
		if (refundError && isPartialRefund && prevProps.invoiceDetailInfo.error !== refundError) {
			if (keyConstants.DELIVERY_CODE_NOT_MATCHED === shipmentErrorCode?.error) {
				// Will show toast if error occurs in refund api.
				this.showToast(refundErrorCode.error);
			} else {
				// Will show alert if refunds api fails.
				ErrorAlertComponent(refundErrorCode, this.onVerify);
			}
		}
	}

	componentWillUnmount() {
		// Will reset otp and shipment reducers on unmount
		const { otpScreenActions, shipmentDetailActions } = this.props;
		otpScreenActions.onResetOtpScreenState();
		shipmentDetailActions.onResetShipmentState();
	}

	showToast = error => {
		this.setState({ toastMessage: localeString(keyConstants[`${error}`]), isApiError: true });
		setTimeout(() => {
			this.setState({ isApiError: false });
		}, toastShowTime);
	};

	onGoToShipments = () => {
		const { navigation, invoiceDetailActions, shipmentDetailActions } = this.props;
		navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
		invoiceDetailActions.onResetRefundState();
		shipmentDetailActions.onResetShipmentState();
	};

	createPaymentReceived = shipmentData => {
		const { navigation, invoiceDetailActions, shipmentDetailActions } = this.props;
		const extraParams = {
			shipmentData,
		};
		navigation.navigate(collectorNavigations.PAYMENT_RECEIVED_NAVIGATION, {
			isDriverRole: true,
			extraParams,
			isResubmit: false,
			isNewMadaPayment: true,
		});
		invoiceDetailActions.onResetRefundState();
		shipmentDetailActions.onResetShipmentState();
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onGoSignIn = () => {
		const { signInScreenActions } = this.props;
		signInScreenActions.onChangeText(this.mobileNumber, 'mobileNumber');
		signInScreenActions.onSetSignInViaPassword(true);
		this.onGoBack();
	};

	onResend = () => {
		// Call resend otp api
		const { languageInfo, otpScreenActions } = this.props;
		this.onDissmissKeyboard();
		const { isRTL } = languageInfo;
		this.setState({ otpValue: '', otpValidation: true });
		const otpDetails = {
			phone: this.mobileNumber,
			country_code: mobilePrefix,
			for_login: 'false',
			language: isRTL ? languageConstants.ar : languageConstants.en,
			platform: Platform.OS,
		};
		otpScreenActions.onResendOtp(otpDetails);
	};

	onSetValue = (value, otpValidation) => {
		this.setState({ otpValue: value, otpValidation });
	};

	onDissmissKeyboard = () => Keyboard.dismiss();

	onVerify = () => {
		const {
			personalInfo,
			route,
			signInScreenActions,
			invoiceDetailActions,
			otpScreenActions,
			shipmentDetailActions,
		} = this.props;
		this.onDissmissKeyboard();
		const {
			mobileNumber,
			email,
			fullName,
			companyRegNumber,
			companyName,
			businessType,
		} = personalInfo;
		const { otpValue } = this.state;
		const { isRegistrationRequest } = route.params || {};
		if (this.isSignIn) {
			// if otp validation is in signin
			const signInDetails = {
				mobile: this.mobileNumber,
				role: [
					vendor,
					retailer,
					collector,
					accountManager,
					salesExecutive,
					customerAdmin,
					driver,
					cashier,
				],
				country_code: mobilePrefix,
				otp: otpValue,
			};
			signInScreenActions.onPerformLogin(signInDetails);
		} else if (this.isDriver) {
			// if otp validation is for driver user
			if (this.isPartialRefund) {
				// if otp validation is for partial refund
				const { queryParams } = route.params || {};
				queryParams.code = parseInt(otpValue, 10);
				invoiceDetailActions.onPartialRefund(queryParams);
			} else {
				// if otp validation is for marking delivery
				const { id } = route.params || {};
				const shipmentDetails = {
					shipment_id: id,
					code: parseInt(otpValue, 10),
				};
				shipmentDetailActions.onMarkDelivered(shipmentDetails);
			}
		} else {
			// if otp validation is for sign up process
			const otpDetails = {
				phone: mobileNumber,
				otp: otpValue,
				email_address: email,
				name: fullName,
				country_code: mobilePrefix,
				for_login: 'false',
				cr: companyRegNumber,
			};
			if (isRegistrationRequest) {
				otpDetails.business_type = businessType;
				otpDetails.orgName = companyName;
			}
			otpScreenActions.onVerifyOtp(otpDetails, isRegistrationRequest);
		}
	};

	getHeadingText = () => {
		return this.isDriver
			? this.isPartialRefund
				? localeString(keyConstants.ENTER_CODE)
				: localeString(keyConstants.ENTER_SHIPMENT_CODE)
			: this.isSignIn
			? localeString(keyConstants.SIGN_IN)
			: localeString(keyConstants.SIGN_UP);
	};

	getSubHeadingText = () => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		return this.isDriver
			? this.isPartialRefund
				? localeString(keyConstants.PARTIAL_REFUND_MESSAGE)
				: localeString(keyConstants.SHIPMENT_MESSAGE)
			: `${localeString(keyConstants.CODE_SENT_MESSAGE)} ${
					isRTL
						? `${mobilePrefix}${this.mobileNumber}${plus}`
						: `${saudiMobilePrefix}${this.mobileNumber}`
			  }`;
	};

	render() {
		const {
			languageInfo,
			otpScreenInfo,
			signInInfo,
			shipmentDetailInfo,
			invoiceDetailInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { otpValidation, toastMessage, isApiError } = this.state;
		const { loader } = otpScreenInfo;
		const signInLoader = signInInfo.loader;
		const {
			isShipmentDelivered,
			success,
			loader: shipmentLoader,
			markDeliveredData,
		} = shipmentDetailInfo;
		const {
			isPartialRefund,
			partialRefundData,
			loader: refundLoader,
			success: refundSuccess,
			markDeliveredData: refundMarkDeliveredData,
		} = invoiceDetailInfo;
		const { amount, organization, vat_amount } = partialRefundData || {};
		const isMarkDelivered = success && isShipmentDelivered;
		const isRefunded = refundSuccess && isPartialRefund;
		let data = {};
		data = isMarkDelivered ? markDeliveredData?.data : refundMarkDeliveredData;
		return (
			<View style={styles.container}>
				{(loader || signInLoader || refundLoader) && <Spinner size="large" />}
				{shipmentLoader && isShipmentDelivered && <Spinner size="large" />}
				{(isMarkDelivered || isRefunded) && (
					<ConfimationModal
						buttonTitle={localeString(keyConstants.PROCEED_FOR_COLLECTION)}
						secondaryButtonTitle={localeString(keyConstants.BACK_TO_SHIPMENTS)}
						hasButton={data?.is_collector}
						onPress={() => this.createPaymentReceived(data)}
						title={
							isRefunded
								? localeString(keyConstants.TOTAL_REFUND)
								: localeString(keyConstants.MARK_AS_DELIVERED)
						}
						description={`${localeString(
							isRefunded
								? keyConstants.TOTAL_REFUND_MESSAGE
								: keyConstants.DELIVERED_MESSAGE,
						)}`}
						innerDescription={
							isRefunded
								? `${currencyFormatter(
										getValueInDecimal(amount + parseFloat(vat_amount, 10)),
								  )} ${localeString(keyConstants.SAR)} `
								: ''
						}
						descriptionTwo={
							isRefunded
								? `${localeString(
										keyConstants.TOTAL_REFUND_MESSAGES,
								  )} ${organization}`
								: ''
						}
						hasSecondaryButton
						onPressButton={this.onGoToShipments}
					/>
				)}
				{!this.isDriver && (
					<View style={styles.headerContainer}>
						{!this.isSignIn && (
							<SignUpHeader
								isRTL={isRTL}
								filledLevelLength={2}
								unFilledLevelLength={1}
								onGoBack={this.onGoBack}
								hasIconBack
							/>
						)}
						{this.isSignIn && (
							<>
								<TouchableOpacity
									activeOpacity={0.8}
									hitSlop={styles.hitSlop}
									style={styles.backButton}
									onPress={this.onGoBack}>
									<ImageLoadComponent
										source={IMAGES.iconRightArrow}
										style={styles.iconBack}
									/>
								</TouchableOpacity>
								<TouchableOpacity
									activeOpacity={0.8}
									hitSlop={styles.hitSlop}
									style={styles.backButton}
									onPress={this.onGoSignIn}>
									<Text style={styles.signInViaPassword}>
										{localeString(keyConstants.SIGN_IN_VIA_PASSWORD)}
									</Text>
								</TouchableOpacity>
							</>
						)}
					</View>
				)}
				{this.isDriver && (
					<TouchableOpacity
						style={styles.iconView}
						hitSlop={styles.hitSlop}
						activeOpacity={0.8}
						onPress={this.onGoBack}>
						<ImageLoadComponent source={IMAGES.iconCross} style={styles.iconCross} />
					</TouchableOpacity>
				)}
				<View style={[styles.innerContainer, this.isDriver && styles.driverInnerStyle]}>
					<Text style={[styles.signUpHeadingText, this.isDriver && styles.driverStyle]}>
						{this.getHeadingText()}
					</Text>
					<Text
						style={[
							styles.personalInfoText,
							this.isDriver && styles.driverPersonalStyle,
						]}>
						{this.getSubHeadingText()}
					</Text>
					<OTPComponent
						onResend={this.onResend}
						style={styles.otp}
						length={this.isDriver ? deliveryCodeLength : otpLength}
						onChange={(value, validation) => this.onSetValue(value, validation)}
						isRTL={isRTL}
						isDriver={this.isDriver}
					/>
				</View>
				<View style={styles.viewStyle}>
					<ButtonComponent
						onPress={this.onVerify}
						text={
							this.isDriver
								? localeString(keyConstants.SUBMIT)
								: this.isSignIn
								? localeString(keyConstants.SIGN_IN)
								: localeString(keyConstants.SUBMIT)
						}
						isButtonDisable={otpValidation}
					/>
				</View>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		otpScreenInfo: state.OTPScreenReducer,
		personalInfo: state.PersonalInformationScreenReducer,
		signInInfo: state.SignInScreenReducer,
		shipmentDetailInfo: state.ShipmentDetailScreenReducer,
		invoiceDetailInfo: state.SalesInvoiceDetailScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		otpScreenActions: bindActionCreators({ ...OtpScreenActions }, dispatch),
		signInScreenActions: bindActionCreators({ ...SignInScreenActions }, dispatch),
		shipmentDetailActions: bindActionCreators({ ...ShipmentDetailActions }, dispatch),
		invoiceDetailActions: bindActionCreators({ ...InvoiceDetailActions }, dispatch),
		signUpScreenActions: bindActionCreators({ ...SignUpScreenActions }, dispatch),
	};
};

OTPScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	otpScreenInfo: PropTypes.object.isRequired,
	personalInfo: PropTypes.object.isRequired,
	signInInfo: PropTypes.object.isRequired,
	shipmentDetailInfo: PropTypes.object.isRequired,
	invoiceDetailInfo: PropTypes.object.isRequired,
	otpScreenActions: PropTypes.object.isRequired,
	signInScreenActions: PropTypes.object.isRequired,
	shipmentDetailActions: PropTypes.object.isRequired,
	invoiceDetailActions: PropTypes.object.isRequired,
	signUpScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(OTPScreen);
