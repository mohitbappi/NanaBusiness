import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(10),
		},
		hitSlop: {
			top: verticalScale(15),
			bottom: verticalScale(15),
			right: normalScale(15),
			left: normalScale(15),
		},
		backButton: {
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			paddingHorizontal: normalScale(30),
		},
		iconBack: {
			height: verticalScale(12),
			width: normalScale(10),
			transform: rtlFunctions.getTransformOpposite(isRTL),
		},
		iconView: {
			paddingHorizontal: normalScale(20),
			alignSelf: rtlFunctions.getAlignmentInFlex(isRTL),
			marginTop: verticalScale(16),
		},
		iconCross: {
			height: normalScale(12),
			width: normalScale(12),
		},
		signInViaPassword: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(14),
		},
		innerContainer: {
			paddingHorizontal: normalScale(30),
			paddingBottom: verticalScale(80),
			marginTop: verticalScale(15),
		},
		driverInnerStyle: {
			paddingHorizontal: normalScale(16),
		},
		signUpHeadingText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(30),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		driverStyle: {
			fontSize: normalize(18),
			marginTop: verticalScale(98),
			alignSelf: 'center',
		},
		personalInfoText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(11),
			marginBottom: verticalScale(30),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		driverPersonalStyle: {
			color: colors.black,
			marginTop: verticalScale(16),
			marginBottom: verticalScale(41),
			alignSelf: 'center',
			textAlign: 'center',
		},
		otp: {
			width: normalScale(44),
			height: verticalScale(44),
		},
		viewStyle: {
			position: 'absolute',
			left: normalScale(30),
			right: normalScale(30),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(20),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
