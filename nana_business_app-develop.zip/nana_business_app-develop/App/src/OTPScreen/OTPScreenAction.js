import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import ResendOtpService from '@SignUp/ResendOtpService';
import VerifyOtpService from '@SignUp/VerifyOtpService';
import * as ActionTypes from './ActionType';

/**
 * Action to call resend otp api
 * @param {object} otpDetails
 */
export const onResendOtp = otpDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.RESEND_OTP_SUCCESS,
		ActionTypes.RESEND_OTP_FAILURE,
		ActionTypes.RESEND_OTP_LOADER,
	);
	const resendOtpService = new ResendOtpService(dispatchedActions);
	addBasicInterceptors(resendOtpService);
	dispatch(resendOtpService.makeRequest(otpDetails));
};

// Action to reset otp screen reducer
export const onResetOtpScreenState = () => ({ type: ActionTypes.RESET_OTP_SCREEN_STATE });

/**
 * Action to call api for otp verification
 * @param {object} otpDetails
 * @param {boolean} isRegistrationRequest
 */
export const onVerifyOtp = (otpDetails, isRegistrationRequest) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.VERIFY_OTP_SUCCESS,
		ActionTypes.VERIFY_OTP_FAILURE,
		ActionTypes.VERIFY_OTP_LOADER,
	)
		.addSuccessExtra(isRegistrationRequest)
		.build();
	const verifyOtpService = new VerifyOtpService(dispatchedActions);
	addBasicInterceptors(verifyOtpService);
	dispatch(verifyOtpService.makeRequest(otpDetails));
};

/**
 * Action to set otp token
 * @param {string} token
 */
export const onSetOtpToken = token => {
	return {
		type: ActionTypes.SET_OTP_TOKEN,
		payload: token,
	};
};
