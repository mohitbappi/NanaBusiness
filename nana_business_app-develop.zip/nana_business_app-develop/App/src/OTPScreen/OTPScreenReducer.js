import {
	saveOtpVerificationToken,
	onAddSignUpRequestType,
	saveSignUpCompleteToken,
} from '@Util/SaveMasterData';
import { REQUEST_TYPE } from '@Constants/Constants';
import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	isResendOtp: false,
	otpToken: null,
	signUpToken: null,
};

const OTPScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.RESEND_OTP_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isResendOtp: true,
			};
		case ActionTypes.RESEND_OTP_LOADER:
		case ActionTypes.VERIFY_OTP_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.RESEND_OTP_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isResendOtp: true,
			};
		case ActionTypes.VERIFY_OTP_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isResendOtp: false,
			};
		case ActionTypes.VERIFY_OTP_SUCCESS: {
			const isRegistrationRequest = action.extra;
			saveOtpVerificationToken(isRegistrationRequest ? action.payload.token : null);
			saveSignUpCompleteToken(
				action.payload && action.payload.row ? action.payload.row.access_token : null,
			);
			onAddSignUpRequestType(isRegistrationRequest ? null : REQUEST_TYPE.userRequest);
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isResendOtp: false,
				otpToken: isRegistrationRequest ? action.payload.token : null,
				signUpToken:
					action.payload && action.payload.row ? action.payload.row.access_token : null,
			};
		}
		case ActionTypes.RESET_OTP_SCREEN_STATE:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
				isResendOtp: false,
			};
		case ActionTypes.SET_OTP_TOKEN:
			return {
				...state,
				otpToken: action.payload,
			};
		default:
			return state;
	}
};

export default OTPScreenReducer;
