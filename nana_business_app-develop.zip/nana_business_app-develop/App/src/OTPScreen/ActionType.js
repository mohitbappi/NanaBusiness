export const RESEND_OTP_SUCCESS = 'resend_otp_success';
export const RESEND_OTP_FAILURE = 'resend_otp_failure';
export const RESEND_OTP_LOADER = 'resend_otp_loader';
export const RESET_OTP_SCREEN_STATE = 'resend_otp_screen_state';
export const VERIFY_OTP_SUCCESS = 'verify_otp_success';
export const VERIFY_OTP_FAILURE = 'verify_otp_failure';
export const VERIFY_OTP_LOADER = 'verify_otp_loader';
export const SET_OTP_TOKEN = 'set_otp_token';
