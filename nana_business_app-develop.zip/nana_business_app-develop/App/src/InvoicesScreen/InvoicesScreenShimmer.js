// import libraries
import React from 'react';
import { Dimensions } from 'react-native';
import ContentLoader, { Rect } from 'react-content-loader/native';
import PropTypes from 'prop-types';

// import colors
import * as colors from '@assets/colors';

// import utils
import { normalScale, verticalScale } from '@device/normalize';

const windowWidth = Dimensions.get('window').width;

export const PaidAmountContainerShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(80)}>
			<Rect width={windowWidth} height={verticalScale(80)} />
		</ContentLoader>
	);
};

export const DueAmountContainerShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(44)}>
			<Rect y={verticalScale(6)} width={windowWidth} height={verticalScale(36)} />
		</ContentLoader>
	);
};

export const TabContainerShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(42)}>
			<Rect
				x={normalScale(16)}
				y={verticalScale(16)}
				rx={normalScale(12)}
				ry={normalScale(12)}
				width={normalScale(72)}
				height={verticalScale(26)}
			/>
			<Rect
				x={normalScale(100)}
				y={verticalScale(16)}
				rx={normalScale(12)}
				ry={normalScale(12)}
				width={normalScale(72)}
				height={verticalScale(26)}
			/>
			<Rect
				x={normalScale(184)}
				y={verticalScale(16)}
				rx={normalScale(12)}
				ry={normalScale(12)}
				width={normalScale(72)}
				height={verticalScale(26)}
			/>
		</ContentLoader>
	);
};

export const InvoiceListingShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(68)}>
			<Rect
				x={normalScale(16)}
				y={verticalScale(16)}
				width={normalScale(140)}
				height={verticalScale(16)}
			/>
			<Rect
				x={windowWidth - normalScale(96)}
				y={verticalScale(16)}
				width={normalScale(80)}
				height={verticalScale(16)}
			/>
			<Rect
				x={normalScale(16)}
				y={verticalScale(40)}
				width={normalScale(80)}
				height={verticalScale(12)}
			/>
			<Rect
				x={windowWidth - normalScale(66)}
				y={verticalScale(40)}
				width={normalScale(50)}
				height={verticalScale(12)}
			/>
			<Rect x={0} y={verticalScale(66)} width={windowWidth} height={verticalScale(3)} />
		</ContentLoader>
	);
};

PaidAmountContainerShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

DueAmountContainerShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

TabContainerShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

InvoiceListingShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};
