import * as ActionTypes from './ActionType';

const initialState = {
	issuedAmount: '0',
	dueAmount: '0',
	invoicesListing: [],
	invoicesCount: 0,
	allInvoicesListing: [],
	allInvoicesCount: 0,
	approvedInvoicesCount: 0,
	approvedInvoicesListing: [],
	approveInvoices: null,
	rejectInvoices: null,
	isApproveInvoicesLoader: false,
	isRejectInvoicesLoader: false,
	isApproveInvoicesSuccess: false,
	isRejectInvoicesSuccess: false,
	userDetails: null,
	loader: false,
	isApproveInvoices: false,
	isRejectInvoices: false,
};

const InvoicesScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.RESET_INVOICES_STATE:
			return {
				...state,
				issuedAmount: '0',
				dueAmount: '0',
				allInvoicesListing: [],
				allInvoicesCount: 0,
				invoicesListing: [],
				invoicesCount: 0,
				approvedInvoicesCount: 0,
				approvedInvoicesListing: [],
				approveInvoices: null,
				rejectInvoices: null,
				isApproveInvoicesLoader: false,
				isRejectInvoicesLoader: false,
				isApproveInvoicesSuccess: false,
				isRejectInvoicesSuccess: false,
				userDetails: null,
				success: false,
				error: false,
				errorCode: '',
				loader: false,
				isApproveInvoices: false,
				isRejectInvoices: false,
			};
		case ActionTypes.GET_RETAILER_INVOICES_SUCCESS: {
			const isOverwriteExistingCategoryList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				invoicesListing: isOverwriteExistingCategoryList
					? [...state.invoicesListing, ...action.payload.invoices]
					: action.payload.invoices,
				invoicesCount: action.payload.count,
				isApproveInvoices: false,
				isRejectInvoices: false,
			};
		}
		case ActionTypes.GET_RETAILER_INVOICES_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_RETAILER_INVOICES_FAILURE:
		case ActionTypes.GET_APPROVED_INVOICES_FAILURE:
		case ActionTypes.GET_ALL_INVOICES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isApproveInvoices: false,
				isRejectInvoices: false,
			};
		case ActionTypes.GET_ALL_INVOICES_SUCCESS: {
			const isOverwriteExistingAllInvoices = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				allInvoicesListing: isOverwriteExistingAllInvoices
					? [...state.allInvoicesListing, ...action.payload.invoices]
					: action.payload.invoices,
				allInvoicesCount: action.payload.count,
				isApproveInvoices: false,
				isRejectInvoices: false,
			};
		}
		case ActionTypes.GET_APPROVED_INVOICES_SUCCESS: {
			const isOverwriteExistingApprovedInvoices = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				approvedInvoicesListing: isOverwriteExistingApprovedInvoices
					? [...state.approvedInvoicesListing, ...action.payload.invoices]
					: action.payload.invoices,
				approvedInvoicesCount: action.payload.count,
				isApproveInvoices: false,
				isRejectInvoices: false,
			};
		}
		case ActionTypes.GET_STATS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				issuedAmount: action.payload.paid_amount,
				dueAmount: action.payload.due,
				isApproveInvoices: false,
				isRejectInvoices: false,
			};
		case ActionTypes.APPROVE_INVOICES_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isApproveInvoicesLoader: false,
				approveInvoices: action.payload,
				isApproveInvoicesSuccess: true,
				isApproveInvoices: true,
				isRejectInvoices: false,
			};
		case ActionTypes.APPROVE_INVOICES_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isApproveInvoicesLoader: true,
				isApproveInvoices: true,
				isRejectInvoices: false,
			};
		case ActionTypes.APPROVE_INVOICES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isApproveInvoicesLoader: false,
				isApproveInvoices: true,
				isRejectInvoices: false,
			};
		case ActionTypes.REJECT_INVOICES_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				rejectInvoices: action.payload,
				isRejectInvoicesLoader: false,
				isRejectInvoicesSuccess: true,
				isApproveInvoices: false,
				isRejectInvoices: true,
			};
		case ActionTypes.REJECT_INVOICES_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isRejectInvoicesLoader: true,
				isApproveInvoices: false,
				isRejectInvoices: true,
			};
		case ActionTypes.REJECT_INVOICES_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isRejectInvoicesLoader: false,
				isApproveInvoices: false,
				isRejectInvoices: true,
			};
		default:
			return state;
	}
};

export default InvoicesScreenReducer;
