import React, { Component } from 'react';
import { Text, View, TouchableOpacity, FlatList, ActivityIndicator } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Header from '@Header/Header';
import * as colors from '@assets/colors';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import navigations from '@routes/navigations';
import {
	fetchDataWithPagination,
	salesInvoice,
	customerAdmin,
	isToggleFeatureEnable,
	toastShowTime,
	accountManager,
	salesExecutive,
} from '@Constants/Constants';
import NoConnectionHandle from '@NoConnectionHandle/NoConnectionHandle';
import Spinner from '@Spinner/Spinner';
import { getFormattedDate } from '@Util/GetFormattedDate';
import ListEmpty from '@ListEmpty/ListEmpty';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import DueAmountContainer from '@DueAmountContainer/DueAmountContainer';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ToggleFeatureScreen from '@ToggleFeatureScreen/ToggleFeatureScreen';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import AlertComponent from '@Util/AlertComponent';
import { verticalScale } from '@device/normalize';
import { getPage, getScrollingIndex } from '@Util/GetScrollingIndex';
import {
	DueAmountContainerShimmer,
	InvoiceListingShimmer,
	PaidAmountContainerShimmer,
	TabContainerShimmer,
} from './InvoicesScreenShimmer';
import { createStyleSheet } from './InvoicesScreenStyle';
import * as InvoicesScreenAction from './InvoicesScreenAction';

class InvoicesScreen extends Component {
	constructor(props) {
		super(props);
		this.invoiceLimit = fetchDataWithPagination.limit;
		this.invoicePage = fetchDataWithPagination.page;
		this.approvedInvoiceLimit = fetchDataWithPagination.limit;
		this.approvedInvoicePage = fetchDataWithPagination.page;
		this.allInvoiceLimit = fetchDataWithPagination.limit;
		this.allInvoicePage = fetchDataWithPagination.page;
		this.state = {
			isTabAll: true,
			isTabPending: false,
			isTabApproved: false,
			inVoiceSelectedList: [],
			bottomLoader: false,
			toastMessage: '',
			isApiError: false,
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { userDetails, invoicesScreenActions, refreshControlComponentInfo } = this.props;
			const { scrollIndex } = refreshControlComponentInfo;
			const { role, default_user_id } = userDetails?.user ? userDetails.user : {};
			if (!isToggleFeatureEnable) {
				// Won't call toggle feature API if return false
				if (
					(role === accountManager || role === salesExecutive) &&
					(default_user_id === null || default_user_id === undefined)
				) {
					// If the user is not selected then will show the popup and navigate to the screen to select the user.
					const alertOptions = {
						message: localeString(keyConstants.USER_DISABLED_ERROR),
						yesText: localeString(keyConstants.OKAY),
						isOneButton: true,
						onPressYes: () => {
							navigation.navigate(navigations.SELECT_CUSTOMER_USER_NAVIGATION);
							invoicesScreenActions.onResetInvoiceState();
						},
					};
					AlertComponent(alertOptions);
				} else {
					this.invoiceLimit = getScrollingIndex(scrollIndex);
					this.approvedInvoiceLimit = getScrollingIndex(scrollIndex);
					this.allInvoiceLimit = getScrollingIndex(scrollIndex);
					this.onFetchData();
				}
			}
		});

		this.willFocusListener = navigation.addListener('blur', () => {
			if (this.itemListRef) {
				this.itemListRef.onSetIndex(0);
			}
		});
	}

	componentDidUpdate(prevProps) {
		const {
			invoiceScreenInfo,
			toggleFeaturesInfo,
			invoicesScreenActions,
			pullToRefreshActions,
			refreshControlComponentInfo,
		} = this.props;
		const {
			error,
			errorCode,
			isRejectInvoicesSuccess,
			isApproveInvoicesSuccess,
			success,
			isApproveInvoices,
			isRejectInvoices,
		} = invoiceScreenInfo;
		const { success: toggleApiSuccess } = toggleFeaturesInfo;
		const { scrollIndex } = refreshControlComponentInfo;
		if (toggleApiSuccess && prevProps.toggleFeaturesInfo.success !== success) {
			// If toggle API returns success.
			this.invoiceLimit = getScrollingIndex(scrollIndex);
			this.approvedInvoiceLimit = getScrollingIndex(scrollIndex);
			this.allInvoiceLimit = getScrollingIndex(scrollIndex);
			this.onFetchData();
		}
		if (
			error &&
			(isApproveInvoices || isRejectInvoices) &&
			prevProps.invoiceScreenInfo.error !== invoiceScreenInfo.error
		) {
			if (keyConstants[errorCode.error]) {
				// Will show toast if api error occurs.
				this.setState({
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				// Will show alert if api fails.
				ErrorAlertComponent(
					errorCode,
					isApproveInvoices ? this.onPressApprove : this.onPressReject,
				);
			}
		}
		if (prevProps.invoiceScreenInfo !== invoiceScreenInfo) {
			if (isApproveInvoicesSuccess === true || isRejectInvoicesSuccess === true) {
				// Will reset reducer and call the api's if customer successfully approved/rejected the invoice.
				this.setState(
					{
						inVoiceSelectedList: [],
					},
					() => {
						invoicesScreenActions.onResetInvoiceState();
						this.getStats();
						this.getInvoices(false);
						this.getApprovedInvoices(false);
						this.getAllInvoices(false);
					},
				);
			}
		}
		if (success && prevProps.invoiceScreenInfo.success !== invoiceScreenInfo.success) {
			// Will hide bottom loader if api succeed.
			this.setState(
				{
					bottomLoader: false,
				},
				() => {
					if (
						this.invoicePage === 1 ||
						this.approvedInvoicePage === 1 ||
						this.allInvoicePage === 1
					) {
						this.itemListRef.onScroll(1);
					}
				},
			);
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onFetchData = () => {
		// API calls to get the invoice listing and amount.
		this.invoicePage = fetchDataWithPagination.page;
		this.approvedInvoicePage = fetchDataWithPagination.page;
		this.allInvoicePage = fetchDataWithPagination.page;
		this.getStats();
		this.getInvoices(false);
		this.getApprovedInvoices(false);
		this.getAllInvoices(false);
	};

	getInvoices = isOverwriteExistingList => {
		// API call to get the pending invoices
		const { invoicesScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.invoiceLimit;
		queryParams.page = this.invoicePage;
		invoicesScreenActions.onGetInvoices(queryParams, isOverwriteExistingList);
	};

	getApprovedInvoices = isOverwriteExistingList => {
		// API call to get the approved invoices.
		const { invoicesScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.approvedInvoiceLimit;
		queryParams.page = this.approvedInvoicePage;
		invoicesScreenActions.onGetApprovedInvoices(queryParams, isOverwriteExistingList);
	};

	getAllInvoices = isOverwriteExistingList => {
		// API call to get the all invoices.
		const { invoicesScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.allInvoiceLimit;
		queryParams.page = this.allInvoicePage;
		invoicesScreenActions.onGetAllInvoices(queryParams, isOverwriteExistingList);
	};

	getLayout = (data, index) => ({
		// To Get length and offset for Scroll To Index Functionality
		length: verticalScale(60),
		offset: verticalScale(60) * index,
		index,
	});

	getStats() {
		// API call to get the amount.
		const { invoicesScreenActions } = this.props;
		invoicesScreenActions.onGetStats();
	}

	onEndReachedPendingInvoice = () => {
		const { invoiceScreenInfo } = this.props;
		const { loader } = invoiceScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.invoicePage += getPage(this.invoiceLimit);
			this.invoiceLimit = fetchDataWithPagination.limit;
			this.getInvoices(true);
		}
	};

	onEndReachedAllInvoice = () => {
		const { invoiceScreenInfo } = this.props;
		const { loader } = invoiceScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.allInvoicePage += getPage(this.allInvoiceLimit);
			this.allInvoiceLimit = fetchDataWithPagination.limit;
			this.getAllInvoices(true);
		}
	};

	onEndReachedApprovedInvoice = () => {
		const { invoiceScreenInfo } = this.props;
		const { loader } = invoiceScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.approvedInvoicePage += getPage(this.approvedInvoiceLimit);
			this.approvedInvoiceLimit = fetchDataWithPagination.limit;
			this.getApprovedInvoices(true);
		}
	};

	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		const { languageInfo, invoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { invoicesListing, invoicesCount } = invoiceScreenInfo;
		const endReached =
			invoicesCount === invoicesListing.length || invoicesCount < invoicesListing.length;
		if (!endReached) {
			return <ActivityIndicator size="small" color={colors.darkBlue} />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	listFooterComponentApproved = () => {
		const { languageInfo, invoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { approvedInvoicesListing, approvedInvoicesCount } = invoiceScreenInfo;
		const endReached =
			approvedInvoicesCount === approvedInvoicesListing.length ||
			approvedInvoicesCount < approvedInvoicesListing.length;
		if (!endReached) {
			return <ActivityIndicator size="small" color={colors.darkBlue} />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	listFooterComponentAll = () => {
		const { languageInfo, invoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { allInvoicesListing, allInvoicesCount } = invoiceScreenInfo;
		const endReached =
			allInvoicesCount === allInvoicesListing.length ||
			allInvoicesCount < allInvoicesListing.length;
		if (!endReached) {
			return <ActivityIndicator size="small" color={colors.darkBlue} />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onSelectTab = selectedTab => {
		// Will call API based on selected tab.
		if (this.itemListRef) {
			this.itemListRef.onSetIndex(0);
		}
		if (selectedTab === keyConstants.PENDING) {
			// If pending tab is selected.
			this.setState(
				{
					isTabAll: false,
					isTabPending: true,
					isTabApproved: false,
				},
				() => {
					this.invoicePage = fetchDataWithPagination.page;
					this.getInvoices(false);
				},
			);
		} else if (selectedTab === keyConstants.APPROVED) {
			// If approved tab is selected.
			this.setState(
				{
					isTabPending: false,
					isTabApproved: true,
					isTabAll: false,
				},
				() => {
					this.approvedInvoicePage = fetchDataWithPagination.page;
					this.getApprovedInvoices(false);
				},
			);
		} else {
			// If all tab is selected.
			this.setState(
				{
					isTabPending: false,
					isTabApproved: false,
					isTabAll: true,
				},
				() => {
					this.allInvoicePage = fetchDataWithPagination.page;
					this.getAllInvoices(false);
				},
			);
		}
	};

	renderInvoiceItem = ({ item, index }) => {
		const { inVoiceSelectedList } = this.state;
		const { languageInfo, userDetails } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		return (
			<View style={styles.productContainer}>
				<InvoiceCardComponent
					name={
						item.type === salesInvoice
							? localeString(keyConstants.NANA_BUSINESS)
							: item.vendor_org_name
					}
					invoiceId={`(${item.invoice_no})`}
					date={getFormattedDate(item.created_at)}
					amount={`${currencyFormatter(
						getValueInDecimal(item.invoice_total),
					)} ${localeString(keyConstants.SAR)}`}
					showCheckBox={role === customerAdmin}
					selectedItem={inVoiceSelectedList}
					id={item.id}
					isDisable={false}
					onPress={() =>
						this.onGetDetail(
							item.id,
							`${item.invoice_no}`,
							item.type === salesInvoice
								? localeString(keyConstants.NANA_BUSINESS)
								: item.owner_name,
							item.type,
							index,
						)
					}
					onSelect={() => this.onSelect(item.id)}
				/>
			</View>
		);
	};

	renderApprovedInvoiceItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.productContainer}>
				<InvoiceCardComponent
					name={
						item.type === salesInvoice
							? localeString(keyConstants.NANA_BUSINESS)
							: item.vendor_org_name
					}
					invoiceId={`(${item.invoice_no})`}
					date={getFormattedDate(item.created_at)}
					amount={`${currencyFormatter(
						getValueInDecimal(item.invoice_total),
					)} ${localeString(keyConstants.SAR)}`}
					id={item.id}
					isDisable={false}
					onPress={() =>
						this.onGetDetail(
							item.id,
							`${item.invoice_no}`,
							item.type === salesInvoice
								? localeString(keyConstants.NANA_BUSINESS)
								: item.owner_name,
							item.type,
							index,
						)
					}
				/>
			</View>
		);
	};

	renderAllInvoiceItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.productContainer}>
				<InvoiceCardComponent
					id={item.id}
					invoiceId={`(${item.invoice_no})`}
					name={
						item.type === salesInvoice
							? localeString(keyConstants.NANA_BUSINESS)
							: item.vendor_org_name
					}
					status={item.status}
					isShowStatus
					date={getFormattedDate(item.created_at)}
					amount={`${currencyFormatter(
						getValueInDecimal(item.invoice_total),
					)} ${localeString(keyConstants.SAR)}`}
					isDisable={false}
					onPress={() =>
						this.onGetDetail(
							item.id,
							`${item.invoice_no}`,
							item.type === salesInvoice
								? localeString(keyConstants.NANA_BUSINESS)
								: item.owner_name,
							item.type,
							index,
						)
					}
				/>
			</View>
		);
	};

	onSelect = id => {
		// Will select multiple invoices.
		const { inVoiceSelectedList } = this.state;
		const inVoiceSelectedListCopy = inVoiceSelectedList;
		if (inVoiceSelectedListCopy.includes(id)) {
			const itemIndex = inVoiceSelectedListCopy.indexOf(id);
			inVoiceSelectedListCopy.splice(itemIndex, 1);
		} else {
			inVoiceSelectedListCopy.push(id);
		}
		this.setState({
			inVoiceSelectedList: inVoiceSelectedListCopy,
		});
	};

	onPressReject = () => {
		// API call to reject the invoice.
		const { inVoiceSelectedList } = this.state;
		const { invoicesScreenActions } = this.props;
		const queryParams = {};
		queryParams.invoices_ids = inVoiceSelectedList;
		invoicesScreenActions.onRejectInvoices(queryParams);
	};

	onPressApprove = () => {
		// API call to approve the invoice.
		const { inVoiceSelectedList } = this.state;
		const { invoicesScreenActions } = this.props;
		const queryParams = {};
		queryParams.invoices_ids = inVoiceSelectedList;
		invoicesScreenActions.onApproveInvoices(queryParams);
	};

	onGetDetail = (id, headerTitle, ownerName, invoiceType, index) => {
		// Will navigate to the invoice detail screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.INVOICE_DETAIL_NAVIGATION, {
			id,
			index,
			headerTitle,
			ownerName,
			isPayNowButton: false,
			invoiceType,
		});
	};

	onRefresh = () => {
		// Will call api's while pull to refresh.
		this.invoiceLimit = fetchDataWithPagination.limit;
		this.approvedInvoiceLimit = fetchDataWithPagination.limit;
		this.allInvoiceLimit = fetchDataWithPagination.limit;
		if (isToggleFeatureEnable) {
			// Will call toggle feature API.
			this.toggleFeature.getToggleFeatures();
		} else {
			this.onFetchData(); // Will call invoice API.
		}
	};

	onListRefresh = () => {
		const { pullToRefreshActions } = this.props;
		pullToRefreshActions.onHandlePullToRefresh(false);
		this.invoiceLimit = fetchDataWithPagination.limit;
		this.approvedInvoiceLimit = fetchDataWithPagination.limit;
		this.allInvoiceLimit = fetchDataWithPagination.limit;
	};

	renderApprovedTab = () => {
		const { languageInfo, invoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			approvedInvoicesListing,
			approvedInvoicesCount,
			error,
			errorCode,
			isApproveInvoices,
			isRejectInvoices,
		} = invoiceScreenInfo;
		return error && !isApproveInvoices && !isRejectInvoices ? (
			<ErrorComponent // Error component if api fails.
				isRTL={isRTL}
				errorCode={errorCode}
				onCallApi={() => this.getApprovedInvoices(false)}
			/>
		) : (
			<ScrollViewComponent
				showsVerticalScrollIndicator={false}
				data={approvedInvoicesListing}
				renderItem={this.renderApprovedInvoiceItem}
				keyExtractor={this.keyExtractor}
				onEndReached={() =>
					approvedInvoicesListing.length !== approvedInvoicesCount &&
					this.onEndReachedApprovedInvoice()
				}
				ListFooterComponent={
					approvedInvoicesListing.length !== 0 &&
					approvedInvoicesCount > fetchDataWithPagination.limit &&
					this.listFooterComponentApproved()
				}
				onEndReachedThreshold={0.5}
				ListEmptyComponent={() => (
					<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
				)}
				contentContainerStyle={
					approvedInvoicesListing.length === 0 ? styles.scrollListStyle : null
				}
				componentType={constants.flatList}
				onRef={ref => {
					this.itemListRef = ref;
				}}
				getItemLayout={this.getLayout}
				onRefresh={this.onListRefresh}
			/>
		);
	};

	renderPendingTab = () => {
		const { languageInfo, invoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			invoicesListing,
			invoicesCount,
			error,
			errorCode,
			isApproveInvoices,
			isRejectInvoices,
		} = invoiceScreenInfo;
		return error && !isApproveInvoices && !isRejectInvoices ? (
			<ErrorComponent // Error component if api fails.
				isRTL={isRTL}
				errorCode={errorCode}
				onCallApi={() => this.getInvoices(false)}
			/>
		) : (
			<ScrollViewComponent
				showsVerticalScrollIndicator={false}
				data={invoicesListing}
				renderItem={this.renderInvoiceItem}
				keyExtractor={this.keyExtractor}
				onEndReached={() =>
					invoicesListing.length !== invoicesCount && this.onEndReachedPendingInvoice()
				}
				ListFooterComponent={
					invoicesListing.length !== 0 &&
					invoicesCount > fetchDataWithPagination.limit &&
					this.listFooterComponent()
				}
				onEndReachedThreshold={0.5}
				ListEmptyComponent={() => (
					<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
				)}
				contentContainerStyle={invoicesListing.length === 0 ? styles.scrollListStyle : null}
				componentType={constants.flatList}
				onRef={ref => {
					this.itemListRef = ref;
				}}
				getItemLayout={this.getLayout}
				onRefresh={this.onListRefresh}
			/>
		);
	};

	renderAllTab = () => {
		const { languageInfo, invoiceScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			allInvoicesListing,
			allInvoicesCount,
			error,
			errorCode,
			isApproveInvoices,
			isRejectInvoices,
		} = invoiceScreenInfo;
		return error && !isApproveInvoices && !isRejectInvoices ? (
			<ErrorComponent // Error component if api fails.
				isRTL={isRTL}
				errorCode={errorCode}
				onCallApi={() => this.getAllInvoices(false)}
			/>
		) : (
			<ScrollViewComponent
				showsVerticalScrollIndicator={false}
				data={allInvoicesListing}
				renderItem={this.renderAllInvoiceItem}
				keyExtractor={this.keyExtractor}
				onEndReached={() =>
					allInvoicesListing.length !== allInvoicesCount && this.onEndReachedAllInvoice()
				}
				ListFooterComponent={
					allInvoicesListing.length !== 0 &&
					allInvoicesCount > fetchDataWithPagination.limit &&
					this.listFooterComponentAll()
				}
				onEndReachedThreshold={0.5}
				ListEmptyComponent={() => (
					<ListEmpty text={localeString(keyConstants.NO_INVOICES_FOUND)} />
				)}
				contentContainerStyle={
					allInvoicesListing.length === 0 ? styles.scrollListStyle : null
				}
				componentType={constants.flatList}
				onRef={ref => {
					this.itemListRef = ref;
				}}
				getItemLayout={this.getLayout}
				onRefresh={this.onListRefresh}
			/>
		);
	};

	render() {
		const {
			languageInfo,
			invoiceScreenInfo,
			refreshControlComponentInfo,
			toggleFeaturesInfo,
			navigation,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			isTabPending,
			isTabApproved,
			isTabAll,
			inVoiceSelectedList,
			bottomLoader,
			toastMessage,
			isApiError,
		} = this.state;
		const {
			loader,
			issuedAmount,
			dueAmount,
			isApproveInvoicesLoader,
			isRejectInvoicesLoader,
		} = invoiceScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { loader: toggleApiLoader } = toggleFeaturesInfo;
		const { isConnected } = this.props;
		return (
			<View style={styles.container}>
				<NoConnectionHandle />
				{((loader && isApproveInvoicesLoader) || (loader && isRejectInvoicesLoader)) && (
					<Spinner size="large" />
				)}
				<View style={styles.header}>
					<Header
						style={styles.invoicesListContainer}
						text={`${localeString(keyConstants.COLL_REQUESTS)}`}
						hasIconInvoices
					/>
				</View>
				{(loader || toggleApiLoader) &&
				!isFetchingForPullToRefresh &&
				!bottomLoader &&
				!(isApproveInvoicesLoader || isRejectInvoicesLoader) ? (
					<View style={styles.shimmerStyle}>
						<PaidAmountContainerShimmer isRTL={isRTL} />
						<DueAmountContainerShimmer isRTL={isRTL} />
						<TabContainerShimmer isRTL={isRTL} />
						<FlatList
							data={['', '', '', '', '']}
							showsVerticalScrollIndicator={false}
							renderItem={() => {
								return <InvoiceListingShimmer isRTL={isRTL} />;
							}}
							keyExtractor={this.keyExtractor}
						/>
					</View>
				) : (
					<>
						<ScrollViewComponent
							showsVerticalScrollIndicator={false}
							contentContainerStyle={
								inVoiceSelectedList.length !== 0 && isTabPending
									? styles.scrollViewWithMoremargin
									: styles.scrollView
							}
							onRefresh={this.onRefresh}
							componentType={constants.scrollView}>
							<View style={styles.issuedAmountContainer}>
								<Text style={styles.issuedAmountValueText}>
									{`${currencyFormatter(
										getValueInDecimal(issuedAmount),
									)} ${localeString(keyConstants.SAR)}`}
								</Text>
								<Text style={styles.issuedAmountText}>
									{localeString(keyConstants.PAID_AMOUNT)}
								</Text>
							</View>
							<DueAmountContainer
								isRTL={isRTL}
								title={localeString(keyConstants.DUE_AMOUNT)}
								amount={dueAmount} // Due amount of all the collection requests
							/>
							<View style={styles.invoicesListContainer}>
								<View style={styles.tabContainer}>
									<TouchableOpacity
										style={isTabAll ? styles.selectedTab : styles.unselectedTab}
										onPress={() => this.onSelectTab(keyConstants.ALL)}>
										<Text
											style={
												isTabAll
													? styles.selectedTabText
													: styles.unselectedTabText
											}>
											{localeString(keyConstants.ALL)}
										</Text>
									</TouchableOpacity>
									<TouchableOpacity
										style={
											isTabPending ? styles.selectedTab : styles.unselectedTab
										}
										onPress={() => this.onSelectTab(keyConstants.PENDING)}>
										<Text
											style={
												isTabPending
													? styles.selectedTabText
													: styles.unselectedTabText
											}>
											{localeString(keyConstants.PENDING)}
										</Text>
									</TouchableOpacity>
									<TouchableOpacity
										style={
											isTabApproved
												? styles.selectedTab
												: styles.unselectedTab
										}
										onPress={() => this.onSelectTab(keyConstants.APPROVED)}>
										<Text
											style={
												isTabApproved
													? styles.selectedTabText
													: styles.unselectedTabText
											}>
											{localeString(keyConstants.APPROVED)}
										</Text>
									</TouchableOpacity>
								</View>
								{isTabPending
									? //  pendingInvoice List
									  this.renderPendingTab()
									: isTabApproved
									? //  ApprovedInvoice List
									  this.renderApprovedTab()
									: // For All List
									  this.renderAllTab()}
							</View>
						</ScrollViewComponent>
						{inVoiceSelectedList.length !== 0 && isTabPending && (
							<View style={styles.bottomContainer}>
								<View style={styles.buttonContainerReject}>
									<ButtonComponent
										buttonStyle={styles.btnReject}
										text={localeString(keyConstants.REJECT)}
										textStyle={styles.btnLabelReject}
										onPress={this.onPressReject}
									/>
								</View>
								<View style={styles.buttonContainerAccept}>
									<ButtonComponent
										buttonStyle={styles.btnAccept}
										text={localeString(keyConstants.APPROVE)}
										textStyle={styles.btnLabelAccept}
										onPress={this.onPressApprove}
									/>
								</View>
							</View>
						)}
						<ToggleFeatureScreen
							navigation={navigation}
							onRef={ref => {
								this.toggleFeature = ref;
							}}
							isDefaultApiCalling={isToggleFeatureEnable} // Boolean to call the toggle feature API.
							isConnected={isConnected}
						/>
					</>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		invoiceScreenInfo: state.InvoicesScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		isConnected: state.NoConnectionHandleReducer.isConnected,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		invoicesScreenActions: bindActionCreators({ ...InvoicesScreenAction }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

InvoicesScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	invoiceScreenInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	invoicesScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	isConnected: PropTypes.bool.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(InvoicesScreen);
