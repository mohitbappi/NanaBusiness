import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import GetStatsService from '@GetStats/GetStatsService';
import GetInvoicesService from '@Invoices/GetInvoicesService';
import GetApprovedInvoicesService from '@Invoices/GetApprovedInvoicesService';
import GetAllInvoicesService from '@Invoices/GetAllInvoicesService';
import ApproveInvoicesService from '@Invoices/ApproveInvoicesService';
import RejectInvoicesService from '@Invoices/RejectInvoicesService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

// Action to reset the reducer.
export const onResetInvoiceState = () => ({ type: ActionTypes.RESET_INVOICES_STATE });

/**
 * Aciton to get the pending invoices.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_RETAILER_INVOICES_SUCCESS,
		ActionTypes.GET_RETAILER_INVOICES_FAILURE,
		ActionTypes.GET_RETAILER_INVOICES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getInvoicesService = new GetInvoicesService(dispatchedActions);
	addBasicInterceptors(getInvoicesService);
	getInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getInvoicesService.makeRequest(props));
};

/**
 * Aciton to get the approved invoices.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetApprovedInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_APPROVED_INVOICES_SUCCESS,
		ActionTypes.GET_RETAILER_INVOICES_FAILURE,
		ActionTypes.GET_RETAILER_INVOICES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getApprovedInvoicesService = new GetApprovedInvoicesService(dispatchedActions);
	addBasicInterceptors(getApprovedInvoicesService);
	getApprovedInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getApprovedInvoicesService.makeRequest(props));
};

/**
 * Aciton to get the all invoices.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetAllInvoices = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ALL_INVOICES_SUCCESS,
		ActionTypes.GET_RETAILER_INVOICES_FAILURE,
		ActionTypes.GET_RETAILER_INVOICES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getAllInvoicesService = new GetAllInvoicesService(dispatchedActions);
	addBasicInterceptors(getAllInvoicesService);
	getAllInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getAllInvoicesService.makeRequest(props));
};

/**
 * Action to get the amount details.
 * @param {object} props
 * @returns
 */

export const onGetStats = props => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_STATS_SUCCESS,
		ActionTypes.GET_RETAILER_INVOICES_FAILURE,
		ActionTypes.GET_RETAILER_INVOICES_LOADER,
	).build();
	const getStatsService = new GetStatsService(dispatchedActions);
	addBasicInterceptors(getStatsService);
	getStatsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getStatsService.makeRequest(props));
};

/**
 * Action to approve the multiple invoices.
 * @param {object} inVoiceSelectedList
 * @returns
 */

export const onApproveInvoices = inVoiceSelectedList => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.APPROVE_INVOICES_SUCCESS,
		ActionTypes.APPROVE_INVOICES_FAILURE,
		ActionTypes.APPROVE_INVOICES_LOADER,
	);
	const approveInvoicesService = new ApproveInvoicesService(dispatchedActions);
	addBasicInterceptors(approveInvoicesService);
	approveInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(approveInvoicesService.makeRequest(inVoiceSelectedList));
};

/**
 * Action to reject the multiple invoices.
 * @param {object} inVoiceSelectedList
 * @returns
 */

export const onRejectInvoices = inVoiceSelectedList => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.REJECT_INVOICES_SUCCESS,
		ActionTypes.REJECT_INVOICES_FAILURE,
		ActionTypes.REJECT_INVOICES_LOADER,
	);
	const rejectInvoicesService = new RejectInvoicesService(dispatchedActions);
	addBasicInterceptors(rejectInvoicesService);
	rejectInvoicesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(rejectInvoicesService.makeRequest(inVoiceSelectedList));
};
