import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		header: {
			height: verticalScale(40),
			backgroundColor: colors.white,
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingHorizontal: normalScale(16),
		},
		shimmerStyle: {
			flex: 1,
		},
		issuedAmountContainer: {
			width: '100%',
			height: verticalScale(80),
			alignItems: 'center',
			backgroundColor: colors.lightGreen,
			justifyContent: 'center',
			marginBottom: verticalScale(4),
		},
		invoicesListContainer: {
			flex: 1,
			paddingHorizontal: normalScale(16),
		},
		issuedAmountValueText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(20),
			alignSelf: 'center',
		},
		issuedAmountText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
			alignSelf: 'center',
		},
		scrollView: {
			flex: 1,
			marginBottom: verticalScale(8),
		},
		scrollViewWithMoremargin: {
			flex: 1,
			marginBottom: verticalScale(60),
		},
		image: {
			width: normalScale(48),
			height: verticalScale(48),
			resizeMode: 'contain',
		},
		pending: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(12),
		},
		tabContainer: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			marginTop: verticalScale(16),
		},
		selectedTab: {
			height: verticalScale(24),
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
			borderRadius: verticalScale(12),
			backgroundColor: colors.black,
			alignItems: 'center',
			justifyContent: 'center',
			paddingHorizontal: verticalScale(15),
			marginRight: isRTL ? 0 : normalScale(16),
			marginLeft: isRTL ? normalScale(16) : 0,
		},
		unselectedTab: {
			height: verticalScale(24),
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
			borderRadius: verticalScale(12),
			backgroundColor: colors.whitishGrey,
			alignItems: 'center',
			justifyContent: 'center',
			paddingHorizontal: verticalScale(15),
			marginRight: isRTL ? 0 : normalScale(16),
			marginLeft: isRTL ? normalScale(16) : 0,
		},
		selectedTabText: {
			color: colors.white,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		unselectedTabText: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
		},
		bottomContainer: {
			flex: 1,
			flexDirection: isRTL ? 'row-reverse' : 'row',
			alignItems: 'center',
			justifyContent: 'center',
			backgroundColor: colors.white,
			marginBottom: verticalScale(4),
			paddingHorizontal: normalScale(16),
			position: 'absolute',
			bottom: 0,
			left: 0,
			right: 0,
		},
		buttonContainerReject: {
			flex: 1,
			marginEnd: normalScale(8),
		},
		buttonContainerAccept: {
			flex: 1,
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		btnReject: {
			flex: 1,
			borderRadius: normalScale(8),
			backgroundColor: colors.white,
			borderStyle: 'solid',
			borderWidth: normalScale(1),
			borderColor: colors.lightGrey,
			shadowColor: colors.lightShadowGrey,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			shadowOpacity: 0,
			elevation: verticalScale(0),
		},
		btnAccept: {
			flex: 1,
			borderRadius: normalScale(8),
			backgroundColor: colors.darkBlue,
		},
		btnLabelReject: {
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
			letterSpacing: normalScale(0),
			color: colors.darkBlack,
		},
		btnLabelAccept: {
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
			letterSpacing: normalScale(0),
			color: colors.white,
		},
		scrollListStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
