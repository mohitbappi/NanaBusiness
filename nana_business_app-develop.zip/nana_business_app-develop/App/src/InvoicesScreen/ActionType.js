export const STORE_USER_DETAILS = 'store_user_details';
export const GET_RETAILER_INVOICES_SUCCESS = 'get_retailer_invoices_success';
export const GET_RETAILER_INVOICES_FAILURE = 'get_retailer_invoices_failure';
export const GET_RETAILER_INVOICES_LOADER = 'get_retailer_invoices_loader';

export const RESET_INVOICES_STATE = 'reset_invoices_state';

export const GET_APPROVED_INVOICES_SUCCESS = 'get_approved_invoices_success';
export const GET_APPROVED_INVOICES_FAILURE = 'get_approved_invoices_failure';
export const GET_APPROVED_INVOICES_LOADER = 'get_approved_invoices_loader';

export const GET_ALL_INVOICES_SUCCESS = 'get_all_invoices_success';
export const GET_ALL_INVOICES_FAILURE = 'get_all_invoices_failure';
export const GET_ALL_INVOICES_LOADER = 'get_all_invoices_loader';

export const GET_STATS_SUCCESS = 'get_stats_success';
export const GET_STATS_FAILURE = 'get_stats_failure';
export const GET_STATS_LOADER = 'get_stats_loader';

export const APPROVE_INVOICES_SUCCESS = 'approve_invoices_success';
export const APPROVE_INVOICES_FAILURE = 'approve_invoices_failure';
export const APPROVE_INVOICES_LOADER = 'approve_invoices_loader';

export const REJECT_INVOICES_SUCCESS = 'reject_invoices_success';
export const REJECT_INVOICES_FAILURE = 'reject_invoices_failure';
export const REJECT_INVOICES_LOADER = 'reject_invoices_loader';
