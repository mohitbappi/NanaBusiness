export const ON_CHANGE_EXISTING_ACC_TEXT = 'on_change_existing_acc_text';
export const RESET_EXISTING_ACC_STATE = 'reset_existing_acc_state';
export const ADD_COMPANY_DETAILS_SUCCESS = 'add_company_details_success';
export const ADD_COMPANY_DETAILS_FAILURE = 'add_company_details_failure';
export const ADD_COMPANY_DETAILS_LOADER = 'add_company_details_loader';
export const ONBOARD_EXISTING_ORGANIZATION_SUCCESS = 'onboard_existing_organization_success';
export const ONBOARD_EXISTING_ORGANIZATION_FAILURE = 'onboard_existing_organization_failure';
export const ONBOARD_EXISTING_ORGANIZATION_LOADER = 'onboard_existing_organization_loader';
