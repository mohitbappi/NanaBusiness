import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AddCompanyDetailsService from '@SignUp/AddCompanyDetailsService';
import OnboardExistingOrganizationService from '@SignUp/OnboardExistingOrganizationService';
import OtpAuthenticationHeaderInterceptor from '@interceptor/OtpAuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_EXISTING_ACC_TEXT,
		payload: text,
		field,
	};
};

export const onResetAccountState = () => ({ type: ActionTypes.RESET_EXISTING_ACC_STATE });

export const onAddCompanyDetails = companyDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ADD_COMPANY_DETAILS_SUCCESS,
		ActionTypes.ADD_COMPANY_DETAILS_FAILURE,
		ActionTypes.ADD_COMPANY_DETAILS_LOADER,
	);
	const addCompanyDetailsService = new AddCompanyDetailsService(dispatchedActions);
	addBasicInterceptors(addCompanyDetailsService);
	addCompanyDetailsService.addRequestInterceptor(new OtpAuthenticationHeaderInterceptor());
	dispatch(addCompanyDetailsService.makeRequest(companyDetails));
};

export const onboardExistingOrganization = companyDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ONBOARD_EXISTING_ORGANIZATION_SUCCESS,
		ActionTypes.ONBOARD_EXISTING_ORGANIZATION_FAILURE,
		ActionTypes.ONBOARD_EXISTING_ORGANIZATION_LOADER,
	);
	const onboardExistingOrganizationService = new OnboardExistingOrganizationService(
		dispatchedActions,
	);
	addBasicInterceptors(onboardExistingOrganizationService);
	onboardExistingOrganizationService.addRequestInterceptor(
		new OtpAuthenticationHeaderInterceptor(),
	);
	dispatch(onboardExistingOrganizationService.makeRequest(companyDetails));
};
