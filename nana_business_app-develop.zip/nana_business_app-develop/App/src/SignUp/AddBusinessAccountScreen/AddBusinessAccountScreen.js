import React, { Component } from 'react';
import { View, Text, Keyboard } from 'react-native';
import { connect } from 'react-redux';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import {
	noSpaceAtStartRegexEx,
	companyNameMaxLength,
	crNumberRegex,
	crAlreadyExists,
	duplicateName,
	crNotFound,
	duplicateArabicName,
	otpVerificationToken,
	languageConstants,
	crNumberLength,
	noSpaceAtStartRegexExArabic,
} from '@Constants/Constants';
import { keyConstants } from '@Constants/KeyConstants';
import navigations from '@routes/navigations';
import OptionPicker from '@OptionPicker/OptionPicker';
import { businessTypeConstants } from '@SignUpNextScreen/SignUpConstants';
import Spinner from '@Spinner/Spinner';
import SignUpHeader from '@SignUpHeader/SignUpHeader';
import * as PersonalInfoScreenActions from '@PersonalInformationScreen/PersonalInformationScreenAction';
import * as OtpScreenActions from '@OTPScreen/OTPScreenAction';
import AsyncStorageUtil from '@AsyncStorage/AsyncStorageUtil';
import * as SignUpScreenActions from '@SignUpNextScreen/SignUpScreenAction';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import { checkStringWith } from '@Util/CheckStringWith';
import * as AddBusinessAccountScreenAction from './AddBusinessAccountScreenAction';
import { createStyleSheet } from './AddbusinessAccountScreenStyle';

class AddBusinessAccountScreen extends Component {
	constructor(props) {
		super(props);
		this.companyName = React.createRef(null);
		this.arabicCompanyName = React.createRef(null);
		this.isExisting = props.route.params.isExisting;
		this.state = {
			isErrorCRNumber: false,
			crErrorMessage: '',
			isErrorDuplicateName: false,
			duplicateNameErrorMessage: '',
			isErrorDuplicateArabicName: false,
			duplicateArabicNameErrorMessage: '',
			businessTypeSelectedIndex: null,
			isDropdownOpened: false,
			isDropdownVisible: false,
			isGetCompany: false,
		};
	}

	componentDidUpdate(prevProps) {
		const { addBusinessAccInfo, navigation, signUpScreenActions } = this.props;
		const {
			companyRegNumber,
			error,
			errorCode,
			success,
			isGetCompany,
			organizationDetails,
			isOnboarding,
			signUpToken,
		} = addBusinessAccInfo;
		const { name, name_ar } = organizationDetails || {};
		if (success && prevProps.addBusinessAccInfo.success !== addBusinessAccInfo.success) {
			if (!isGetCompany && !isOnboarding) {
				navigation.navigate(navigations.SIGN_UP_MAP_NAVIGATION);
				this.setState({
					isErrorCRNumber: false,
					crErrorMessage: '',
					isErrorDuplicateName: false,
					duplicateNameErrorMessage: '',
					isErrorDuplicateArabicName: false,
					duplicateArabicNameErrorMessage: '',
					isDropdownOpened: false,
				});
			} else if (isGetCompany) {
				this.onChangeText(name, 'companyName');
				this.onChangeText(name_ar, 'arabicCompanyName');
				this.setState({
					isGetCompany: true,
				});
			} else {
				signUpScreenActions.onSetSignUpToken(signUpToken);
				this.onResetReducer();
			}
		}
		if (error && prevProps.addBusinessAccInfo.error !== addBusinessAccInfo.error) {
			if (errorCode && errorCode.error && errorCode.error === crNotFound) {
				this.setState({
					isErrorCRNumber: true,
					crErrorMessage: localeString(keyConstants.CR_NOT_FOUND),
					isGetCompany: false,
				});
				this.onChangeText('', 'companyName');
				this.onChangeText('', 'arabicCompanyName');
			} else {
				errorCode.errors.forEach(element => {
					if (element.error === crAlreadyExists) {
						this.setState({
							isErrorCRNumber: true,
							crErrorMessage: localeString(keyConstants.CR_ALREADY_EXISTS),
						});
					}
					if (element.error === duplicateName) {
						this.setState({
							isErrorDuplicateName: true,
							duplicateNameErrorMessage: localeString(keyConstants.DUPLICATE_NAME),
						});
					}
					if (element.error === duplicateArabicName) {
						this.setState({
							isErrorDuplicateArabicName: true,
							duplicateArabicNameErrorMessage: localeString(
								keyConstants.DUPLICATE_ARABIC_NAME,
							),
						});
					}
				});
			}
		}
		if (!error && prevProps.addBusinessAccInfo !== addBusinessAccInfo) {
			if (crNumberRegex.test(companyRegNumber)) {
				this.setState({
					isErrorCRNumber: false,
					crErrorMessage: '',
				});
			}
		}
	}

	componentWillUnmount() {
		const { addBusinessAccountScreenAction } = this.props;
		addBusinessAccountScreenAction.onResetAccountState();
	}

	onGoSignIn = () => {
		this.onResetReducer();
	};

	onResetReducer = () => {
		const { personalInfoScreenActions, otpScreenActions } = this.props;
		personalInfoScreenActions.onResetPersonalInfoState();
		otpScreenActions.onResetOtpScreenState();
		otpScreenActions.onSetOtpToken('');
		this.onResetOTPAsync();
	};

	onResetOTPAsync = async () => {
		await new AsyncStorageUtil(otpVerificationToken).removeData();
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeText = (text, field) => {
		const { addBusinessAccountScreenAction } = this.props;
		addBusinessAccountScreenAction.onChangeText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = field => {
		const { addBusinessAccInfo } = this.props;
		const { companyRegNumber } = addBusinessAccInfo;
		if (field === 'companyRegNumber') {
			if (!crNumberRegex.test(String(companyRegNumber).toLowerCase())) {
				this.setState({
					isErrorCRNumber: true,
					crErrorMessage: localeString(keyConstants.MUST_BE_TEN_DIGITS),
					isGetCompany: false,
				});
				this.onChangeText('', 'companyName');
				this.onChangeText('', 'arabicCompanyName');
			} else if (this.isExisting) {
				this.onGetCompanyDetails();
			}
		}
	};

	onGetCompanyDetails = () => {
		const { addBusinessAccInfo, addBusinessAccountScreenAction } = this.props;
		const { companyRegNumber } = addBusinessAccInfo;
		const crNumberData = {
			crNumber: companyRegNumber,
		};
		addBusinessAccountScreenAction.onGetCompany(crNumberData);
	};

	onSubmit = () => {
		const { addBusinessAccInfo } = this.props;
		this.onDissmissKeyboard();
		const {
			companyRegNumber,
			companyName,
			arabicCompanyName,
			organizationDetails,
		} = addBusinessAccInfo;
		const { id } = organizationDetails || {};
		if (this.isExisting) {
			this.onboardExistingOrganization(id);
		} else {
			this.setState({
				isErrorCRNumber: false,
				isErrorDuplicateName: false,
				isErrorDuplicateArabicName: false,
			});
			this.onAddCompanyDetails(companyRegNumber, companyName, arabicCompanyName);
		}
	};

	onboardExistingOrganization = id => {
		const { languageInfo, addBusinessAccountScreenAction } = this.props;
		const { isRTL } = languageInfo;
		const companyDetails = {
			organization_id: id,
			lang: isRTL ? languageConstants.ar : languageConstants.en,
		};
		addBusinessAccountScreenAction.onboardExistingOrganization(companyDetails);
	};

	onAddCompanyDetails = (companyRegNumber, companyName, arabicCompanyName) => {
		const { addBusinessAccountScreenAction } = this.props;
		const companyDetails = {
			org_name: companyName,
			org_name_ar: arabicCompanyName,
			org_cr: companyRegNumber,
		};
		addBusinessAccountScreenAction.onAddCompanyDetails(companyDetails);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onCloseDropdown = () => {
		this.setState({
			isDropdownVisible: false,
		});
	};

	onSelectOption = index => {
		const { addBusinessAccountScreenAction } = this.props;
		this.onCloseDropdown();
		this.setState(
			{
				businessTypeSelectedIndex: index,
				isDropdownOpened: false,
			},
			() => {
				addBusinessAccountScreenAction.onChangeText(
					businessTypeConstants[index].key,
					'businessType',
				);
			},
		);
	};

	onPressDropdown = () => {
		const { isDropdownOpened } = this.state;
		this.onDissmissKeyboard();
		this.setState({
			isDropdownOpened: !isDropdownOpened,
			isDropdownVisible: true,
		});
	};

	render() {
		const { languageInfo, addBusinessAccInfo } = this.props;
		const {
			businessTypeSelectedIndex,
			isErrorCRNumber,
			crErrorMessage,
			isErrorDuplicateName,
			duplicateNameErrorMessage,
			isErrorDuplicateArabicName,
			duplicateArabicNameErrorMessage,
			isDropdownOpened,
			isDropdownVisible,
			isGetCompany,
		} = this.state;
		const { isRTL } = languageInfo;
		const { companyRegNumber, companyName, arabicCompanyName, loader } = addBusinessAccInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<>
				<OptionPicker
					title={localeString(keyConstants.SELECT_BUSINESS_TYPE)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={businessTypeConstants}
					provideLanguageSupport
					onClose={this.onCloseDropdown}
					onSelectOption={index => this.onSelectOption(index)}
					activeIndex={businessTypeSelectedIndex}
				/>
				<View style={styles.container}>
					{loader && <Spinner size="large" />}
					<View style={styles.headerContainer}>
						<SignUpHeader
							isRTL={isRTL}
							filledLevelLength={3}
							onGoBack={this.onGoBack}
							hasIconBack
						/>
					</View>
					<KeyboardAwareScrollView
						resetScrollToCoords={{ x: 10, y: 20 }}
						innerRef={ref => {
							this.scroll = ref;
						}}
						contentContainerStyle={styles.formContainer}
						keyboardShouldPersistTaps="handled">
						<View style={[styles.innerContainer, isDropdownOpened && styles.dropdown]}>
							<Text style={styles.joinTeamHeadingText}>
								{this.isExisting
									? localeString(keyConstants.JOIN_YOUR_TEAM)
									: localeString(keyConstants.NEW_BUSINESS_ACCOUNT)}
							</Text>
							<Text style={styles.personalInfoText}>
								{this.isExisting
									? localeString(keyConstants.JOIN_YOUR_TEAM_TEXT)
									: localeString(keyConstants.NEW_BUSINESS_ACCOUNT_TEXT)}
							</Text>
							<Input
								value={companyRegNumber}
								width={normalScale(260)}
								label={`${localeString(keyConstants.COMPANY_REG_NUMBER)}*`}
								placeholder={localeString(keyConstants.COMPANY_REG_NUMBER)}
								blurOnSubmit={this.isExisting}
								returnKeyType="done"
								isRTL={isRTL}
								onChangeText={text =>
									(checkStringWith(
										String(text).toLocaleLowerCase(),
										noSpaceAtStartRegexEx,
										noSpaceAtStartRegexExArabic,
										isRTL,
									) ||
										text === '') &&
									this.onChangeText(text, 'companyRegNumber')
								}
								onSubmitEditing={() => {
									if (!this.isExisting) {
										this.onSubmitRef(this.companyName);
									}
									this.onBlur('companyRegNumber');
								}}
								autoCapitalize="none"
								maxLength={crNumberLength}
								keyboardType="number-pad"
								isError={isErrorCRNumber}
								errorMessage={crErrorMessage}
							/>
							{(this.isExisting ? isGetCompany : true) && (
								<>
									<Input
										value={companyName}
										width={normalScale(260)}
										maxLength={companyNameMaxLength}
										label={`${localeString(keyConstants.COMPANY_ENG_NAME)}*`}
										placeholder={localeString(keyConstants.COMPANY_ENG_NAME)}
										blurOnSubmit={false}
										returnKeyType="next"
										onChangeText={text =>
											(noSpaceAtStartRegexEx.test(
												String(text).toLocaleLowerCase(),
											) ||
												text === '') &&
											this.onChangeText(text, 'companyName')
										}
										isRTL={isRTL}
										onSubmitEditing={() => {
											this.onSubmitRef(this.arabicCompanyName);
											this.onBlur('companyName');
										}}
										refs={this.refCallback(this.companyName)}
										autoCapitalize="none"
										isError={isErrorDuplicateName}
										errorMessage={duplicateNameErrorMessage}
										editable={!this.isExisting}
									/>
									<Input
										value={arabicCompanyName}
										width={normalScale(260)}
										maxLength={companyNameMaxLength}
										label={`${localeString(keyConstants.COMPANY_ARABIC_NAME)}*`}
										placeholder={localeString(keyConstants.COMPANY_ARABIC_NAME)}
										refs={this.refCallback(this.arabicCompanyName)}
										blurOnSubmit
										returnKeyType="done"
										onChangeText={text =>
											(noSpaceAtStartRegexExArabic.test(
												String(text).toLocaleLowerCase(),
											) ||
												text === '') &&
											this.onChangeText(text, 'arabicCompanyName')
										}
										isRTL={isRTL}
										autoCapitalize="none"
										isError={isErrorDuplicateArabicName}
										errorMessage={duplicateArabicNameErrorMessage}
										editable={!this.isExisting}
									/>
								</>
							)}
							{this.isExisting ? null : (
								<DropdownFieldComponent
									isRTL={isRTL}
									onPress={this.onPressDropdown}
									value={
										businessTypeSelectedIndex !== null
											? localeString(
													businessTypeConstants[businessTypeSelectedIndex]
														.name,
											  )
											: ''
									}
									label={`${localeString(keyConstants.BUSINESS_TYPE)}*`}
									placeholder={`${localeString(keyConstants.BUSINESS_TYPE)}`}
								/>
							)}
						</View>
					</KeyboardAwareScrollView>
					<ButtonComponent
						viewStyle={styles.buttonStyle}
						onPress={this.onSubmit}
						text={localeString(keyConstants.NEXT)}
						isButtonDisable={
							!(
								crNumberRegex.test(String(companyRegNumber).toLowerCase()) &&
								companyRegNumber &&
								companyName &&
								arabicCompanyName &&
								(this.isExisting ? true : businessTypeSelectedIndex != null)
							)
						}
					/>
				</View>
			</>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		addBusinessAccInfo: state.AddBusinessAccountScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		addBusinessAccountScreenAction: bindActionCreators(
			{ ...AddBusinessAccountScreenAction },
			dispatch,
		),
		personalInfoScreenActions: bindActionCreators({ ...PersonalInfoScreenActions }, dispatch),
		otpScreenActions: bindActionCreators({ ...OtpScreenActions }, dispatch),
		signUpScreenActions: bindActionCreators({ ...SignUpScreenActions }, dispatch),
	};
};

AddBusinessAccountScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	addBusinessAccInfo: PropTypes.object.isRequired,
	addBusinessAccountScreenAction: PropTypes.object.isRequired,
	personalInfoScreenActions: PropTypes.object.isRequired,
	otpScreenActions: PropTypes.object.isRequired,
	signUpScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(AddBusinessAccountScreen);
