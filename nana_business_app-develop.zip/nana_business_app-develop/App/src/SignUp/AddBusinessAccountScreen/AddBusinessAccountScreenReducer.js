import { saveSignUpCompleteToken, onAddSignUpRequestType } from '@Util/SaveMasterData';
import { REQUEST_TYPE } from '@Constants/Constants';
import * as ActionTypes from './ActionType';

const initialState = {
	companyRegNumber: '',
	companyName: '',
	arabicCompanyName: '',
	businessType: '',
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	isGetCompany: false,
	organizationDetails: null,
	isOnboarding: false,
	signUpToken: null,
};

const AddBusinessAccountScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_EXISTING_ACC_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.RESET_EXISTING_ACC_STATE:
			return initialState;
		case ActionTypes.ADD_COMPANY_DETAILS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				isGetCompany: false,
				isOnboarding: false,
			};
		case ActionTypes.ADD_COMPANY_DETAILS_LOADER:
		case ActionTypes.GET_COMPANY_LOADER:
		case ActionTypes.ONBOARD_EXISTING_ORGANIZATION_LOADER:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: true,
			};
		case ActionTypes.ADD_COMPANY_DETAILS_FAILURE:
		case ActionTypes.GET_COMPANY_FAILURE:
		case ActionTypes.ONBOARD_EXISTING_ORGANIZATION_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
			};
		case ActionTypes.GET_COMPANY_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				organizationDetails: action.payload.orgainzation,
				isGetCompany: true,
				isOnboarding: false,
			};
		case ActionTypes.ONBOARD_EXISTING_ORGANIZATION_SUCCESS:
			saveSignUpCompleteToken(
				action.payload && action.payload.row ? action.payload.row.access_token : null,
			);
			onAddSignUpRequestType(REQUEST_TYPE.userRequest); // Adding signup request type in async storage.
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				isGetCompany: false,
				isOnboarding: true,
				signUpToken:
					action.payload && action.payload.row ? action.payload.row.access_token : null,
			};
		default:
			return state;
	}
};

export default AddBusinessAccountScreenReducer;
