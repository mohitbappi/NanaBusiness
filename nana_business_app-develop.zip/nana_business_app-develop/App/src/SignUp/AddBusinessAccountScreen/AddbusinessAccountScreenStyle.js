import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginBottom: verticalScale(27),
		},
		signUpLevelContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignSelf: rtlFunctions.getAlignmentInFlex(isRTL),
		},
		signUpLevelComplete: {
			width: normalScale(20),
			height: verticalScale(2),
			marginHorizontal: normalScale(2),
			backgroundColor: colors.darkBlue,
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		formContainer: {
			backgroundColor: colors.white,
		},
		innerContainer: {
			paddingHorizontal: normalScale(30),
			paddingBottom: verticalScale(80),
		},
		dropdown: {
			paddingBottom: verticalScale(230),
		},
		joinTeamHeadingText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(20),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		personalInfoText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			marginTop: verticalScale(13),
			marginBottom: verticalScale(14),
		},
		buttonStyle: {
			position: 'absolute',
			left: normalScale(25),
			right: normalScale(25),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(24),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
