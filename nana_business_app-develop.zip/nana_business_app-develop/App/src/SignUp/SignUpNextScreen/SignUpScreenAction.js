import { actions } from '@libapi/APIActionsBuilder';
import SignUpService from '@SignUp/SignUpService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import OtpAuthenticationHeaderInterceptor from '@interceptor/OtpAuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to set entered inputfield text in respective values in reducer
 * @param {string} text
 * @param {string} field
 */
export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_SIGN_UP_TEXT,
		payload: text,
		field,
	};
};

// Action to reset signup screen reducer
export const onResetSignUpState = () => ({ type: ActionTypes.RESET_SIGN_UP_STATE });

/**
 * Action to call signup api
 * @param {object} signUpDetails
 */
export const onPerformSignUp = signUpDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SIGN_UP_SUCCESS,
		ActionTypes.SIGN_UP_FAILURE,
		ActionTypes.SIGN_UP_LOADER,
	);
	const signUpService = new SignUpService(dispatchedActions);
	addBasicInterceptors(signUpService);
	signUpService.addRequestInterceptor(new OtpAuthenticationHeaderInterceptor());
	dispatch(signUpService.makeRequest(signUpDetails));
};

/**
 * Action to set latitude and longitude
 * @param {float} lat
 * @param {float} long
 */
export const onAddLatLong = (lat, long) => {
	return {
		type: ActionTypes.ADD_LAT_LONG,
		payload: { lat, long },
	};
};

/**
 * Action to set signup token
 * @param {string} token
 */
export const onSetSignUpToken = token => {
	return {
		type: ActionTypes.SET_SIGN_UP_TOKEN,
		payload: token,
	};
};
