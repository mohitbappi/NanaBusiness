import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		mapContainer: {
			flex: 1,
		},
		map: {
			flex: 1,
		},
		markerImage: {
			width: normalScale(56),
			height: verticalScale(69),
			zIndex: 3,
			position: 'absolute',
			marginTop: -verticalScale(37),
			marginLeft: -normalScale(21),
			left: '50%',
			top: '50%',
		},
		searchBarContainer: {
			zIndex: 3,
			flex: 1,
			paddingHorizontal: normalScale(10),
			paddingVertical: verticalScale(10),
			width: normalScale(280),
			position: 'absolute',
			left: normalScale(35),
			top: normalScale(0),
		},
		backMapButton: {
			position: 'absolute',
			left: normalScale(20),
			top: normalScale(20),
		},
		iconBack: {
			height: verticalScale(12),
			width: normalScale(10),
			transform: rtlFunctions.getTransformOpposite(isRTL),
		},
		buttonMapStyle: {
			position: 'absolute',
			left: normalScale(30),
			right: normalScale(30),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(60),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingTop: verticalScale(21),
		},
		headerContainer: {
			width: normalScale(320),
		},
		backButton: {
			marginHorizontal: normalScale(30),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		signupFormContainer: {
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(30),
			paddingBottom: verticalScale(76),
		},
		signUpHeadingText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(30),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		personalInfoText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			marginTop: verticalScale(11),
		},
		signUpFinalMapView: {
			width: normalScale(260),
			height: verticalScale(120),
			marginTop: verticalScale(24),
		},
		mapSmall: {
			width: normalScale(260),
			height: verticalScale(120),
			borderRadius: normalScale(8),
		},
		textStyle: {
			color: colors.lightWhite,
			paddingVertical: verticalScale(5),
		},
		acceptView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			alignItems: 'center',
			marginTop: verticalScale(16),
		},
		imageStyle: {
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(15),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.6,
			elevation: verticalScale(15),
		},
		checkBoxImage: {
			width: normalScale(18),
			height: verticalScale(18),
		},
		acceptText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		underline: {
			textDecorationLine: 'underline',
		},
		buttonStyle: {
			position: 'absolute',
			left: normalScale(25),
			right: normalScale(25),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(24),
			backgroundColor: colors.white,
		},
		formContainer: {
			backgroundColor: colors.white,
			paddingTop: verticalScale(17),
		},
		innerContainer: {
			paddingHorizontal: normalScale(30),
			paddingBottom: verticalScale(80),
		},
	});
};

export default createStyleSheet;
