import React, { Component } from 'react';
import { View, Text, Keyboard, ScrollView, TouchableOpacity } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import MapView, { Marker } from 'react-native-maps';
import { localeString } from '@assets/Localization';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { addressMaxLength, otpVerificationToken, languageConstants } from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import navigations from '@routes/navigations';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import AsyncStorageUtil from '@AsyncStorage/AsyncStorageUtil';
import * as PersonalInfoScreenActions from '@PersonalInformationScreen/PersonalInformationScreenAction';
import * as OtpScreenActions from '@OTPScreen/OTPScreenAction';
import * as AddBusinessAccountScreenAction from '@AddBusinessAccountScreen/AddBusinessAccountScreenAction';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import Header from '@Header/Header';
import * as SignUpScreenActions from './SignUpScreenAction';
import { createStyleSheet } from './SignUpScreenStyle';

class SignUpNextScreen extends Component {
	constructor(props) {
		super(props);
		this.addressLine = React.createRef(null);
		this.addressInformation = React.createRef(null);
		const { region } = props.route.params;
		this.region = region;
		this.state = {
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('blur', () => {
			this.setState({
				isApiError: false,
				toastMessage: '',
			});
		});
	}

	componentDidUpdate(prevProps) {
		const { signUpInfo } = this.props;
		const { success, error, errorCode } = signUpInfo;
		if (success && prevProps.signUpInfo.success !== success) {
			// if user signed up successfully
			this.onGoSignIn();
		}
		if (error && prevProps.signUpInfo.error !== signUpInfo.error) {
			ErrorAlertComponent(errorCode, this.onSubmit); // Will show alert if signup api fails.
		}
	}

	onChangeText = (text, field) => {
		const { signUpScreenActions } = this.props;
		signUpScreenActions.onChangeText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	openTermsAndCondition = () => {
		// Navigate to Terms and condition screen
		const { navigation } = this.props;
		navigation.navigate(navigations.TERMS_AND_CONDITION_NAVIGATION);
	};

	onSubmit = () => {
		// Call signup api
		const { signUpInfo, languageInfo, signUpScreenActions, personalInfo } = this.props;
		const { addressLine, addressInformation, city } = signUpInfo;
		const { latitude, longitude } = this.region;
		const { companyRegNumber, companyName, arabicCompanyName, businessType } = personalInfo;
		const { isRTL } = languageInfo;
		this.onDissmissKeyboard();
		const signUpDetails = {
			orgName: companyName,
			name_ar: arabicCompanyName,
			address_one: addressLine,
			address_two: addressInformation,
			latitude,
			longitude,
			city,
			cr: companyRegNumber,
			business_type: businessType,
			lang: isRTL ? languageConstants.ar : languageConstants.en,
		};
		signUpScreenActions.onPerformSignUp(signUpDetails);
	};

	onGoSignIn = () => {
		this.onResetReducer();
	};

	onResetReducer = () => {
		const { personalInfoScreenActions, otpScreenActions } = this.props;
		personalInfoScreenActions.onResetPersonalInfoState();
		otpScreenActions.onResetOtpScreenState();
		otpScreenActions.onSetOtpToken('');
		this.onResetOTPAsync();
	};

	onResetOTPAsync = async () => {
		await new AsyncStorageUtil(otpVerificationToken).removeData();
	};

	onClickCheckBox = () => {
		// on accepting terms and condition
		const { signUpInfo } = this.props;
		const { isAcceptTerms } = signUpInfo;
		this.onChangeText(!isAcceptTerms, 'isAcceptTerms');
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	render() {
		const { toastMessage, isApiError } = this.state;
		const { languageInfo, signUpInfo } = this.props;
		const { isRTL } = languageInfo;
		const { addressLine, addressInformation, loader, isAcceptTerms } = signUpInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<KeyboardAwareScrollView
				contentContainerStyle={styles.container}
				keyboardShouldPersistTaps="handled">
				{loader && <Spinner size="large" />}
				<Header headerStyle={styles.backButton} onPressBack={this.onGoBack} hasIconBack />
				<ScrollView
					contentContainerStyle={styles.signupFormContainer}
					showsVerticalScrollIndicator={false}
					keyboardShouldPersistTaps="handled">
					<Text style={styles.signUpHeadingText}>
						{localeString(keyConstants.SIGN_UP)}
					</Text>
					<Text style={styles.personalInfoText}>
						{localeString(keyConstants.ADDRESS_INFO_TEXT)}
					</Text>
					{/* for Map View */}
					<TouchableOpacity style={styles.signUpFinalMapView}>
						<MapView
							style={styles.mapSmall}
							initialRegion={this.region}
							showsUserLocation
							onPress={() => {
								this.onGoBack();
							}}
							zoomEnabled={false}
							onRegionChangeComplete={this.onRegionChange}>
							<Marker
								coordinate={{
									latitude: this.region.latitude,
									longitude: this.region.longitude,
								}}
								draggable={false}
								onLoad={() => this.forceUpdate()}
								image={IMAGES.iconLocationPin}
							/>
						</MapView>
					</TouchableOpacity>
					{/* Address line 1 */}
					<Input
						value={addressLine}
						width={normalScale(260)}
						label={`${localeString(keyConstants.ADDRESS_LINE_1)}*`}
						placeholder={localeString(keyConstants.ADDRESS_LINE_1)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						onChangeText={text => this.onChangeText(text, 'addressLine')}
						onSubmitEditing={() => {
							this.onSubmitRef(this.addressInformation);
						}}
						refs={this.refCallback(this.addressLine)}
						autoCapitalize="none"
						textInputStyle={styles.textStyle}
						multiline
						textAlignVertical="center"
						maxLength={addressMaxLength}
					/>
					{/* Address Information */}
					<Input
						value={addressInformation}
						width={normalScale(260)}
						label={`${localeString(keyConstants.ADDRESS_INFORMATION)}`}
						placeholder={localeString(keyConstants.ADDRESS_INFORMATION)}
						blurOnSubmit
						returnKeyType="done"
						isRTL={isRTL}
						refs={this.refCallback(this.addressInformation)}
						onChangeText={text => this.onChangeText(text, 'addressInformation')}
						autoCapitalize="none"
						maxLength={addressMaxLength}
					/>
					<View style={styles.acceptView}>
						<TouchableOpacity
							style={isAcceptTerms && styles.imageStyle}
							activeOpacity={0.8}
							onPress={this.onClickCheckBox}>
							<ImageLoadComponent
								source={
									isAcceptTerms
										? IMAGES.iconCheckedCheckBox
										: IMAGES.iconUncheckedCheckBox
								}
								style={styles.checkBoxImage}
							/>
						</TouchableOpacity>
						<TouchableOpacity activeOpacity={0.8} onPress={this.openTermsAndCondition}>
							<Text style={styles.acceptText}>
								{`${localeString(keyConstants.ACCEPT_TERMS_AND_CONDITIONS)} `}
								<Text style={styles.underline}>
									{localeString(keyConstants.TERMS_AND_CONDITIONS)}
								</Text>
							</Text>
						</TouchableOpacity>
					</View>
				</ScrollView>
				<ButtonComponent
					viewStyle={styles.buttonStyle}
					onPress={this.onSubmit}
					text={localeString(keyConstants.NEXT)}
					isButtonDisable={!(addressLine && isAcceptTerms)}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		signUpInfo: state.SignUpScreenReducer,
		personalInfo: state.PersonalInformationScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		signUpScreenActions: bindActionCreators({ ...SignUpScreenActions }, dispatch),
		addBusinessAccountScreenAction: bindActionCreators(
			{ ...AddBusinessAccountScreenAction },
			dispatch,
		),
		personalInfoScreenActions: bindActionCreators({ ...PersonalInfoScreenActions }, dispatch),
		otpScreenActions: bindActionCreators({ ...OtpScreenActions }, dispatch),
	};
};

SignUpNextScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	signUpInfo: PropTypes.object.isRequired,
	personalInfo: PropTypes.object.isRequired,
	signUpScreenActions: PropTypes.object.isRequired,
	personalInfoScreenActions: PropTypes.object.isRequired,
	otpScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SignUpNextScreen);
