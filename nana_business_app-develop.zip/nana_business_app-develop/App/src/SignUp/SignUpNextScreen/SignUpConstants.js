import { keyConstants } from '@Constants/KeyConstants';

export const businessTypeConstants = [
	{
		key: 'miniMarket',
		name: keyConstants.MINI_MARKET,
	},
	{
		key: 'superMarket',
		name: keyConstants.SUPER_MARKET,
	},
	{
		key: 'restaurant',
		name: keyConstants.RESTAURANTS,
	},
	{
		key: 'hotel',
		name: keyConstants.HOTELS,
	},
	{
		key: 'cafeShop',
		name: keyConstants.CAFE_SHOP,
	},
	{
		key: 'hospital',
		name: keyConstants.HOSPITAL,
	},
	{
		key: 'others',
		name: keyConstants.OTHERS,
	},
];

export default businessTypeConstants;
