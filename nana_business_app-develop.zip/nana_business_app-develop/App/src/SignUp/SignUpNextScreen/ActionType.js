export const ON_CHANGE_SIGN_UP_TEXT = 'on_change_sign_up_text';
export const RESET_SIGN_UP_STATE = 'reset_sign_up_state';
export const SIGN_UP_SUCCESS = 'sign_up_success';
export const SIGN_UP_FAILURE = 'sign_up_failure';
export const SIGN_UP_LOADER = 'sign_up_loader';
export const ADD_LAT_LONG = 'add_lat_long';
export const SET_SIGN_UP_TOKEN = 'set_sign_up_token';
