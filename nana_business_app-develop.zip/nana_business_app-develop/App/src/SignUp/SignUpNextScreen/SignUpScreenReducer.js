import { saveSignUpCompleteToken, onAddSignUpRequestType } from '@Util/SaveMasterData';
import { REQUEST_TYPE } from '@Constants/Constants';
import * as ActionTypes from './ActionType';

const initialState = {
	addressLine: '',
	addressInformation: '',
	city: '',
	isAcceptTerms: false,
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	lat: '',
	long: '',
	signUpToken: null,
};

const SignUpScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_SIGN_UP_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.RESET_SIGN_UP_STATE:
			return {
				...state,
				addressLine: '',
				addressInformation: '',
				city: '',
				isAcceptTerms: false,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
				lat: '',
				long: '',
			};
		case ActionTypes.SIGN_UP_SUCCESS:
			saveSignUpCompleteToken(
				action.payload && action.payload.row ? action.payload.row.access_token : null,
			);
			onAddSignUpRequestType(REQUEST_TYPE.registrationRequest); // Adding signup request type in async storage.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				signUpToken:
					action.payload && action.payload.row ? action.payload.row.access_token : null,
			};
		case ActionTypes.SIGN_UP_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.SIGN_UP_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.ADD_LAT_LONG:
			return {
				...state,
				lat: action.payload.lat,
				long: action.payload.long,
			};
		case ActionTypes.SET_SIGN_UP_TOKEN:
			return {
				...state,
				signUpToken: action.payload,
			};
		default:
			return state;
	}
};

export default SignUpScreenReducer;
