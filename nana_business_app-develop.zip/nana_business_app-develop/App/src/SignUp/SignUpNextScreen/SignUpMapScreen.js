import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import Config from 'react-native-config';
import { localeString } from '@assets/Localization';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import navigations from '@routes/navigations';
import EnableLocation from '@Util/EnableLocation';
import GooglePlacesAutoCompleteComponent from '@Components/GooglePlacesAutoCompleteComponent';
import { saudiLatitude, saudiLongitude, mapMovementDuration } from '@Constants/Constants';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import * as SignUpScreenActions from './SignUpScreenAction';
import { createStyleSheet } from './SignUpScreenStyle';

class SignUpMapScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			region: {
				latitude: parseFloat(saudiLatitude),
				longitude: parseFloat(saudiLongitude),
				latitudeDelta: 0.005,
				longitudeDelta: 0.005,
			},
			currentLocation: {
				latitude: parseFloat(saudiLatitude),
				longitude: parseFloat(saudiLongitude),
			},
			isEnable: false,
			isSetLocation: true,
		};
		this._mapView = React.createRef(null);
	}

	enableLocation = () => {
		const { isSetLocation } = this.state;
		Geolocation.getCurrentPosition(
			info => {
				// Will get location from Geolocation service
				if (isSetLocation) {
					this.setState({
						isEnable: true,
						region: {
							latitude: parseFloat(info.coords.latitude),
							longitude: parseFloat(info.coords.longitude),
							latitudeDelta: 0.005,
							longitudeDelta: 0.005,
						},
						currentLocation: {
							latitude: parseFloat(info.coords.latitude),
							longitude: parseFloat(info.coords.longitude),
						},
						isSetLocation: false,
					});
				}
			},
			() => {
				// Geolocation service unable fetch location
				this.setState({ isEnable: false, isSetLocation: true });
			},
		);
	};

	onMapReady = () => {
		this.setState({});
	};

	onRegionChange = region => {
		// Called on region changed
		this.setState(
			{
				region,
			},
			() => this.fetchAddress(),
		);
	};

	onAddressSearch = location => {
		this.setState(
			{
				region: {
					latitude: parseFloat(location.lat),
					longitude: parseFloat(location.lng),
					latitudeDelta: 0.005,
					longitudeDelta: 0.005,
				},
			},
			() => {
				this.fetchAddress(); // fetch physical address of the selected location on map
				this.animateMap(); // move map camera to the selected location
			},
		);
	};

	animateMap = () => {
		const { region } = this.state;
		const { latitude, longitude } = region;
		const temp_cordinate = {
			latitude,
			longitude,
		};
		this._mapView.animateCamera(
			{
				center: temp_cordinate,
			},
			mapMovementDuration,
		);
	};

	fetchAddress = () => {
		// fetch address of the selected location(lat and long) on map
		const { region } = this.state;
		fetch(
			`https://maps.googleapis.com/maps/api/geocode/json?address=${region.latitude},${region.longitude}&key=${Config.GOOGLE_API_KEY}`,
		)
			.then(response => response.json())
			.then(responseJson => {
				const userLocation = responseJson.results[0].formatted_address;
				const city = responseJson.results[0].address_components[2].long_name;
				this.onChangeText(userLocation, 'addressLine');
				this.onChangeText(city, 'city');
			});
	};

	onChangeText = (text, field) => {
		const { signUpScreenActions } = this.props;
		signUpScreenActions.onChangeText(text, field);
	};

	onSubmit = () => {
		const { navigation } = this.props;
		const { region } = this.state;
		navigation.navigate(navigations.SIGN_UP_NEXT_NAVIGATION, {
			region,
		});
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	render() {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { isEnable, currentLocation, region } = this.state;
		const { latitude, longitude } = currentLocation;
		const homePlace = {
			description: localeString(keyConstants.CURRENT_LOCATION),
			geometry: {
				location: {
					lat: latitude,
					lng: longitude,
				},
			},
		};
		this.enableLocation();
		if (!isEnable) {
			return <EnableLocation onCancel={this.onPressBack} />;
		}
		return (
			<View style={styles.mapContainer}>
				<MapView
					style={styles.map}
					ref={mapView => {
						this._mapView = mapView;
					}}
					provider={PROVIDER_GOOGLE}
					initialRegion={region}
					showsUserLocation
					onMapReady={this.onMapReady}
					zoomControlEnabled
					showsMyLocationButton
					onRegionChangeComplete={this.onRegionChange}
				/>
				<ImageLoadComponent style={styles.markerImage} source={IMAGES.iconLocationPin} />
				<View keyboardShouldPersistTaps="always" style={styles.searchBarContainer}>
					<GooglePlacesAutoCompleteComponent
						onSelectAddressSearch={this.onAddressSearch}
						predefinedPlaces={[homePlace]}
					/>
				</View>
				<TouchableOpacity
					activeOpacity={0.8}
					style={styles.backMapButton}
					onPress={this.onGoBack}>
					<ImageLoadComponent source={IMAGES.iconRightArrow} style={styles.iconBack} />
				</TouchableOpacity>
				<ButtonComponent
					viewStyle={styles.buttonMapStyle}
					onPress={this.onSubmit}
					text={localeString(keyConstants.SELECT_LOCATION)}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		signUpScreenActions: bindActionCreators({ ...SignUpScreenActions }, dispatch),
	};
};

SignUpMapScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	signUpScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SignUpMapScreen);
