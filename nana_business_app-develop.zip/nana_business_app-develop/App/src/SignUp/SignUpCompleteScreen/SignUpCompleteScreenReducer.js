import { userStatus } from '@Constants/Constants';
import {} from '@SignInScreen/SignInScreenReducer';
import { saveMasterLoginData } from '@Util/SaveMasterLoginData';
import * as ActionTypes from './ActionType';

const initialState = {
	data: null,
	status: userStatus.pending,
	success: false,
	error: false,
	errorCode: null,
	loader: false,
};

const SignUpCompleteScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_REQUEST_STATUS_SUCCESS:
			if (action.payload && action.payload.status === userStatus.approved) {
				saveMasterLoginData(action.payload.data); // Save master data if signup request is approved and login the user.
			}
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				data: action.payload.data ? action.payload.data : null,
				status: action.payload.status, // Status of the signup request.
			};
		case ActionTypes.GET_REQUEST_STATUS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_REQUEST_STATUS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.RESET_SIGNUP_COMPLETE_DATA:
			return initialState;
		default:
			return state;
	}
};

export default SignUpCompleteScreenReducer;
