export const GET_REQUEST_STATUS_SUCCESS = 'get_request_status_success';
export const GET_REQUEST_STATUS_FAILURE = 'get_request_status_failure';
export const GET_REQUEST_STATUS_LOADER = 'get_request_status_loader';
export const RESET_SIGNUP_COMPLETE_DATA = 'reset_signup_complete_data';
