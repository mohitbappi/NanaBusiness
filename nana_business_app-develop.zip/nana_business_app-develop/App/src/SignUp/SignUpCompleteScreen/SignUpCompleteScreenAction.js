import { actions } from '@libapi/APIActionsBuilder';
import GetRequestStatusService from '@SignUp/GetRequestStatusService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import SignUpAuthenticationHeaderInterceptor from '@interceptor/SignUpAuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

// Action to call get request status api
export const onCheckStatus = () => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_REQUEST_STATUS_SUCCESS,
		ActionTypes.GET_REQUEST_STATUS_FAILURE,
		ActionTypes.GET_REQUEST_STATUS_LOADER,
	);
	const getRequestStatusService = new GetRequestStatusService(dispatchedActions);
	addBasicInterceptors(getRequestStatusService);
	getRequestStatusService.addRequestInterceptor(new SignUpAuthenticationHeaderInterceptor());
	dispatch(getRequestStatusService.makeRequest());
};

// Action to reset signupComplete screen reducer
export const onResetSignupCompleteState = () => ({ type: ActionTypes.RESET_SIGNUP_COMPLETE_DATA });
