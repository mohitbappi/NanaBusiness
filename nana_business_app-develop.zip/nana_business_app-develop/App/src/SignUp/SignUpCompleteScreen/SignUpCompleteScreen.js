import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import {
	REQUEST_TYPE,
	signUpCompleteToken,
	signUpRequestType,
	userStatus,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import * as AddBusinessAccountScreenAction from '@AddBusinessAccountScreen/AddBusinessAccountScreenAction';
import AsyncStorageUtil from '@AsyncStorage/AsyncStorageUtil';
import * as SignUpScreenActions from '@SignUpNextScreen/SignUpScreenAction';
import IMAGES from '@Images/index';
import * as SignInActions from '@SignInScreen/SignInScreenAction';
import * as PersonalInfoScreenActions from '@PersonalInformationScreen/PersonalInformationScreenAction';
import * as OtpScreenActions from '@OTPScreen/OTPScreenAction';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import * as SignUpCompleteScreenActions from './SignUpCompleteScreenAction';

class SignUpCompleteScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			type: '', // Signup request type
			masterData: {
				[`${REQUEST_TYPE.userRequest}`]: {
					// If signup request is user request
					[`${userStatus.pending}`]: {
						// If user request status is pending
						title: localeString(keyConstants.ONBOARDING_PENDING),
						description: localeString(keyConstants.ONBOARDED_TEXT_FOR_PENDING),
						onPress: () => this.onCheckStatus(), // Will check user request status
						buttonTitle: localeString(keyConstants.REFRESH),
						imageSource: IMAGES.iconPending, // Will show pending image
					},
					[`${userStatus.cancelled}`]: {
						// If user request status is rejected
						title: localeString(keyConstants.ONBOARDING_FAILED),
						description: localeString(keyConstants.ONBOARDED_TEXT_FOR_FAILED),
						onPress: () => this.onResetReducer(), // will reset all the reducers of signup
						buttonTitle: localeString(keyConstants.OKAY),
						imageSource: IMAGES.iconFailed, // Will show rejected image
					},
				},
				[`${REQUEST_TYPE.registrationRequest}`]: {
					// If signup request is registration request
					[`${userStatus.pending}`]: {
						// If registration request status is pending
						title: localeString(keyConstants.ONBOARDING_PENDING),
						description: localeString(
							keyConstants.SIGN_UP_CONFIRMATION_TEXT_FOR_PENDING,
						),
						onPress: () => this.onCheckStatus(), // Will check registration request status
						buttonTitle: localeString(keyConstants.REFRESH),
						imageSource: IMAGES.iconPending, // Will show pending image
					},
					[`${userStatus.cancelled}`]: {
						// If registration request status is rejected
						title: localeString(keyConstants.REGISTRATION_FAILED),
						description: localeString(
							keyConstants.SIGN_UP_CONFIRMATION_TEXT_FOR_FAILED,
						),
						onPress: () => this.onResetReducer(), // will reset all the reducers of signup
						buttonTitle: localeString(keyConstants.OKAY),
						imageSource: IMAGES.iconFailed, // Will show rejected image
					},
				},
			},
		};
	}

	async componentDidMount() {
		this.setState({
			type: await AsyncStorage.getItem(signUpRequestType), // Get signup request type from async storage.
		});
	}

	componentDidUpdate(prevProps) {
		const { signUpCompleteInfo, signInActions } = this.props;
		const { status, success, data } = signUpCompleteInfo;
		const { access_token, user } = data || {};
		if (
			success &&
			status === userStatus.approved &&
			prevProps.signUpCompleteInfo.success !== signUpCompleteInfo.success
		) {
			// This block will work if signup request has been approved.
			this.onResetReducer(); // Reset all the data of signup.
			signInActions.onSetToken(access_token, user.role); // Saving token and role of the user to login.
			logCustomEventOnBraze('registrationCompleted', null);
		}
	}

	onCheckStatus = async () => {
		const { signUpCompleteScreenActions } = this.props;
		signUpCompleteScreenActions.onCheckStatus();
	};

	onResetReducer = () => {
		const {
			addBusinessAccountScreenAction,
			signUpScreenActions,
			signUpCompleteScreenActions,
			personalInfoScreenActions,
			otpScreenActions,
		} = this.props;
		addBusinessAccountScreenAction.onResetAccountState(); // Reset reducer of user request.
		signUpScreenActions.onResetSignUpState(); // Reset reducer of registration request.
		signUpScreenActions.onSetSignUpToken(''); // Remove signup temporary token.
		signUpCompleteScreenActions.onResetSignupCompleteState(); // Reset signup complete reducer.
		personalInfoScreenActions.onResetPersonalInfoState(); // Reset personal informatoin reducer.
		otpScreenActions.onResetOtpScreenState(); // Reset otp screen reducer.
		otpScreenActions.onSetOtpToken(''); // Reset otp token.
		this.onResetSignUpCompleteAsync();
	};

	onResetSignUpCompleteAsync = async () => {
		await new AsyncStorageUtil(signUpCompleteToken).removeData(); // Removed signup temporary token.
		await new AsyncStorageUtil(signUpRequestType).removeData(); // Removed signup request type.
	};

	render() {
		const { signUpCompleteInfo } = this.props;
		const { type, masterData } = this.state;
		const { loader, status } = signUpCompleteInfo;
		if (loader || !(type && status)) {
			return <Loader size="large" />;
		}
		if (status !== userStatus.approved) {
			const { title, description, onPress, buttonTitle, imageSource } = masterData[type][
				status
			];
			return (
				<ConfimationModal
					title={title}
					description={description}
					onPress={onPress}
					buttonTitle={buttonTitle}
					imageSource={imageSource}
					hasButton
				/>
			);
		}
		return null;
	}
}

const mapStateToProps = state => {
	return {
		signUpCompleteInfo: state.SignUpCompleteScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		signUpCompleteScreenActions: bindActionCreators(
			{ ...SignUpCompleteScreenActions },
			dispatch,
		),
		addBusinessAccountScreenAction: bindActionCreators(
			{ ...AddBusinessAccountScreenAction },
			dispatch,
		),
		signUpScreenActions: bindActionCreators({ ...SignUpScreenActions }, dispatch),
		signInActions: bindActionCreators({ ...SignInActions }, dispatch),
		personalInfoScreenActions: bindActionCreators({ ...PersonalInfoScreenActions }, dispatch),
		otpScreenActions: bindActionCreators({ ...OtpScreenActions }, dispatch),
	};
};

SignUpCompleteScreen.propTypes = {
	signUpCompleteInfo: PropTypes.object.isRequired,
	signUpCompleteScreenActions: PropTypes.object.isRequired,
	addBusinessAccountScreenAction: PropTypes.object.isRequired,
	signUpScreenActions: PropTypes.object.isRequired,
	signInActions: PropTypes.object.isRequired,
	personalInfoScreenActions: PropTypes.object.isRequired,
	otpScreenActions: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SignUpCompleteScreen);
