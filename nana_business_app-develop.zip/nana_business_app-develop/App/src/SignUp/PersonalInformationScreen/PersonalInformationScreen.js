import React, { Component } from 'react';
import { View, Text, Keyboard, TouchableOpacity, Platform } from 'react-native';
import { connect } from 'react-redux';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import auth from '@react-native-firebase/auth';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { localeString } from '@assets/Localization';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import {
	emailRegexEx,
	mobileNumberLength,
	nameMaxLength,
	customMobileRegex,
	toastShowTime,
	mobilePrefix,
	numericRegexExp,
	languageConstants,
	crNumberLength,
	companyNameMaxLength,
	crNumberRegex,
	duplicateName,
	numericalRegexExp,
	locatorConstants,
} from '@Constants/Constants';
import { keyConstants } from '@Constants/KeyConstants';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import navigations from '@routes/navigations';
import SignUpHeader from '@SignUpHeader/SignUpHeader';
import OptionPicker from '@OptionPicker/OptionPicker';
import { businessTypeConstants } from '@SignUpNextScreen/SignUpConstants';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import AlertComponent from '@Util/AlertComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import getTestIdProps from '@Util/GetTestIdProps';
import * as PersonalInfoScreenActions from './PersonalInformationScreenAction';
import { createStyleSheet } from './PersonalInformationScreenStyle';

class PersonalInformationScreen extends Component {
	constructor(props) {
		super(props);
		this.email = React.createRef(null);
		this.mobileNumber = React.createRef(null);
		this.crNumber = React.createRef(null);
		this.state = {
			isErrorEmail: false,
			isErrorMobileNumber: false,
			isApiError: false,
			toastMessage: '',
			isErrorCRNumber: false,
			crErrorMessage: '',
			isDropdownVisible: false,
			businessTypeSelectedIndex: null,
			isErrorDuplicateName: false,
			duplicateNameErrorMessage: '',
			crNumberDoesNotExist: false,
			isInitialFocusEmail: true,
			isFetchingEmail: false,
			isCrNumberFocused: false,
		};
	}

	componentDidMount() {
		const { route } = this.props;
		const { mobileNumber } = route.params;
		this.onChangeText(mobileNumber, 'mobileNumber');
	}

	componentDidUpdate(prevProps) {
		const { personalInfo } = this.props;
		const {
			email,
			mobileNumber,
			error,
			errorCode,
			success,
			companyRegNumber,
			isGetCompany,
		} = personalInfo;
		if (success && prevProps.personalInfo.success !== personalInfo.success) {
			if (isGetCompany) {
				// If API call to check cr number exists or not.
				this.setState({
					crNumberDoesNotExist: false,
				});
				const alertOptions = {
					message: localeString(keyConstants.CR_EXIST_POPUP_MESSAGE),
					noText: localeString(keyConstants.NO),
					yesText: localeString(keyConstants.YES),
					onPressYes: this.onGetOtp,
				};
				setTimeout(() => AlertComponent(alertOptions), 200);
			} else {
				this.onNavigateToOtpScreen(mobileNumber); // Will send otp and navigate to otp screen.
			}
		}
		if (error && prevProps.personalInfo.error !== error) {
			if (isGetCompany && keyConstants[errorCode.error]) {
				this.setState({
					crNumberDoesNotExist: true,
				});
			} else if (errorCode.errors) {
				errorCode.errors.forEach(element => {
					// Will show multiple errors.
					if (element.error === duplicateName) {
						// If English company name exists.
						this.setState({
							isErrorDuplicateName: true,
							duplicateNameErrorMessage: localeString(keyConstants.DUPLICATE_NAME),
						});
					}
				});
			} else if (keyConstants[errorCode.error]) {
				// Will show toast if api error occurs.
				this.setState({
					toastMessage: localeString(keyConstants[`${errorCode.error}`]),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				setTimeout(
					() =>
						ErrorAlertComponent(
							// Will show alert if api fails.
							errorCode,
							isGetCompany ? this.onGetCompanyDetails : this.onSubmit,
						),
					20,
				);
			}
		}
		if (prevProps.personalInfo !== personalInfo) {
			if (customMobileRegex.test(mobileNumber)) {
				// if entered mobile number is invalid
				this.setState({
					isErrorMobileNumber: false,
				});
			}
			if (emailRegexEx.test(String(email).toLowerCase())) {
				// if entered email id number is invalid
				this.setState({
					isErrorEmail: false,
				});
			}
			if (crNumberRegex.test(companyRegNumber)) {
				// if entered company registeration number is invalid
				this.setState({
					isErrorCRNumber: false,
					crErrorMessage: '',
				});
			}
		}
	}

	componentWillUnmount() {
		// Will reset reducer on screen unmount
		const { personalInfoScreenActions } = this.props;
		this.setState({
			isErrorEmail: false,
			isErrorMobileNumber: false,
		});
		personalInfoScreenActions.onResetPersonalInfoState();
	}

	onGetOtp = () => {
		// Will check for validations and hit send otp API.
		const { isErrorEmail, isErrorMobileNumber } = this.state;
		this.onBlur('email');
		this.onBlur('mobileNumber');
		if (!isErrorEmail && !isErrorMobileNumber) {
			this.onSubmit();
		}
	};

	onNavigateToOtpScreen = mobileNumber => {
		const { personalInfoScreenActions, navigation } = this.props;
		const { crNumberDoesNotExist } = this.state;
		personalInfoScreenActions.onResetOtpState();
		navigation.navigate(navigations.OTP_SCREEN_NAVIGATION, {
			mobileNumber,
			isSignIn: false,
			isDriver: false,
			isRegistrationRequest: crNumberDoesNotExist,
		});
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeText = (text, field) => {
		const { personalInfoScreenActions } = this.props;
		personalInfoScreenActions.onChangeText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = field => {
		const { personalInfo } = this.props;
		const { email, companyRegNumber, mobileNumber } = personalInfo;
		if (field === 'email' && !emailRegexEx.test(String(email).toLowerCase())) {
			// Will check email id validation.
			this.setState({
				isErrorEmail: true,
			});
		} else if (field === 'companyRegNumber') {
			// Will check cr number validation.
			this.setState({
				isCrNumberFocused: false,
			});
			if (!crNumberRegex.test(String(companyRegNumber).toLowerCase())) {
				this.setState({
					isErrorCRNumber: true,
					crErrorMessage: localeString(keyConstants.MUST_BE_TEN_DIGITS),
				});
				this.onChangeText('', 'companyName');
			} else {
				this.onGetCompanyDetails();
			}
		} else if (field === 'mobileNumber') {
			// Will check mobile number validation.
			if (!customMobileRegex.test(mobileNumber)) {
				this.setState({
					isErrorMobileNumber: true,
				});
			}
		}
	};

	onFocus = () => {
		this.setState({
			isCrNumberFocused: true,
		});
	};

	onGetCompanyDetails = () => {
		// Function to call API to check cr exists or not.
		const { personalInfo, personalInfoScreenActions } = this.props;
		const { companyRegNumber } = personalInfo;
		const crNumberData = {
			crNumber: companyRegNumber,
		};
		personalInfoScreenActions.onGetCompany(crNumberData);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onSubmit = () => {
		// Call api to send otp to the entered mobile number for signup
		const { languageInfo, personalInfo, personalInfoScreenActions } = this.props;
		const { isCrNumberFocused } = this.state;
		this.onDissmissKeyboard();
		if (isCrNumberFocused) {
			this.onBlur('companyRegNumber');
		} else {
			this.setState({
				isErrorDuplicateName: false,
			});
			const { isRTL } = languageInfo;
			const { email, mobileNumber, companyName } = personalInfo;
			const { crNumberDoesNotExist } = this.state;
			const otpDetails = {
				mobile: mobileNumber,
				email_address: email,
				country_code: mobilePrefix,
				language: isRTL ? languageConstants.ar : languageConstants.en,
				platform: Platform.OS,
			};
			if (crNumberDoesNotExist) {
				otpDetails.company_name = companyName;
			}
			personalInfoScreenActions.onSendOtp(otpDetails);
		}
	};

	getCRNumberError = () => {
		// Will check validation to enable button.
		const { personalInfo } = this.props;
		const { businessTypeSelectedIndex, crNumberDoesNotExist } = this.state;
		const { companyName } = personalInfo;
		if (crNumberDoesNotExist) {
			return businessTypeSelectedIndex !== null && companyName !== '';
		}
		return true;
	};

	onCloseDropdown = () => this.setState({ isDropdownVisible: false });

	onSelectOption = index => {
		const { personalInfoScreenActions } = this.props;
		this.onCloseDropdown();
		this.setState(
			{
				businessTypeSelectedIndex: index,
			},
			() => {
				personalInfoScreenActions.onChangeText(
					businessTypeConstants[index].key,
					'businessType',
				);
			},
		);
	};

	onPressDropdown = () => {
		this.onDissmissKeyboard();
		this.setState({
			isDropdownVisible: true,
		});
	};

	// shows popup to select an gmail id
	onFocusEmail = async () => {
		const { isInitialFocusEmail } = this.state;
		if (!isInitialFocusEmail) {
			return;
		} // if not an initial focus then do nothing
		this.email.current.blur();
		this.setState({
			isFetchingEmail: true,
			isInitialFocusEmail: false,
		});
		try {
			// try sign-in from google
			const { idToken } = await GoogleSignin.signIn();
			const googleCredential = await auth.GoogleAuthProvider.credential(idToken);
			const credential = await auth().signInWithCredential(googleCredential);
			this.onChangeText(
				credential &&
					credential.additionalUserInfo &&
					credential.additionalUserInfo.profile &&
					credential.additionalUserInfo.profile.email &&
					credential.additionalUserInfo.profile.email,
				'email',
			);
			GoogleSignin.revokeAccess();
			GoogleSignin.signOut();
		} catch (err) {
			// after google signin error when coming back to sign up screen from google popup then manually set email error to false
			this.setState({ isErrorEmail: false });
		} finally {
			// when email fetching completes or fails then set isFetchingEmail to false
			this.setState({ isFetchingEmail: false });
		}
	};

	render() {
		const { languageInfo, personalInfo } = this.props;
		const {
			isErrorEmail,
			isErrorMobileNumber,
			toastMessage,
			isApiError,
			isErrorCRNumber,
			crErrorMessage,
			isDropdownVisible,
			businessTypeSelectedIndex,
			isErrorDuplicateName,
			duplicateNameErrorMessage,
			crNumberDoesNotExist,
			isFetchingEmail,
			isInitialFocusEmail,
		} = this.state;
		const { isRTL } = languageInfo;
		const {
			fullName,
			email,
			mobileNumber,
			loader,
			companyRegNumber,
			companyName,
		} = personalInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{(loader || isFetchingEmail) && <Spinner size="large" />}
				<OptionPicker
					title={localeString(keyConstants.SELECT_BUSINESS_TYPE)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={businessTypeConstants}
					provideLanguageSupport
					onClose={this.onCloseDropdown}
					onSelectOption={index => this.onSelectOption(index)}
					activeIndex={businessTypeSelectedIndex}
				/>
				<KeyboardAwareScrollView
					contentContainerStyle={styles.formContainer}
					keyboardShouldPersistTaps="handled">
					<SignUpHeader
						isHeader
						isRTL={isRTL}
						filledLevelLength={1}
						unFilledLevelLength={2}
					/>
					<View style={styles.innerContainer}>
						<View style={styles.innerView}>
							<Text style={styles.signUpHeadingText}>
								{localeString(keyConstants.SIGN_UP)}
							</Text>
							<TouchableOpacity onPress={this.onGoBack} activeOpacity={0.8}>
								<Text style={styles.signInHeadingText}>
									{localeString(keyConstants.SIGN_IN)}
								</Text>
							</TouchableOpacity>
						</View>
						<Text style={styles.personalInfoText}>
							{localeString(keyConstants.PERSONAL_INFO_TEXT)}
						</Text>
						<Input
							value={fullName}
							width={normalScale(260)}
							maxLength={nameMaxLength}
							label={`${localeString(keyConstants.FULL_NAME)}*`}
							placeholder={localeString(keyConstants.YOUR_FULL_NAME)}
							blurOnSubmit={false}
							returnKeyType="next"
							isRTL={isRTL}
							onChangeText={text => this.onChangeText(text, 'fullName')}
							onSubmitEditing={() => this.onSubmitRef(this.email)}
							autoCapitalize="none"
							extraProps={getTestIdProps(locatorConstants.name)}
						/>
						<Input
							value={email}
							width={normalScale(260)}
							label={`${localeString(keyConstants.EMAIL_ADDRESS)}*`}
							placeholder={localeString(keyConstants.YOUR_EMAIL_ADDRESS)}
							blurOnSubmit={false}
							returnKeyType="next"
							isRTL={isRTL}
							onChangeText={text => this.onChangeText(text, 'email')}
							onSubmitEditing={() => this.onSubmitRef(this.mobileNumber)}
							onBlur={() => this.onBlur('email')}
							refs={this.refCallback(this.email)}
							isError={isErrorEmail && !isFetchingEmail}
							autoCapitalize="none"
							errorMessage={localeString(keyConstants.EMAIL_VALIDATION_MESSAGE)}
							keyboardType="email-address"
							onFocus={this.onFocusEmail}
							showSoftInputOnFocus={!isInitialFocusEmail}
							extraProps={getTestIdProps(locatorConstants.email)}
							extraPropsForError={getTestIdProps(locatorConstants.emailError)}
						/>
						<Input
							value={mobileNumber}
							width={normalScale(260)}
							label={`${localeString(keyConstants.MOBILE_NUMBER)}*`}
							placeholder={localeString(keyConstants.MOBILE_NUMBER_PLACEHOLDER)}
							blurOnSubmit
							returnKeyType="next"
							isRTL={isRTL}
							onChangeText={text =>
								(numericRegexExp.test(String(text).toLocaleLowerCase()) ||
									text === '') &&
								this.onChangeText(text, 'mobileNumber')
							}
							onBlur={() => this.onBlur('mobileNumber')}
							refs={this.refCallback(this.mobileNumber)}
							onSubmitEditing={() => this.onSubmitRef(this.crNumber)}
							isError={isErrorMobileNumber}
							autoCapitalize="none"
							errorMessage={localeString(
								keyConstants.MOBILE_NUMBER_VALIDATION_MESSAGE,
							)}
							maxLength={mobileNumberLength}
							keyboardType="number-pad"
							hasMobilePrefix
							extraProps={getTestIdProps(locatorConstants.number)}
							extraPropsForError={getTestIdProps(locatorConstants.phoneError)}
						/>
						<Input
							value={companyRegNumber}
							width={normalScale(260)}
							label={`${localeString(keyConstants.COMPANY_REG_NUMBER)}*`}
							placeholder={localeString(keyConstants.COMPANY_REG_NUMBER)}
							blurOnSubmit
							returnKeyType="done"
							isRTL={isRTL}
							onChangeText={text =>
								(numericalRegexExp.test(String(text).toLocaleLowerCase()) ||
									text === '') &&
								this.onChangeText(text, 'companyRegNumber')
							}
							onSubmitEditing={() => this.onBlur('companyRegNumber')}
							refs={this.refCallback(this.crNumber)}
							autoCapitalize="none"
							maxLength={crNumberLength}
							keyboardType="number-pad"
							isError={isErrorCRNumber}
							errorMessage={crErrorMessage}
							onFocus={this.onFocus}
							extraProps={getTestIdProps(locatorConstants.companyNum)}
						/>
						{companyRegNumber && !isErrorCRNumber && crNumberDoesNotExist ? (
							<>
								<DropdownFieldComponent
									isRTL={isRTL}
									onPress={this.onPressDropdown}
									value={
										businessTypeSelectedIndex !== null
											? localeString(
													businessTypeConstants[businessTypeSelectedIndex]
														.name,
											  )
											: ''
									}
									label={`${localeString(keyConstants.BUSINESS_TYPE)}*`}
									placeholder={`${localeString(keyConstants.BUSINESS_TYPE)}`}
									extraProps={getTestIdProps(locatorConstants.businessType)}
								/>
								<Input
									value={companyName}
									width={normalScale(260)}
									maxLength={companyNameMaxLength}
									label={`${localeString(keyConstants.BUSINESS_NAME)}*`}
									placeholder={localeString(keyConstants.BUSINESS_NAME)}
									blurOnSubmit
									returnKeyType="done"
									onChangeText={text => this.onChangeText(text, 'companyName')}
									isRTL={isRTL}
									autoCapitalize="none"
									isError={isErrorDuplicateName}
									errorMessage={duplicateNameErrorMessage}
									extraProps={getTestIdProps(locatorConstants.businessName)}
								/>
							</>
						) : null}
					</View>
				</KeyboardAwareScrollView>
				<ButtonComponent
					viewStyle={styles.buttonStyle}
					onPress={this.onSubmit}
					text={localeString(keyConstants.NEXT)}
					isButtonDisable={
						!(
							!isErrorEmail &&
							fullName &&
							mobileNumber &&
							!isErrorMobileNumber &&
							companyRegNumber &&
							!isErrorCRNumber &&
							this.getCRNumberError()
						)
					}
					extraProps={getTestIdProps(locatorConstants.next)}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		personalInfo: state.PersonalInformationScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		personalInfoScreenActions: bindActionCreators({ ...PersonalInfoScreenActions }, dispatch),
	};
};

PersonalInformationScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	personalInfo: PropTypes.object.isRequired,
	personalInfoScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(PersonalInformationScreen);
