export const ON_CHANGE_PERSONAL_INFO = 'on_change_personal_info';

export const SEND_OTP_SUCCESS = 'send_otp_success';
export const SEND_OTP_FAILURE = 'send_otp_failure';
export const SEND_OTP_LOADER = 'send_otp_loader';

export const RESET_PERSONAL_INFO_STATE = 'reset_personal_info_state';

export const RESET_OTP_STATE = 'reset_otp_state';

export const GET_COMPANY_SUCCESS = 'get_company_success';
export const GET_COMPANY_FAILURE = 'get_company_failure';
export const GET_COMPANY_LOADER = 'get_company_loader';
