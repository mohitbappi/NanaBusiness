import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		formContainer: {
			backgroundColor: colors.white,
			paddingTop: verticalScale(17),
		},
		innerContainer: {
			paddingHorizontal: normalScale(30),
			paddingBottom: verticalScale(80),
			marginTop: verticalScale(15),
		},
		innerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		signUpHeadingText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(30),
		},
		signInHeadingText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(14),
		},
		personalInfoText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			marginTop: verticalScale(11),
			marginBottom: verticalScale(14),
		},
		buttonStyle: {
			position: 'absolute',
			left: normalScale(25),
			right: normalScale(25),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(24),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
