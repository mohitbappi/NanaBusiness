import * as ActionTypes from './ActionType';

const initialState = {
	fullName: '',
	email: '',
	mobileNumber: '',
	companyRegNumber: '',
	companyName: '',
	businessType: '',
	isGetCompany: false,
	success: false,
	error: false,
	errorCode: null,
	loader: false,
};

const PersonalInformationScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_PERSONAL_INFO:
			return {
				...state,
				[action.payload.field]: action.payload.text,
			};
		case ActionTypes.SEND_OTP_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isGetCompany: false,
			};
		case ActionTypes.SEND_OTP_LOADER:
		case ActionTypes.GET_COMPANY_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.SEND_OTP_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isGetCompany: false,
			};
		case ActionTypes.GET_COMPANY_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: null,
				loader: false,
				isGetCompany: true,
			};
		case ActionTypes.GET_COMPANY_FAILURE:
			return {
				...state,
				success: false,
				error: true,
				errorCode: action.payload,
				loader: false,
				isGetCompany: true,
			};
		case ActionTypes.RESET_PERSONAL_INFO_STATE:
			return initialState;
		case ActionTypes.RESET_OTP_STATE:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
			};
		default:
			return state;
	}
};

export default PersonalInformationScreenReducer;
