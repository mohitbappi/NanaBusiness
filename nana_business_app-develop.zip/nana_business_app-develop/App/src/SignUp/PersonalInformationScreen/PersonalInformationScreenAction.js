import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import SendOtpService from '@SignUp/SendOtpService';
import GetCompanyService from '@SignUp/GetCompanyService';
import * as ActionTypes from './ActionType';

/**
 * Action to set entered inputfield text in respective values in reducer
 * @param {string} text
 * @param {string} field
 */
export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_PERSONAL_INFO,
		payload: { text, field },
	};
};

// Action to reset Personal info screen reducer
export const onResetPersonalInfoState = () => ({ type: ActionTypes.RESET_PERSONAL_INFO_STATE });

/**
 * Action to call send otp api
 * @param {object} otpDetails
 */
export const onSendOtp = otpDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SEND_OTP_SUCCESS,
		ActionTypes.SEND_OTP_FAILURE,
		ActionTypes.SEND_OTP_LOADER,
	);
	const sendOtpService = new SendOtpService(dispatchedActions);
	addBasicInterceptors(sendOtpService);
	dispatch(sendOtpService.makeRequest(otpDetails));
};

/**
 * Action to call get company detail api
 * @param {string} crNumberData
 */
export const onGetCompany = crNumberData => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_COMPANY_SUCCESS,
		ActionTypes.GET_COMPANY_FAILURE,
		ActionTypes.GET_COMPANY_LOADER,
	);
	const getCompanyService = new GetCompanyService(dispatchedActions);
	addBasicInterceptors(getCompanyService);
	dispatch(getCompanyService.makeRequest(crNumberData));
};

// Action to reset otp state
export const onResetOtpState = () => ({ type: ActionTypes.RESET_OTP_STATE });
