export const ON_CHANGE_ADD_TEXT = 'on_change_add_text';
export const ADD_MONEY_SUCCESS = 'add_money_success';
export const ADD_MONEY_FAILURE = 'add_money_failure';
export const ADD_MONEY_LOADER = 'add_money_loader';
export const RESET_ADD_MONEY_STATE = 'reset_add_money_state';
