import APIActionsBuilder from '@libapi/APIActionsBuilder';
import AddMoneyService from '@BalanceDetails/AddMoneyService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_ADD_TEXT,
		payload: text,
		field,
	};
};

/**
 * Action to call the add money API.
 * @param {object} paymentDetails
 * @param {boolean} isCalledfromHomeScreen
 * @returns
 */

export const onAddMoney = (paymentDetails, isCalledfromHomeScreen) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.ADD_MONEY_SUCCESS,
		ActionTypes.ADD_MONEY_FAILURE,
		ActionTypes.ADD_MONEY_LOADER,
	)
		.addSuccessExtra(isCalledfromHomeScreen)
		.addInprogressExtra(isCalledfromHomeScreen)
		.addFailureExtra(isCalledfromHomeScreen)
		.build();
	const addMoneyService = new AddMoneyService(dispatchedActions);
	addBasicInterceptors(addMoneyService);
	addMoneyService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(addMoneyService.makeRequest(paymentDetails));
};

export const onResetAddMoneyState = () => ({ type: ActionTypes.RESET_ADD_MONEY_STATE });
