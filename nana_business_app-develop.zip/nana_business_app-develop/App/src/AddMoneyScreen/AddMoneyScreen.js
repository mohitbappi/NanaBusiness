import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, Keyboard } from 'react-native';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Header from '@Header/Header';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import {
	numericRegexWithDecimalEx,
	spaceRegexEx,
	paymentType,
	minAmountToAddMoney,
} from '@Constants/Constants';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import Spinner from '@Spinner/Spinner';
import navigations from '@routes/navigations';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import * as AddMoneyActions from './AddMoneyScreenAction';
import { createStyleSheet } from './AddMoneyScreenStyle';

class AddMoneyScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isAmountError: false,
			errorMessage: '',
		};
	}

	componentDidUpdate(prevProps) {
		const { navigation, addMoneyInfo, route } = this.props;
		const { amount, success, paymentDetail, error, errorCode } = addMoneyInfo;
		const { type } = route.params || {};
		if (success && prevProps.addMoneyInfo.success !== success) {
			// Will navigate to the payment confirmation screen after successful payment.
			navigation.navigate(navigations.PAYMENT_NAVIGATION, {
				paymentDetail,
				type,
				extraParams: {},
			});
		}
		if (
			prevProps.addMoneyInfo.amount !== amount &&
			numericRegexWithDecimalEx.test(String(amount).toLowerCase()) &&
			amount >= minAmountToAddMoney
		) {
			// Will check for amount validations.
			this.setState({
				isAmountError: false,
			});
		}
		if (error && prevProps.addMoneyInfo.error !== error) {
			// Will show popup in case of error.
			ErrorAlertComponent(errorCode, this.onAddMoney);
		}
	}

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeText = (text, field) => {
		// Will save the input fields data in reducer.
		const { addMoneyActions } = this.props;
		addMoneyActions.onChangeText(text, field);
	};

	onAddMoney = () => {
		// API call to add money into the wallet.
		const { addMoneyActions, addMoneyInfo } = this.props;
		this.onDissmissKeyboard();
		const { amount } = addMoneyInfo;
		const paymentDetails = {
			payment_type: paymentType.advancePayment,
			amount,
		};
		addMoneyActions.onAddMoney(paymentDetails, false);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	onBlur = () => {
		const { addMoneyInfo } = this.props;
		const { amount } = addMoneyInfo;
		if (!numericRegexWithDecimalEx.test(String(amount).toLowerCase())) {
			this.setState({
				isAmountError: true,
				errorMessage: localeString(keyConstants.ONLY_TWO_DIGIT_AFTER_DECIMAL),
			});
		} else if (amount < minAmountToAddMoney) {
			this.setState({
				isAmountError: true,
				errorMessage: `${localeString(keyConstants.MIN_AMOUNT_SAR)} ${localeString(
					keyConstants.SAR,
				)}`,
			});
		}
	};

	render() {
		const { languageInfo, addMoneyInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { isAmountError, errorMessage } = this.state;
		const { amount, loader } = addMoneyInfo;
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				<Header
					hasIconBack
					onPressBack={this.onGoBack}
					text={localeString(keyConstants.ADD_MONEY_TO_WALLET)}
				/>
				<Input
					value={amount}
					width={normalScale(288)}
					label={`${localeString(keyConstants.AMOUNT)}*`}
					placeholder={localeString(keyConstants.AMOUNT)}
					blurOnSubmit
					returnKeyType="done"
					keyboardType="decimal-pad"
					isRTL={isRTL}
					onChangeText={text =>
						(spaceRegexEx.test(String(text).toLowerCase()) || text === '') &&
						this.onChangeText(text, 'amount')
					}
					autoCapitalize="none"
					isError={isAmountError}
					errorMessage={errorMessage}
					onBlur={this.onBlur}
				/>
				<View style={styles.buttonView}>
					<ButtonComponent
						text={localeString(keyConstants.PROCEED)}
						onPress={this.onAddMoney}
						isButtonDisable={!(!isAmountError && amount >= minAmountToAddMoney)}
					/>
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		addMoneyInfo: state.AddMoneyScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		addMoneyActions: bindActionCreators({ ...AddMoneyActions }, dispatch),
	};
};

AddMoneyScreen.propTypes = {
	addMoneyInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	addMoneyActions: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(AddMoneyScreen);
