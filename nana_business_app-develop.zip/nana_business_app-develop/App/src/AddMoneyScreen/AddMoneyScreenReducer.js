import * as ActionTypes from './ActionType';

const initialState = {
	amount: 0,
	paymentDetail: null,
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	isCalledfromHomeScreen: false,
};

const AddMoneyScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_ADD_TEXT:
			return {
				[action.field]: action.payload,
			};
		case ActionTypes.ADD_MONEY_SUCCESS: {
			const isCalledfromHomeScreenSuccess = action.extra; // Boolean to check this action is called from home screen or not.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				paymentDetail: action.payload,
				isCalledfromHomeScreen: isCalledfromHomeScreenSuccess,
			};
		}
		case ActionTypes.ADD_MONEY_LOADER: {
			const isCalledfromHomeScreenLoader = action.extra; // Boolean to check this action is called from home screen or not.
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCalledfromHomeScreen: isCalledfromHomeScreenLoader,
			};
		}
		case ActionTypes.ADD_MONEY_FAILURE: {
			const isCalledfromHomeScreenFailure = action.extra; // Boolean to check this action is called from home screen or not.
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isCalledfromHomeScreen: isCalledfromHomeScreenFailure,
			};
		}
		case ActionTypes.RESET_ADD_MONEY_STATE: // Will reset the state.
			return initialState;
		default:
			return state;
	}
};

export default AddMoneyScreenReducer;
