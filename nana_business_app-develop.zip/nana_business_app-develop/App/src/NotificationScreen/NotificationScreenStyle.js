import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		customerView: {
			alignItems: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			borderTopWidth: verticalScale(1),
			borderColor: colors.grey,
		},
		image: {
			height: normalScale(36),
			width: normalScale(36),
			borderRadius: normalScale(18),
		},
		detailsView: {
			paddingVertical: verticalScale(12),
			flex: 1,
		},
		titleContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			flex: 1,
			alignContent: 'center',
			alignItems: 'center',
			paddingRight: normalScale(8),
		},
		titleUnRead: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			marginBottom: verticalScale(4),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		titleRead: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginBottom: verticalScale(4),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		notificationBody: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(10),
			marginBottom: verticalScale(12),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		notificationTime: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(10),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		unreadDot: {
			backgroundColor: colors.seaGreen,
			width: normalScale(6),
			height: normalScale(6),
			borderRadius: normalScale(3),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		bodyStyle: {
			fontSize: normalize(12),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		header: {
			marginTop: verticalScale(8),
			marginHorizontal: normalScale(16),
		},
		scrollView: {
			flex: 1,
		},
		listingView: {
			marginTop: verticalScale(8),
			marginHorizontal: normalScale(16),
			flex: 1,
		},
	});
};

export default createStyleSheet;
