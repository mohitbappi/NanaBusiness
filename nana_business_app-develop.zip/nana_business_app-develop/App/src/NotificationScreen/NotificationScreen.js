import React, { Component } from 'react';
import { Text, View, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import {
	fetchDataWithPagination,
	collector,
	numberOfLineForNotifMessage,
	vendor,
	NOTIFICATION_ROUTE,
	driver,
	cashier,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import { getFormattedDateWithTime } from '@Util/GetFormattedDate';
import vendorNavigations from '@routes/vendorNavigations';
import collectorNavigations from '@routes/collectorNavigations';
import navigations from '@routes/navigations';
import driverNavigations from '@routes/driverNavigations';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import AlertComponent from '@Util/AlertComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import * as MyCollectionActions from '@CollectionScreen/CollectionScreenAction';
import cashierNavigations from '@config/routes/cashierNavigations';
import * as NotificationScreenActions from './NotificationScreenAction';
import { createStyleSheet } from './NotificationScreenStyle';
import NotificationPopupScreen from './NotificationPopupScreen';

class NotificationScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			isNotificationPopUpVisible: false,
			notificationItem: {},
			currentIndex: null,
		};
	}

	componentDidMount() {
		const { navigation, route, notificationScreenActions } = this.props;
		const { notificationCount } = route.params;
		notificationScreenActions.onSetUnreadNotificationsCount(notificationCount);
		this.willFocusListener = navigation.addListener('focus', () => {
			const { pullToRefreshActions } = this.props;
			this.page = fetchDataWithPagination.page;
			// call Notification Listing Api on page load
			this.onLoadMore(false);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			route,
			notificationInfo,
			notificationScreenActions,
			pullToRefreshActions,
		} = this.props;
		const {
			success,
			isMarkAllRead,
			isMarkRead,
			unreadNotificationsCount,
			notificationListing,
			error,
			errorCode,
		} = notificationInfo;
		const { currentIndex, notificationItem } = this.state;
		const { notificationCount } = route.params;
		if (success && prevProps.notificationInfo.success !== success) {
			// If notification API returns success.
			if (isMarkAllRead) {
				// if set all notification to be read
				notificationScreenActions.onSetUnreadNotificationsCount(0);
			} else if (isMarkRead) {
				// if set selected notification read
				notificationScreenActions.onSetUnreadNotificationsCount(
					unreadNotificationsCount - 1,
				);
				notificationListing[currentIndex].is_read = true;
				notificationListing.splice(currentIndex, 1, notificationListing[currentIndex]);
			} else {
				// If notification listing API returns success.
				this.setState({
					bottomLoader: false,
				});
				pullToRefreshActions.onHandlePullToRefresh(false);
				notificationScreenActions.onSetUnreadNotificationsCount(
					notificationCount !== unreadNotificationsCount
						? unreadNotificationsCount
						: notificationCount,
				);
			}
		}
		if (
			error &&
			(isMarkAllRead || isMarkRead) &&
			prevProps.notificationInfo.error !== notificationInfo.error
		) {
			// Will show alert if api fails
			ErrorAlertComponent(
				errorCode,
				isMarkAllRead
					? this.onMarkAllNotificationsRead
					: () => this.updateNotificationReadStatus(notificationItem.id),
			);
		}
	}

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		// API calls to get the notification listing.
		const { notificationScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		notificationScreenActions.onGetAllNotifications(queryParams, isOverwriteExistingList);
	};

	onPressClose = () => {
		// function to go back from the notification screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponentNotification = () => {
		const { languageInfo, notificationInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { notificationListing, count } = notificationInfo;
		const endReached =
			count === notificationListing.length || count < notificationListing.length;
		if (!endReached) {
			// will show a small loader on listing pagination
			return <Loader size="small" isSmallLoader />;
		}
		// if no data is available in notification listing
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReachedNotification = () => {
		const { notificationInfo } = this.props;
		const { loader } = notificationInfo;
		if (!loader) {
			this.setState(
				{
					bottomLoader: true,
				},
				() => {
					this.page += 1;
					this.onLoadMore(true);
				},
			);
		}
	};

	renderItem = ({ item, index }) => {
		// row item component for notification list.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				style={styles.customerView}
				onPress={() => this.showNotificationPopUp(item, index)}>
				<View style={styles.detailsView}>
					<View style={styles.titleContainer}>
						<Text style={item.is_read ? styles.titleRead : styles.titleUnRead}>
							{isRTL ? item.title_ar : item.title}
						</Text>
						{item.is_read ? null : <View style={styles.unreadDot} />}
					</View>
					<Text
						numberOfLines={numberOfLineForNotifMessage}
						style={styles.notificationBody}>
						{isRTL ? item.body_ar : item.body}
					</Text>
					<Text style={styles.notificationTime}>
						{getFormattedDateWithTime(item.created_at)}
					</Text>
				</View>
			</TouchableOpacity>
		);
	};

	showNotificationPopUp = (item, index) => {
		// will open notification pop-up
		this.setState(
			{
				notificationItem: item,
				isNotificationPopUpVisible: true,
			},
			() => {
				if (!item.is_read) {
					this.setState({ currentIndex: index });
					this.updateNotificationReadStatus(item.id);
				}
			},
		);
	};

	onCloseNotificationPopUp = () => {
		// will close notification pop-up
		this.setState({
			isNotificationPopUpVisible: false,
			notificationItem: {},
		});
	};

	onNavigate = () => {
		// function to navigate to screen accordingly
		const { userDetails, navigation, myCollectionActions } = this.props;
		const { role, id } = userDetails.user;
		const { notificationItem } = this.state;
		this.onCloseNotificationPopUp();
		switch (role) {
			case driver:
				if (notificationItem.type === NOTIFICATION_ROUTE.Shipments) {
					navigation.navigate(driverNavigations.SHIPMENTS_NAVIGATION);
				} else if (notificationItem.type === NOTIFICATION_ROUTE.PurchaseReturns) {
					navigation.navigate(driverNavigations.PURCHASE_RETURN_INVOICE_NAVIGATION);
				} else if (notificationItem.type === NOTIFICATION_ROUTE.PurchaseInvoices) {
					navigation.navigate(driverNavigations.PURCHASE_INVOICE_NAVIGATION);
				}
				return;
			case collector:
				if (notificationItem.type === NOTIFICATION_ROUTE.Collections) {
					myCollectionActions.onSetTabIndex(0);
				}
				if (notificationItem.type === NOTIFICATION_ROUTE.MadaTransactions) {
					myCollectionActions.onSetTabIndex(1);
				}
				navigation.navigate(collectorNavigations.COLLECTION_NAVIGATION);
				return;
			case vendor:
				if (notificationItem.type === NOTIFICATION_ROUTE.Collections) {
					navigation.navigate(vendorNavigations.MY_INVOICES_NAVIGATION);
				}
				return;
			case cashier:
				if (notificationItem.type === NOTIFICATION_ROUTE.ReceivablesSection) {
					navigation.navigate(cashierNavigations.RECEIVABLES_NAVIGATION);
				} else if (
					notificationItem.type === NOTIFICATION_ROUTE.DepositsSection ||
					notificationItem.type === NOTIFICATION_ROUTE.Collections
				) {
					navigation.navigate(cashierNavigations.PENDING_DEPOSIT_NAVIGATION);
				}
				return;
			default: {
				const routes = this.getNotificationRoute(id); // Will return routes with params.
				const { route, params } = routes[notificationItem.type];
				navigation.navigate(route, params); // Will navigate to requested screen.
				break;
			}
		}
	};

	getNotificationRoute = id => {
		return {
			[`${NOTIFICATION_ROUTE.Collections}`]: {
				// Navigation to collection request.
				route: navigations.INVOICES_NAVIGATION,
				params: {},
			},
			[`${NOTIFICATION_ROUTE.Home}`]: {
				// Navigation to home.
				route: navigations.HOME_NAVIGATION,
				params: {},
			},
			[`${NOTIFICATION_ROUTE.OrderDetails}`]: {
				// Navigation to orders.
				route: navigations.ORDERS_NAVIGATION,
				params: {},
			},
			[`${NOTIFICATION_ROUTE.CustomerAdmin}`]: {
				// Navigation to user list.
				route: navigations.USER_LIST_NAVIGATION,
				params: {},
			},
			[`${NOTIFICATION_ROUTE.CreditLineDetails}`]: {
				// Navigation to credit line.
				route: navigations.CREDIT_LINE_REPORT_NAVIGATION,
				params: { organizationId: id }, // Navigation params
			},
			[`${NOTIFICATION_ROUTE.BalanceDetails}`]: {
				// Navigation to balance details.
				route: navigations.BALANCE_DETAILS_NAVIGATION,
				params: {},
			},
		};
	};

	updateNotificationReadStatus = notification_id => {
		// function to update read status of notification
		const { notificationScreenActions } = this.props;
		const queryParams = { notification_id };
		notificationScreenActions.onUpdateNotificationReadStatus(queryParams);
	};

	onRefresh = () => {
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	// show alert for marks all notifications as read
	onShowAlert = () => {
		const alertOptions = {
			message: localeString(keyConstants.MARK_NOTIFICATIONS_READ),
			yesText: localeString(keyConstants.YES),
			noText: localeString(keyConstants.NO),
			onPressYes: this.onMarkAllNotificationsRead,
		};
		AlertComponent(alertOptions);
	};

	onMarkAllNotificationsRead = () => {
		// marks all notifications as read
		const { notificationScreenActions } = this.props;
		notificationScreenActions.onSetAllNotificationsRead();
	};

	render() {
		const { languageInfo, notificationInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { bottomLoader, isNotificationPopUpVisible, notificationItem } = this.state;
		const { title, title_ar, body, body_ar, type } = notificationItem || {};
		const {
			loader,
			notificationListing,
			count,
			unreadNotificationsCount,
			error,
			errorCode,
			isMarkAllRead,
			isMarkRead,
		} = notificationInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && <Loader size="large" />}
				<NotificationPopupScreen
					isRTL={isRTL}
					isVisible={isNotificationPopUpVisible}
					title={isRTL ? title_ar : title}
					body={isRTL ? body_ar : body}
					onClose={this.onCloseNotificationPopUp}
					onNavigate={this.onNavigate}
					hasButton={type && type !== NOTIFICATION_ROUTE.CreditLineRequest}
					bodyStyle={styles.bodyStyle}
				/>
				<View style={styles.header}>
					<Header
						text={`${localeString(keyConstants.NOTIFICATIONS)}`}
						textSecondary={
							parseInt(unreadNotificationsCount, 10) !== 0
								? `(${unreadNotificationsCount})`
								: ''
						}
						hasIconNotificationLeft
						hasIconClose
						onPressClose={this.onPressClose}
						hasIconMarkAllNotificationsRead={
							parseInt(unreadNotificationsCount, 10) !== 0
						}
						onPressMarkAllNotificationsRead={this.onShowAlert}
					/>
				</View>
				{error && !isMarkRead && !isMarkAllRead ? (
					// Will show error component if api fails.
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<View style={styles.listingView}>
						<FlatListComponent
							data={notificationListing}
							renderItem={this.renderItem}
							keyExtractor={this.keyExtractor}
							showsVerticalScrollIndicator={false}
							onEndReached={() =>
								notificationListing.length !== count &&
								this.onEndReachedNotification()
							}
							ListFooterComponent={
								notificationListing.length !== 0 &&
								count > fetchDataWithPagination.limit &&
								this.listFooterComponentNotification()
							}
							onEndReachedThreshold={0.5}
							ListEmptyComponent={() => (
								<ListEmpty
									text={localeString(keyConstants.NO_NOTIFICATIONS_FOUND)}
								/>
							)}
							contentContainerStyle={
								notificationListing.length === 0 ? styles.scrollView : null
							}
							onRefresh={this.onRefresh}
							componentType={constants.flatList}
						/>
					</View>
				)}
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		notificationInfo: state.NotificationScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		notificationScreenActions: bindActionCreators({ ...NotificationScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		myCollectionActions: bindActionCreators({ ...MyCollectionActions }, dispatch),
	};
};

NotificationScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	notificationInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	notificationScreenActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	myCollectionActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(NotificationScreen);
