import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	notificationListing: [],
	count: 0,
	unreadNotificationsCount: 0,
	isMarkAllRead: false,
	isMarkRead: false,
};

const NotificationScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_NOTIFICATIONS_LISTING_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				notificationListing: isOverwriteExistingList
					? [...state.notificationListing, ...action.payload.notifications]
					: action.payload.notifications,
				count: parseInt(action.payload.count, 10),
				isMarkAllRead: false,
				isMarkRead: false,
			};
		}
		case ActionTypes.GET_NOTIFICATIONS_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_NOTIFICATIONS_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isMarkAllRead: false,
				isMarkRead: false,
			};
		case ActionTypes.GET_NOTIFICATION_READ_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isMarkRead: true,
				isMarkAllRead: false,
			};
		case ActionTypes.GET_NOTIFICATIONS_READ_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isMarkRead: true,
				isMarkAllRead: false,
			};
		case ActionTypes.SET_ALL_NOTIFICATIONS_READ_SUCCESS: {
			const newNotificationListing = state.notificationListing.map(notification => {
				return {
					...notification,
					is_read: true, // marks all notifications as read locally on success
				};
			});
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				notificationListing: newNotificationListing,
				isMarkAllRead: true,
				isMarkRead: false,
			};
		}
		case ActionTypes.SET_ALL_NOTIFICATIONS_READ_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isMarkAllRead: true,
				isMarkRead: false,
			};
		case ActionTypes.SET_UNREAD_NOTIFICATIONS_COUNT:
			return {
				...state,
				unreadNotificationsCount: action.payload,
				success: false,
				isMarkAllRead: false,
				isMarkRead: false,
			};
		default:
			return state;
	}
};

export default NotificationScreenReducer;
