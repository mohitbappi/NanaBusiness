import React from 'react';
import { StyleSheet, Modal, View, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import normalize, {
	verticalScale,
	normalScale,
	moderateScale,
	lineHeightScale,
} from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import IMAGES from '@Images/index';
import { fontsConstants, notificationTitleLength } from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.opacityGrey,
			justifyContent: 'center',
			alignItems: 'center',
			width: '100%',
			height: '100%',
			paddingHorizontal: normalScale(17),
		},
		innerContainer: {
			backgroundColor: colors.white,
			paddingVertical: verticalScale(16),
			width: '100%',
			borderRadius: moderateScale(8),
		},
		header: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			borderBottomColor: colors.grey,
			paddingHorizontal: normalScale(12),
			borderBottomWidth: normalScale(1),
			paddingBottom: verticalScale(14),
			justifyContent: 'center',
		},
		title: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			color: colors.darkBlue,
		},
		iconView: {
			position: 'absolute',
			right: normalScale(12),
			top: verticalScale(4),
			bottom: 0,
		},
		iconCross: {
			height: verticalScale(12),
			width: verticalScale(12),
		},
		detailContainer: {
			marginTop: verticalScale(10),
			justifyContent: 'center',
			alignItems: 'center',
			paddingHorizontal: normalScale(8),
		},
		name: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			color: colors.black,
			lineHeight: lineHeightScale(18),
			marginBottom: verticalScale(8),
		},
		button: {
			width: normalScale(100),
			alignSelf: 'center',
		},
		congratsButtonStyle: {
			marginHorizontal: normalScale(8),
			marginTop: verticalScale(12),
		},
	});
};

const NotificationPopupScreen = props => {
	// Modal pop-up component for Notification View
	const {
		isRTL,
		isVisible,
		title,
		body,
		loader,
		onClose,
		onNavigate,
		bodyStyle, // Will pass custom body style from props.
		hasButton, // Boolean to show button
	} = props;
	const styles = createStyleSheet(isRTL);
	return isVisible ? (
		<Modal transparent>
			{loader && <Spinner size="large" />}
			<View style={styles.container}>
				<View style={styles.innerContainer}>
					<View style={styles.header}>
						<Text style={styles.title}>
							{title.length > notificationTitleLength
								? `${title.split('', notificationTitleLength).join('')}...`
								: title}
						</Text>
						<TouchableOpacity
							style={styles.iconView}
							activeOpacity={0.8}
							onPress={onClose}>
							<ImageLoadComponent
								source={IMAGES.iconCross}
								style={styles.iconCross}
							/>
						</TouchableOpacity>
					</View>
					<View style={styles.detailContainer}>
						<Text style={[styles.name, bodyStyle]}>{body}</Text>
					</View>
					{hasButton && (
						<View style={styles.button}>
							<ButtonComponent
								viewStyle={styles.congratsButtonStyle}
								onPress={onNavigate}
								text={localeString(keyConstants.VIEW)}
								isButtonDisable={false}
							/>
						</View>
					)}
				</View>
			</View>
		</Modal>
	) : null;
};

NotificationPopupScreen.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	isVisible: PropTypes.bool.isRequired,
	title: PropTypes.string.isRequired,
	body: PropTypes.string.isRequired,
	loader: PropTypes.bool.isRequired,
	onClose: PropTypes.func.isRequired,
	onNavigate: PropTypes.func.isRequired,
	bodyStyle: PropTypes.object.isRequired,
	hasButton: PropTypes.bool.isRequired,
};

export default NotificationPopupScreen;
