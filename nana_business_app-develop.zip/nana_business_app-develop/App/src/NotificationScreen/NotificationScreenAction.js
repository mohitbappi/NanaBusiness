import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import GetAllNotificationsService from '@Notification/GetAllNotificationsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import UpdateNotificationReadStatusService from '@Notification/UpdateNotificationReadStatusService';
import SetAllNotificationsReadService from '@Notification/SetAllNotificationsReadService';
import * as ActionTypes from './ActionType';

/**
 * Action to get notification listing
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetAllNotifications = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_NOTIFICATIONS_LISTING_SUCCESS,
		ActionTypes.GET_NOTIFICATIONS_LISTING_FAILURE,
		ActionTypes.GET_NOTIFICATIONS_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getAllNotificationsService = new GetAllNotificationsService(dispatchedActions);
	addBasicInterceptors(getAllNotificationsService);
	getAllNotificationsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getAllNotificationsService.makeRequest(props));
};

/**
 * Action to update notification read status
 * @param {object} props
 */
export const onUpdateNotificationReadStatus = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_NOTIFICATION_READ_SUCCESS,
		ActionTypes.GET_NOTIFICATIONS_READ_FAILURE,
		ActionTypes.GET_NOTIFICATIONS_READ_LOADER,
	);
	const updateNotificationReadStatusService = new UpdateNotificationReadStatusService(
		dispatchedActions,
	);
	addBasicInterceptors(updateNotificationReadStatusService);
	updateNotificationReadStatusService.addRequestInterceptor(
		new AuthenticationHeaderInterceptor(),
	);
	dispatch(updateNotificationReadStatusService.makeRequest(props));
};

// Action to mark all notifications as read
export const onSetAllNotificationsRead = () => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SET_ALL_NOTIFICATIONS_READ_SUCCESS,
		ActionTypes.SET_ALL_NOTIFICATIONS_READ_FAILURE,
		ActionTypes.SET_ALL_NOTIFICATIONS_READ_LOADER,
	);
	const setAllNotificationsReadService = new SetAllNotificationsReadService(dispatchedActions);
	addBasicInterceptors(setAllNotificationsReadService);
	setAllNotificationsReadService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(setAllNotificationsReadService.makeRequest());
};

/**
 * Action to set number of unread notification count
 * @param {int} count
 */
export const onSetUnreadNotificationsCount = count => {
	return {
		type: ActionTypes.SET_UNREAD_NOTIFICATIONS_COUNT,
		payload: count,
	};
};
