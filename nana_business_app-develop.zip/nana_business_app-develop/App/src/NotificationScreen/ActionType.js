export const GET_NOTIFICATIONS_LISTING_SUCCESS = 'get_notifications_listing_success';
export const GET_NOTIFICATIONS_LISTING_FAILURE = 'get_notifications_listing_failure';
export const GET_NOTIFICATIONS_LISTING_LOADER = 'get_notifications_listing_loader';

export const GET_NOTIFICATION_READ_SUCCESS = 'get_notifications_read_success';
export const GET_NOTIFICATIONS_READ_FAILURE = 'get_notifications_read_failure';
export const GET_NOTIFICATIONS_READ_LOADER = 'get_notifications_read_loader';

export const SET_ALL_NOTIFICATIONS_READ_SUCCESS = 'SET_ALL_NOTIFICATIONS_READ_SUCCESS';
export const SET_ALL_NOTIFICATIONS_READ_FAILURE = 'SET_ALL_NOTIFICATIONS_READ_FAILURE';
export const SET_ALL_NOTIFICATIONS_READ_LOADER = 'SET_ALL_NOTIFICATIONS_READ_LOADER';

export const SET_UNREAD_NOTIFICATIONS_COUNT = 'SET_UNREAD_NOTIFICATIONS_COUNT';
