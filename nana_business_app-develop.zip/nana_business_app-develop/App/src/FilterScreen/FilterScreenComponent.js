// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@assets/Localization';

// import components
import FilterScreenUI from './FilterScreenUI';

class FilterScreenComponent extends Component {
	constructor(props) {
		super(props);
		const { selectedCategoryId, selectedBrandId } = props;
		this.state = {
			filter: [
				{
					title: localeString(keyConstants.CATEGORIES),
				},
				{
					title: localeString(keyConstants.BRANDS),
				},
				// Todo:- Will remove this comment when we use this sorting.
				// {
				// 	title: localeString(keyConstants.PRICE),
				// },
			],
			selectedFilterIndex: selectedCategoryId ? 0 : 1,
			selectedCategoryId,
			selectedBrandId,
			priceFilter: [
				localeString(keyConstants.HIGH_TO_LOW),
				localeString(keyConstants.LOW_TO_HIGH),
			],
			selectedPriceIndex: 0,
		};
	}

	onPressFilterTitle = index => {
		// Set selected filter title index.
		const { onSwitchTab } = this.props;
		this.setState({ selectedFilterIndex: index }, () => {
			onSwitchTab(index);
		});
	};

	onPressOption = id => {
		// Set selected category id.
		this.setState({ selectedCategoryId: id, selectedBrandId: null });
	};

	onPressBrand = id => {
		// Set selected brand id.
		this.setState({ selectedBrandId: id, selectedCategoryId: null });
	};

	onSelectPrice = index => {
		// Set selected price sorting index.
		this.setState({ selectedPriceIndex: index });
	};

	render() {
		const {
			isRTL,
			categoryListing, // Array of all the categories.
			onPressCancel,
			onPressApply,
			onEndReached,
			onEndReachedBrand,
			error,
			errorCode,
			onCallApi,
			brandListing,
		} = this.props;
		const {
			filter,
			selectedFilterIndex,
			selectedCategoryId,
			selectedBrandId,
			priceFilter,
			selectedPriceIndex,
		} = this.state;
		return (
			<FilterScreenUI
				isRTL={isRTL}
				categoryListing={categoryListing}
				onPressBack={onPressCancel}
				onPressApply={onPressApply}
				selectedFilterIndex={selectedFilterIndex}
				filterTitle={filter}
				onPressOption={this.onPressOption}
				onPressFilterTitle={this.onPressFilterTitle}
				selectedCategoryId={selectedCategoryId}
				onEndReached={onEndReached}
				onEndReachedBrand={onEndReachedBrand}
				error={error}
				errorCode={errorCode}
				onCallApi={onCallApi}
				onPressBrand={this.onPressBrand}
				selectedBrandId={selectedBrandId}
				brandListing={brandListing}
				priceFilter={priceFilter}
				selectedPriceIndex={selectedPriceIndex}
				onSelectPrice={this.onSelectPrice}
			/>
		);
	}
}

FilterScreenComponent.propTypes = {
	selectedBrandId: PropTypes.element.isRequired,
	selectedCategoryId: PropTypes.element.isRequired,
	onSwitchTab: PropTypes.func.isRequired,
	isRTL: PropTypes.bool.isRequired,
	categoryListing: PropTypes.array.isRequired,
	onPressCancel: PropTypes.func.isRequired,
	onPressApply: PropTypes.func.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onEndReachedBrand: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	onCallApi: PropTypes.func.isRequired,
	brandListing: PropTypes.array.isRequired,
};

export default FilterScreenComponent;
