import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import { moderateScale, normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		filterTitle: {
			paddingHorizontal: normalScale(12),
			paddingVertical: verticalScale(13),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		selectedFilterTitle: {
			backgroundColor: colors.lightGreen,
		},
		filterTitleText: {
			color: colors.blackGreyWhite,
			fontSize: normalScale(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		selectedFilterTitleText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		filterOption: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			borderBottomColor: colors.whitishGrey,
			borderBottomWidth: 1,
			justifyContent: 'space-between',
			alignItems: 'center',
			paddingVertical: verticalScale(12),
			paddingHorizontal: verticalScale(12),
		},
		filterOptionText: {
			color: colors.black,
			fontSize: normalScale(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		selectedFilterOptionText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		iconRight: {
			height: verticalScale(9),
			width: verticalScale(12),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			shadowColor: colors.pureBlack,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.05,
			elevation: verticalScale(2),
		},
		headerStyle: {
			paddingHorizontal: normalScale(16),
		},
		body: {
			flex: 1,
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		sidebar: {
			width: normalScale(120),
			backgroundColor: colors.lighterGrey,
			borderBottomRightRadius: isRTL ? 0 : normalScale(10),
			borderBottomLeftRadius: isRTL ? normalScale(10) : 0,
			borderRightColor: colors.greenShadow,
			borderRightWidth: normalScale(1),
		},
		mainView: {
			flex: 1,
		},
		scrollView: {
			paddingBottom: verticalScale(65),
		},
		options: {
			marginTop: verticalScale(7),
		},
	});
};

export default createStyleSheet;
