// import libraries
import React, { Component } from 'react';
import { View, Text, TouchableOpacity, FlatList } from 'react-native';
import PropTypes from 'prop-types';

// import utils
import { localeString } from '@assets/Localization';
import IMAGES from '@Images/index';

// import constants
import { keyConstants } from '@assets/Constants/KeyConstants';

// import components
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import Header from '@Header/Header';
import SaveCancelButtonComponent from '@Components/SaveCancelButtonComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

// import styles
import { createStyleSheet } from './FilterScreenStyle';

class FilterScreenUI extends Component {
	keyExtractor = (item, index) => {
		return index.toString();
	};

	renderFilterTitles = ({ item, index }) => {
		// Will show all the titles on the sidebar.
		const { isRTL, onPressFilterTitle, selectedFilterIndex } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				onPress={() => onPressFilterTitle(index)}
				style={[
					styles.filterTitle,
					index === selectedFilterIndex && styles.selectedFilterTitle,
				]}>
				<Text
					style={[
						styles.filterTitleText,
						index === selectedFilterIndex && styles.selectedFilterTitleText,
					]}>
					{item.title}
				</Text>
			</TouchableOpacity>
		);
	};

	getFilterList = index => {
		// Will return filter options.
		const { categoryListing, brandListing, priceFilter } = this.props;
		const data = {
			0: categoryListing, // Category listing.
			1: brandListing, // Brand listing.
			2: priceFilter, // Price sorting.
		};
		return data[index];
	};

	renderPriceOptions = ({ item, index }) => {
		// Will show price sorting options.
		const { isRTL, onSelectPrice, selectedPriceIndex } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				onPress={() => onSelectPrice(index)}
				style={styles.filterOption}>
				<Text
					style={[
						styles.filterOptionText,
						index === selectedPriceIndex && styles.selectedFilterOptionText,
					]}>
					{item}
				</Text>
				{index === selectedPriceIndex ? (
					<ImageLoadComponent source={IMAGES.iconRight} style={styles.iconRight} />
				) : null}
			</TouchableOpacity>
		);
	};

	renderFilterOptions = ({ item }) => {
		// Will show options of the selected title.
		const { isRTL, onPressOption, onPressBrand, selectedFilterIndex } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				onPress={() =>
					selectedFilterIndex === 0 ? onPressOption(item.id) : onPressBrand(item.id)
				}
				style={styles.filterOption}>
				<Text
					style={[
						styles.filterOptionText,
						this.onCheckOptionSelected(item.id) && styles.selectedFilterOptionText,
					]}>
					{isRTL ? item.name_ar : item.name}
				</Text>
				{this.onCheckOptionSelected(item.id) ? (
					<ImageLoadComponent source={IMAGES.iconRight} style={styles.iconRight} />
				) : null}
			</TouchableOpacity>
		);
	};

	onCheckOptionSelected = id => {
		// Will highlight selected category or brand.
		const { selectedCategoryId, selectedBrandId } = this.props;
		if (selectedCategoryId === id || selectedBrandId === id) {
			return true;
		}
		return false;
	};

	render() {
		const {
			isRTL,
			onPressBack,
			onPressApply,
			selectedFilterIndex,
			filterTitle,
			selectedCategoryId,
			onEndReached,
			onEndReachedBrand,
			error,
			errorCode,
			onCallApi,
			selectedBrandId,
			selectedPriceIndex,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.FILTER)}
						hasIconFilter
						hasIconBack
						onPressBack={onPressBack}
						headerStyle={styles.headerStyle}
					/>
				</View>
				{error ? (
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onCallApi} />
				) : (
					<>
						<View style={styles.body}>
							<View style={styles.sidebar}>
								<FlatList
									data={filterTitle}
									extraData={selectedFilterIndex}
									showsVerticalScrollIndicator={false}
									renderItem={this.renderFilterTitles}
									keyExtractor={this.keyExtractor}
								/>
							</View>
							<View style={styles.mainView}>
								<FlatList
									data={this.getFilterList(selectedFilterIndex)}
									showsVerticalScrollIndicator={false}
									renderItem={
										selectedFilterIndex === 2
											? this.renderPriceOptions
											: this.renderFilterOptions
									}
									keyExtractor={this.keyExtractor}
									style={styles.options}
									onEndReachedThreshold={0.5}
									onEndReached={
										selectedFilterIndex === 0 ? onEndReached : onEndReachedBrand
									}
									contentContainerStyle={styles.scrollView}
								/>
							</View>
						</View>
						<SaveCancelButtonComponent
							isRTL={isRTL}
							cancelText={localeString(keyConstants.CANCEL)}
							onPressCancel={onPressBack}
							saveText={localeString(keyConstants.APPLY)}
							onPressSave={() =>
								onPressApply(
									selectedCategoryId,
									selectedBrandId,
									selectedPriceIndex,
								)
							}
						/>
					</>
				)}
			</View>
		);
	}
}

FilterScreenUI.propTypes = {
	selectedBrandId: PropTypes.element.isRequired,
	selectedCategoryId: PropTypes.element.isRequired,
	onPressFilterTitle: PropTypes.func.isRequired,
	isRTL: PropTypes.bool.isRequired,
	categoryListing: PropTypes.array.isRequired,
	selectedFilterIndex: PropTypes.element.isRequired,
	onPressApply: PropTypes.func.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onEndReachedBrand: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	onCallApi: PropTypes.func.isRequired,
	brandListing: PropTypes.array.isRequired,
	priceFilter: PropTypes.array.isRequired,
	onSelectPrice: PropTypes.func.isRequired,
	selectedPriceIndex: PropTypes.element.isRequired,
	onPressOption: PropTypes.func.isRequired,
	onPressBrand: PropTypes.func.isRequired,
	onPressBack: PropTypes.func.isRequired,
	filterTitle: PropTypes.string.isRequired,
};

export default FilterScreenUI;
