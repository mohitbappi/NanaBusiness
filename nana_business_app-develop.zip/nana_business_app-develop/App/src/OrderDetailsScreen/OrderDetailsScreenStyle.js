import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		itemListView: {
			paddingVertical: verticalScale(16),
			paddingHorizontal: normalScale(16),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(4),
		},
		topView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		item: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			marginBottom: verticalScale(10),
		},
		reason: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		bottomButtonView: {
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
		pendingItems: {
			color: colors.blue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(12),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		listEmptyContainer: {
			marginBottom: verticalScale(10),
		},
		shipmentContainer: {
			backgroundColor: colors.white,
			borderColor: colors.greenShadow,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(4),
			marginHorizontal: normalScale(8),
			marginBottom: verticalScale(12),
			shadowColor: colors.shadowLightGreen,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(4),
			shadowOpacity: 0.1,
			elevation: verticalScale(4),
		},
		shipmentView: {
			paddingVertical: verticalScale(6),
			paddingHorizontal: verticalScale(16),
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		lastRow: {
			borderBottomWidth: normalScale(0),
		},
		id: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		items: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(6),
		},
		amountView: {
			justifyContent: 'center',
		},
		shipmentAmount: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			marginBottom: verticalScale(6),
			textAlign: rtlFunctions.getTextAlignOpposite(isRTL),
		},
		status: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.boldItalic),
			fontSize: normalize(12),
			textAlign: rtlFunctions.getTextAlignOpposite(isRTL),
		},
		itemView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginBottom: verticalScale(12),
			marginHorizontal: normalScale(16),
		},
		itemImage: {
			width: normalScale(35),
			height: normalScale(35),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 10),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 10),
		},
		name: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(10),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		priceView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(4),
		},
		amount: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(10),
		},
		totalPrice: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(10),
		},
		scrollView: {
			marginBottom: verticalScale(65),
		},
		paymentDetails: {
			paddingVertical: verticalScale(16),
			paddingHorizontal: normalScale(16),
		},
		detail: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingVertical: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			marginTop: verticalScale(4),
			borderRadius: moderateScale(4),
		},
		text: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(10),
		},
		total: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingVertical: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			borderRadius: moderateScale(4),
		},
		discount: {
			color: colors.green,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
		},
		paymentMode: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
		},
		pay: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(8),
		},
		totalAmount: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(10),
		},
		pendingView: {
			paddingVertical: verticalScale(16),
			paddingHorizontal: normalScale(16),
			borderTopColor: colors.grey,
			borderTopWidth: normalScale(4),
		},
		deliveryCodeView: {
			paddingVertical: verticalScale(3),
			paddingHorizontal: normalScale(8),
			backgroundColor: colors.skyBlue,
			alignItems: 'center',
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		textDeliveryCode: {
			color: colors.lightBlueShadowGrey,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
		},
	});
};

export default createStyleSheet;
