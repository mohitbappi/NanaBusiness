import { actions } from '@libapi/APIActionsBuilder';
import GetOrderDetailService from '@Orders/GetOrderDetailService';
import RepeatOrderService from '@Orders/RepeatOrderService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to get order detail
 * @param {object} props
 */
export const onGetOrderDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_ORDER_DETAIL_SUCCESS,
		ActionTypes.GET_ORDER_DETAIL_FAILURE,
		ActionTypes.GET_ORDER_DETAIL_LOADER,
	);
	const getOrderDetailService = new GetOrderDetailService(dispatchedActions);
	addBasicInterceptors(getOrderDetailService);
	getOrderDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getOrderDetailService.makeRequest(props));
};

/**
 * Action to repeat order
 * @param {object} props
 */
export const onRepeatOrder = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.REPEAT_ORDER_SUCCESS,
		ActionTypes.REPEAT_ORDER_FAILURE,
		ActionTypes.REPEAT_ORDER_LOADER,
	);
	const repeatOrderService = new RepeatOrderService(dispatchedActions);
	addBasicInterceptors(repeatOrderService);
	repeatOrderService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(repeatOrderService.makeRequest(props));
};
