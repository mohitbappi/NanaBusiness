export const GET_ORDER_DETAIL_SUCCESS = 'get_order_detail_success';
export const GET_ORDER_DETAIL_FAILURE = 'get_order_detail_failure';
export const GET_ORDER_DETAIL_LOADER = 'get_order_detail_loader';
export const REPEAT_ORDER_SUCCESS = 'repeat_order_success';
export const REPEAT_ORDER_FAILURE = 'repeat_order_failure';
export const REPEAT_ORDER_LOADER = 'repeat_order_loader';
