import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	orderDetail: null,
	isRepeatOrder: false,
};

const OrderDetailsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_ORDER_DETAIL_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				orderDetail: action.payload,
				isRepeatOrder: false,
			};
		case ActionTypes.GET_ORDER_DETAIL_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isRepeatOrder: false,
			};
		case ActionTypes.GET_ORDER_DETAIL_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isRepeatOrder: false,
			};
		case ActionTypes.REPEAT_ORDER_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isRepeatOrder: true,
			};
		case ActionTypes.REPEAT_ORDER_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isRepeatOrder: true,
			};
		case ActionTypes.REPEAT_ORDER_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isRepeatOrder: true,
			};
		default:
			return state;
	}
};

export default OrderDetailsScreenReducer;
