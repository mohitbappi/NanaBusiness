import React, { Component } from 'react';
import { View, Text, FlatList, TouchableOpacity, BackHandler, Alert } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import OrderCard from '@OrdersScreen/OrderCard';
import {
	canceled,
	paymentModeConstants,
	paymentType,
	navigationType,
	orderDetailsToastShowTime,
	toggleFeatureConstants,
	isToggleFeatureEnable,
	IMAGE_TYPE,
	accountManager,
	salesExecutive,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import navigations from '@routes/navigations';
import Spinner from '@Spinner/Spinner';
import ListEmpty from '@ListEmpty/ListEmpty';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getShipmentStatus } from '@Util/GetShipmentStatus';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import CollapsedView from '@CollapsedView/CollapsedView';
import * as AddMoneyActions from '@AddMoneyScreen/AddMoneyScreenAction';
import ToastComponent from '@ToastComponent/ToastComponent';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import AlertComponent from '@Util/AlertComponent';
import * as ToggleFeaturesActions from '@ToggleFeatureScreen/ToggleFeatureScreenAction';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import * as OrderDetailActions from './OrderDetailsScreenAction';
import { createStyleSheet } from './OrderDetailsScreenStyle';

class OrderDetailsScreen extends Component {
	constructor(props) {
		super(props);
		const { userDetails } = props;
		this.role = (userDetails && userDetails.user && userDetails.user.role) || {};
		this.state = {
			isApiError: false, // Boolean to show api error
			toastMessage: '', // API error message
			isCancelPressed: false, // Boolean to check if cancel button is pressed
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			// call order detail api on page load
			this.getOrderDetail();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
		BackHandler.addEventListener('hardwareBackPress', this.onGoBack);
	}

	componentDidUpdate(prevProps) {
		const { isCancelPressed } = this.state;
		const {
			orderDetailInfo,
			route,
			addMoneyInfo,
			navigation,
			homeScreenActions,
			pullToRefreshActions,
			toggleFeaturesActions,
			homeScreenInfo,
			userDetails,
		} = this.props;
		const {
			isRepeatOrder,
			success,
			orderDetail,
			error: orderDetailError,
			errorCode: orderDetailErrorCode,
		} = orderDetailInfo;
		const { is_pi_generated, total_amount } = orderDetail || {};
		const { success: addMoneySuccess, paymentDetail, error, errorCode } = addMoneyInfo;
		const { orderData, id, isShowAlert } = route.params;
		const { branchDetail } = homeScreenInfo;
		const { id: branchId } = branchDetail || userDetails.user.organization || {};
		if (addMoneySuccess && prevProps.addMoneyInfo.success !== success) {
			// This block will call after getting successful response with payment url.
			navigation.navigate(navigations.PAYMENT_NAVIGATION, {
				paymentDetail, // Contains payment_id and payment_url
				type: navigationType.order, // After getting payment confirmation it will navigate to order detail screen
				extraParams: {
					id, // Sales order id
					orderData, // Sales order datapoints (id, amount, time)
					isNavigateBack: false,
				},
			});
		}
		if (
			orderDetailError &&
			prevProps.orderDetailInfo.error !== orderDetailInfo.error &&
			isRepeatOrder
		) {
			// Will show alert if api fails
			ErrorAlertComponent(orderDetailErrorCode, this.onRepeatOrder);
		}
		if (success && prevProps.orderDetailInfo.success !== orderDetailInfo.success) {
			// if order deteail api returns success
			if (isRepeatOrder) {
				homeScreenActions.onGetCartCount();
				navigation.popToTop();
				navigation.navigate(navigations.CART_NAVIGATION);
			}
			if (isShowAlert) {
				const alertProps = {
					message: `${localeString(keyConstants.PAY_NOW_ALERT)} ${localeString(
						keyConstants.QUESTION_MARK,
					)}`,
					yesText: localeString(keyConstants.YES),
					noText: localeString(keyConstants.NO),
					onPressYes: () => {
						delete route.params.isShowAlert;
						this.onPayAmount(total_amount);
					},
					onPressNo: () => {
						delete route.params.isShowAlert;
					},
				};
				AlertComponent(alertProps);
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		} else if (isCancelPressed) {
			// if cancel pressed
			if (this.isOrderCancelable()) {
				this.setState(
					{
						isCancelPressed: false,
					},
					() => {
						navigation.navigate(navigations.CANCEL_ORDER_NAVIGATION, { id, branchId });
					},
				);
			} else {
				const alertProps = {
					message: is_pi_generated
						? localeString(keyConstants.PI_ALREADY_GENERATED)
						: localeString(keyConstants.CANNOT_CANCEL_ORDER),
					yesText: localeString(keyConstants.OK),
					isOneButton: true,
				};
				AlertComponent(alertProps);
			}
		}
		if (error && isToggleFeatureEnable && prevProps.addMoneyInfo.error !== addMoneyInfo.error) {
			// Will show toast if API error occurs
			this.setState(
				{
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				},
				() => {
					if (errorCode.error === keyConstants.NOT_AUTHORIZED) {
						// Will update the online payment value to false because user is not authorized.
						toggleFeaturesActions.onUpdateSpecificToggleFeature(
							toggleFeatureConstants.onlinePayment,
							false,
						);
					}
				},
			);
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, orderDetailsToastShowTime);
		}
	}

	componentWillUnmount() {
		BackHandler.removeEventListener('hardwareBackPress', this.onGoBack);
	}

	getOrderDetail = () => {
		// funtion to call order detail api
		const { route, orderDetailActions } = this.props;
		const { id } = route.params;
		const queryParams = {
			id,
		};
		orderDetailActions.onGetOrderDetail(queryParams);
	};

	onGoBack = () => {
		// function to go back
		const { route, navigation } = this.props;
		const { isNavigateBack } = route.params;
		if (isNavigateBack) {
			navigation.goBack();
		} else {
			navigation.popToTop();
		}
		return true;
	};

	keyExtractor = (item, index) => {
		return index.toString();
	};

	onRepeatOrder = () => {
		// function called to repeat order
		const { route, orderDetailActions } = this.props;
		Alert.alert(
			'',
			localeString(keyConstants.ARE_YOU_SURE_ORDER),
			[
				{
					text: localeString(keyConstants.NO),
				},
				{
					text: localeString(keyConstants.YES),
					onPress: () => {
						const { id } = route.params;
						const queryParams = {
							id,
						};
						orderDetailActions.onRepeatOrder(queryParams);
					},
				},
			],
			{ cancelable: false },
		);
	};

	renderItem = ({ item }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.itemView}>
				<ImageLoadComponent
					isUrl
					imageType={IMAGE_TYPE.item}
					source={item && item.images && item.images['x-small']}
					style={styles.itemImage}
				/>
				<View style={styles.container}>
					<Text style={styles.name}>{isRTL ? item.name_ar : item.name}</Text>
					<View style={styles.priceView}>
						<Text style={styles.amount}>
							{`${item.quantity} x ${currencyFormatter(
								parseFloat(item.offer_price ? item.offer_price : item.price),
							)} ${localeString(keyConstants.SAR)}`}
						</Text>
						<Text style={styles.totalPrice}>
							{`${currencyFormatter(
								getValueInDecimal(
									item.quantity *
										parseFloat(
											item.offer_price ? item.offer_price : item.price,
										),
								),
							)} ${localeString(keyConstants.SAR)}`}
						</Text>
					</View>
				</View>
			</View>
		);
	};

	// returns number of items with 'item'(1) or 'items'(>1)
	getItemString = (quantity, isRTL) => {
		return isRTL
			? `${localeString(quantity > 1 ? keyConstants.ITEMS : keyConstants.ITEM)} ${quantity}`
			: `${quantity} ${localeString(quantity > 1 ? keyConstants.ITEMS : keyConstants.ITEM)}`;
	};

	renderShipments = () => {
		// function to render shipment
		const { languageInfo, orderDetailInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { orderDetail } = orderDetailInfo;
		const { shipment_items } = orderDetail || {};
		if (shipment_items && shipment_items.length === 0) {
			return <ListEmpty text={localeString(keyConstants.NO_ITEMS_SHIPPED)} />;
		}
		return (
			<FlatList
				data={shipment_items}
				renderItem={({ item, index }) => {
					return (
						<TouchableOpacity
							activeOpacity={0.8}
							onPress={() => this.getShipmentDetail(item.id)}
							style={styles.shipmentContainer}>
							<View
								style={[
									styles.shipmentView,
									shipment_items &&
										shipment_items.length - 1 === index &&
										styles.lastRow,
								]}>
								<View>
									<Text style={styles.id}>{`#${item.id}`}</Text>
									<Text style={styles.items}>
										{this.getItemString(item.quantity, isRTL)}
									</Text>
								</View>
								<View>
									<Text style={styles.shipmentAmount}>
										{`${currencyFormatter(
											getValueInDecimal(
												item.offer_price +
													item.delivery_fee +
													item.delivery_fee_vat,
											),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
									<Text style={styles.status}>
										{getShipmentStatus(item.status)}
									</Text>
								</View>
							</View>
							{this.role === accountManager || this.role === salesExecutive ? null : (
								<View style={styles.deliveryCodeView}>
									<Text style={styles.textDeliveryCode}>
										{`${localeString(keyConstants.DELIVERY_CODE)}: ${
											item.delivery_code
										}`}
									</Text>
									<Text style={styles.textDeliveryCode}>
										{localeString(keyConstants.VIEW_DETAILS)}
									</Text>
								</View>
							)}
						</TouchableOpacity>
					);
				}}
				keyExtractor={this.keyExtractor}
				showsVerticalScrollIndicator={false}
				initialNumToRender={shipment_items ? shipment_items.length : 0}
			/>
		);
	};

	getShipmentDetail = id => {
		// Api call to get shipment detail
		const { navigation } = this.props;
		navigation.navigate(navigations.SHIPMENT_DETAIL_NAVIGATION, {
			id,
			isDriver: false,
		});
	};

	renderPendingItems = () => {
		// function to render pending items
		const { languageInfo, orderDetailInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { orderDetail } = orderDetailInfo;
		const { pending_items } = orderDetail || {};
		if (pending_items && pending_items.length === 0) {
			return (
				<ListEmpty
					listEmptyContainer={styles.listEmptyContainer}
					text={localeString(keyConstants.NO_ITEMS_FOUND)}
				/>
			);
		}
		return (
			<FlatList
				data={pending_items}
				renderItem={this.renderItem}
				keyExtractor={this.keyExtractor}
				showsVerticalScrollIndicator={false}
				initialNumToRender={pending_items ? pending_items.length : 0}
			/>
		);
	};

	renderCancelledItems = () => {
		// function to render Cancelled items
		const { languageInfo, orderDetailInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { orderDetail } = orderDetailInfo;
		const { canceled_items } = orderDetail || {};
		if (canceled_items && canceled_items.length === 0) {
			return (
				<ListEmpty
					listEmptyContainer={styles.listEmptyContainer}
					text={localeString(keyConstants.NO_ITEMS_FOUND)}
				/>
			);
		}
		return (
			<FlatList
				data={canceled_items}
				renderItem={this.renderItem}
				keyExtractor={this.keyExtractor}
				showsVerticalScrollIndicator={false}
				initialNumToRender={canceled_items ? canceled_items.length : 0}
			/>
		);
	};

	renderReturns = () => {
		// function to render Returns
		const { languageInfo, orderDetailInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { orderDetail } = orderDetailInfo;
		const { returned_items } = orderDetail || {};
		if (returned_items && returned_items.length === 0) {
			return <ListEmpty text={localeString(keyConstants.NO_ITEMS_FOUND)} />;
		}
		return (
			<FlatList
				data={returned_items}
				renderItem={({ item, index }) => {
					return (
						<TouchableOpacity
							activeOpacity={0.8}
							onPress={() => this.getItemDetail(item)}
							style={[
								styles.shipmentView,
								returned_items &&
									returned_items.length - 1 === index &&
									styles.lastRow,
							]}>
							<View>
								<Text style={styles.id}>{`#${item.return_si_id}`}</Text>
								<Text style={styles.items}>
									{this.getItemString(item.quantity, isRTL)}
								</Text>
							</View>
							<View style={styles.amountView}>
								<Text style={styles.shipmentAmount}>
									{`${currencyFormatter(
										getValueInDecimal(
											item?.item_total +
												item?.vat_amount +
												item?.items[0]?.delivery_fee +
												item?.items[0]?.delivery_fee_vat,
										),
									)} ${localeString(keyConstants.SAR)}`}
								</Text>
							</View>
						</TouchableOpacity>
					);
				}}
				keyExtractor={this.keyExtractor}
				showsVerticalScrollIndicator={false}
				initialNumToRender={returned_items ? returned_items.length : 0}
			/>
		);
	};

	getItemDetail = data => {
		// navigate to Return Items screen
		const { navigation } = this.props;
		navigation.navigate(navigations.RETURN_ITEMS_NAVIGATION, data);
	};

	onCancelOrder = () => {
		// on cancelling order
		this.setState(
			{
				isCancelPressed: true,
			},
			() => {
				this.getOrderDetail();
			},
		);
	};

	isOrderCancelable = () => {
		const { orderDetailInfo } = this.props;
		const { orderDetail } = orderDetailInfo;
		const { is_pi_generated, status } = orderDetail || {};
		return !is_pi_generated && status !== canceled;
	};

	capitalizeFirstLetter = str => {
		// function to capitalize first string
		if (str) {
			return str.charAt(0).toUpperCase() + str.slice(1);
		}
		return '';
	};

	onPayAmount = amount => {
		// API to pay amount of the sales order.
		const { route, addMoneyActions } = this.props;
		const { id } = route.params;
		const paymentDetails = {
			payment_type: paymentType.advancePayment, // Payment type is advance payment
			amount, // sales order amount
			sales_order_id: id, // sales order id
		};
		addMoneyActions.onAddMoney(paymentDetails, false);
	};

	onRefresh = () => {
		this.getOrderDetail(); // will call order detail api
	};

	getPaymentMode = mode => {
		// function to return payment mode string
		if (mode === paymentModeConstants.online) {
			return localeString(keyConstants.ONLINE_PAYMENT);
		}
		return localeString(keyConstants.CASH_ON_DELIVERY);
	};

	render() {
		const { isApiError, toastMessage } = this.state;
		const {
			route,
			languageInfo,
			orderDetailInfo,
			addMoneyInfo,
			refreshControlComponentInfo,
			toggleFeaturesInfo,
			homeScreenInfo,
			configurableFileInfo,
		} = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, orderDetail, isRepeatOrder, error, errorCode } = orderDetailInfo;
		const {
			total_amount,
			delivery_fee,
			vat_amount,
			discount_price,
			item_amount,
			cancel_reason,
			cancel_reason_ar,
			status,
			shipment_items,
			pending_items,
			canceled_items,
			returned_items,
			enable_pay_now,
		} = orderDetail || {};
		const { orderData } = route.params;
		const isShowCancelButton = this.isOrderCancelable();
		const { loader: addMoneyLoader } = addMoneyInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		// Will provide all the variables of the home screen reducer.
		const { toggleFeatures } = toggleFeaturesInfo;
		const { online_payment } = toggleFeatures; // Will return toggleFeatures key value pair.
		const { zoneId } = homeScreenInfo;
		return (
			<View style={styles.container}>
				{loader &&
					!isFetchingForPullToRefresh &&
					(isRepeatOrder ? <Spinner size="large" /> : <Loader size="large" />)}
				{addMoneyLoader && <Spinner size="large" />}
				<View style={styles.headerContainer}>
					<Header onPressBack={this.onGoBack} hasIconBack />
				</View>
				{error && !isRepeatOrder ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<ScrollViewComponent
						style={
							remoteConfigData?.orders?.payNow &&
							enable_pay_now &&
							online_payment &&
							this.role !== accountManager &&
							this.role !== salesExecutive
								? styles.scrollView
								: null
						}
						showsVerticalScrollIndicator={false}
						onRefresh={this.onRefresh}
						componentType={constants.scrollView}>
						<OrderCard
							wantToRepeat={zoneId}
							onRepeatOrder={this.onRepeatOrder}
							isRTL={isRTL}
							isDisable
							status={this.capitalizeFirstLetter(status)}
							orderDetail={orderData}
							onCancel={this.onCancelOrder}
							isCancelButton={
								isShowCancelButton && remoteConfigData?.orders?.cancelOrder
							}
						/>
						<View style={styles.paymentDetails}>
							<Text style={styles.item}>
								{localeString(keyConstants.PAYMENT_DETAILS)}
							</Text>
							<View style={styles.detail}>
								<Text style={styles.text}>
									{localeString(keyConstants.ITEM_TOTAL)}
								</Text>
								<Text style={styles.text}>
									{`${currencyFormatter(
										getValueInDecimal(item_amount),
									)} ${localeString(keyConstants.SAR)}`}
								</Text>
							</View>
							<View style={styles.total}>
								<Text style={styles.text}>
									{localeString(keyConstants.DELIVERY_FEE)}
								</Text>
								<Text style={styles.text}>
									{`${currencyFormatter(
										getValueInDecimal(delivery_fee),
									)} ${localeString(keyConstants.SAR)}`}
								</Text>
							</View>
							<View style={styles.total}>
								<Text style={styles.text}>{localeString(keyConstants.VAT)}</Text>
								<Text style={styles.text}>
									{`${currencyFormatter(
										getValueInDecimal(vat_amount),
									)} ${localeString(keyConstants.SAR)}`}
								</Text>
							</View>
							<View style={[discount_price > 0 ? styles.total : styles.pay]}>
								{/* Grand total of the sales order including vat and delivery fee */}
								<Text style={styles.text}>
									{localeString(keyConstants.GRAND_TOTAL)}
								</Text>
								<Text style={styles.totalAmount}>
									{`${currencyFormatter(
										getValueInDecimal(total_amount),
									)} ${localeString(keyConstants.SAR)}`}
								</Text>
							</View>
							{discount_price > 0 ? (
								<View style={styles.pay}>
									<Text style={styles.text}>
										{localeString(keyConstants.YOUR_SAVINGS)}
									</Text>
									<Text style={styles.discount}>
										{`- ${currencyFormatter(
											getValueInDecimal(discount_price),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
								</View>
							) : null}
						</View>
						{status === canceled && cancel_reason_ar && cancel_reason ? (
							<View style={styles.pendingView}>
								<Text style={styles.item}>
									{localeString(keyConstants.REASON_FOR_REJECTION)}
								</Text>
								<Text style={styles.reason}>
									{isRTL ? cancel_reason_ar : cancel_reason}
								</Text>
							</View>
						) : null}
						<CollapsedView
							sections={[
								{
									title: `${localeString(keyConstants.SHIPMENTS)} (${
										shipment_items && shipment_items.length
									})`,
									content: this.renderShipments(),
									index: 0,
								},
								{
									title: `${localeString(keyConstants.PENDING_ITEMS)} (${
										pending_items && pending_items.length
									})`,
									content: this.renderPendingItems(),
									index: 1,
								},
								{
									title: `${localeString(keyConstants.CANCELLED_ITEMS)} (${
										canceled_items && canceled_items.length
									})`,
									content: this.renderCancelledItems(),
									index: 2,
								},
								{
									title: `${localeString(keyConstants.RETURNED_ITEMS)} (${
										returned_items && returned_items.length
									})`,
									content: this.renderReturns(),
									index: 3,
								},
							]}
							isRTL={isRTL}
						/>
					</ScrollViewComponent>
				)}
				{/* Will show Pay Now hyperlink if payment is not done yet and if online payment feature is enable for this user. */}
				{remoteConfigData?.orders?.payNow &&
					enable_pay_now &&
					online_payment &&
					this.role !== accountManager &&
					this.role !== salesExecutive && (
						<View style={styles.bottomButtonView}>
							<ButtonComponent
								text={localeString(keyConstants.PAY_NOW)}
								onPress={() => this.onPayAmount(total_amount)}
							/>
						</View>
					)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		orderDetailInfo: state.OrderDetailsScreenReducer,
		addMoneyInfo: state.AddMoneyScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		userDetails: state.HomeScreenReducer.userDetails,
		homeScreenInfo: state.HomeScreenReducer,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		orderDetailActions: bindActionCreators({ ...OrderDetailActions }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		addMoneyActions: bindActionCreators({ ...AddMoneyActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		toggleFeaturesActions: bindActionCreators({ ...ToggleFeaturesActions }, dispatch),
	};
};

OrderDetailsScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	orderDetailInfo: PropTypes.object.isRequired,
	addMoneyInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	orderDetailActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	addMoneyActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	toggleFeaturesActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(OrderDetailsScreen);
