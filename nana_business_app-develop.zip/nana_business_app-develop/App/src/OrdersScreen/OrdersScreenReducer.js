import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	ordersListing: [],
	count: 0,
	isBranchUpdated: true,
};

const OrdersScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_ORDERS_LISTING_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				ordersListing: isOverwriteExistingList
					? [...state.ordersListing, ...action.payload.sales_order_listing]
					: action.payload.sales_order_listing,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_ORDERS_LISTING_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_ORDERS_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.HANDLE_ORDERS_API_CALLING_ON_BRANCH_UPDATE:
			return {
				...state,
				isBranchUpdated: action.payload,
			};
		default:
			return state;
	}
};

export default OrdersScreenReducer;
