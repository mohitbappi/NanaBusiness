export const GET_ORDERS_LISTING_SUCCESS = 'get_orders_listing_success';
export const GET_ORDERS_LISTING_FAILURE = 'get_orders_listing_failure';
export const GET_ORDERS_LISTING_LOADER = 'get_orders_listing_loader';

export const HANDLE_ORDERS_API_CALLING_ON_BRANCH_UPDATE =
	'handle_orders_api_calling_on_branch_update';
