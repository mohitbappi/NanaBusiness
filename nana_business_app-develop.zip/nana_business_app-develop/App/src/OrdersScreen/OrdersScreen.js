import React, { Component } from 'react';
import { View, Text, FlatList } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import navigations from '@routes/navigations';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import {
	fetchDataWithPagination,
	numericalRegexExp,
	isToggleFeatureEnable,
	salesExecutive,
	accountManager,
} from '@Constants/Constants';
import Search from '@Search/Search';
import OptionPicker from '@OptionPicker/OptionPicker';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ToggleFeatureScreen from '@ToggleFeatureScreen/ToggleFeatureScreen';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import AlertComponent from '@Util/AlertComponent';
import * as OrdersListingActions from './OrdersScreenAction';
import OrderCard from './OrderCard';
import { createStyleSheet } from './OrdersScreenStyle';
import { SearchShimmer, OrdersListingShimmer } from './OrdersScreenShimmer';

class OrdersScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
			searchText: '',
			isPickerVisible: false, // Boolen to show popup to choose search by
			activePickerIndex: 0, // By default search will work for sales order id
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			const { userDetails, pullToRefreshActions, ordersListingInfo } = this.props;
			const { isBranchUpdated } = ordersListingInfo;
			const { role, default_user_id } =
				userDetails && userDetails.user ? userDetails.user : {};
			if (!isToggleFeatureEnable && isBranchUpdated) {
				// Won't call toggle feature API if return false
				if (
					(role === accountManager || role === salesExecutive) &&
					(default_user_id === null || default_user_id === undefined)
				) {
					// If the user is not selected then will show the popup and navigate to the screen to select the user.
					const alertOptions = {
						message: localeString(keyConstants.USER_DISABLED_ERROR),
						yesText: localeString(keyConstants.OKAY),
						isOneButton: true,
						onPressYes: () => {
							navigation.navigate(navigations.SELECT_CUSTOMER_USER_NAVIGATION);
						},
					};
					AlertComponent(alertOptions);
				} else {
					this.page = fetchDataWithPagination.page;
					this.setState(
						{
							searchText: '',
						},
						() => this.onLoadMore(false), // will call orders listing api
					);
				}
			}
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { ordersListingInfo, toggleFeaturesInfo, pullToRefreshActions } = this.props;
		const { success } = ordersListingInfo;
		const { success: toggleApiSuccess } = toggleFeaturesInfo;
		if (toggleApiSuccess && prevProps.toggleFeaturesInfo.success !== success) {
			// Will call API if toggle feature API succeed.
			this.page = fetchDataWithPagination.page;
			this.setState(
				{
					searchText: '',
				},
				() => this.onLoadMore(false),
			);
		}
		if (success && prevProps.ordersListingInfo.success !== ordersListingInfo.success) {
			// if order listing api return success
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onSearch = text => {
		// will call order listing api with some filtered text search
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onLoadMore(false);
			},
		);
	};

	onLoadMore = isOverwriteExistingList => {
		const { ordersListingActions } = this.props;
		ordersListingActions.onHandleApiCall(false);
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		// function to call orders listing api
		const { searchText, activePickerIndex } = this.state;
		const { homeScreenInfo, userDetails, ordersListingActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization || {};
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		queryParams.branch_id = id;
		if (searchText) {
			if (activePickerIndex) {
				// It can be 0 or 1
				queryParams.shipment_id = searchText; // If search is done by shipment id
			} else {
				queryParams.order_id = searchText; // If search is done by sales order id
			}
		}
		ordersListingActions.onGetOrders(queryParams, isOverwriteExistingList);
	};

	onSelectOption = index => {
		// Will update selected option
		this.setState(
			{
				searchText: '',
				activePickerIndex: index,
			},
			() => this.handlePicker(false),
		);
	};

	handlePicker = value => {
		// Will hide/show popup
		this.setState({
			isPickerVisible: value,
		});
	};

	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		const { languageInfo, ordersListingInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { ordersListing, count } = ordersListingInfo;
		const endReached = count === ordersListing.length || count < ordersListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { ordersListingInfo } = this.props;
		const { loader } = ordersListingInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onLoadMore(true);
		}
	};

	onPressCard = (id, orderData, index) => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ORDER_DETAIL_NAVIGATION, {
			id,
			orderData,
			index,
			isNavigateBack: true,
			isShowAlert: false,
		});
	};

	onRefresh = () => {
		this.page = fetchDataWithPagination.page;
		this.limit = fetchDataWithPagination.limit;
		if (isToggleFeatureEnable) {
			// Will call toggle feature API.
			this.toggleFeature.getToggleFeatures();
		} else {
			this.onFetchData(false); // Will call orders API.
		}
	};

	render() {
		const { bottomLoader, searchText, isPickerVisible, activePickerIndex } = this.state;
		const {
			languageInfo,
			ordersListingInfo,
			refreshControlComponentInfo,
			toggleFeaturesInfo,
			navigation,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, ordersListing, count, error, errorCode } = ordersListingInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { loader: toggleApiLoader } = toggleFeaturesInfo;
		const { isConnected } = this.props;
		return (
			<View style={styles.container}>
				<OptionPicker
					isVisible={isPickerVisible} // Boolean to show/hide popup
					options={[
						{ name: localeString(keyConstants.SALES_ORDER_ID) },
						{ name: localeString(keyConstants.SHIPMENT_ID) },
					]}
					title={localeString(keyConstants.SEARCH_BY)}
					isRTL={isRTL}
					onClose={() => this.handlePicker(false)}
					onSelectOption={this.onSelectOption}
					activeIndex={activePickerIndex} // Selected option
				/>
				<View style={styles.headerContainer}>
					<Header text={localeString(keyConstants.ORDERS)} hasIconOrder />
				</View>
				{(loader || toggleApiLoader) &&
				!bottomLoader &&
				!isFetchingForPullToRefresh &&
				searchText === '' ? (
					<>
						<SearchShimmer isRTL={isRTL} />
						<FlatList
							data={['', '', '']}
							showsVerticalScrollIndicator={false}
							renderItem={() => {
								return <OrdersListingShimmer isRTL={isRTL} />;
							}}
							keyExtractor={this.keyExtractor}
						/>
					</>
				) : (
					<>
						<View style={styles.searchContainer}>
							<Search
								placeholder={localeString(keyConstants.SEARCH_BY_ORDER_SHIPMENT_ID)}
								onChangeText={text =>
									(numericalRegexExp.test(String(text).toLocaleLowerCase()) ||
										text === '') &&
									this.onSearch(text)
								}
								value={searchText}
								hasIconFilter // Boolean to show filter icon in the search bar
								onPressFilter={() => this.handlePicker(true)}
							/>
						</View>
						{error ? (
							// Will show error component if api fails.
							<ErrorComponent
								isRTL={isRTL}
								errorCode={errorCode}
								onCallApi={() => this.onLoadMore(false)}
							/>
						) : ordersListing.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_ORDERS_FOUND)} />
						) : (
							<FlatListComponent
								keyboardShouldPersistTaps="handled"
								data={ordersListing}
								showsVerticalScrollIndicator={false}
								renderItem={({ item, index }) => {
									return (
										<OrderCard
											footerStyle={styles.footerStyle}
											isRTL={isRTL}
											isArrow
											onPressCard={() =>
												this.onPressCard(item.id, item, index)
											}
											status={item && item.status}
											orderDetail={item}
										/>
									);
								}}
								keyExtractor={this.keyExtractor}
								onEndReached={() =>
									ordersListing.length !== count && this.onEndReached()
								}
								ListFooterComponent={
									ordersListing.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								componentType={constants.flatList}
								onRefresh={this.onRefresh}
							/>
						)}
						<ToggleFeatureScreen
							navigation={navigation}
							onRef={ref => {
								this.toggleFeature = ref;
							}}
							isDefaultApiCalling={isToggleFeatureEnable} // Boolean to call the toggle feature API.
							isConnected={isConnected}
						/>
					</>
				)}
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		ordersListingInfo: state.OrdersScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		isConnected: state.NoConnectionHandleReducer.isConnected,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		userDetails: state.HomeScreenReducer.userDetails,
		homeScreenInfo: state.HomeScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		ordersListingActions: bindActionCreators({ ...OrdersListingActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

OrdersScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	ordersListingInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	ordersListingActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	isConnected: PropTypes.bool.isRequired,
	userDetails: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(OrdersScreen);
