import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import * as colors from '@assets/colors';
import fonts from '@assets/fonts';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import IMAGES from '@Images/index';
import { getFormattedDateWithoutYear } from '@Util/GetFormattedDate';
import { getFormattedTime } from '@Util/GetFormattedTime';
import { orderStatus, fontsConstants } from '@Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			paddingVertical: verticalScale(12),
			paddingHorizontal: normalScale(16),
		},
		itemView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
		},
		orderId: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
		},
		iconView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			alignItems: 'center',
		},
		item: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		iconRightArrow: {
			width: normalScale(6),
			height: verticalScale(10),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			transform: isRTL ? [{ rotate: '180deg' }] : [{ rotate: '360deg' }],
		},
		date: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(12),
			marginTop: verticalScale(4),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		wantToRepeat: {
			textAlign: rtlFunctions.getTextAlign(isRTL),
			color: colors.blue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			marginTop: verticalScale(8),
		},
		amountView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(12),
		},
		amountLabel: {
			color: colors.lightBlack,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		payNow: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		amount: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		successPaymentStatus: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		pendingPaymentStatus: {
			color: colors.darkOrange,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		footer: {
			paddingHorizontal: normalScale(16),
			paddingVertical: verticalScale(8),
			justifyContent: 'center',
			borderTopColor: colors.grey,
			borderTopWidth: normalScale(4),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(4),
		},
		orderView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		image: {
			width: normalScale(16),
			height: verticalScale(16),
			resizeMode: 'contain',
		},
		orderStatus: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(12),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		statusView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginVertical: verticalScale(4),
			alignItems: 'center',
			marginHorizontal: verticalScale(8),
		},
		orderImage: {
			height: verticalScale(18),
			width: normalScale(16),
		},
		greenLine: {
			borderBottomColor: colors.lightBlueShadowGrey,
			borderBottomWidth: normalScale(1),
			width: normalScale(68),
		},
		greyLine: {
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			width: normalScale(68),
		},
		statusTextView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		status: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			textAlign: rtlFunctions.getTextAlignOpposite(isRTL),
		},
		buttonStyle: {
			paddingHorizontal: normalScale(20),
			height: verticalScale(30),
		},
	});
};

class OrderCard extends Component {
	getSecondStageStatus = status => {
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case orderStatus.placed:
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			case orderStatus.canceled:
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	getThirdStageStatus = status => {
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case orderStatus.placed:
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case orderStatus.approved:
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			case orderStatus.canceled:
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	getLastStageStatus = status => {
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case orderStatus.placed: // If sales order status is placed
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case orderStatus.approved: // If sales order status is approved
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case orderStatus.canceled: // If sales order status is cancelled
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			case orderStatus.inProgress: // If sales order status is inprogress
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			case orderStatus.inProgressUnderscore: // If sales order status is inprogress
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	render() {
		const {
			isRTL,
			orderDetail,
			onPressCard,
			isDisable,
			isArrow,
			wantToRepeat,
			onRepeatOrder,
			footerStyle,
			status,
			onCancel,
			isCancelButton,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		const { id, item_count, created_at, total_amount } = orderDetail || {};
		return (
			<TouchableOpacity disabled={isDisable} onPress={onPressCard} activeOpacity={0.8}>
				<View style={styles.container}>
					<View style={styles.itemView}>
						<Text style={styles.orderId}>
							{`${localeString(keyConstants.SALES_ORDER_ID)}: ${id}`}
						</Text>
						<View style={styles.iconView}>
							<Text style={styles.item}>
								(
								{isRTL
									? `${localeString(
											item_count > 1 ? keyConstants.ITEMS : keyConstants.ITEM,
									  )} ${item_count}`
									: `${item_count} ${localeString(
											item_count > 1 ? keyConstants.ITEMS : keyConstants.ITEM,
									  )}`}
								)
							</Text>
							{isArrow && (
								<ImageLoadComponent
									source={IMAGES.iconRightArrow}
									style={styles.iconRightArrow}
								/>
							)}
						</View>
					</View>
					<Text style={styles.date}>
						{`${getFormattedDateWithoutYear(created_at)}, ${getFormattedTime(
							created_at,
						)}`}
					</Text>
					{wantToRepeat && (
						<TouchableOpacity activeOpacity={0.8} onPress={onRepeatOrder}>
							<Text style={styles.wantToRepeat}>
								{localeString(keyConstants.WANT_TO_REPEAT)}
								{localeString(keyConstants.QUESTION_MARK)}
							</Text>
						</TouchableOpacity>
					)}
					<View style={styles.amountView}>
						{/* Total amount of the sales order */}
						<Text style={styles.amountLabel}>
							{`${localeString(keyConstants.AMOUNT)}: `}
							<Text style={styles.amount}>
								{`${currencyFormatter(
									getValueInDecimal(total_amount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</Text>
						{/* Hyperlink to pay amount of the sales order. */}
						{isCancelButton ? (
							<TouchableOpacity onPress={onCancel} activeOpacity={0.8}>
								<Text style={styles.payNow}>
									{localeString(keyConstants.CANCEL)}
								</Text>
							</TouchableOpacity>
						) : null}
					</View>
				</View>
				<View style={[styles.footer, footerStyle]}>
					<Text style={styles.orderStatus}>
						{localeString(keyConstants.ORDER_STATUS)}
					</Text>
					<View style={styles.statusView}>
						<ImageLoadComponent
							source={
								status === orderStatus.canceled
									? IMAGES.iconCrossRed
									: IMAGES.iconOrderStatusFilled
							}
							style={styles.orderImage}
						/>
						<View
							style={
								status === orderStatus.canceled ? styles.greyLine : styles.greenLine
							}
						/>
						<ImageLoadComponent
							source={this.getSecondStageStatus(status).image}
							style={styles.orderImage}
						/>
						<View style={this.getSecondStageStatus(status).style} />
						<ImageLoadComponent
							source={this.getThirdStageStatus(status).image}
							style={styles.orderImage}
						/>
						<View style={this.getThirdStageStatus(status).style} />
						<ImageLoadComponent
							source={this.getLastStageStatus(status).image}
							style={styles.orderImage}
						/>
					</View>
					<View style={styles.statusTextView}>
						<Text style={styles.status}>
							{status === orderStatus.canceled
								? localeString(keyConstants.CANCELLED)
								: localeString(keyConstants.PLACED)}
						</Text>
						<Text style={styles.status}>
							{status === orderStatus.canceled
								? localeString(keyConstants.CANCELLED)
								: localeString(keyConstants.APPROVED)}
						</Text>
						<Text style={styles.status}>
							{status === orderStatus.canceled
								? localeString(keyConstants.CANCELLED)
								: localeString(keyConstants.IN_PROGRESS)}
						</Text>
						<Text style={styles.status}>
							{status === orderStatus.canceled
								? localeString(keyConstants.CANCELLED)
								: localeString(keyConstants.COMPLETED)}
						</Text>
					</View>
				</View>
			</TouchableOpacity>
		);
	}
}

OrderCard.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	orderDetail: PropTypes.object.isRequired,
	onPressCard: PropTypes.func.isRequired,
	isDisable: PropTypes.bool.isRequired,
	isArrow: PropTypes.bool.isRequired,
	wantToRepeat: PropTypes.bool.isRequired,
	onRepeatOrder: PropTypes.func.isRequired,
	footerStyle: PropTypes.object.isRequired,
	status: PropTypes.string.isRequired,
	onCancel: PropTypes.func.isRequired,
	isCancelButton: PropTypes.bool.isRequired,
};

export default OrderCard;
