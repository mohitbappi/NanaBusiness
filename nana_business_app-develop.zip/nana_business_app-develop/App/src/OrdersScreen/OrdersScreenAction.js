import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetOrdersService from '@Orders/GetOrdersService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to get orders listing
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetOrders = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ORDERS_LISTING_SUCCESS,
		ActionTypes.GET_ORDERS_LISTING_FAILURE,
		ActionTypes.GET_ORDERS_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getOrdersService = new GetOrdersService(dispatchedActions);
	addBasicInterceptors(getOrdersService);
	getOrdersService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getOrdersService.makeRequest(props));
};

/**
 * Action to update branch update key.
 * @param {boolean} value
 * @returns
 */

export const onHandleApiCall = value => {
	return {
		type: ActionTypes.HANDLE_ORDERS_API_CALLING_ON_BRANCH_UPDATE,
		payload: value,
	};
};

export default onGetOrders;
