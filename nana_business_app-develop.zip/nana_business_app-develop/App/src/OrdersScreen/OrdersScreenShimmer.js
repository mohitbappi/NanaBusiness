// import libraries
import React from 'react';
import { Dimensions } from 'react-native';
import ContentLoader, { Circle, Rect } from 'react-content-loader/native';
import PropTypes from 'prop-types';

// import colors
import * as colors from '@assets/colors';

// import utils
import { normalScale, verticalScale } from '@device/normalize';

const windowWidth = Dimensions.get('window').width;

export const SearchShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(40)}>
			<Rect
				x={normalScale(16)}
				rx={normalScale(8)}
				ry={normalScale(8)}
				width={windowWidth - normalScale(32)}
				height={verticalScale(40)}
			/>
		</ContentLoader>
	);
};

export const OrdersListingShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(150)}>
			<Rect
				x={normalScale(16)}
				y={normalScale(16)}
				width={normalScale(140)}
				height={normalScale(16)}
			/>
			<Rect
				x={windowWidth - normalScale(96)}
				y={normalScale(16)}
				width={normalScale(80)}
				height={normalScale(16)}
			/>
			<Rect
				x={normalScale(16)}
				y={normalScale(42)}
				width={normalScale(80)}
				height={normalScale(12)}
			/>
			<Rect
				x={normalScale(16)}
				y={normalScale(72)}
				width={normalScale(130)}
				height={normalScale(16)}
			/>
			<Rect x={0} y={normalScale(100)} width={windowWidth} height={normalScale(3)} />
			<Rect
				x={normalScale(16)}
				y={normalScale(108)}
				width={normalScale(40)}
				height={normalScale(12)}
			/>
			<Circle cx={normalScale(32)} cy={normalScale(140)} r={normalScale(10)} />
			<Circle cx={windowWidth / 3 + 8} cy={normalScale(140)} r={normalScale(10)} />
			<Circle cx={(windowWidth * 2) / 3 - 8} cy={normalScale(140)} r={normalScale(10)} />
			<Circle cx={windowWidth - normalScale(32)} cy={normalScale(140)} r={normalScale(10)} />
			<Rect
				x={normalScale(16)}
				y={normalScale(155)}
				width={normalScale(40)}
				height={normalScale(12)}
			/>
			<Rect
				x={windowWidth / 3 - 16}
				y={normalScale(155)}
				width={normalScale(40)}
				height={normalScale(12)}
			/>
			<Rect
				x={(windowWidth * 2) / 3 - 32}
				y={normalScale(155)}
				width={normalScale(40)}
				height={normalScale(12)}
			/>
			<Rect
				x={windowWidth - normalScale(56)}
				y={normalScale(155)}
				width={normalScale(40)}
				height={normalScale(12)}
			/>
			<Rect x={0} y={normalScale(172)} width={windowWidth} height={normalScale(3)} />
		</ContentLoader>
	);
};

SearchShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

OrdersListingShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};
