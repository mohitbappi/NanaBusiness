export const ON_EDIT_TEXT_ADD_USER = 'on_edit_text_add_user';
export const ON_UPLOAD_PROFILE_PIC_ADD_USER = 'on_upload_profile_pic_add_user';

export const ADD_USER_SUCCESS = 'add_user_success';
export const ADD_USER_FAILURE = 'add_user_failure';
export const ADD_USER_LOADER = 'add_user_loader';

export const GET_BRANCHES_SUCCESS = 'get_branches_success';
export const GET_BRANCHES_FAILURE = 'get_branches_failure';
export const GET_BRANCHES_LOADER = 'get_branches_loader';

export const RESET_ADD_USER_STATE = 'reset_add_user_state';
export const ON_RESET_USER_CREATED = 'on_reset_user_created';

export const EDIT_USER_SUCCESS = 'edit_user_success';
export const EDIT_USER_FAILURE = 'edit_user_failure';
export const EDIT_USER_LOADER = 'edit_user_loader';
