import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

// Used for AdduserDetailScreen and EditProfileScreen
const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		backButton: {
			paddingHorizontal: normalScale(16),
		},
		image: {
			width: normalScale(16),
			height: verticalScale(12),
		},
		scrollView: {
			paddingBottom: verticalScale(116),
		},
		scrollViewEditProfile: {
			paddingBottom: verticalScale(86),
		},
		imageView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(24),
		},
		innerImageView: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
			justifyContent: 'center',
		},
		defaultImage: {
			height: normalScale(80),
			width: normalScale(80),
			borderRadius: moderateScale(6),
		},
		optionView: {
			marginLeft: isRTL ? 0 : normalScale(16),
			marginRight: isRTL ? normalScale(16) : 0,
			marginTop: verticalScale(12),
		},
		innerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginTop: verticalScale(12),
		},
		galleryView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			width: normalScale(192),
			height: verticalScale(30),
			alignItems: 'center',
			borderRadius: moderateScale(8),
			backgroundColor: colors.white,
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(15),
			},
			shadowRadius: moderateScale(14),
			shadowOpacity: 0.6,
			elevation: verticalScale(15),
			justifyContent: 'center',
			borderWidth: moderateScale(1),
			borderColor: colors.darkBlue,
		},
		iconGallery: {
			height: verticalScale(14),
			width: normalScale(14),
		},
		gallery: {
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		removeImage: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(12),
			marginTop: verticalScale(23),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		textStyle: {
			color: colors.lightWhite,
		},
		statusContainer: {
			marginTop: verticalScale(16),
		},
		activeContainer: {
			marginTop: verticalScale(18),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		status: {
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.lightBlack,
		},
		active: {
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.black,
		},
		activeStyle: {
			height: verticalScale(27),
			width: normalScale(36),
		},
		inActiveStyle: {
			height: verticalScale(27),
			width: normalScale(36),
		},
		dropdownViewStyle: {
			height: verticalScale(70),
		},
		formView: {
			paddingHorizontal: normalScale(16),
		},
	});
};

export default createStyleSheet;
