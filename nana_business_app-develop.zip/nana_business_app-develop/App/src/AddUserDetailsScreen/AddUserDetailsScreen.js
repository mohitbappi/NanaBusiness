// import libraries
import React, { Component } from 'react';
import { View, TouchableOpacity, Text, ScrollView, Keyboard } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';

// import images
import IMAGES from '@Images/index';

// import components
import Input from '@Input/Input';
import { imagePicker } from '@Util/DocumentPicker';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import { uploadFile } from '@Util/UploadFile';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { getImageUrl } from '@Util/GetImageUrl';
import OverlayComponent from '@OverlayComponent/OverlayComponent';
import EditImageComponent from '@Components/EditImageComponent';
import SaveCancelButtonComponent from '@Components/SaveCancelButtonComponent';
import ItemSelectionComponent from '@OverlayComponent/ItemSelectionComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import DropdownFieldComponent from '@DropdownFieldComponent/DropdownFieldComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import Header from '@Header/Header';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { normalScale } from '@device/normalize';
import {
	mobileNumberLength,
	numericRegexExp,
	emailRegexEx,
	toastShowTime,
	customMobileRegex,
} from '@Constants/Constants';
import navigations from '@routes/navigations';
import * as fieldType from './constants';

// import styles
import { createStyleSheet } from './AddUserDetailsScreenStyle';

// import actions
import * as AddUserDetailsAction from './AddUserDetailsScreenAction';

class AddUserDetailsScreen extends Component {
	constructor(props) {
		super(props);
		this.mobileNumber = React.createRef(null);
		this.emailAddress = React.createRef(null);
		this.state = {
			isApiError: false,
			toastMessage: '',
			imageLoader: false,
			mobileErrorValidationMessage: false,
			emailErrorValidationMessage: false,
			branchNameSelectedIndex: null,
			active: true,
			isVisible: false,
			isDropdownVisible: false,
		};
		this.page = 1;
		this.isEditProfile = props.route.params && props.route.params.isEditProfile;
	}

	componentDidMount() {
		if (this.isEditProfile) {
			// Will autopopulate the user details in case edit user detail.
			const { route, addUserDetailsAction } = this.props;
			const {
				name,
				mobile,
				email_address,
				profile_images,
				is_active,
			} = route.params.userDetails;
			const queryParams = {
				page: this.page,
			};
			addUserDetailsAction.getBranches(queryParams);
			addUserDetailsAction.onEditText(name, 'name');
			addUserDetailsAction.onEditText(mobile, 'mobileNumber');
			addUserDetailsAction.onEditText(email_address, 'emailAddress');
			addUserDetailsAction.onUploadProfilePic(profile_images && profile_images.medium);
			this.setState({
				active: is_active,
			});
		}
	}

	componentDidUpdate(prevProps) {
		const { route, addUserDetailsAction, addUserDetailsInfo, navigation } = this.props;
		const {
			mobileNumber,
			emailAddress,
			success,
			error,
			isUserCreated,
			isUserEdited,
			errorCode,
			isBranch,
		} = addUserDetailsInfo;
		if (
			(isUserCreated || isUserEdited) &&
			success &&
			prevProps.addUserDetailsInfo.success !== success
		) {
			// Will navigate to the user list screen after successfully created/edited the user.
			navigation.navigate(navigations.USER_LIST_NAVIGATION);
		}
		if (error && prevProps.addUserDetailsInfo.error !== error) {
			if (keyConstants[errorCode && errorCode.error]) {
				this.setState({
					toastMessage: localeString(keyConstants.USER_ALREADY_EXIST),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				// If any api call is failed then will show an alert.
				let actionButton = null;
				if (isBranch) {
					actionButton = this.onPressDropdown;
				} else if (this.isEditProfile) {
					// Boolean to check if API is called for edit the user details.
					actionButton = this.onPressSaveEditUser;
				} else {
					actionButton = this.onPressSave;
				}
				setTimeout(() => ErrorAlertComponent(errorCode, actionButton), 20);
			}
		}
		if (prevProps.addUserDetailsInfo !== addUserDetailsInfo) {
			if (customMobileRegex.test(mobileNumber)) {
				// Will check mobile number validation.
				this.setState({
					mobileErrorValidationMessage: false,
				});
			}
			if (emailRegexEx.test(String(emailAddress).toLowerCase())) {
				// Will check email validation.
				this.setState({
					emailErrorValidationMessage: false,
				});
			}
		}
		if (
			this.isEditProfile &&
			!isUserCreated &&
			!isUserEdited &&
			success &&
			addUserDetailsInfo !== prevProps.addUserDetailsInfo
		) {
			const { organisationList } = addUserDetailsInfo;
			const { userDetails } = route.params;
			organisationList.forEach((item, orgIndex) => {
				if (item.id === userDetails.organization_id) {
					this.setState({
						branchNameSelectedIndex: orgIndex,
					});
				}
			});
			addUserDetailsAction.resetAddUserState();
		}
		if (
			!isUserCreated &&
			!isUserEdited &&
			(success || error) &&
			addUserDetailsInfo !== prevProps.addUserDetailsInfo
		) {
			addUserDetailsAction.resetAddUserState();
		}
	}

	onGoBack = () => {
		// Will navigate back to the previous screen and reset the reducer.
		const { addUserDetailsAction, navigation } = this.props;
		navigation.goBack();
		addUserDetailsAction.onResetUserCreatedSuccess();
	};

	onUploadProfilePic = async () => {
		// API call to upload the profile pic.
		const { addUserDetailsAction } = this.props;
		const results = await imagePicker();
		const { response, success, fileName } = results;
		if (success) {
			this.onSelectorVisible(false);
			this.setState({
				imageLoader: true,
			});
			const file = await uploadFile(response.uri, response.type, fileName);
			if (file) {
				this.setState({
					imageLoader: false,
				});
				addUserDetailsAction.onUploadProfilePic(file);
			}
		}
	};

	onRemoveImage = () => {
		// Function to remove the image.
		const { addUserDetailsAction } = this.props;
		this.onSelectorVisible(false);
		addUserDetailsAction.onUploadProfilePic(null);
	};

	onChangeText = (text, field) => {
		// Will save the input fields values.
		const { addUserDetailsAction } = this.props;
		addUserDetailsAction.onEditText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = type => {
		const { addUserDetailsInfo } = this.props;
		const { mobileNumber, emailAddress } = addUserDetailsInfo;
		if (
			type === fieldType.mobile &&
			mobileNumber.length === 0 &&
			!customMobileRegex.test(mobileNumber)
		) {
			this.setState({
				mobileErrorValidationMessage: true,
			});
		}
		if (type === fieldType.email && !emailRegexEx.test(String(emailAddress).toLowerCase())) {
			this.setState({
				emailErrorValidationMessage: true,
			});
		}
	};

	onPressSave = () => {
		// API call to create a new user.
		const { addUserDetailsAction, addUserDetailsInfo } = this.props;
		this.onDismissKeyboard();
		const { branchNameSelectedIndex, active } = this.state;
		const {
			name,
			emailAddress,
			profile_pic,
			organisationList,
			mobileNumber,
		} = addUserDetailsInfo;
		const queryParams = {};
		queryParams.name = name;
		queryParams.parent_id = organisationList[branchNameSelectedIndex].id;
		queryParams.profile_pic = getImageUrl(profile_pic);
		queryParams.email_address = emailAddress;
		queryParams.mobile = mobileNumber;
		queryParams.status = active;
		queryParams.role = `${fieldType.customerLabel
			.charAt(0)
			.toLocaleLowerCase()}${fieldType.customerLabel.slice(1)}`;
		addUserDetailsAction.addUser(queryParams);
	};

	onPressSaveEditUser = () => {
		// API call to edit the user details.
		const { route, addUserDetailsAction, addUserDetailsInfo } = this.props;
		this.onDismissKeyboard();
		const { branchNameSelectedIndex, active } = this.state;
		const { name, profile_pic, organisationList, mobileNumber } = addUserDetailsInfo;
		const { userDetails } = route.params;
		const queryParams = {};
		queryParams.id = userDetails.id;
		queryParams.name = name;
		queryParams.organization_id = organisationList[branchNameSelectedIndex].id;
		queryParams.profile_pic = getImageUrl(profile_pic);
		if (mobileNumber !== userDetails.mobile) {
			queryParams.mobile = mobileNumber;
		}
		queryParams.status = `${active}`;
		queryParams.role = `${fieldType.customerLabel
			.charAt(0)
			.toLocaleLowerCase()}${fieldType.customerLabel.slice(1)}`;
		addUserDetailsAction.editUser(queryParams);
	};

	onSelectOption = (index, type) => {
		this.onCloseDropdown();
		if (type === fieldType.branchName) {
			this.setState({
				branchNameSelectedIndex: index,
			});
		}
	};

	onCloseDropdown = () => {
		this.setState({
			isDropdownVisible: false,
		});
	};

	onSelectorVisible = value => {
		this.setState({
			isVisible: value,
		});
	};

	onPressStatus = () => {
		// Will toggle user status.
		const { active } = this.state;
		this.setState({
			active: !active,
		});
	};

	onDismissKeyboard = () => {
		Keyboard.dismiss();
	};

	onPressDropdown = () => {
		const { addUserDetailsAction } = this.props;
		this.onDismissKeyboard();
		this.setState({
			isDropdownVisible: true,
		});
		const queryParams = {};
		queryParams.page = this.page;
		addUserDetailsAction.getBranches(queryParams);
	};

	render() {
		const { addUserDetailsInfo, languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const {
			mobileErrorValidationMessage,
			emailErrorValidationMessage,
			isApiError,
			toastMessage,
			imageLoader,
			branchNameSelectedIndex,
			active,
			isVisible,
			isDropdownVisible,
		} = this.state;
		const styles = createStyleSheet(isRTL);
		const {
			name,
			mobileNumber,
			emailAddress,
			profile_pic,
			loader,
			isUserCreated,
			isUserEdited,
			organisationList,
			createUserLoader,
		} = addUserDetailsInfo;
		const imageData = [
			{
				title: localeString(keyConstants.VIEW_GALLERY),
				image: IMAGES.iconGallery,
				action: () => this.onUploadProfilePic(),
			},
			{
				title: localeString(keyConstants.REMOVE_IMAGE),
				image: IMAGES.iconDeleteRed,
				action: () => this.onRemoveImage(),
			},
		];
		return (
			<KeyboardAwareScrollView
				contentContainerStyle={styles.container}
				keyboardShouldPersistTaps="handled">
				{loader && createUserLoader && <Spinner size="large" />}
				<OverlayComponent
					isRTL={isRTL}
					isVisible={isVisible}
					onClose={() => this.onSelectorVisible(false)}
					component={ItemSelectionComponent(isRTL, imageData)}
				/>
				<OptionPicker
					title={localeString(keyConstants.SELECT_BRANCH_NAME)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={organisationList}
					onClose={this.onCloseDropdown}
					onSelectOption={index => this.onSelectOption(index, fieldType.branchName)}
					activeIndex={branchNameSelectedIndex}
					loader={loader && !isUserCreated && !isUserEdited}
				/>
				<Header headerStyle={styles.backButton} onPressBack={this.onGoBack} hasIconBack />
				<ScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					keyboardShouldPersistTaps="handled"
					showsHorizontalScrollIndicator={false}>
					<EditImageComponent
						isRTL={isRTL}
						imageLoader={imageLoader}
						profile_pic={profile_pic}
						onImageSelectorVisible={() => this.onSelectorVisible(true)}
					/>
					<View style={styles.formView}>
						<Input
							value={name}
							width={normalScale(288)}
							label={`${localeString(keyConstants.NAME)}*`}
							placeholder={localeString(keyConstants.YOUR_FULL_NAME)}
							blurOnSubmit={false}
							returnKeyType="done"
							isRTL={isRTL}
							onChangeText={text => this.onChangeText(text, 'name')}
							autoCapitalize="none"
						/>
						<DropdownFieldComponent
							isRTL={isRTL}
							onPress={this.onPressDropdown}
							value={
								branchNameSelectedIndex !== null && // dropdown index should not be null
								organisationList &&
								organisationList[branchNameSelectedIndex] // there should be value in organisationList at the selected index of dropdown
									? organisationList[branchNameSelectedIndex].name // Will show branch name
									: ''
							}
							placeholder={localeString(keyConstants.SELECT_BRANCH_NAME)}
							label={`${localeString(keyConstants.SELECT_BRANCH_NAME)}*`}
						/>
						<Input
							value={emailAddress}
							width={normalScale(288)}
							label={`${localeString(keyConstants.EMAIL)}*`}
							placeholder={localeString(keyConstants.ABC_EMAIL)}
							isRTL={isRTL}
							blurOnSubmit
							editable={!this.isEditProfile}
							returnKeyType="next"
							onChangeText={text => this.onChangeText(text, 'emailAddress')}
							autoCapitalize="none"
							refs={this.refCallback(this.emailAddress)}
							onSubmitEditing={() => this.onSubmitRef(this.mobileNumber)}
							onBlur={() => this.onBlur(fieldType.email)}
							isError={emailErrorValidationMessage}
							errorMessage={localeString(keyConstants.EMAIL_VALIDATION_MESSAGE)}
							keyboardType="email-address"
							textInputStyle={this.isEditProfile ? styles.textStyle : null}
						/>
						<Input
							maxLength={mobileNumberLength}
							value={mobileNumber}
							width={normalScale(288)}
							label={`${localeString(keyConstants.MOBILE_NUMBER)}*`}
							placeholder={localeString(keyConstants.MOBILE_NUMBER_PLACEHOLDER)}
							blurOnSubmit
							returnKeyType="done"
							keyboardType="number-pad"
							isRTL={isRTL}
							onChangeText={text =>
								(numericRegexExp.test(String(text).toLowerCase()) || text === '') &&
								this.onChangeText(text, 'mobileNumber')
							}
							autoCapitalize="none"
							refs={this.refCallback(this.mobileNumber)}
							onBlur={() => this.onBlur(fieldType.mobile)}
							isError={mobileErrorValidationMessage}
							errorMessage={localeString(
								keyConstants.PHONE_NUMBER_VALIDATION_MESSAGE,
							)}
							hasMobilePrefix
						/>
						<View style={styles.statusContainer}>
							<Text style={styles.status}>
								{`${localeString(keyConstants.USER_STATUS)}*`}
							</Text>
							<View style={styles.activeContainer}>
								<Text style={styles.active}>
									{localeString(keyConstants.ACTIVE)}
								</Text>
								<TouchableOpacity onPress={this.onPressStatus} activeOpacity={0.8}>
									<ImageLoadComponent
										source={active ? IMAGES.iconActive : IMAGES.iconInActive}
										style={active ? styles.activeStyle : styles.inActiveStyle}
									/>
								</TouchableOpacity>
							</View>
						</View>
					</View>
				</ScrollView>
				<SaveCancelButtonComponent
					isRTL={isRTL}
					isButtonDisable={
						!(
							name &&
							branchNameSelectedIndex !== null &&
							emailAddress &&
							customMobileRegex.test(mobileNumber) &&
							!imageLoader
						)
					}
					cancelText={localeString(keyConstants.CANCEL)}
					onPressCancel={this.onGoBack}
					saveText={localeString(keyConstants.SAVE)}
					onPressSave={this.isEditProfile ? this.onPressSaveEditUser : this.onPressSave}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		addUserDetailsInfo: state.AddUserDetailsScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		addUserDetailsAction: bindActionCreators({ ...AddUserDetailsAction }, dispatch),
	};
};

AddUserDetailsScreen.propTypes = {
	addUserDetailsAction: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	addUserDetailsInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(AddUserDetailsScreen);
