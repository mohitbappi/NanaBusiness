import { actions } from '@libapi/APIActionsBuilder';
import AddUserService from '@Users/AddUserService';
import GetBranchesService from '@Users/GetBranchesService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import EditUserService from '@Users/EditUserService';
import * as ActionTypes from './ActionType';

/**
 * Action to save input fields.
 * @param {string} text
 * @param {string} field
 * @returns
 */

export const onEditText = (text, field) => {
	return {
		type: ActionTypes.ON_EDIT_TEXT_ADD_USER,
		payload: text,
		field,
	};
};

/**
 * Action to upload profile pic.
 * @param {string} file
 * @returns
 */

export const onUploadProfilePic = file => {
	return {
		type: ActionTypes.ON_UPLOAD_PROFILE_PIC_ADD_USER,
		payload: file,
	};
};

/**
 * Action to get the branches.
 * @param {object} data
 * @returns
 */

export const getBranches = data => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_BRANCHES_SUCCESS,
		ActionTypes.GET_BRANCHES_FAILURE,
		ActionTypes.GET_BRANCHES_LOADER,
	);
	const getBranchesService = new GetBranchesService(dispatchedActions);
	addBasicInterceptors(getBranchesService);
	getBranchesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getBranchesService.makeRequest(data));
};

/**
 * Action to add a new user.
 * @param {object} data
 * @returns
 */

export const addUser = data => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.ADD_USER_SUCCESS,
		ActionTypes.ADD_USER_FAILURE,
		ActionTypes.ADD_USER_LOADER,
	);
	const addUserService = new AddUserService(dispatchedActions);
	addBasicInterceptors(addUserService);
	addUserService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(addUserService.makeRequest(data));
};

/**
 * Action to edit a user.
 * @param {object} data
 * @returns
 */

export const editUser = data => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.EDIT_USER_SUCCESS,
		ActionTypes.EDIT_USER_FAILURE,
		ActionTypes.EDIT_USER_LOADER,
	);
	const editUserService = new EditUserService(dispatchedActions);
	addBasicInterceptors(editUserService);
	editUserService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(editUserService.makeRequest(data));
};

export const resetAddUserState = () => ({ type: ActionTypes.RESET_ADD_USER_STATE });

export const onResetUserCreatedSuccess = () => ({ type: ActionTypes.ON_RESET_USER_CREATED });
