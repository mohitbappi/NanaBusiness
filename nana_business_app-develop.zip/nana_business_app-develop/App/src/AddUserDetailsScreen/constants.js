export const branchName = 'branchName';
export const mobile = 'mobile';
export const email = 'email';
export const role = 'role';
export const customerLabel = 'Customer';
