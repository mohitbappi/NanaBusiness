import * as ActionTypes from './ActionType';

const initialState = {
	name: '',
	mobileNumber: '',
	emailAddress: '',
	profile_pic: null,
	success: false,
	isUserCreated: false,
	isUserEdited: false,
	createUserLoader: false,
	error: false,
	loader: false,
	organisationList: [],
	errorCode: null,
	isBranch: false,
};

const AddUserDetailsScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_EDIT_TEXT_ADD_USER:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.ON_UPLOAD_PROFILE_PIC_ADD_USER:
			return {
				...state,
				profile_pic: action.payload,
			};
		case ActionTypes.GET_BRANCHES_SUCCESS:
			return {
				...state,
				success: true,
				loader: false,
				error: false,
				errorCode: '',
				organisationList: action.payload.branch_list,
				isUserCreated: false,
				isUserEdited: false,
				createUserLoader: false,
			};
		case ActionTypes.GET_BRANCHES_FAILURE:
			return {
				...state,
				success: true,
				loader: false,
				error: true,
				errorCode: action.payload,
				organisationList: [],
				isUserCreated: false,
				isUserEdited: false,
				createUserLoader: false,
				isBranch: true,
			};
		case ActionTypes.GET_BRANCHES_LOADER:
			return {
				...state,
				success: false,
				loader: true,
				error: false,
				errorCode: '',
				isUserCreated: false,
				isUserEdited: false,
				createUserLoader: false,
			};
		case ActionTypes.ADD_USER_SUCCESS:
			return {
				...state,
				success: true,
				loader: false,
				error: false,
				errorCode: '',
				isUserCreated: true,
				isUserEdited: false,
				createUserLoader: false,
			};
		case ActionTypes.ADD_USER_FAILURE:
		case ActionTypes.EDIT_USER_FAILURE:
			return {
				...state,
				success: false,
				loader: false,
				error: true,
				errorCode: action.payload.data,
				isUserCreated: false,
				isUserEdited: false,
				createUserLoader: false,
				isBranch: false,
			};
		case ActionTypes.ADD_USER_LOADER:
		case ActionTypes.EDIT_USER_LOADER:
			return {
				...state,
				success: false,
				loader: true,
				error: false,
				errorCode: '',
				isUserCreated: false,
				isUserEdited: false,
				createUserLoader: true,
			};
		case ActionTypes.EDIT_USER_SUCCESS:
			return {
				...state,
				success: true,
				loader: false,
				error: false,
				errorCode: '',
				isUserCreated: false,
				isUserEdited: true,
				createUserLoader: false,
			};
		case ActionTypes.RESET_ADD_USER_STATE:
			return {
				...state,
				success: false,
				loader: false,
				error: false,
				errorCode: '',
				createUserLoader: false,
			};
		case ActionTypes.ON_RESET_USER_CREATED:
			return initialState;
		default:
			return state;
	}
};

export default AddUserDetailsScreenReducer;
