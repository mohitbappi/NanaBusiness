// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import navigations from '@routes/navigations';

// import components
import TransactionDetailUI from './TransactionDetailUI';

class TransactionDetailComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
	}

	onGoBack = () => {
		// Will navigate to previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onNavigateToSupport = () => {
		// Will navigate to contact us screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.CONTACT_US);
	};

	render() {
		const { languageInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const { transactionDetail, date, hasNote } = route.params || {};
		return (
			<TransactionDetailUI
				isRTL={isRTL}
				transactionDetail={transactionDetail} // Transaction detail.
				date={date} // Transaction date.
				onGoBack={this.onGoBack}
				onPressSupport={this.onNavigateToSupport}
				hasNote={hasNote} // Boolean to the note.
				disableOrganization={hasNote} // Boolean to show the organization.
			/>
		);
	}
}

TransactionDetailComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default TransactionDetailComponent;
