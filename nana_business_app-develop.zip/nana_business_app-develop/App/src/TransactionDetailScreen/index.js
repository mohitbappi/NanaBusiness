export { default } from './TransactionDetailContainer';
