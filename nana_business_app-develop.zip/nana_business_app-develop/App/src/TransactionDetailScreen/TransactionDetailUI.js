// import libraries
import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';

// import constants
import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';
import { promotionCash } from '@Constants/Constants';

// import components
import Header from '@Header/Header';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';

// import utils
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { localeString } from '@assets/Localization';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDate } from '@Util/GetFormattedDate';
import { getFormattedTime } from '@Util/GetFormattedTime';

// import styles
import { createStyleSheet } from './TransactioDetailScreenStyle';

class TransactionDetailUI extends Component {
	getTransactionUIProps = transactionStatus => {
		// Function to return textStyle, backgroundStyle and icon according to the status.
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		const transactionProps = {
			success: {
				textStyle: styles.successText,
				backgroundStyle: styles.successBackground,
				icon: IMAGES.iconTransactionDetailSuccess,
			},
			pending: {
				textStyle: styles.pendingText,
				backgroundStyle: styles.pendingBackground,
				icon: IMAGES.iconTransactionDetailPending,
			},
			failed: {
				textStyle: styles.failedText,
				backgroundStyle: styles.failedBackground,
				icon: IMAGES.iconTransactionDetailFailed,
			},
			waiting: {
				textStyle: styles.pendingText,
				backgroundStyle: styles.pendingBackground,
				icon: IMAGES.iconTransactionDetailPending,
			},
		};
		if (transactionStatus && transactionProps[transactionStatus]) {
			// If status is given.
			return transactionProps[transactionStatus];
		}
		return transactionProps.success; // If status is null or empty.
	};

	getId = item => {
		// Function to return payment id.
		if (item.reference_id) {
			return item.reference_id;
		}
		if (item.is_advance_payment) {
			return item.pr_id;
		}
		return null;
	};

	getNote = type => {
		// Will return the note accordind to the type.
		const noteData = {
			placed: localeString(keyConstants.UNBILLED_SUMMARY_NOTE_IF_PLACED),
			delivered: localeString(keyConstants.UNBILLED_SUMMARY_NOTE_IF_DELIVERED),
			default: localeString(keyConstants.UNBILLED_SUMMARY_NOTE_IF_REFUND),
		};
		if (noteData[type]) {
			return noteData[type];
		}
		return noteData.default;
	};

	getOrganizationName = (transactionDetail, isRTL) => {
		// Function to return organization name.
		const { customer_org_name, customer_org_name_ar } = transactionDetail;
		let organizationName = localeString(keyConstants.NANA_BUSINESS);
		if (customer_org_name && customer_org_name_ar) {
			organizationName = isRTL ? customer_org_name_ar : customer_org_name;
		}
		return organizationName;
	};

	render() {
		const {
			isRTL,
			transactionDetail,
			onGoBack,
			onPressSupport,
			date,
			hasNote,
			disableOrganization,
		} = this.props;
		const {
			status,
			title,
			title_ar,
			amount,
			transaction_id,
			reference_id, // Payment id.
			sales_order_id,
			collection_request_id,
			promotion_reference_id,
			type,
		} = transactionDetail;
		const styles = createStyleSheet(isRTL);
		const { textStyle, backgroundStyle, icon } = this.getTransactionUIProps(status);
		return (
			<View style={styles.container}>
				<Header
					hasIconBack
					onPressBack={onGoBack}
					headerStyle={[styles.headerStyle, backgroundStyle]}
				/>
				<View
					style={[
						styles.topContainer,
						backgroundStyle,
						disableOrganization && styles.bottomMargin,
					]}>
					<View>
						<Text style={styles.titleText}>{isRTL ? title_ar : title}</Text>
						<Text style={[styles.normalText, textStyle]}>
							{`${currencyFormatter(getValueInDecimal(amount))} ${localeString(
								keyConstants.SAR,
							)}`}
						</Text>
						<Text style={styles.dateStyle}>
							{`${getFormattedDate(date)}, ${getFormattedTime(date)}`}
						</Text>
					</View>
					<ImageLoadComponent source={icon} style={styles.icon} />
				</View>
				<View style={styles.detailContainer}>
					{!disableOrganization ? (
						<View style={styles.innerContainer}>
							{type === promotionCash ? (
								<Text style={styles.organizationStyle}>
									{localeString(keyConstants.PROMOTIONAL_BALANCE)}
								</Text>
							) : (
								<View>
									<Text style={styles.toText}>
										{localeString(keyConstants.TO)}
									</Text>
									<Text style={styles.organizationStyle}>
										{this.getOrganizationName(transactionDetail, isRTL)}
									</Text>
								</View>
							)}
							<ImageLoadComponent
								source={IMAGES.iconNanaBusinessCircle}
								style={styles.icon}
							/>
						</View>
					) : null}
					{transaction_id ? (
						<Text style={styles.idText}>
							{`${localeString(keyConstants.TRANSACTION_ID)}: ${transaction_id}`}
						</Text>
					) : null}
					{reference_id ? (
						<Text style={styles.idText}>
							{`${localeString(keyConstants.PAYMENT_ID)}: ${this.getId(
								transactionDetail,
							)}`}
						</Text>
					) : null}
					{promotion_reference_id ? (
						<Text style={styles.idText}>
							{`${localeString(
								keyConstants.REFERENCE_NUMBER,
							)}: ${promotion_reference_id}`}
						</Text>
					) : null}
					{sales_order_id ? (
						<Text style={[styles.idText, hasNote && styles.idStyle]}>
							{`${localeString(keyConstants.SALES_ORDER_ID)}: ${sales_order_id}`}
						</Text>
					) : null}
					{collection_request_id ? (
						<Text style={styles.idText}>
							{`${localeString(
								keyConstants.COLLECTION_REQUEST_ID,
							)}: ${collection_request_id}`}
						</Text>
					) : null}
				</View>
				{/* Will show note component. */}
				{hasNote ? (
					<View style={styles.noteContainer}>
						<ImageLoadComponent source={IMAGES.iconNote} style={styles.iconNote} />
						<View style={styles.noteInnerContainer}>
							<Text style={styles.note}>{`${localeString(keyConstants.NOTE)}:`}</Text>
							<Text style={[styles.note, styles.noteDesc]}>
								{this.getNote(transactionDetail.case)}
							</Text>
						</View>
					</View>
				) : null}
				<TouchableOpacity
					style={styles.supportContainer}
					activeOpacity={0.8}
					onPress={onPressSupport}>
					<View style={styles.innerView}>
						<ImageLoadComponent
							source={IMAGES.iconSupportBlue}
							style={styles.iconSupportBlue}
						/>
						<Text style={styles.supportText}>
							{`${localeString(keyConstants.NEED_SUPPORT)}${localeString(
								keyConstants.QUESTION_MARK,
							)}`}
						</Text>
					</View>
					<ImageLoadComponent
						source={IMAGES.iconRightArrow}
						style={styles.iconRightArrow}
					/>
				</TouchableOpacity>
			</View>
		);
	}
}

TransactionDetailUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	transactionDetail: PropTypes.object.isRequired,
	onGoBack: PropTypes.func.isRequired,
	onPressSupport: PropTypes.func.isRequired,
	date: PropTypes.string.isRequired,
	hasNote: PropTypes.bool.isRequired,
	disableOrganization: PropTypes.bool.isRequired,
};

export default TransactionDetailUI;
