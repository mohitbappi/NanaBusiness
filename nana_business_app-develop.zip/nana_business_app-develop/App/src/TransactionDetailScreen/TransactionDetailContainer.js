// import libraries
import React from 'react';
import { connect } from 'react-redux';

// import components
import TransactionDetailComponent from './TransactionDetailComponent';

const TransactionDetailContainer = props => {
	const customProps = { ...props }; // Will store all the props.
	return <TransactionDetailComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
	};
};

export default connect(mapStateToProps, null)(TransactionDetailContainer);
