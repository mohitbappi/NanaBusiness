// import libraries
import { StyleSheet } from 'react-native';

// import colors
import * as colors from '@assets/colors';

// import constants
import normalize, { normalScale, verticalScale } from '@device/normalize';
import { fontsConstants } from '@Constants/Constants';

// import components
import RTLFunctions from '@Util/RTLFunctions';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		successText: {
			color: colors.lightBlueShadowGrey,
		},
		successBackground: {
			backgroundColor: colors.lightSkyBlue,
		},
		pendingText: {
			color: colors.darkOrange,
		},
		pendingBackground: {
			backgroundColor: colors.orange,
		},
		failedText: {
			color: colors.red,
		},
		failedBackground: {
			backgroundColor: colors.lightTransparentRed,
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerStyle: {
			paddingHorizontal: normalScale(16),
		},
		topContainer: {
			paddingTop: verticalScale(8),
			paddingBottom: verticalScale(20),
			paddingHorizontal: normalScale(16),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginBottom: verticalScale(20),
		},
		bottomMargin: {
			marginBottom: verticalScale(0),
		},
		titleText: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(14),
			color: colors.black,
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		normalText: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(20),
			marginTop: verticalScale(8),
			marginLeft: -rtlFunctions.getMarginLeft(isRTL, 5),
		},
		dateStyle: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(12),
			color: colors.blackGreyWhite,
			marginTop: verticalScale(8),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		icon: {
			height: normalScale(40),
			width: normalScale(40),
			alignSelf: 'center',
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 12),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 12),
		},
		detailContainer: {
			paddingHorizontal: normalScale(16),
			paddingTop: verticalScale(12),
			paddingBottom: verticalScale(19),
		},
		innerContainer: {
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		toText: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			color: colors.blackGreyWhite,
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		organizationStyle: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			color: colors.black,
			marginTop: verticalScale(4),
		},
		idText: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			color: colors.blackGreyWhite,
			marginTop: verticalScale(8),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		idStyle: {
			color: colors.black,
		},
		noteContainer: {
			backgroundColor: colors.orange,
			paddingHorizontal: normalScale(16),
			paddingVertical: verticalScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			marginTop: verticalScale(11),
		},
		iconNote: {
			height: normalScale(20),
			width: normalScale(20),
		},
		noteInnerContainer: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		note: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.boldItalic),
			fontSize: normalize(10),
			color: colors.black,
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
			marginRight: rtlFunctions.getMarginLeftRTL(isRTL, 8),
		},
		noteDesc: {
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 2),
			marginRight: rtlFunctions.getMarginLeftRTL(isRTL, 2),
			width: normalScale(205),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		supportContainer: {
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			backgroundColor: colors.whitishGrey,
			paddingHorizontal: normalScale(16),
			paddingVertical: verticalScale(8),
			marginTop: verticalScale(20),
			alignItems: 'center',
		},
		innerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
		},
		iconSupportBlue: {
			height: normalScale(30),
			width: normalScale(30),
		},
		supportText: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			color: colors.black,
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 12),
			marginRight: rtlFunctions.getMarginLeftRTL(isRTL, 12),
		},
		iconRightArrow: {
			width: normalScale(6),
			height: verticalScale(10),
		},
	});
};

export default createStyleSheet;
