1. AddUserDetailScreen - (Line no 330 - 341) {/_ Todo :- Will use in future. _/} {/_ <Dropdown
   label={`${localeString(keyConstants.ROLE)}_`} placeholder={`${localeString(keyConstants.ROLE)}_`}
   width={normalScale(288)} value={roleArray} selectedIndex={roleSelectedIndex} onPress={(index) =>
   this.onSelectOption(index, role)} childRef={ref => (this.childRefTwo = ref)}
   onPressDropdown={this.onPressDropdown} dropdownViewStyle={styles.dropdownViewStyle} /> _/}

2. HomeScreen - (Line no - 446 - 497) {/_ Todo :- Will use in future. _/} {/_
   <View style={styles.card}>
   <Text style={styles.availableBalance}>{localeString(keyConstants.AVAILABLE_BALANCE)}</Text>
   <Text style={styles.amount}>{clConstants.nil} {SAR}</Text>
   <TouchableOpacity style={styles.applyView} activeOpacity={0.8} onPress={this.onApplyForCreditLine}>
   <Text style={styles.apply}>{localeString(keyConstants.APPLY_FOR_CREDIT_LINE)}</Text>
   </TouchableOpacity> </View> <View style={styles.orangeCard}> <View style={styles.dueAmountView}>
   <Text style={styles.dueText}>{`${localeString(keyConstants.DUE_AMOUNT)} ${clConstants.nil} ${SAR}`}</Text>
   </View> <View style={styles.progressBar}> <View style={[styles.usedAmount, { width:
   `${(getValueInDecimal(clConstants.usedAmount) / getValueInDecimal(clConstants.totalCreditAmount))
   _
   100}%`}]} /> <View style={[styles.dueAmount, { width:`${(getValueInDecimal(clConstants.dueAmount)
   / getValueInDecimal(clConstants.totalCreditAmount)) _ 100}%` }]} /> </View>
   <View style={styles.detailView}> <View>
   <Text style={styles.text}>{localeString(keyConstants.USED)}</Text>
   <Text style={styles.amountStyle}>{clConstants.nil} {SAR}</Text> </View> <View>
   <Text style={styles.text}>{localeString(keyConstants.TOTAL_CREDIT)}</Text>
   <Text style={styles.amountStyle}>{clConstants.nil} {SAR}</Text> </View> </View> </View> _/} {/_
   Todo :- Will use in future. _/} {/_ <Search
       hasSearchIcon
       placeholder={localeString(keyConstants.SEARCH_BY_CATEGORY_OR_BRAND)}
   /> _/}

3. HomeScreen - (Line no 531 - 549) {/_ Todo :- Will use in future. _/} {/_
   <Text style={styles.offers}>{localeString(keyConstants.OFFERS)}</Text>
   <View style={styles.offersView}> <FlatList data={offersArray}
   showsVerticalScrollIndicator={false} renderItem={({item, index}) => { return (
   <CartItemCardComponent
                       image={item.image}
                       itemName={item.itemName}
                       category={item.category}
                       price={item.price}
                   /> ); }} keyExtractor={this.keyExtractor} /> </View> _/}

4. OrderCard - (Line no 109 - 117) {/_ Todo :- Will use in future if needed. _/} {/_ { status ===
   orderStatus.approved && <ButtonComponent
           buttonStyle={styles.buttonStyle}
           onPress={onTrackOrder}
           text={localeString(keyConstants.TRACK_ORDER)}
       /> } _/}

5. ProductListScreen - (Line no 761 - 765) {/_ TODO: Will use SORT button in future _/} {/_
   <TouchableOpacity style={styles.sortContainer} activeOpacity={0.8}>
   <ImageLoadComponent source={IMAGES.iconSort} style={styles.sortImg} />
   <Text style={styles.sortText}>{localeString(keyConstants.SORT_BY)}</Text> </TouchableOpacity> _/}

6. UserDetailsScreen - (Line no 224 - 231) {/_ Todo :- Will use in future. _/} {/_
   <View style={styles.buttonView}> <ButtonComponent
           textStyle={styles.sendActivationButton}
           text={localeString(keyConstants.SEND_ACTIVATION_CODE)}
           onPress={this.onSendActivationMail}
       /> </View> _/}

7. InvoiceDetailScreen - (Line no 407 - 424) {/_ Todo :- Will use in future. _/} {/_ { (this.role
   === collector && isPayNowButton) && <View style={styles.buttonView}> <ButtonComponent
               buttonStyle={styles.cancelButton}
               text={localeString(keyConstants.BACK)}
               textStyle={styles.cancelText}
               onPress={this.onGoBack}
           /> <ButtonComponent buttonStyle={styles.payButton}
   text={localeString(keyConstants.PAY_NOW)} onPress={() => this.onPayNow(invoice_total,
   invoice_total - paid_amount_approved)} isButtonDisable={invoice_total === paid_amount_approved}
   /> </View> } _/}

8. EditUserDetailsScreen - (Line no 364 - 374) {/_ Todo :- Will use in future. _/} {/_ <Dropdown
   label={`${localeString(keyConstants.ROLE)}`} placeholder={`${localeString(keyConstants.ROLE)}`}
   width={normalScale(288)} value={roleArray} selectedIndex={roleSelectedIndex} onPress={(index) =>
   this.onSelectOption(index)} dropdownViewStyle={styles.dropdownViewStyle} childRef={ref =>
   (this.childRefTwo = ref)} onPressDropdown={this.onPressDropdown} /> _/}

9. AddUserDetailsScreen - (Line no 171 - 172) // Todo :- will use in future. // queryParams.role =
   `${roleArray[roleSelectedIndex].name.charAt(0).toLocaleLowerCase()}${roleArray[roleSelectedIndex].name.slice(1)}`;

10. EditUserDetailsScreen - (Line no 214 - 215) // Todo :- will use in future. // queryParams.role =
    `${roleArray[roleSelectedIndex].name.charAt(0).toLocaleLowerCase()}${roleArray[roleSelectedIndex].name.slice(1)}`;

11. MyAccountScreen - (Line no 238 - 250) {/_ Todo :- will use in future. _/} {/_ <ProgressCircle
    unfilledColor={colors.greenShadow} borderWidth={0} // Todo :- Will fetch from api.
    formatText={() => {return scorePlaceholderValue;}} showsText progress={organization &&
    (organization.score ? parseInt(organization.score, 10) : 0) / 5} size={62} thickness={10}
    strokeCap="round" color={colors.darkBlue} textStyle={styles.progressTextStyle} /> _/}

12. CreditLineComponent - (Line no 31 - 34) {/_ Todo :- will use in future. _/}
    <TouchableOpacity activeOpacity={0.8} onPress={this.goToCreditLine}>
    <ImageLoadComponent source={IMAGES.iconAddGreen} style={styles.iconAdd} /> </TouchableOpacity>

13. AccountConstants - (Line no 18 - 22) // Todo :- Will use in future. // { // image:
    IMAGES.iconSupport, // label: keyConstants.SUPPORT, // },

14. WishListScreen - (Line no 392 - 408) // TODO: Add db Search Feature for wishlist item {/_ {
    activePickerIndex === null ? <TouchableOpacity activeOpacity={1} onPress={() =>
    this.handlePicker(true)} style={styles.buttonContainer}>
    <ImageLoadComponent source={IMAGES.iconSearch} style={styles.icon} />
    <Text style={styles.textInput}>{localeString(keyConstants.SEARCH_BY_ITEM_OR_BARCODE)}</Text>
    </TouchableOpacity> : <View style={styles.searchContainer}> <Search hasSearchIcon
    placeholder={localeString(keyConstants.SEARCH_BY_ITEM_OR_BARCODE)} onChangeText={text =>
    this.onSearch(text)} value={searchText} onPressIcon={() => this.handlePicker(true)} /> </View> }
    _/}

15. HomeScreen - (Line no 392 - 408) // TODO: Floating Search icon on Home Screen for Customer

    {/_ <TouchableOpacity onPress={this.onSearch} style={styles.searchView} activeOpacity={1}>
    <ImageLoadComponent source={IMAGES.iconSearchGreen} style={styles.iconSearchGreen} />
    </TouchableOpacity> _/}

16. CartScreen - (Line no 749 - 752)
    <TouchableOpacity activeOpacity={0.8} onPress={this.onSelectPaymentMode} style={styles.footerView}>
    <Text style={styles.finalLabel}>{paymentMode}</Text>
    <ImageLoadComponent source={IMAGES.iconArrowDown} style={styles.iconArrowDown} />
    </TouchableOpacity>
17. CartScreen - (Line no 89 - 112) if (paymentModeIndex) { // If paymentModeIndex = 1 then the
    payment mode is offline payment (cash on delivery).
    this.props.navigation.navigate(navigations.ORDER_DETAIL_NAVIGATION, { id: orderDetails &&
    orderDetails.id, orderData: orderDetails, isNavigateBack: false, } ); } else { // If
    paymentModeIndex = 0 then the payment mode is online payment.
    this.props.navigation.navigate(navigations.PAYMENT_NAVIGATION, { paymentDetail, type:
    navigationType.order, extraParams: { orderData: orderDetails, id: orderDetails &&
    orderDetails.id, isNavigateBack: false, }, } ); }

18. OrderDetailScreen - (Line no 367 - 378) <View style={styles.total}>
    <Text style={styles.text}>{localeString(keyConstants.PAYMENT_MODE)}</Text>
    <Text style={styles.paymentMode}>{this.getPaymentMode(payment_mode)}</Text> </View> {
    payment_mode === paymentModeConstants.online ? <View style={styles.total}>
    <Text style={styles.text}>{localeString(keyConstants.TRANSACTION_ID)}</Text>
    <Text style={styles.paymentMode}>{payment_id}</Text> </View> : null }

19. HomeScreen - (line no 547 - 587) renderHotDeals = (dashboardData, isLastElement) => { const {
    brands } = dashboardData || {}; const { isRTL } = this.props.languageInfo; const styles =
    createStyleSheet(isRTL); if (brands && brands.to_show && brands.data && brands.data.length) {
    return ( <> <View style={styles.innerContainer}> <View style={styles.brandView}>
    <Text style={styles.brands}>{localeString(keyConstants.HOT_DEALS)}</Text>
    <TouchableOpacity activeOpacity={0.8} onPress={this.viewAllBrands}>
    <Text style={styles.viewBrands}>{localeString(keyConstants.VIEW_ALL)}</Text> </TouchableOpacity>
    </View> <FlatList data={brands ? brands.data : []} horizontal inverted={isRTL}
    showsHorizontalScrollIndicator={false} renderItem={({ item, index }) => { return (
    <TouchableOpacity style={styles.hotDealContainer} onPress={() => this.onPressBrand(item)}
    activeOpacity={0.8}> <ImageLoadComponent imageType={IMAGE_TYPE.brand} isUrl={item.images}
    source={(item.images && item.images.small) ? item.images.small : IMAGES.iconDefaultBrand}
    style={styles.hotDealImage} /> <Text style={styles.label}>{isRTL ? item.name_ar :
    item.name}</Text> </TouchableOpacity> ); }} keyExtractor={this.keyExtractor} /> </View>
    {!isLastElement && this.getSeparator()} </> ); } return null; }

20. RetailerDetailScreen - (line no 164 - 178) {role === collector && (
    <View style={styles.buttonView}> <ButtonComponent buttonStyle={styles.depositButtonStyle}
    text={`${localeString(keyConstants.CREATE_PAYMENT)} ${ totalAmount ? `(${currencyFormatter(
    getValueInDecimal(totalAmount), )} ${localeString(keyConstants.SAR)} )` : '' }`} onPress={() =>
    this.onCreatePayment(id)} /> </View> )}
