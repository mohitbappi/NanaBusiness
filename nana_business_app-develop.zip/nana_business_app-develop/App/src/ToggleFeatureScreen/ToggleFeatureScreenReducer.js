import { isToggleFeatureEnable } from '@Constants/Constants';
import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	toggleFeatures: {
		online_payment: !isToggleFeatureEnable, // Key to enable disable online payment feature.
	},
};

const ToggleFeatureScreenReducer = (state = initialState, action = {}) => {
	const toggleFeaturesCopy = state.toggleFeatures; // Will store copy of the toggleFeature.
	switch (action.type) {
		case ActionTypes.GET_ENABLE_DISABLE_FEATURE_SUCCESS: {
			// If API calling is succeed.
			const toggleFeatureObject = action.payload;
			if (toggleFeatureObject) {
				// Will return true if toggleFeatureObject is not null.
				Object.entries(toggleFeatureObject).forEach(([key, value]) => {
					if (key in toggleFeaturesCopy) {
						// Will update the value of the key if key exists in the object.
						toggleFeaturesCopy[key] = value;
					}
				});
			}
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				toggleFeatures: toggleFeaturesCopy, // Will store the object to check which feature is enable or disable.
			};
		}
		case ActionTypes.GET_ENABLE_DISABLE_FEATURE_LOADER: // f API calling is in progress.
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_ENABLE_DISABLE_FEATURE_FAILURE: // If API calling is failed.
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.UPDATE_SPECIFIC_TOGGLE_FEATURE_VALUE: // To update the specific value of the key
			toggleFeaturesCopy[action.payload.featureName] = action.payload.value;
			return {
				...state,
				toggleFeatures: toggleFeaturesCopy,
			};
		default:
			return state;
	}
};

export default ToggleFeatureScreenReducer;
