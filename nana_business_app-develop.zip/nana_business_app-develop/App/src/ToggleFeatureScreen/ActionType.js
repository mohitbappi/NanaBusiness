export const GET_ENABLE_DISABLE_FEATURE_SUCCESS = 'get_enable_disable_feature_success';
export const GET_ENABLE_DISABLE_FEATURE_FAILURE = 'get_enable_disable_feature_failure';
export const GET_ENABLE_DISABLE_FEATURE_LOADER = 'get_enable_disable_feature_loader';
export const UPDATE_SPECIFIC_TOGGLE_FEATURE_VALUE = 'update_specific_toggle_feature_value';
