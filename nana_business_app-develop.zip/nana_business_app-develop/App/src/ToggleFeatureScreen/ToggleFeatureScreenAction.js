import { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetToggleFeatureService from '@ToggleFeature/GetToggleFeatureService';
import * as ActionTypes from './ActionType';

export const onGetToggleFeatures = () => dispatch => {
	// Function to call the API to get the list of all the features which will help to enable or disable them.
	const dispatchedActions = actions(
		ActionTypes.GET_ENABLE_DISABLE_FEATURE_SUCCESS,
		ActionTypes.GET_ENABLE_DISABLE_FEATURE_FAILURE,
		ActionTypes.GET_ENABLE_DISABLE_FEATURE_LOADER,
	);
	const getToggleFeatureService = new GetToggleFeatureService(dispatchedActions);
	addBasicInterceptors(getToggleFeatureService);
	getToggleFeatureService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getToggleFeatureService.makeRequest());
};

export const onUpdateSpecificToggleFeature = (featureName, value) => {
	// Will update the value of the specific feature.
	return {
		type: ActionTypes.UPDATE_SPECIFIC_TOGGLE_FEATURE_VALUE,
		payload: { featureName, value },
	};
};
