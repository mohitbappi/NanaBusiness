import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as ToggleFeaturesActions from './ToggleFeatureScreenAction';

class ToggleFeatureScreen extends Component {
	componentDidMount() {
		const { onRef, navigation, isDefaultApiCalling } = this.props;
		onRef(this); // Will set ref this
		this.willFocusListener = navigation.addListener('focus', () => {
			if (isDefaultApiCalling) {
				// Will call the toggle feature API if this value is getting true from the prop.
				this.getToggleFeatures();
			}
		});
	}

	componentWillUnmount() {
		const { onRef } = this.props;
		onRef(null); // Will set ref null
	}

	getToggleFeatures = () => {
		// Function to call toggle feature API.
		const { toggleFeaturesActions } = this.props;
		toggleFeaturesActions.onGetToggleFeatures();
	};

	render() {
		return <View />;
	}
}

ToggleFeatureScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	onRef: PropTypes.object.isRequired,
	isDefaultApiCalling: PropTypes.bool.isRequired,
	toggleFeaturesActions: PropTypes.object.isRequired,
};

const mapDispatchToProps = dispatch => {
	return {
		toggleFeaturesActions: bindActionCreators({ ...ToggleFeaturesActions }, dispatch),
	};
};

export default connect(null, mapDispatchToProps)(ToggleFeatureScreen);
