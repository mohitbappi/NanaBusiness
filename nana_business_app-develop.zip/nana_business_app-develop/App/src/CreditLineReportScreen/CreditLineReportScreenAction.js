import GetCreditLineReportService from '@CreditLine/GetCreditLineReportService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import DownloadCreditLineReportService from '@CreditLine/DownloadCreditLineReportService';
import * as ActionTypes from './ActionType';

/**
 * Action to get the credit report logs and credit line amount.
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetReports = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_CREDIT_LINE_REPORT_SUCCESS,
		ActionTypes.GET_CREDIT_LINE_REPORT_FAILURE,
		ActionTypes.GET_CREDIT_LINE_REPORT_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getCreditLineReportService = new GetCreditLineReportService(dispatchedActions);
	addBasicInterceptors(getCreditLineReportService);
	getCreditLineReportService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCreditLineReportService.makeRequest(props));
};

/**
 * Action to download the credit report for a given month & year.
 * @param {object} props
 * @returns
 */

export const onDownloadCreditLineReport = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.DOWNLOAD_CREDIT_LINE_REPORT_SUCCESS,
		ActionTypes.DOWNLOAD_CREDIT_LINE_REPORT_FAILURE,
		ActionTypes.DOWNLOAD_CREDIT_LINE_REPORT_LOADER,
	);
	const downloadCreditLineReportService = new DownloadCreditLineReportService(dispatchedActions);
	addBasicInterceptors(downloadCreditLineReportService);
	downloadCreditLineReportService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(downloadCreditLineReportService.makeRequest(props));
};

/**
 * Updates date in reducer & returns Promise to do task on successful promise resolve
 * @param {string} date
 * @returns
 */

export const onChangeDate = date => {
	return {
		type: ActionTypes.ON_CHANGE_CREDIT_LINE_REPORT_DATE,
		payload: date,
	};
};
