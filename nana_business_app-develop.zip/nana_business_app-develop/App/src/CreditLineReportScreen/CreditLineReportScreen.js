/* import libraries */
import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';

/* import components */
import Header from '@Header/Header';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import TransactionCard from '@TransactionCard/TransactionCard';
import MonthSelector from '@MonthSelector/MonthSelector';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import CreditLineInformation from '@CreditLineInformation/CreditLineInformation';
import Spinner from '@Spinner/Spinner';
import CreditLineDueComponent from '@CreditLineDueComponent/CreditLineDueComponent';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

/* import constants */
import { constants } from '@RefreshControlComponent/Constants';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import {
	fetchDataWithPagination,
	toastShowTime,
	paymentType,
	navigationType,
	toggleFeatureConstants,
	isToggleFeatureEnable,
	dateMonthFormatWithoutHyphen,
} from '@Constants/Constants';
import navigations from '@routes/navigations';

/* import utils */
import { getMonth } from '@Util/GetMonth';
import { convertAmount } from '@Util/GetValueInDecimal';
import { getFormattedDateWithHyphen, onConvertDateWithFormat } from '@Util/GetFormattedDate';
import { downloadFile } from '@Util/DownloadFile';
import { removeSpaces } from '@Util/GetFormattedString';
import AlertComponent from '@Util/AlertComponent';

/* import actions */
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as AddMoneyActions from '@AddMoneyScreen/AddMoneyScreenAction';
import * as ToggleFeaturesActions from '@ToggleFeatureScreen/ToggleFeatureScreenAction';
import * as CreditLineReportActions from './CreditLineReportScreenAction';

/* import styles */
import { createStyleSheet } from './CreditLineReportScreenStyle';

import { verticalScale } from '../config/device/normalize';

class CreditLineReportScreen extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			isShowPicker: false,
			bottomLoader: false,
			isApiError: false, // Boolean to show error
			toastMessage: '', // Will show error message
		};
	}

	componentDidMount() {
		const { pullToRefreshActions } = this.props;
		this.page = fetchDataWithPagination.page;
		this.onLoadMore(false);
		pullToRefreshActions.onHandlePullToRefresh(false);
	}

	componentDidUpdate(prevProps) {
		const {
			creditLineReportInfo,
			route,
			pullToRefreshActions,
			addMoneyInfo,
			viewProfileInfo,
			userDetails,
			navigation,
			toggleFeaturesActions,
		} = this.props;
		const {
			success,
			isDownload,
			downloadUrl,
			error: creditLineError,
			errorCode: creditLineErrorCode,
		} = creditLineReportInfo;
		const { success: addMoneySuccess, paymentDetail, error, errorCode } = addMoneyInfo;
		const { organizationId } = route.params;
		const { date } = creditLineReportInfo;
		if (success && prevProps.creditLineReportInfo.success !== creditLineReportInfo.success) {
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
			if (isDownload && downloadUrl) {
				// when user clicked download & downloadUrl is not null
				const name =
					(viewProfileInfo &&
						viewProfileInfo.userDetails &&
						viewProfileInfo.userDetails.name) ||
					userDetails.user.name; // get username
				const downloadFileName = `${removeSpaces(name)} ${getFormattedDateWithHyphen(
					date,
				)} ${localeString(keyConstants.CREDIT_REPORT)}`; // filename format = username-MM-YYYY-Credit-Report
				// download the credit line report file present at downloadUrl
				downloadFile(
					downloadUrl,
					downloadFileName,
					() => {
						this.onShowToast(`${localeString(keyConstants.DOWNLOADING)}...`);
					},
					() => {
						this.onShowToast(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
					},
					() => {
						this.onShowToast(localeString(keyConstants.FAILED_DOWNLOADING));
					},
				);
			}
		}
		if (addMoneySuccess && prevProps.addMoneyInfo.success !== addMoneyInfo.success) {
			// After getting successful response from the api it will navigate to payment screen page.
			navigation.navigate(navigations.PAYMENT_NAVIGATION, {
				paymentDetail,
				type: navigationType.creditLine,
				extraParams: { organizationId },
			});
		}
		if (error && prevProps.addMoneyInfo.error !== addMoneyInfo.error) {
			if (isToggleFeatureEnable && keyConstants[errorCode.error]) {
				// Will update the online payment value to false because user is not authorized.
				this.setState(
					{
						toastMessage: localeString(`${errorCode.error}`),
						isApiError: true,
					},
					() => {
						toggleFeaturesActions.onUpdateSpecificToggleFeature(
							toggleFeatureConstants.onlinePayment,
							false,
						);
					},
				);
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				ErrorAlertComponent(errorCode, this.payNow);
			}
		}
		if (creditLineError && creditLineError !== prevProps.creditLineReportInfo.error) {
			if (keyConstants[creditLineErrorCode.error]) {
				// when error then show relevant error message in toast
				this.onShowToast(localeString(creditLineErrorCode.error));
			} else {
				ErrorAlertComponent(creditLineErrorCode, this.onPressDownload);
			}
		}
	}

	componentWillUnmount() {
		const { creditLineReportActions } = this.props;
		creditLineReportActions.onChangeDate(new Date()); // reset date
	}

	onLoadMore = isOverwriteExistingList => {
		this.onFetchData(isOverwriteExistingList);
	};

	onFetchData = isOverwriteExistingList => {
		const { route, creditLineReportInfo, creditLineReportActions } = this.props;
		const { organizationId } = route.params;
		const { date } = creditLineReportInfo;
		const queryParams = {};
		queryParams.limit = fetchDataWithPagination.limit;
		queryParams.page = this.page;
		queryParams.organization_id = organizationId;
		queryParams.month = date ? date.getMonth() + 1 : null;
		queryParams.year = this.getFullYear(date);
		creditLineReportActions.onGetReports(queryParams, isOverwriteExistingList);
	};

	// displays 'message' in a toast
	onShowToast = message => {
		this.setState({
			toastMessage: message,
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	onChange = (event, newDate) => {
		const { creditLineReportActions } = this.props;
		this.hideMonthpicker();
		if (newDate) {
			creditLineReportActions.onChangeDate(newDate);
			this.page = fetchDataWithPagination.page;
			this.onLoadMore(false);
		}
	};

	getLayout = (data, index) => ({
		// To Get length and offset for Scroll To Index Functionality
		length: verticalScale(60),
		offset: verticalScale(60) * index,
		index,
	});

	showMonthpicker = () => {
		this.setState({
			isShowPicker: true,
		});
	};

	hideMonthpicker = () => {
		this.setState({
			isShowPicker: false,
		});
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	renderItem = ({ item, index }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		return (
			<TransactionCard
				isRTL={isRTL}
				date={item[0]}
				entries={item[1]}
				index={index}
				isShowTime // Will show time only.
				onPress={this.getTransactionDetail}
			/>
		);
	};

	getTransactionDetail = transactionDetail => {
		/*
			Will navigate to the transaction detail screen.
			Passing parameters are :-
			1. transactionDetail - Contains all the details of the transaction.
			2. date - Transaction date.
		*/
		// hiding datepicker
		const { navigation } = this.props;
		this.hideMonthpicker();
		navigation.navigate(navigations.TRANSACTION_DETAIL_NAVIGATION, {
			transactionDetail,
			date: transactionDetail.transaction_date,
		});
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponent = () => {
		const { languageInfo } = this.props;
		const { bottomLoader } = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const endReached = bottomLoader;
		if (endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { creditLineReportInfo } = this.props;
		const { loader } = creditLineReportInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onLoadMore(true);
		}
	};

	getFullYear = date => {
		if (date) {
			return date.getFullYear();
		}
		return null;
	};

	getMonthString = date => {
		if (date) {
			return getMonth(date.getMonth());
		}
		return null;
	};

	getCreditLineAmount = (usedAmount, totalAmount) => {
		return `${convertAmount(usedAmount)}/${convertAmount(totalAmount)}K`;
	};

	onRefresh = () => {
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	payNow = () => {
		const { creditLineReportInfo, addMoneyActions } = this.props;
		const { dueAmount } = creditLineReportInfo;
		// API call to pay all the dues.
		const paymentDetails = {
			payment_type: paymentType.creditLine,
			amount: dueAmount, // Due amount getting from backend.
		};
		addMoneyActions.onAddMoney(paymentDetails, false);
	};

	canPay = (selectedDate, creditLimitRefreshDate) => {
		if (selectedDate && creditLimitRefreshDate) {
			const currentMonth = selectedDate.getMonth(); // Extract current month from current date.
			const creditLimitRefreshMonth = new Date(creditLimitRefreshDate).getMonth(); // Extract month from the last credit limit refresh date.
			return {
				canPay: currentMonth >= creditLimitRefreshMonth, // If true then it will show due on the credit report screen.
				isShowAvailableBalance: currentMonth <= creditLimitRefreshMonth, // If true it will show available balance, Due balance, paid amount & used amount on the credit report screen.
			};
		}
		return {
			canPay: false,
			isShowAvailableBalance: true, // If credit limit is not assigned to the user then the available balance, Due balance, paid amount & used amount will still show as 0.
		};
	};

	/** to navigate to Increase Credit Line screen */
	onPressApplyForCreditLine = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.INCREASE_CREDIT_LINENAVIGATION);
	};

	onPressDownload = () => {
		// call API to get credit line report file download url
		const { creditLineReportInfo, route, creditLineReportActions } = this.props;
		const queryParams = {};
		const { date } = creditLineReportInfo;
		const { organizationId } = route.params;
		queryParams.organization_id = organizationId;
		queryParams.time = getFormattedDateWithHyphen(date);
		creditLineReportActions.onDownloadCreditLineReport(queryParams);
	};

	getAlert = () => {
		// OS alert confirmation to download credit report for <month> <year>
		// hiding datepicker
		const { creditLineReportInfo } = this.props;
		this.hideMonthpicker();
		const { date } = creditLineReportInfo;
		const alertOptions = {
			message: `${localeString(
				keyConstants.CONFIRM_DOWNLOAD_CREDIT_REPORT,
			)} ${onConvertDateWithFormat(date, dateMonthFormatWithoutHyphen)}?`,
			noText: localeString(keyConstants.NO),
			yesText: localeString(keyConstants.YES),
			onPressYes: this.onPressDownload,
		};
		AlertComponent(alertOptions);
	};

	render() {
		const {
			languageInfo,
			creditLineReportInfo,
			addMoneyInfo,
			refreshControlComponentInfo,
			toggleFeaturesInfo,
			configurableFileInfo,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { remoteConfigData } = configurableFileInfo;
		const { isShowPicker, bottomLoader, isApiError, toastMessage } = this.state;
		const {
			date,
			loader,
			creditReports,
			count,
			totalAmount,
			dueAmount,
			paidAmount,
			creditLimitRefreshDate,
			isDownload,
			error,
			errorCode,
		} = creditLineReportInfo;
		const usedAmount = totalAmount ? totalAmount.debit : 0;
		const totalCreditAmount = totalAmount ? totalAmount.credit : 0;
		const { loader: addMoneyLoader } = addMoneyInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		// Will provide all the variables of the home screen reducer.
		const { toggleFeatures } = toggleFeaturesInfo;
		const { online_payment } = toggleFeatures; // Will return toggleFeatures key value pair.
		return (
			<View style={styles.container}>
				{loader && !isDownload && !isFetchingForPullToRefresh && !bottomLoader && (
					<Loader size="large" />
				)}
				{((loader && isDownload) || addMoneyLoader) && <Spinner size="large" />}
				<MonthSelector isVisible={isShowPicker} onChange={this.onChange} value={date} />
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.CREDIT_LINE)}
						hasIconBack
						onPressBack={this.onGoBack}
						hasIconDownload={!!count} // '!!' is to convert count numeric value to boolean value
						// show download icon only when count is greater that 0
						onPressDownload={this.getAlert}
					/>
				</View>
				{error && !isDownload ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<ScrollViewComponent
						contentContainerStyle={styles.scrollViewStyle}
						showsVerticalScrollIndicator={false}
						onRefresh={this.onRefresh}
						componentType={constants.scrollView}>
						<View style={styles.innerContainer}>
							{this.canPay(date, creditLimitRefreshDate).isShowAvailableBalance && (
								<View style={styles.creditLineView}>
									<CreditLineInformation
										isRTL={isRTL}
										amount={totalCreditAmount - usedAmount}
										usedAmount={usedAmount}
										totalCreditAmount={totalCreditAmount}
										paidAmount={paidAmount}
										isCreditLine={paidAmount > 0} // Boolean to show paid amount popup on credit line card if paid amount > 0.
										hasHyperlink={
											remoteConfigData?.creditLine?.applyForCreditLine
										}
										onPressHyperlink={this.onPressApplyForCreditLine} // on Pressing Apply for credit Line
										hyperlinkTitle={localeString(
											keyConstants.APPLY_FOR_CREDIT_LINE,
										)}
									/>
								</View>
							)}
							{
								/*
										Will return true if
										1. the due has not been cleared in the existing month
										2. Due balance must be > 0
									*/
								this.canPay(date, creditLimitRefreshDate).canPay && dueAmount > 0 && (
									<View style={styles.creditLineDueView}>
										<CreditLineDueComponent
											isRTL={isRTL}
											dueAmount={dueAmount}
											onPayNow={this.payNow}
											isPayNowEnable={
												online_payment &&
												remoteConfigData?.creditLine?.payNow
											} // Boolean to check the online payment feature is enable for the user.
										/>
									</View>
								)
							}
							<View style={styles.monthView}>
								<TouchableOpacity
									activeOpacity={0.8}
									onPress={this.showMonthpicker}
									style={styles.monthButton}>
									<Text style={styles.placeholder}>
										{`${this.getMonthString(date)}, ${this.getFullYear(date)}`}
									</Text>
									<ImageLoadComponent
										source={IMAGES.iconArrowDown}
										style={styles.iconArrowDown}
									/>
								</TouchableOpacity>
							</View>
						</View>
						<ScrollViewComponent
							data={Object.entries(creditReports)}
							renderItem={this.renderItem}
							keyExtractor={this.keyExtractor}
							showsVerticalScrollIndicator={false}
							ListFooterComponent={
								creditReports &&
								count > fetchDataWithPagination.limit &&
								this.listFooterComponent()
							}
							onEndReached={() =>
								this.limit * this.page < count && this.onEndReached()
							}
							onEndReachedThreshold={0.5}
							ListEmptyComponent={() => (
								<ListEmpty text={localeString(keyConstants.NO_LOGS_FOUND)} />
							)}
							contentContainerStyle={
								Object.entries(creditReports).length === 0
									? styles.scrollViewStyle
									: null
							}
							componentType={constants.flatList}
						/>
					</ScrollViewComponent>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		creditLineReportInfo: state.CreditLineReportScreenReducer,
		addMoneyInfo: state.AddMoneyScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		viewProfileInfo: state.ViewProfileScreenReducer,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		creditLineReportActions: bindActionCreators({ ...CreditLineReportActions }, dispatch),
		addMoneyActions: bindActionCreators({ ...AddMoneyActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		toggleFeaturesActions: bindActionCreators({ ...ToggleFeaturesActions }, dispatch),
	};
};

CreditLineReportScreen.propTypes = {
	route: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	creditLineReportInfo: PropTypes.object.isRequired,
	addMoneyInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	viewProfileInfo: PropTypes.object.isRequired,
	creditLineReportActions: PropTypes.object.isRequired,
	addMoneyActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	toggleFeaturesActions: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(CreditLineReportScreen);
