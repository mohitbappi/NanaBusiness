import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(12),
		},
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		innerContainer: {
			marginHorizontal: normalScale(16),
		},
		creditLineDueView: {
			marginTop: verticalScale(10),
		},
		monthView: {
			marginTop: verticalScale(12),
			alignItems: 'center',
			alignSelf: rtlFunctions.getAlignmentInFlex(isRTL),
		},
		monthButton: {
			borderColor: colors.lightGreen,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(4),
			paddingVertical: verticalScale(9),
			paddingHorizontal: verticalScale(12),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		placeholder: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
			marginRight: isRTL ? 0 : normalScale(12),
			marginLeft: isRTL ? normalScale(12) : 0,
		},
		iconArrowDown: {
			width: normalScale(10),
			height: verticalScale(6),
		},
		scrollViewStyle: {
			flex: 1,
			justifyContent: 'center',
		},
	});
};

export default createStyleSheet;
