import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	creditReports: [],
	count: 0,
	totalAmount: null,
	paidAmount: null,
	creditLimitRefreshDate: '',
	isDownload: false,
	downloadUrl: '',
	date: new Date(),
};

const getUpdatedData = (data, newData) => {
	let finalData = {};
	const initialData = data;
	const updatedData = newData;
	const updatedDataKeys = Object.keys(updatedData);
	updatedDataKeys.forEach(key => {
		if (key in initialData) {
			// Key is the date
			// If key is already exist in the data then it will append the data into the existing value of the key.
			initialData[key] = [...initialData[key], ...updatedData[key]];
			finalData = initialData;
		} else {
			// If key is not exist in the data then it will append key value in the object.
			finalData = { ...initialData, ...{ [`${key}`]: updatedData[key] } };
		}
	});
	return finalData; // Will return updated data after appending the new data.
};

const CreditLineReportScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_CREDIT_LINE_REPORT_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				creditReports: isOverwriteExistingList
					? getUpdatedData(state.creditReports, action.payload.credit_logs)
					: action.payload.credit_logs,
				count: action.payload.count,
				totalAmount: action.payload.total,
				dueAmount: action.payload.due_amount,
				paidAmount: action.payload.total_paid, // Paid amount of the credit line.
				creditLimitRefreshDate: action.payload.credit_refresh_date, // Date on which credit limit is last refreshed.
				isDownload: false,
			};
		}
		case ActionTypes.GET_CREDIT_LINE_REPORT_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isDownload: false,
			};
		case ActionTypes.GET_CREDIT_LINE_REPORT_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isDownload: false,
			};
		case ActionTypes.DOWNLOAD_CREDIT_LINE_REPORT_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isDownload: true,
			};
		case ActionTypes.DOWNLOAD_CREDIT_LINE_REPORT_SUCCESS:
			return {
				...state,
				success: true,
				loader: false,
				error: false,
				errorCode: '',
				isDownload: true,
				downloadUrl: action.payload.row.download_url,
			};
		case ActionTypes.DOWNLOAD_CREDIT_LINE_REPORT_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isDownload: true,
			};
		case ActionTypes.ON_CHANGE_CREDIT_LINE_REPORT_DATE:
			return {
				...state,
				date: action.payload,
			};
		default:
			return state;
	}
};

export default CreditLineReportScreenReducer;
