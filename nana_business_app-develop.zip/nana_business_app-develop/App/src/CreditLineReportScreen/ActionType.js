export const GET_CREDIT_LINE_REPORT_SUCCESS = 'get_credit_line_report_success';
export const GET_CREDIT_LINE_REPORT_FAILURE = 'get_credit_line_report_failure';
export const GET_CREDIT_LINE_REPORT_LOADER = 'get_credit_line_report_loader';

export const DOWNLOAD_CREDIT_LINE_REPORT_SUCCESS = 'download_credit_line_report_success';
export const DOWNLOAD_CREDIT_LINE_REPORT_FAILURE = 'download_credit_line_report_failure';
export const DOWNLOAD_CREDIT_LINE_REPORT_LOADER = 'download_credit_line_report_loader';

export const ON_CHANGE_CREDIT_LINE_REPORT_DATE = 'on_change_credit_line_report_date';
