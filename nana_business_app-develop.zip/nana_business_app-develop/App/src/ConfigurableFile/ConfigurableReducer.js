import * as ActionTypes from './ActionType';

const initialState = {
	remoteConfigData: {
		nextButtonOnLogin: false,
		signupButtonOnLogin: true,
		addToCart: true,
		placeOrder: true,
		wallet: { addMoney: true },
		creditLine: { applyForCreditLine: true, payNow: true },
		orders: { payNow: true, cancelOrder: true },
	},
};

const configurableReducer = (state = initialState, action = {}) => {
	if (action.type === ActionTypes.UPDATE_REMOTE_CONFIG_VALUES) {
		return {
			...state,
			remoteConfigData: action.payload,
		};
	}
	return state;
};

export default configurableReducer;
