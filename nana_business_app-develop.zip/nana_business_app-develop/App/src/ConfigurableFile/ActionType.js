export const UPDATE_REMOTE_CONFIG_VALUES = 'update_remote_config_values';

export default UPDATE_REMOTE_CONFIG_VALUES;
