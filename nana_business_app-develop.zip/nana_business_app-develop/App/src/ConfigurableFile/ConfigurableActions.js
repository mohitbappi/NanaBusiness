import * as ActionTypes from './ActionType';

export const onUpdateRemoteConfig = obj => {
	return {
		type: ActionTypes.UPDATE_REMOTE_CONFIG_VALUES,
		payload: obj,
	};
};

export default onUpdateRemoteConfig;
