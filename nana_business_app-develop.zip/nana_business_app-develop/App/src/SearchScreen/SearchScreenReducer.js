import * as ActionTypes from './ActionType';

const initialState = {
	brandListing: [],
	categoryListing: [],
	itemListing: [],
	success: false,
	errorCategories: false,
	errorBrands: false,
	errorItems: false,
	errorCodeCategories: '',
	errorCodeBrands: '',
	errorCodeItems: '',
	loader: false,
	brandCount: 0,
	categoryCount: 0,
	itemCount: 0,
};

const SearchScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_BRANDS_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				errorBrands: false,
				errorCodeBrands: '',
				loader: false,
				brandListing: isOverwriteExistingList
					? [...state.brandListing, action.payload.brands]
					: action.payload.brands,
				brandCount: action.payload.count,
			};
		}
		case ActionTypes.GET_CATEGORIES_SUCCESS: {
			const isOverwriteExistingCategoryList = action.extra;
			return {
				...state,
				success: true,
				errorCategories: false,
				errorCodeCategories: '',
				loader: false,
				categoryListing: isOverwriteExistingCategoryList
					? [...state.categoryListing, action.payload.categories]
					: action.payload.categories,
				categoryCount: action.payload.count,
			};
		}
		case ActionTypes.GET_ITEM_LISTING_SUCCESS: {
			const isOverwriteExistingItemList = action.extra;
			return {
				...state,
				success: true,
				errorItems: false,
				errorCodeItems: '',
				loader: false,
				itemListing: isOverwriteExistingItemList
					? [...state.itemListing, ...action.payload.items]
					: action.payload.items,
				itemCount: action.payload.count,
			};
		}
		case ActionTypes.GET_BRANDS_LOADER:
		case ActionTypes.GET_CATEGORIES_LOADER:
		case ActionTypes.GET_ITEM_LISTING_LOADER:
			return {
				...state,
				loader: true,
				errorCategories: false,
				errorBrands: false,
				errorItems: false,
				errorCodeCategories: '',
				errorCodeBrands: '',
				errorCodeItems: '',
				success: false,
			};
		case ActionTypes.GET_BRANDS_FAILURE:
			return {
				...state,
				errorBrands: true,
				errorCodeBrands: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.GET_CATEGORIES_FAILURE:
			return {
				...state,
				errorCategories: true,
				errorCodeCategories: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.GET_ITEM_LISTING_FAILURE:
			return {
				...state,
				errorItems: true,
				errorCodeItems: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default SearchScreenReducer;
