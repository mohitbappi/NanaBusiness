import { StyleSheet, Dimensions } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();
const categoryWidth = Dimensions.get('window').width / 3.7;
const width = (Dimensions.get('window').width - normalScale(32)) / 3;

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		activeView: {
			marginTop: verticalScale(12),
			marginRight: isRTL ? normalScale(10) : normalScale(13),
			alignItems: 'center',
			shadowColor: colors.darkBlue,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(15),
			},
			shadowRadius: moderateScale(14),
			shadowOpacity: 0.1,
			elevation: verticalScale(15),
			width: categoryWidth,
		},
		inactiveView: {
			marginTop: verticalScale(12),
			marginRight: isRTL ? normalScale(10) : normalScale(13),
			alignItems: 'center',
			width: categoryWidth,
		},
		activeImageView: {
			width: normalScale(60),
			height: normalScale(60),
			borderRadius: normalScale(30),
			borderColor: colors.darkBlue,
			borderWidth: moderateScale(1),
			backgroundColor: colors.white,
		},
		inactiveImageView: {
			width: normalScale(60),
			height: normalScale(60),
			backgroundColor: colors.lightGreen,
			borderRadius: normalScale(30),
			justifyContent: 'center',
			alignItems: 'center',
		},
		image: {
			width: normalScale(60),
			height: normalScale(60),
			borderRadius: normalScale(30),
		},
		defaultImage: {
			width: normalScale(17),
			height: verticalScale(17),
		},
		label: {
			fontSize: normalize(12),
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			marginTop: verticalScale(8),
			textAlign: 'center',
		},
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		selectView: {
			alignItems: 'center',
			width,
		},
		brandImage: {
			width: normalScale(60),
			height: normalScale(60),
			marginTop: verticalScale(12),
		},
		productContainer: {
			borderRadius: moderateScale(8),
			borderColor: colors.whitishGrey,
			borderWidth: normalScale(1.5),
			paddingHorizontal: normalScale(6),
			paddingVertical: verticalScale(12),
			alignItems: 'center',
			width: normalScale(136),
			marginEnd: normalScale(16),
			marginBottom: verticalScale(16),
			marginLeft: 0,
			marginRight: 0,
		},
		unitStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
			marginTop: verticalScale(8),
		},
		imageStyle: {
			width: normalScale(110),
			height: normalScale(110),
		},
		priceStyle: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(8),
			marginBottom: verticalScale(12),
			maxWidth: normalScale(150),
		},
		titleStyle: {
			marginTop: verticalScale(14),
			fontSize: normalize(10),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			color: colors.black,
			textAlign: 'center',
			height: normalScale(24),
		},
		brandNoImage: {
			justifyContent: 'center',
			marginTop: verticalScale(12),
			width: normalScale(60),
			height: normalScale(60),
			borderRadius: normalScale(30),
			backgroundColor: colors.lightGreen,
		},
		brandName: {
			fontSize: normalize(10),
			paddingHorizontal: normalScale(3),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			textAlign: 'center',
		},
		containerStyle: {
			marginHorizontal: normalScale(0),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		header: {
			marginTop: verticalScale(10),
			position: 'absolute',
			left: normalScale(16),
		},
		searchView: {
			marginRight: normalScale(16),
			marginLeft: normalScale(16),
		},
		buttonContainer: {
			borderRadius: moderateScale(8),
			borderColor: colors.whitishGrey,
			borderWidth: moderateScale(2),
			height: verticalScale(38),
			alignItems: 'center',
			marginTop: verticalScale(10),
			marginHorizontal: normalScale(0),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginBottom: verticalScale(0),
		},
		icon: {
			width: normalScale(14),
			height: verticalScale(14),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
			justifyContent: 'center',
		},
		textInput: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(12),
			color: colors.lightBlackGrey,
			paddingHorizontal: normalScale(10),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		searchContainer: {
			marginTop: verticalScale(10),
		},
		scrollView: {
			marginBottom: verticalScale(8),
			paddingHorizontal: normalScale(16),
		},
		errorView: {
			marginVertical: verticalScale(8),
		},
		columnView: {
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		pendingView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
		},
		categories: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
			marginTop: verticalScale(12),
		},
		viewInvoices: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(12),
			marginTop: verticalScale(16),
		},
		brandView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(20),
		},
		brands: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(12),
		},
		viewBrands: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(12),
		},
		listView: {
			marginTop: verticalScale(200),
		},
		listItemView: {
			flex: 1,
		},
		itemView: {
			marginTop: verticalScale(10),
			paddingHorizontal: normalScale(16),
		},
	});
};

export default createStyleSheet;
