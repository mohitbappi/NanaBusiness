import React, { Component } from 'react';
import { Text, View, TouchableOpacity, FlatList } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import IMAGES from '@Images/index';
import { keyConstants } from '@Constants/KeyConstants';
import { localeString } from '@Localization/index';
import navigations from '@routes/navigations';
import {
	fetchDataWithPagination,
	stretch,
	IMAGE_TYPE,
	numOfColumns,
	locatorConstants,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import Search from '@Search/Search';
import OptionPicker from '@OptionPicker/OptionPicker';
import ListEmpty from '@ListEmpty/ListEmpty';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import HomeItemComponent from '@HomeItemComponent/HomeItemComponent';
import getTestIdProps from '@Util/GetTestIdProps';
import * as SearchScreenActions from './SearchScreenAction';
import { shopConstants } from './ShopConstants';
import { createStyleSheet } from './SearchScreenStyle';

class SearchScreen extends Component {
	constructor(props) {
		super(props);
		this.brandLimit = shopConstants.limit;
		this.brandPage = fetchDataWithPagination.page;
		this.categoryLimit = shopConstants.limit;
		this.categoryPage = fetchDataWithPagination.page;
		this.itemLimit = fetchDataWithPagination.limit;
		this.itemPage = fetchDataWithPagination.page;
		this.state = {
			activeCategoryIndex: 0,
			searchText: '',
			isPickerVisible: false,
			activePickerIndex: 0,
			bottomLoader: false,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onCallAPIs();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { searchScreenInfo, pullToRefreshActions } = this.props;
		const { success } = searchScreenInfo;
		if (success && prevProps.searchScreenInfo.success !== success) {
			// if search screen api return success
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onCallAPIs = async () => {
		this.brandLimit = shopConstants.limit;
		this.brandPage = fetchDataWithPagination.page;
		this.categoryLimit = shopConstants.limit;
		this.categoryPage = fetchDataWithPagination.page;
		this.onLoadCategories(false);
		this.onLoadBrands(false);
	};

	onLoadCategories = isOverwriteExistingList => {
		const { searchText } = this.state;
		const { homeScreenInfo, userDetails, searchScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization;
		const queryParams = {};
		queryParams.limit = this.categoryLimit;
		queryParams.page = this.categoryPage;
		queryParams.branch_id = id;
		if (searchText) {
			queryParams.name = searchText;
		}
		searchScreenActions.onGetCategories(queryParams, isOverwriteExistingList);
	};

	onLoadBrands = isOverwriteExistingList => {
		const { searchText } = this.state;
		const { homeScreenInfo, userDetails, searchScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization;
		const queryParams = {};
		queryParams.limit = this.brandLimit;
		queryParams.page = this.brandPage;
		queryParams.branch_id = id;
		if (searchText) {
			queryParams.name = searchText;
		}
		searchScreenActions.onGetBrands(queryParams, isOverwriteExistingList);
	};

	onPressSearchOption = (index, item) => {
		const { navigation } = this.props;
		this.setState(
			{
				activeCategoryIndex: index,
			},
			() => {
				navigation.navigate(navigations.PRODUCT_LIST_NAVIAGTION, {
					category_id: item.id,
					activeCategoryIndex: index,
				});
			},
		);
	};

	onGetCategoryDefaultImageSearch = (index, activeCategoryIndex) => {
		if (index === activeCategoryIndex) {
			return IMAGES.iconDefaultCategoryActive;
		}
		return IMAGES.iconDefaultCategoryInactive;
	};

	onPressSearchBrand = item => {
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_LIST_NAVIAGTION, {
			brand_id: item.id,
		});
	};

	viewAllCategories = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.VIEW_ALL_CATEGORIES_NAVIGATION);
	};

	viewAllBrands = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ALL_BRANDS_NAVIGATION);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	handlePicker = value => {
		this.brandPage = fetchDataWithPagination.page;
		this.categoryPage = fetchDataWithPagination.page;
		this.itemPage = fetchDataWithPagination.page;
		this.setState({
			isPickerVisible: value,
		});
	};

	onSelectOption = index => {
		this.setState(
			{
				searchText: '',
				activePickerIndex: index,
			},
			() => this.handlePicker(false),
		);
	};

	onSearch = text => {
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onFetchData();
			},
		);
	};

	onFetchData = () => {
		const { activePickerIndex } = this.state;
		this.itemPage = fetchDataWithPagination.page;
		this.categoryPage = fetchDataWithPagination.page;
		this.brandPage = fetchDataWithPagination.page;
		switch (activePickerIndex) {
			case 0:
				return this.onLoadItems(false);
			case 1:
				return this.onLoadCategories(false);
			case 2:
				return this.onLoadBrands(false);
			default:
				return null;
		}
	};

	renderCategoryItem = ({ item, index }) => {
		// Render category list item component
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { activeCategoryIndex } = this.state;
		return (
			<TouchableOpacity
				onPress={() => this.onPressSearchOption(index, item)}
				activeOpacity={0.8}
				style={index === activeCategoryIndex ? styles.activeView : styles.inactiveView}>
				<View
					style={[
						styles.inactiveImageView,
						index === activeCategoryIndex &&
							!(item && item.images) &&
							styles.activeImageView,
					]}>
					<ImageLoadComponent
						imageType={IMAGE_TYPE.category}
						isUrl={item && item.images}
						resizeMode={stretch}
						source={
							item && item.images && item.images.medium
								? item.images.medium
								: this.onGetCategoryDefaultImageSearch(index, activeCategoryIndex)
						}
						style={
							item && item.images && item.images.medium
								? styles.image
								: styles.defaultImage
						}
					/>
				</View>
				<Text style={styles.label}>{isRTL ? item.name_ar : item.name}</Text>
			</TouchableOpacity>
		);
	};

	keyExtractor = (item, index) => index.toString();

	listFooterComponent = () => {
		const { languageInfo, searchScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { categoryListing, categoryCount } = searchScreenInfo;
		const endReached =
			categoryCount === categoryListing.length || categoryCount < categoryListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReached = () => {
		const { searchScreenInfo } = this.props;
		const { loader } = searchScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.categoryPage += 1;
			this.onLoadCategories(true);
		}
	};

	renderBrandItem = ({ item }) => {
		// Render brands list item component
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				onPress={() => this.onPressSearchBrand(item)}
				activeOpacity={0.8}
				style={styles.selectView}>
				{item && item.images && item.images.medium ? (
					<ImageLoadComponent
						imageType={IMAGE_TYPE.brand}
						isUrl={item && item.images}
						source={
							item && item.images && item.images.medium
								? item.images.medium
								: IMAGES.iconDefaultBrand
						}
						style={styles.brandImage}
					/>
				) : (
					<View style={styles.brandNoImage}>
						<Text numberOfLines={2} style={styles.brandName}>
							{isRTL ? item.name_ar : item.name}
						</Text>
					</View>
				)}
			</TouchableOpacity>
		);
	};

	listFooterBrandComponent = () => {
		const { languageInfo, searchScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { brandListing, brandCount } = searchScreenInfo;
		const endReached = brandCount === brandListing.length || brandCount < brandListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onBrandEndReached = () => {
		const { searchScreenInfo } = this.props;
		const { loader } = searchScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.brandPage += 1;
			this.onLoadBrands(true);
		}
	};

	renderProducts = ({ item, index }) => {
		// Render product list item component
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const {
			images,
			name_ar,
			name,
			price_with_vat,
			offer_price_with_vat,
			count_in_cart,
			items_per_packet,
			value_of_item,
			unit,
			unit_ar,
			price_per_item,
		} = item;
		return (
			<HomeItemComponent
				isRTL={isRTL}
				image={images && images.large}
				name={isRTL ? name_ar : name}
				valueOfItem={value_of_item}
				itemsPerPacket={items_per_packet}
				unit={isRTL ? unit_ar : unit}
				offerPrice={offer_price_with_vat}
				pricePerItem={price_per_item}
				isProductList
				price={price_with_vat}
				itemCount={count_in_cart || 0}
				onPress={() => this.navigateTo(item)}
				containerStyle={styles.productContainer}
				unitStyle={styles.unitStyle}
				imageStyle={styles.imageStyle}
				priceStyle={styles.priceStyle}
				titleStyle={styles.titleStyle}
				numberOfLines={2}
				noPerUnitPrice
				extraProps={getTestIdProps(`${locatorConstants.searchItem}${index + 1}`)}
			/>
		);
	};

	listFooterItemComponent = () => {
		const { languageInfo, searchScreenInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { itemListing, itemCount } = searchScreenInfo;
		const endReached = itemCount === itemListing.length || itemCount < itemListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	onEndReachedCategoryItem = () => {
		const { searchScreenInfo } = this.props;
		const { loader } = searchScreenInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.itemPage += 1;
			this.onLoadItems(true);
		}
	};

	onLoadItems = isOverwriteExistingList => {
		const { homeScreenInfo, userDetails, searchScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { searchText } = this.state;
		const { id } = branchDetail || userDetails.user.organization;
		const queryParams = {};
		queryParams.limit = this.itemLimit;
		queryParams.page = this.itemPage;
		queryParams.branch = id;
		if (searchText) {
			queryParams.name = searchText;
		}
		searchScreenActions.onGetItems(queryParams, isOverwriteExistingList);
	};

	navigateTo = item => {
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_DETAILS_NAVIGATION, { id: item.id });
	};

	onRefresh = () => {
		const { searchText, activePickerIndex } = this.state;
		if (searchText === '' && activePickerIndex === 0) {
			this.onCallAPIs();
		} else {
			this.onFetchData();
		}
	};

	render() {
		const { languageInfo, searchScreenInfo, refreshControlComponentInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { searchText, isPickerVisible, activePickerIndex, bottomLoader } = this.state;
		const {
			loader,
			brandCount,
			brandListing,
			categoryListing,
			categoryCount,
			itemListing,
			itemCount,
			errorCategories,
			errorBrands,
			errorItems,
			errorCodeCategories,
			errorCodeBrands,
			errorCodeItems,
		} = searchScreenInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<View style={styles.container}>
				{loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === '' && (
					<Loader size="large" />
				)}
				<OptionPicker
					isVisible={isPickerVisible}
					options={[
						{ name: localeString(keyConstants.ITEM_NAME) },
						{ name: localeString(keyConstants.CATEGORY) },
						{ name: localeString(keyConstants.BRAND) },
					]}
					title={localeString(keyConstants.SEARCH_BY)}
					isRTL={isRTL}
					onClose={() => this.handlePicker(false)}
					onSelectOption={this.onSelectOption}
					activeIndex={activePickerIndex}
				/>
				<View style={styles.searchView}>
					<View style={styles.searchContainer}>
						<Search
							hasIconFilter
							hasIconBack
							onPressBack={this.onGoBack}
							onPressFilter={() => this.handlePicker(true)}
							placeholder={localeString(
								keyConstants.SEARCH_BY_CATEGORY_BRAND_OR_ITEM,
							)}
							onChangeText={text => this.onSearch(text)}
							value={searchText}
							autoFocus
							extraProps={getTestIdProps(locatorConstants.searchBox)}
						/>
					</View>
				</View>
				{activePickerIndex === 0 && searchText !== '' ? (
					errorItems ? (
						<View style={styles.listView}>
							<ErrorComponent // Error component if product listing api fails.
								isRTL={isRTL}
								errorCode={errorCodeItems}
								onCallApi={() => this.onLoadItems(false)}
							/>
						</View>
					) : itemListing.length === 0 ? (
						<View style={styles.listItemView}>
							<ListEmpty text={localeString(keyConstants.NO_ITEMS_FOUND)} />
						</View>
					) : (
						<FlatList
							showsVerticalScrollIndicator={false}
							data={itemListing}
							renderItem={this.renderProducts}
							keyExtractor={this.keyExtractor}
							ListFooterComponent={
								itemListing.length !== 0 &&
								itemCount > fetchDataWithPagination.limit &&
								this.listFooterItemComponent()
							}
							onEndReached={() =>
								itemListing.length !== itemCount && this.onEndReachedCategoryItem()
							}
							onEndReachedThreshold={0.8}
							style={styles.itemView}
							numColumns={2}
						/>
					)
				) : (
					<ScrollViewComponent
						showsVerticalScrollIndicator={false}
						contentContainerStyle={styles.scrollView}
						onRefresh={this.onRefresh}
						componentType={constants.scrollView}>
						{(activePickerIndex === null ||
							activePickerIndex === 1 ||
							(activePickerIndex === 0 && searchText === '')) &&
						!loader ? (
							<>
								<View style={styles.pendingView}>
									<Text style={styles.categories}>
										{localeString(keyConstants.CATEGORIES)}
									</Text>
									{categoryListing.length !== 0 && (
										<TouchableOpacity
											activeOpacity={0.8}
											onPress={this.viewAllCategories}>
											<Text style={styles.viewInvoices}>
												{localeString(keyConstants.VIEW_ALL)}
											</Text>
										</TouchableOpacity>
									)}
								</View>
								{errorCategories ? (
									<View style={styles.errorView}>
										<ErrorComponent // Error component if categories api fails.
											isRTL={isRTL}
											errorCode={errorCodeCategories}
											onCallApi={() => this.onLoadCategories(false)}
											isSectionComponent
										/>
									</View>
								) : categoryListing.length !== 0 ? (
									<FlatList
										data={categoryListing}
										columnWrapperStyle={styles.columnView}
										renderItem={this.renderCategoryItem}
										keyExtractor={this.keyExtractor}
										numColumns={numOfColumns}
										showsVerticalScrollIndicator={false}
										ListFooterComponent={
											activePickerIndex === 1 &&
											searchText.length > 0 &&
											categoryListing.length !== 0 &&
											categoryCount > shopConstants.limit &&
											this.listFooterComponent()
										}
										onEndReached={() =>
											activePickerIndex === 1 &&
											searchText.length > 0 &&
											categoryListing.length !== categoryCount &&
											this.onEndReached()
										}
										onEndReachedThreshold={0.5}
									/>
								) : (
									<View style={styles.listView}>
										<ListEmpty
											text={localeString(keyConstants.NO_CATEGORIES_FOUND)}
										/>
									</View>
								)}
							</>
						) : null}
						{(activePickerIndex === null ||
							activePickerIndex === 2 ||
							(activePickerIndex === 0 && searchText === '')) &&
						!loader ? (
							<>
								<View style={styles.brandView}>
									<Text style={styles.brands}>
										{localeString(keyConstants.BRANDS)}
									</Text>
									{brandListing.length !== 0 && (
										<TouchableOpacity
											activeOpacity={0.8}
											onPress={this.viewAllBrands}>
											<Text style={styles.viewBrands}>
												{localeString(keyConstants.VIEW_ALL)}
											</Text>
										</TouchableOpacity>
									)}
								</View>
								{errorBrands ? (
									<View style={styles.errorView}>
										<ErrorComponent // Error component if brands api fails.
											isRTL={isRTL}
											errorCode={errorCodeBrands}
											onCallApi={() => this.onLoadBrands(false)}
											isSectionComponent
										/>
									</View>
								) : brandListing.length !== 0 ? (
									<FlatList
										data={brandListing}
										columnWrapperStyle={styles.columnView}
										renderItem={this.renderBrandItem}
										keyExtractor={this.keyExtractor}
										numColumns={numOfColumns}
										showsVerticalScrollIndicator={false}
										ListFooterComponent={
											activePickerIndex === 2 &&
											searchText.length > 0 &&
											brandListing.length !== 0 &&
											brandCount > shopConstants.limit &&
											this.listFooterBrandComponent()
										}
										onEndReached={() =>
											activePickerIndex === 2 &&
											searchText.length > 0 &&
											brandListing.length !== brandCount &&
											this.onBrandEndReached()
										}
										onEndReachedThreshold={0.5}
									/>
								) : (
									<View style={styles.listView}>
										<ListEmpty
											text={localeString(keyConstants.NO_BRANDS_FOUND)}
										/>
									</View>
								)}
							</>
						) : null}
					</ScrollViewComponent>
				)}
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		searchScreenInfo: state.SearchScreenReducer,
		homeScreenInfo: state.HomeScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		searchScreenActions: bindActionCreators({ ...SearchScreenActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

SearchScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	searchScreenInfo: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	searchScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SearchScreen);
