export const shopConstants = {
	modValue: 3,
	lengthValue: 4,
	limit: 8,
};

export default shopConstants;
