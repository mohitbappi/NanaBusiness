import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetCategoryService from '@CategoryListing/GetCategoryService';
import BrandListingService from '@BrandListing/BrandListingService';
import GetItemsService from '@SubCategoryListing/GetSubCategoryItemsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to call get categories listing api
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetCategories = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_CATEGORIES_SUCCESS,
		ActionTypes.GET_CATEGORIES_FAILURE,
		ActionTypes.GET_CATEGORIES_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getCategoryService = new GetCategoryService(dispatchedActions);
	addBasicInterceptors(getCategoryService);
	getCategoryService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCategoryService.makeRequest(props));
};

/**
 * Action to call get brands listing api
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetBrands = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_BRANDS_SUCCESS,
		ActionTypes.GET_BRANDS_FAILURE,
		ActionTypes.GET_BRANDS_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const brandListingService = new BrandListingService(dispatchedActions);
	addBasicInterceptors(brandListingService);
	brandListingService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(brandListingService.makeRequest(props));
};

/**
 * Action to call get product listing api
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 */
export const onGetItems = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ITEM_LISTING_SUCCESS,
		ActionTypes.GET_ITEM_LISTING_FAILURE,
		ActionTypes.GET_ITEM_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getItemsService = new GetItemsService(dispatchedActions);
	addBasicInterceptors(getItemsService);
	getItemsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getItemsService.makeRequest(props));
};
