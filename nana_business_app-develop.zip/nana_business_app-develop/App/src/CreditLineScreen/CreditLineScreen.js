import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import IMAGES from '@Images/index';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import CreditLineInformation from '@CreditLineInformation/CreditLineInformation';
import { clConstants } from './CreditLineScreenConstants';
import { createStyleSheet } from './CreditLineScreenStyle';

class CreditLineScreen extends Component {
	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	render() {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.CREDIT_LINE)}
						onPressBack={this.onGoBack}
						hasIconBack
					/>
				</View>
				<CreditLineInformation
					isRTL={isRTL}
					amount={clConstants.amount}
					dueAmount={clConstants.dueAmount}
					usedAmount={clConstants.usedAmount}
					totalCreditAmount={clConstants.totalCreditAmount}
					isCreditLine
				/>
				<Text style={styles.payNow}>{localeString(keyConstants.PAY_NOW)}</Text>
				<View style={styles.payNowView}>
					<TouchableOpacity style={styles.paymentOptionView} activeOpacity={0.8}>
						<ImageLoadComponent source={IMAGES.iconMada} style={styles.iconMada} />
					</TouchableOpacity>
					<TouchableOpacity style={styles.bankTransferView} activeOpacity={0.8}>
						<ImageLoadComponent
							source={IMAGES.iconBankTransfer}
							style={styles.iconBankTransfer}
						/>
						<Text style={styles.bankTransfer}>
							{localeString(keyConstants.BANK_TRANSFER)}
						</Text>
					</TouchableOpacity>
				</View>
				<View style={styles.payNowView}>
					<TouchableOpacity style={styles.paymentOptionView} activeOpacity={0.8}>
						<ImageLoadComponent
							source={IMAGES.iconApplePay}
							style={styles.iconApplePay}
						/>
					</TouchableOpacity>
				</View>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
	};
};

CreditLineScreen.propTypes = {
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, null)(CreditLineScreen);
