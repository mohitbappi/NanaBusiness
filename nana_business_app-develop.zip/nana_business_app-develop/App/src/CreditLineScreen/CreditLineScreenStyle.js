import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
			paddingHorizontal: normalScale(16),
		},
		headerContainer: {
			marginBottom: verticalScale(16),
		},
		payNow: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			marginTop: verticalScale(16),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		payNowView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(16),
		},
		paymentOptionView: {
			shadowColor: colors.darkBlue,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.09,
			elevation: verticalScale(2),
			height: verticalScale(66),
			width: normalScale(136),
			borderRadius: moderateScale(8),
			backgroundColor: colors.white,
			justifyContent: 'center',
			alignItems: 'center',
		},
		iconMada: {
			width: normalScale(90),
			height: verticalScale(31),
		},
		bankTransferView: {
			shadowColor: colors.darkBlue,
			shadowOffset: {
				width: normalScale(2),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.09,
			elevation: verticalScale(2),
			height: verticalScale(66),
			width: normalScale(136),
			borderRadius: moderateScale(8),
			backgroundColor: colors.white,
			alignItems: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			paddingHorizontal: verticalScale(15),
		},
		iconBankTransfer: {
			width: normalScale(24),
			height: verticalScale(24),
		},
		bankTransfer: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		iconApplePay: {
			width: normalScale(63),
			height: verticalScale(40),
		},
	});
};

export default createStyleSheet;
