export const clConstants = {
	amount: '35000',
	usedAmount: '65000',
	dueAmount: '5000',
	totalCreditAmount: '100000',
	nil: '0',
};

export default clConstants;
