import UserTokenUtil from '@AsyncStorage/UserTokenUtil';
import * as ActionTypes from '@RoleScreen/ActionType';
import * as SignInActionTypes from '@SignInScreen/ActionType';
import * as HomeScreenActionTypes from '@HomeScreen/ActionType';
import { removeExternalIdForOneSignal } from '@Util/NotificationUtils';
import AsyncStorageUtil from '@AsyncStorage/AsyncStorageUtil';
import * as ProfileScreenActions from '@ViewProfileScreen/ActionType';
import store from '@config/store';

const removeTokenFromStorage = async () => {
	const userTokenUtil = new UserTokenUtil();
	userTokenUtil.removeData();
	userTokenUtil.removeData('refreshTokenKey');
};

const removeUserDetail = async () => {
	await new AsyncStorageUtil('user_details').removeData();
};

const removeUserRole = async () => {
	await new AsyncStorageUtil('user_role').removeData();
};

const resetUserData = () => {
	return {
		type: SignInActionTypes.RESET_SIGNIN_STATE,
	};
};

const setSignInViaPassword = value => {
	return {
		type: SignInActionTypes.SET_SIGN_IN_VIA_PASSWORD,
		payload: value,
	};
};

const getRemoteValue = dispatch => {
	const configurableReducer = store.getState();
	const { remoteConfigData } = configurableReducer.ConfigurableReducer;
	dispatch(setSignInViaPassword(remoteConfigData.nextButtonOnLogin));
};

const resetHomeScreenData = () => {
	return {
		type: HomeScreenActionTypes.RESET_HOME_SCREEN_REDUCER,
	};
};

const resetToken = () => {
	return {
		type: SignInActionTypes.SET_TOKEN,
		payload: { token: null, role: '' },
	};
};

const resetProfileData = () => {
	return {
		type: ProfileScreenActions.RESET_VIEW_PROFILE_STATE,
	};
};

const setModalInvisible = () => {
	return {
		type: ActionTypes.SET_MODAL_VISIBILITY,
		payload: false,
	};
};

export default class LogoutHandler {
	logout(dispatch) {
		// Remove user-id from OneSignal Notification
		removeExternalIdForOneSignal();
		// Remove the token from the store.
		removeTokenFromStorage();
		// Remover user details.
		removeUserDetail();
		// Remover user role.
		removeUserRole();
		// Remove view profile data.
		dispatch(resetProfileData());
		// Reset the data.
		dispatch(resetUserData());
		// Reset home screen data.
		dispatch(resetHomeScreenData());
		// Reset the token and role.
		dispatch(resetToken());
		// Set modal invisible.
		dispatch(setModalInvisible());
		// Will get the value from remote config to enable/disable the next button on login.
		getRemoteValue(dispatch);
	}
}
