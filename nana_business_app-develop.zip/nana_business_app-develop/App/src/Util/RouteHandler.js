export const routeHandler = (route, key) => {
	if (route && route.state) {
		const { routes } = route.state;
		let tabBarVisible = false;
		routes.map(routesArray => {
			if (key.includes(routesArray.name)) {
				tabBarVisible = true;
			} else {
				tabBarVisible = false;
			}
		});
		return tabBarVisible;
	}
	return null;
};

export default routeHandler;
