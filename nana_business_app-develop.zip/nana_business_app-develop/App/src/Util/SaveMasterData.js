import AsyncStorage from '@react-native-async-storage/async-storage';
import {
	invoicePopup,
	otpVerificationToken,
	signUpCompleteToken,
	setWalkthroughValue,
	signUpRequestType,
} from '@Constants/Constants';
import AsyncStorageUtil from './AsyncStorage/AsyncStorageUtil';
import UserTokenUtil from './AsyncStorage/UserTokenUtil';

export const saveUserDetails = async response => {
	await new AsyncStorageUtil('user_details').saveData(JSON.stringify(response));
};

export const saveUserToken = token => {
	const userTokenUtil = new UserTokenUtil();
	userTokenUtil.saveUserToken(
		token,
		() => {},
		() => {},
	);
};

export const saveUserRefreshToken = token => {
	const userTokenUtil = new UserTokenUtil();
	userTokenUtil.saveUserRefreshToken(
		token,
		() => {},
		() => {},
	);
};

export const onEditUserDetails = async (name, profilePic, organization) => {
	AsyncStorage.getItem('user_details')
		.then(data => {
			let userData = data;
			userData = JSON.parse(userData);
			userData.user.name = name;
			if (userData.user.profile_images) {
				userData.user.profile_images = {
					...userData.user.profile_images,
					medium: profilePic,
				};
			}
			if (userData.user && userData.user.organization) {
				userData.user.organization = {
					...userData.user.organization,
					business_type: organization ? organization.business_type : '',
				};
			}
			AsyncStorage.setItem('user_details', JSON.stringify(userData));
		})
		.done();
};

export const saveUserRole = async role => {
	await new AsyncStorageUtil('user_role').saveData(role);
};

export const saveInvoicePopupValue = async value => {
	await new AsyncStorageUtil(invoicePopup).saveData(value);
};

export const saveOtpVerificationToken = async token => {
	await new AsyncStorageUtil(otpVerificationToken).saveData(token);
};

export const saveSignUpCompleteToken = async token => {
	await new AsyncStorageUtil(signUpCompleteToken).saveData(token);
};

export const onAddSignUpRequestType = async type => {
	// Adding signup request type as we are not hitting api on confirmation page.
	await new AsyncStorageUtil(signUpRequestType).saveData(type);
};

export const setWalkthrough = async value => {
	await new AsyncStorageUtil(setWalkthroughValue).saveData(value);
};

export const editUserRole = async role => {
	let data = await AsyncStorage.getItem('user_details');
	data = JSON.parse(data);
	data.user.role = role;
	await AsyncStorage.setItem('user_details', JSON.stringify(data));
};

export const onEditCustomerOrgAndUser = async (orgData, userId, userName) => {
	// Will set the customer organization and user in async storage.
	let data = await AsyncStorage.getItem('user_details');
	data = JSON.parse(data);
	data.user.default_user_id = userId;
	data.user.default_user_name = userName;
	data.user.organization = orgData;
	await AsyncStorage.setItem('user_details', JSON.stringify(data));
};
