export const getScrollingIndex = scrollIndex => {
	// Will return number of entries using index.
	let index = scrollIndex || 0;
	if (index % 10 !== 0 || index === 0) {
		index = parseInt(index / 10, 10) + 1;
	} else {
		index = parseInt(index / 10, 10);
	}
	return index * 10;
};

export const getPage = limit => {
	// Will return the page number using the current limit.
	return limit > 10 ? parseInt(limit / 10, 10) : 1;
};
