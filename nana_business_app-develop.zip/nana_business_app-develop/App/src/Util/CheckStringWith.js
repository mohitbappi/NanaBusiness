export const checkStringWith = (text, regExEn, regExAr, isRTL) => {
	return isRTL ? regExAr.test(text) : regExEn.test(text);
};

export default checkStringWith;
