import { Alert } from 'react-native';
import OneSignal from 'react-native-onesignal';

export const setAppId = appId => {
	OneSignal.setAppId(appId);
};

export const setExternalIdForOneSignal = externalUserId => {
	// You will supply the external user id to the OneSignal SDK
	// Setting External User Id with Callback Available in SDK Version 3.7.0+
	OneSignal.setExternalUserId(externalUserId.toString());
};

export const removeExternalIdForOneSignal = () => {
	// Remove External User Id with Callback Available in SDK Version 3.7.0+
	OneSignal.removeExternalUserId();
};

export const foregroundNotificationHandler = () => {
	// will be used for foreground notification handling
	OneSignal.setNotificationWillShowInForegroundHandler(notifReceivedEvent => {
		const notif = notifReceivedEvent.getNotification();

		const button1 = {
			text: 'Cancel',
			onPress: () => {
				notifReceivedEvent.complete();
			},
			style: 'cancel',
		};

		const button2 = {
			text: 'Complete',
			onPress: () => {
				notifReceivedEvent.complete(notif);
			},
		};

		Alert.alert('Complete notification?', 'Test', [button1, button2], { cancelable: true });
	});
};

export const notificationOpenedHandler = () => {
	OneSignal.setNotificationOpenedHandler();
};

export const permissionObserver = () => {
	OneSignal.addPermissionObserver();
};

export const checkSubscription = () => {
	OneSignal.addSubscriptionObserver();
};
