import { decimalValue } from '@Constants/Constants';
import { currencyFormatter } from './CurrencyFormatter';

export const getValueInDecimal = value => {
	return Number(Number(parseFloat(value)).toFixed(decimalValue));
};

export const convertAmount = amount => {
	return currencyFormatter(getValueInDecimal(amount / 1000));
};
