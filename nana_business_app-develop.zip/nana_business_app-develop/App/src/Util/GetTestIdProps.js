const getTestIdProps = id => {
	return { accessible: true, accessibilityLabel: id, testID: id };
};

export default getTestIdProps;
