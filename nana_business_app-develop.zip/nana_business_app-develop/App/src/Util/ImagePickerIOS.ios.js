// import libraries
import { launchImageLibrary } from 'react-native-image-picker';

export const imagePickerIOS = () => {
	const options = {
		mediaType: 'photo',
	};
	return new Promise((resolve, reject) => {
		launchImageLibrary(options, res => {
			if (res.didCancel) {
				reject(new Error({ response: {}, success: false }));
			} else if (res.error) {
				reject(new Error({ response: {}, success: false }));
			} else {
				resolve({ response: res.assets[0], success: true });
			}
		});
	});
};

export default imagePickerIOS;
