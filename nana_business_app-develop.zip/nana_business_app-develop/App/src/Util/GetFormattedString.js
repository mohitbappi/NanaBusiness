export const getCapitalizedFirstChar = stringData => {
	if (typeof stringData !== 'string') {
		return '';
	}
	return stringData.charAt(0).toUpperCase() + stringData.slice(1);
};

export const removeSpaces = data => {
	// this function replaces " "  with "-"
	// and "." with ""
	const replaceBy = { ' ': '-', '.': '' };
	return data ? data.replace(/[ .]/g, currentCharacter => replaceBy[currentCharacter]) : '';
};
