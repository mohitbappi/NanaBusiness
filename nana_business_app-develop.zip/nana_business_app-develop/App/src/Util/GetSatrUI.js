import React from 'react';
import { StyleSheet, FlatList } from 'react-native';
import { normalScale, verticalScale } from '@device/normalize';
import { starRating } from '@Constants/Constants';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import IMAGES from '@Images/index';

const createStyleSheet = () => {
	return StyleSheet.create({
		star: {
			width: normalScale(9),
			height: verticalScale(9),
			resizeMode: 'contain',
			marginRight: normalScale(1),
		},
	});
};

export const getStarUI = rating => {
	const styles = createStyleSheet();
	let modifiedRating = 0;
	let isContainHalfRating = false;
	if (rating > 0 && rating < 1) {
		isContainHalfRating = true;
	} else if (rating > 1 && rating < 2) {
		modifiedRating = 1;
		isContainHalfRating = true;
	} else if (rating > 2 && rating < 3) {
		modifiedRating = 2;
		isContainHalfRating = true;
	} else if (rating > 3 && rating < 4) {
		modifiedRating = 3;
		isContainHalfRating = true;
	} else if (rating > 4 && rating < 5) {
		modifiedRating = 4;
		isContainHalfRating = true;
	} else {
		modifiedRating = rating;
	}
	const tempArray = Array(modifiedRating).fill(true);
	const finalArray = Array(
		starRating - (isContainHalfRating ? modifiedRating + 1 : modifiedRating),
	).fill(false);
	return (
		<>
			<FlatList
				data={tempArray}
				showsVerticalScrollIndicator={false}
				horizontal
				renderItem={({ item }) => {
					return (
						<ImageLoadComponent
							source={item ? IMAGES.iconStarFilled : IMAGES.iconStar}
							style={styles.star}
						/>
					);
				}}
				keyExtractor={this.keyExtractor}
			/>
			{isContainHalfRating && (
				<ImageLoadComponent source={IMAGES.iconStarHalfFilled} style={styles.star} />
			)}
			<FlatList
				data={finalArray}
				showsVerticalScrollIndicator={false}
				horizontal
				renderItem={({ item }) => {
					return (
						<ImageLoadComponent
							source={item ? IMAGES.iconStarFilled : IMAGES.iconStar}
							style={styles.star}
						/>
					);
				}}
				keyExtractor={this.keyExtractor}
			/>
		</>
	);
};

export default getStarUI;
