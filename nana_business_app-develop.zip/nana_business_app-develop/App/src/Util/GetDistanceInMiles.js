import { miles } from '@Constants/Constants';

export const getDistanceInMiles = distance => {
	return Number(parseFloat(parseInt(distance, 10) * miles)).toFixed(2);
};

export default getDistanceInMiles;
