import AsyncStorage from '@react-native-async-storage/async-storage';

class AsyncStorageUtil {
	constructor(dataKey) {
		this.key = dataKey;
	}

	async saveData(value, storageKey = this.key) {
		try {
			return await AsyncStorage.setItem(storageKey, value);
		} catch (e) {
			return null;
		}
	}

	async retreiveData(storageKey = this.key) {
		try {
			return await AsyncStorage.getItem(storageKey);
		} catch (e) {
			return null;
		}
	}

	async removeData(storageKey = this.key) {
		try {
			return await AsyncStorage.removeItem(storageKey);
		} catch (e) {
			return null;
		}
	}
}

export default AsyncStorageUtil;
