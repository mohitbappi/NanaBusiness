import moment from 'moment';

export const getFormattedTime = date => {
	return moment(date).format('h:mm A'); // Will return time in UTC format like 11:59 PM
};

export default getFormattedTime;
