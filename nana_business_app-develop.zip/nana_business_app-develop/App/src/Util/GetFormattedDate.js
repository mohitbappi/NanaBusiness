import moment from 'moment';
import {
	dateFormat,
	hyphenDateFormat,
	dateFormatWithTime,
	day,
	dateFormatWithoutYear,
	dateFormatWithoutHyphen,
	dateFormatWithHyphen,
} from '@Constants/Constants';

export const getFormattedDate = date => {
	return moment(date).format(dateFormat);
};

export const getFormattedDateWithoutHyphen = date => {
	return moment(date).format(dateFormatWithoutHyphen);
};

export const getFormattedDateWithHyphen = date => {
	return moment(date).format(dateFormatWithHyphen);
};

export const getFormattedDateWithoutYear = date => {
	return moment(date).format(dateFormatWithoutYear);
};

export const getFormattedDateWithTime = date => {
	return moment(date).format(dateFormatWithTime);
};

export const onAddDaysInDate = (date, days) => {
	return moment(date).add(days, day).format(hyphenDateFormat);
};

export const onConvertDateFormat = date => {
	return moment(date).format(hyphenDateFormat);
};

// return formatted 'date' with passed 'format'
export const onConvertDateWithFormat = (date, format) => {
	return moment(date).format(format);
};
