import { Alert } from 'react-native';
import { localeString } from '@assets/Localization';
import LogoutHandler from '@Logout/LogoutHandler';
import store from '@config/store';

const logoutAlert = message => {
	setTimeout(() => {
		Alert.alert(
			'',
			message,
			[
				{
					text: localeString('OK'),
					onPress: () => {
						new LogoutHandler().logout(store.dispatch);
					},
				},
			],
			{ cancelable: false },
		);
	}, 10);
};

export default logoutAlert;
