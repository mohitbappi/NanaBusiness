import SystemSetting from 'react-native-system-setting';
import { Component } from 'react';
import PropTypes from 'prop-types';
import { Alert } from 'react-native';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

class EnableLocation extends Component {
	componentDidMount() {
		this.checkLocation();
	}

	checkLocation = () => {
		const { onCancel } = this.props;
		SystemSetting.isLocationEnabled().then(enable => {
			if (!enable) {
				Alert.alert(
					'',
					localeString(keyConstants.ENABLE_LOCATION),
					[
						{
							text: localeString(keyConstants.NO),
							onPress: onCancel,
						},
						{
							text: localeString(keyConstants.YES),
							onPress: () => {
								SystemSetting.switchLocation(() => {
									if (!enable) {
										return this.checkLocation();
									}
									return null;
								});
							},
						},
					],
					{ cancelable: false },
				);
			}
		});
	};

	render() {
		return null;
	}
}

EnableLocation.propTypes = {
	onCancel: PropTypes.func.isRequired,
};

export default EnableLocation;
