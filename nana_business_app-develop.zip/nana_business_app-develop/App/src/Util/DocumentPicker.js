// import libraries
import DocumentPicker from 'react-native-document-picker';
import { Platform } from 'react-native';

// import components
import { imagePickerIOS } from './ImagePickerIOS.ios';

export const singleDocumentPicker = async () => {
	try {
		const results = await DocumentPicker.pick({
			type: [DocumentPicker.types.images],
		});
		return { response: results, success: true };
	} catch (err) {
		if (DocumentPicker.isCancel(err)) {
			return { response: err, success: false };
		}
		throw err;
	}
};

export const imagePicker = async () => {
	let results = {};
	let fileName = '';
	if (Platform.OS === 'android') {
		results = await singleDocumentPicker();
		fileName = results.response.name;
	} else {
		results = await imagePickerIOS();
		fileName = results.response.fileName;
	}
	results.fileName = fileName;
	return results;
};
