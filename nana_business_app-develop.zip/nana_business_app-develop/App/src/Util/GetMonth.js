import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

export const getMonth = month => {
	const monthNames = [
		localeString(keyConstants.JANUARY),
		localeString(keyConstants.FEBRUARY),
		localeString(keyConstants.MARCH),
		localeString(keyConstants.APRIL),
		localeString(keyConstants.MAY),
		localeString(keyConstants.JUNE),
		localeString(keyConstants.JULY),
		localeString(keyConstants.AUGUST),
		localeString(keyConstants.SEPTEMBER),
		localeString(keyConstants.OCTOBER),
		localeString(keyConstants.NOVEMBER),
		localeString(keyConstants.DECEMBER),
	];
	return monthNames[month];
};

export default getMonth;
