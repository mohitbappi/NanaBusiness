import CurrencyFormatter from 'currency-formatter';
import { SAR } from '@Constants/Constants';

export const currencyFormatter = amount => {
	return CurrencyFormatter.format(amount, { code: SAR, symbol: '' });
};

export default currencyFormatter;
