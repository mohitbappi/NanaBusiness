import { shipmentStatus } from '@Constants/Constants';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

export const getShipmentStatus = status => {
	switch (status) {
		case shipmentStatus.inProgress:
			return localeString(keyConstants.IN_PROGRESS);
		case shipmentStatus.assigned:
			return localeString(keyConstants.ASSIGNED);
		case shipmentStatus.started:
			return localeString(keyConstants.STARTED);
		case shipmentStatus.successful:
			return localeString(keyConstants.SUCCESSFUL);
		case shipmentStatus.failed:
			return localeString(keyConstants.FAILED);
		case shipmentStatus.accepted:
			return localeString(keyConstants.ACCEPTED);
		case shipmentStatus.decline:
			return localeString(keyConstants.DECLINE);
		case shipmentStatus.cancel:
			return localeString(keyConstants.CANCEL);
		case shipmentStatus.deleted:
			return localeString(keyConstants.DELETED);
		default:
			return localeString(keyConstants.PLACED);
	}
};

export default getShipmentStatus;
