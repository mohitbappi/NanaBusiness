import { apiVersionConstants } from '@Constants/Constants';

export const checkNetworkError = error => {
	// Will check for network error
	const errorCode = [
		apiVersionConstants.apiVersionNotSupported,
		apiVersionConstants.apiEndpointDeleted,
		apiVersionConstants.apiEndpointNotFound,
	];
	if (errorCode.includes(error.error)) {
		return false;
	}
	return true; // in case of default
};

export default checkNetworkError;
