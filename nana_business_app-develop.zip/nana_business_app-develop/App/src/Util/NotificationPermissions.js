import { checkNotifications, requestNotifications, RESULTS } from 'react-native-permissions';

// this function checks for notifications permissions(for IOS only as android do not need notification permissions)
// if permission is not granted for any of ['alert', 'badge', 'sound', 'criticalAlert'], then it asks for permissions in the OS popup
export const getNotificationPermission = () => {
	checkNotifications(['alert', 'badge', 'sound', 'criticalAlert']).then(({ status }) => {
		if (status !== RESULTS.GRANTED) {
			requestNotifications(['alert', 'badge', 'sound', 'criticalAlert']).then(() => {
				// status can be: RESULTS.UNAVAILABLE, RESULTS.DENIED, RESULTS.GRANTED, RESULTS.LIMITED, RESULTS.BLOCKED
			});
		}
	});
};

export default getNotificationPermission;
