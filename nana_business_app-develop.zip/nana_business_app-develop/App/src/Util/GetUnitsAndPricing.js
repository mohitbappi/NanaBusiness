import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { xString } from '@Constants/Constants';
import { getValueInDecimal } from './GetValueInDecimal';

export const getUnitsAndPricing = (
	itemsPerPacket,
	valueOfItem,
	unit,
	pricePerItem,
	noPerUnitPrice = false,
) => {
	let unitsAndPricing = '';
	if (itemsPerPacket && valueOfItem && unit) {
		unitsAndPricing = `${itemsPerPacket} ${xString} ${getValueInDecimal(valueOfItem)} ${unit}`;
		unitsAndPricing =
			pricePerItem && !noPerUnitPrice
				? unitsAndPricing.concat(
						` | ${getValueInDecimal(pricePerItem)} ${localeString(
							keyConstants.SAR,
						)}/${localeString(keyConstants.UNIT)}`,
				  )
				: unitsAndPricing;
	}
	return unitsAndPricing;
};

export default getUnitsAndPricing;
