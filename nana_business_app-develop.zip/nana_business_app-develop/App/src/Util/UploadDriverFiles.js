import Config from 'react-native-config';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { APIConstants } from '@Constants/Constants';

export const uploadDriverFiles = async (uri, type, name, invoiceId) => {
	const formData = new FormData();
	formData.append('image_url', {
		uri,
		type,
		name,
	});
	const url = Config.SERVER_URL;
	const token = await AsyncStorage.getItem('user');
	return axios({
		method: 'POST',
		url: `${url}${APIConstants.driver}/${APIConstants.invoices}/${APIConstants.uploadInvoice}/${invoiceId}`,
		data: formData,
		headers: {
			'Content-Type': 'multipart/form-data',
			Authorization: `Bearer ${token}`,
		},
	})
		.then(result => {
			return result.data.success;
		})
		.catch(() => {
			// Error
		});
};

export default uploadDriverFiles;
