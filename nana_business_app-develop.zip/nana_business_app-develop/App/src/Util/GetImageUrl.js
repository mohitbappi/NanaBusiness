export const getImageUrl = imageId => {
	return imageId || null;
};
export default getImageUrl;
