import remoteConfig from '@react-native-firebase/remote-config';

const getValue = value => {
	if (value.getSource() === 'remote') {
		return JSON.parse(value._value);
	}
	return null;
};

class RemoteConfig {
	// Will get the value from remote config to enable/disable the app features.

	nextButtonOnLogin = () => {
		const value = remoteConfig().getValue('nextButtonOnLogin');
		return getValue(value);
	};

	signupButtonOnLogin = () => {
		const value = remoteConfig().getValue('signupButtonOnLogin');
		return getValue(value);
	};

	addToCart = () => {
		const value = remoteConfig().getValue('addToCart');
		return getValue(value);
	};

	placeOrder = () => {
		const value = remoteConfig().getValue('placeOrder');
		return getValue(value);
	};

	wallet = () => {
		const value = remoteConfig().getValue('wallet');
		return getValue(value);
	};

	creditLine = () => {
		const value = remoteConfig().getValue('creditLine');
		return getValue(value);
	};

	orders = () => {
		const value = remoteConfig().getValue('orders');
		return getValue(value);
	};
}

export default RemoteConfig;
