import fonts from '@assets/fonts';
import { fontsConstants } from '@Constants/Constants';
import { normalScale } from '@device/normalize';

class RTLFunctions {
	getFont = (isRTL, type) => {
		switch (type) {
			case fontsConstants.light:
				return isRTL ? fonts.TajawalLight : fonts.LatoLight;
			case fontsConstants.bold:
				return isRTL ? fonts.TajawalBold : fonts.LatoBold;
			case fontsConstants.medium:
				return isRTL ? fonts.TajawalMedium : fonts.LatoMedium;
			case fontsConstants.regular:
				return isRTL ? fonts.TajawalRegular : fonts.LatoRegular;
			case fontsConstants.italic:
				return isRTL ? fonts.TajawalRegular : fonts.LatoItalic;
			case fontsConstants.boldItalic:
				return isRTL ? fonts.TajawalBold : fonts.LatoBoldItalic;
			default:
				return null;
		}
	};

	getFlexDirection = isRTL => {
		return isRTL ? 'row-reverse' : 'row';
	};

	getTextAlign = isRTL => {
		return isRTL ? 'right' : 'left';
	};

	getTextAlignOpposite = isRTL => {
		return isRTL ? 'left' : 'right';
	};

	getAlignmentInFlex = isRTL => {
		return isRTL ? 'flex-start' : 'flex-end';
	};

	getAlignmentInFlexOpposite = isRTL => {
		return isRTL ? 'flex-end' : 'flex-start';
	};

	getTransform = isRTL => {
		return isRTL ? [{ rotate: '180deg' }] : [{ rotate: '360deg' }];
	};

	getTransformOpposite = isRTL => {
		return isRTL ? [{ rotate: '360deg' }] : [{ rotate: '180deg' }];
	};

	getMarginLeft = (isRTL, margin) => {
		return isRTL ? 0 : normalScale(margin);
	};

	getMarginLeftRTL = (isRTL, margin) => {
		return isRTL ? normalScale(margin) : 0;
	};

	getMarginRight = (isRTL, margin) => {
		return isRTL ? normalScale(margin) : 0;
	};

	getMarginRightRTL = (isRTL, margin) => {
		return isRTL ? 0 : normalScale(margin);
	};
}

export default RTLFunctions;
