import { setExternalIdForOneSignal } from './NotificationUtils';
import {
	saveUserDetails,
	saveUserToken,
	saveUserRefreshToken,
	saveUserRole,
	saveInvoicePopupValue,
} from './SaveMasterData';

export const saveMasterLoginData = data => {
	const { id } = data.user;
	setExternalIdForOneSignal(id); // Add user to one signal to send push notifications.
	saveUserDetails(data); // Save user data into asyn storage.
	saveUserToken(data.access_token); // Save access token into asyn storage.
	saveUserRefreshToken(data.refresh_token); // Save refresh token into asyn storage.
	saveUserRole(data.user.role); // Save user role into asyn storage.
	saveInvoicePopupValue('true'); // Set invoice popup value to true which will show on home screen.
};

export default saveMasterLoginData;
