import RNFetchBlob from 'rn-fetch-blob';
import Permissions from 'react-native-permissions';
import { Platform } from 'react-native';

export const getMimeType = type => {
	switch (type) {
		// .pdf format file
		case '.pdf':
			return 'application/pdf';
		// .png format file
		case '.png':
			return 'image/png';
		// .jpg format file
		case '.jpg':
			return 'image/jpeg';
		// .jpeg format file
		case '.jpeg':
			return 'image/jpeg';
		// All other file formats
		default:
			return '*/*';
	}
};

export const extention = filename => {
	return /[.]/.exec(filename) ? /[^.]+$/.exec(filename) : undefined;
};

const downloadFileCode = (url, filename, inProgressCallback, successCallback, errorCallBack) => {
	try {
		inProgressCallback();
		let ext = extention(url);
		ext = `.${ext[0]}`;
		const { config, fs } = RNFetchBlob;
		const filePath =
			Platform.OS === 'ios' ? `${fs.dirs.DocumentDir}` : `${fs.dirs.DownloadDir}`;
		const configfb = {
			fileCache: true,
			useDownloadManager: true,
			notification: true,
			mediaScannable: true,
			title: filename,
			path: `${filePath}/${filename}${ext}`,
		};
		const configOptions = Platform.select({
			ios: {
				fileCache: configfb.fileCache,
				title: configfb.title,
				path: configfb.path,
			},
			android: {
				addAndroidDownloads: {
					fileCache: configfb.fileCache,
					path: `${filePath}/${filename}${ext}`,
					title: filename,
					useDownloadManager: true,
					notification: true,
					mime: getMimeType(ext),
				},
			},
		});
		config(configOptions)
			.fetch('GET', url)
			.then(res => {
				if (Platform.OS === 'ios') {
					RNFetchBlob.fs.writeFile(configfb.path, res.data, 'base64');
					RNFetchBlob.ios.previewDocument(configfb.path);
				}
				successCallback();
			})
			.catch(() => {
				errorCallBack();
			});
	} catch (error) {
		errorCallBack();
	}
};

const askForStoragePermission = (
	url,
	filename,
	inProgressCallback,
	successCallback,
	errorCallBack,
) => {
	if (Platform.OS === 'ios') {
		Permissions.check('ios.permission.PHOTO_LIBRARY').then(response => {
			if (response === 'granted') {
				downloadFileCode(url, filename, inProgressCallback, successCallback, errorCallBack);
			} else if (response === 'unavailable' || response === 'denied') {
				Permissions.request('ios.permission.PHOTO_LIBRARY').then(res => {
					if (res === 'granted') {
						downloadFileCode(
							url,
							filename,
							inProgressCallback,
							successCallback,
							errorCallBack,
						);
					}
				});
			}
		});
	} else {
		Permissions.check('android.permission.WRITE_EXTERNAL_STORAGE').then(response => {
			if (response === 'granted') {
				downloadFileCode(url, filename, inProgressCallback, successCallback, errorCallBack);
			} else if (response === 'unavailable' || response === 'denied') {
				Permissions.request('android.permission.WRITE_EXTERNAL_STORAGE').then(res => {
					if (res === 'granted') {
						downloadFileCode(
							url,
							filename,
							inProgressCallback,
							successCallback,
							errorCallBack,
						);
					}
				});
			}
		});
	}
};

export const downloadFile = (
	url,
	filename,
	inProgressCallback = () => {},
	successCallback = () => {},
	errorCallBack = () => {},
) => {
	askForStoragePermission(url, filename, inProgressCallback, successCallback, errorCallBack);
};
