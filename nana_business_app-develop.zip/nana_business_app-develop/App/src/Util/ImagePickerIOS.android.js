export const imagePickerIOS = () => {
	return null;
};
