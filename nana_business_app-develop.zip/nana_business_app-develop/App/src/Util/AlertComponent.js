import { Alert } from 'react-native';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';

const AlertComponent = props => {
	const {
		message,
		onPressYes = () => {},
		onPressNo = () => {},
		title,
		cancelable = false,
		yesText = localeString(keyConstants.YES),
		noText = localeString(keyConstants.NO),
		isOneButton,
	} = props;

	Alert.alert(
		title,
		message,
		isOneButton
			? [
					{
						text: yesText,
						onPress: () => onPressYes(),
					},
			  ]
			: [
					{
						text: noText,
						onPress: () => onPressNo(),
					},
					{
						text: yesText,
						onPress: () => onPressYes(),
					},
			  ],

		{ cancelable },
	);
};

export default AlertComponent;
