import Config from 'react-native-config';
import ReactAppboy from 'react-native-appboy-sdk';

const logCustomEventOnBraze = async (eventName, params) => {
	const url = Config.SERVER_URL;
	if (url.includes('app.nana.business')) {
		ReactAppboy.logCustomEvent(eventName, params);
	}
};

export default logCustomEventOnBraze;
