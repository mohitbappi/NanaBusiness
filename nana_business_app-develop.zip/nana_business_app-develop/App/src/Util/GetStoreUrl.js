// import libraries
import { Platform } from 'react-native';

// import constants
import { playStoreUrl, appStoreUrl } from '@Constants/Constants';

export const getStoreUrl = () => {
	// Will get store url according to the platform.
	return Platform.OS === 'android' ? playStoreUrl : appStoreUrl;
};

export default getStoreUrl;
