export const getNoOfDays = (presentDate, dueDate) => {
	return Math.round(
		(new Date(dueDate).getTime() - new Date(presentDate).getTime()) / (1000 * 3600 * 24),
	);
};

export default getNoOfDays;
