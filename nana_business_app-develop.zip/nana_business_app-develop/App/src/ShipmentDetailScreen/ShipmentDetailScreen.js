import React, { Component } from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { showLocation } from 'react-native-map-link';
import PropTypes from 'prop-types';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import {
	toastShowTime,
	shipmentStatus,
	dash,
	googleMaps,
	appleMaps,
	purchaseReturnInvoiceStatus,
	accountManager,
	salesExecutive,
} from '@Constants/Constants';
import Loader from '@Loader/Loader';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import IMAGES from '@Images/index';
import { getFormattedDateWithoutHyphen } from '@Util/GetFormattedDate';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import SmallMapComponent from '@Components/SmallMapComponent';
import { verticalScale, normalScale } from '@device/normalize';
import Input from '@Input/Input';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import driverNavigations from '@routes/driverNavigations';
import * as SalesInvoiceActions from '@SalesInvoiceScreen/SalesInvoiceScreenAction';
import Spinner from '@Spinner/Spinner';
import { downloadFile } from '@Util/DownloadFile';
import { removeSpaces } from '@Util/GetFormattedString';
import ToastComponent from '@ToastComponent/ToastComponent';
import DownloadSalesInvoice from '@Components/DownloadSalesInvoice';
import { getShipmentStatus } from '@Util/GetShipmentStatus';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ProductCardComponent from '@Products/ProductCardComponent';
import OptionPicker from '@OptionPicker/OptionPicker';
import { getFormattedTime } from '@Util/GetFormattedTime';
import AlertComponent from '@Util/AlertComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import * as ShipmentDetailActions from './ShipmentDetailScreenAction';
import { createStyleSheet } from './ShipmentDetailScreenStyle';

class ShipmentDetailScreen extends Component {
	constructor(props) {
		super(props);
		const { userDetails } = props;
		this.role = (userDetails && userDetails.user && userDetails.user.role) || {};
		this.state = {
			isApiError: false,
			toastMessage: '',
			isDropdownVisible: false,
			dropdownOptions: [
				{ name: localeString(keyConstants.HAS_RETURN_ITEMS) },
				{ name: localeString(keyConstants.DOES_NOT_HAS_RETURN_ITEMS) },
			],
			activeOptionIndex: null,
		};
	}

	componentDidMount() {
		const { pullToRefreshActions } = this.props;
		this.getShipmentDetail();
		pullToRefreshActions.onHandlePullToRefresh(false);
	}

	componentDidUpdate(prevProps) {
		const { salesInvoiceInfo, route, shipmentDetailInfo, pullToRefreshActions } = this.props;
		const { success, isDownload, downloadUrl } = salesInvoiceInfo;
		const { id } = route.params;
		const { shipmentDetail } = shipmentDetailInfo;
		const { customer } = shipmentDetail || {};
		const { success: shipmentDetailInfoSuccess } = shipmentDetailInfo;
		if (
			success &&
			isDownload &&
			prevProps.salesInvoiceInfo.success !== salesInvoiceInfo.success
		) {
			// if download salesinvoice api return success
			const downloadFileName = `${removeSpaces(customer && customer.name)}-${id}`;
			downloadFile(
				downloadUrl,
				downloadFileName,
				() => {
					this.onShowDownloadFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
				},
				() => {
					this.onShowDownloadFileStatus(
						localeString(keyConstants.SUCCESSFULLY_DOWNLOADED),
					);
				},
				() => {
					this.onShowDownloadFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
				},
			);
		}
		if (
			shipmentDetailInfoSuccess &&
			prevProps.shipmentDetailInfo.success !== shipmentDetailInfo.success
		) {
			// if shipment detail api return success
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	getShipmentDetail = () => {
		// Call api to get shipment details
		const { route, shipmentDetailActions, pullToRefreshActions } = this.props;
		const { id, index } = route.params || {};
		const queryParams = {
			id,
		};
		setTimeout(() => pullToRefreshActions.onSetSelectIndex(index));
		shipmentDetailActions.onGetShipmentDetail(queryParams);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onShowDownloadFileStatus = message => {
		// function to show file downloading status in toast message
		this.setState({
			toastMessage: message,
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	onNavigate = (latitude, longitude) => {
		showLocation({
			latitude,
			longitude,
			googleForceLatLon: true,
			appsWhiteList: [googleMaps, appleMaps],
		});
	};

	keyExtractor = (item, index) => {
		return index.toString();
	};

	getDriverSecondStageStatus = status => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case shipmentStatus.assigned:
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			case shipmentStatus.failed:
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	getSecondStageStatus = status => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case shipmentStatus.unassigned:
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			case shipmentStatus.failed:
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	getThirdStageStatus = status => {
		const { languageInfo, route } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { isDriver } = route.params || {};
		switch (status) {
			case shipmentStatus.unassigned:
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case shipmentStatus.assigned:
				return {
					image: isDriver
						? IMAGES.iconOrderStatusHollow
						: IMAGES.iconOrderStatusHollowCheck,
					style: styles.greyLine,
				};
			case shipmentStatus.started:
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			case shipmentStatus.failed:
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	getLastStageStatus = status => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		switch (status) {
			case shipmentStatus.unassigned:
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case shipmentStatus.assigned:
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case shipmentStatus.started:
				return { image: IMAGES.iconOrderStatusHollow, style: styles.greyLine };
			case shipmentStatus.failed:
				return { image: IMAGES.iconCrossRed, style: styles.greyLine };
			case shipmentStatus.inProgress:
				return { image: IMAGES.iconOrderStatusHollowCheck, style: styles.greyLine };
			default:
				return { image: IMAGES.iconOrderStatusFilled, style: styles.greenLine };
		}
	};

	getStartedDate = (timestamps, status) => {
		if (timestamps.started) {
			return timestamps.started;
		}
		switch (status) {
			case shipmentStatus.inProgress:
				return timestamps.in_progress;
			case shipmentStatus.failed:
				return timestamps.failed;
			case shipmentStatus.successful:
				return timestamps.successful;
			default:
				return null;
		}
	};

	getAssignedDate = (timestamps, status) => {
		if (timestamps.assigned) {
			return timestamps.assigned;
		}
		switch (status) {
			case shipmentStatus.inProgress:
				return timestamps.in_progress;
			case shipmentStatus.failed:
				return timestamps.failed;
			case shipmentStatus.successful:
				return timestamps.successful;
			default:
				return null;
		}
	};

	getInProgressDate = (timestamps, status) => {
		if (timestamps.in_progress) {
			return timestamps.in_progress;
		}
		switch (status) {
			case shipmentStatus.failed:
				return timestamps.failed;
			case shipmentStatus.successful:
				return timestamps.successful;
			default:
				return null;
		}
	};

	changeDropdownVisibility = value => this.setState({ isDropdownVisible: value });

	// show mark delivered options
	onPressMarkDelivered = () => this.changeDropdownVisibility(true);

	onRefresh = () => {
		this.getShipmentDetail();
	};

	onCloseDropdown = () => this.changeDropdownVisibility(false);

	// select a dropdown option and navigate accordingly
	onSelectDropdownOption = index => {
		const { shipmentDetailInfo, navigation } = this.props;
		const { total_amount, customer, sales_invoice_id } =
			(shipmentDetailInfo && shipmentDetailInfo.shipmentDetail) || {};
		this.onCloseDropdown();
		this.setState({
			activeOptionIndex: index,
		});
		if (index) {
			// if index === 1
			setTimeout(() => {
				this.getAlert();
			}, 200);
		} else {
			// when index === 0
			navigation.navigate(driverNavigations.SALES_INVOICE_DETAIL_NAVIGATION, {
				id: sales_invoice_id,
				amount: total_amount,
				organization: customer && customer.name,
				isSalesInvoice: true,
				isPurchase: false,
			});
		}
	};

	getAlert = () => {
		// Function to show shipment confirmation alert
		const alertOptions = {
			message: localeString(keyConstants.SHIPMENT_CONFIRMATION),
			yesText: localeString(keyConstants.OKAY),
			onPressYes: this.onNavigateToOtp,
			isOneButton: true,
		};
		AlertComponent(alertOptions);
	};

	onNavigateToOtp = () => {
		const { route, navigation } = this.props;
		const { id } = route.params;
		navigation.navigate(driverNavigations.OTP_SCREEN_NAVIGATION, {
			mobileNumber: '',
			isSignIn: false,
			isDriver: true,
			id,
		});
	};

	onCheckShipmentStatus = status => {
		return (
			status !== shipmentStatus.assigned &&
			status !== shipmentStatus.failed &&
			status !== shipmentStatus.successful
		);
	};

	// returns formatted date without hyphen with formatted time
	getFormatedDateAndTime = date => {
		return `${getFormattedDateWithoutHyphen(date)}, ${getFormattedTime(date)}`;
	};

	render() {
		const {
			isApiError,
			toastMessage,
			isDropdownVisible,
			dropdownOptions,
			activeOptionIndex,
		} = this.state;
		const {
			route,
			languageInfo,
			shipmentDetailInfo,
			salesInvoiceInfo,
			refreshControlComponentInfo,
		} = this.props;
		const { isDriver } = route.params || {};
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, shipmentDetail } = shipmentDetailInfo;
		const {
			item_total,
			delivery_fee,
			vat_amount,
			total_amount,
			shipment_status,
			placed_on,
			timestamps,
			customer,
			delivery_code,
			sales_invoice_id,
			error,
			errorCode,
			shipment_paid,
		} = shipmentDetail || {};
		const salesInvoiceloader = salesInvoiceInfo.loader;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const isShowMarkDeliveredButton =
			shipmentDetail &&
			shipmentDetail.shipment_items &&
			shipmentDetail.shipment_items.length &&
			shipmentDetail.shipment_items[0].acceptance_status ===
				purchaseReturnInvoiceStatus.approved;
		if (loader && !isFetchingForPullToRefresh) {
			return <Loader size="large" />;
		}
		return (
			<View style={styles.container}>
				{salesInvoiceloader && <Spinner size="large" />}
				<OptionPicker
					title={localeString(keyConstants.SELECT_SHIPMENT_PROCESSING_OPTION)}
					isRTL={isRTL}
					isVisible={isDropdownVisible}
					options={dropdownOptions}
					onClose={this.onCloseDropdown}
					onSelectOption={this.onSelectDropdownOption}
					activeIndex={activeOptionIndex}
					hasRadioButton
				/>
				<View style={styles.header}>
					<Header
						onPressBack={this.onGoBack}
						hasIconBack
						text={localeString(keyConstants.SHIPMENT_DETAILS)}
					/>
					{isDriver ? (
						<View style={styles.codeView}>
							<Text style={styles.statusText}>
								{`${localeString(keyConstants.STATUS)}: `}
								<Text
									style={[
										styles.paymentStatus,
										shipment_paid && styles.shipmentPaid,
									]}>
									{shipment_paid
										? localeString(keyConstants.PAID)
										: localeString(keyConstants.NOT_PAID)}
								</Text>
							</Text>
						</View>
					) : (
						<View style={styles.codeView}>
							<Text style={styles.code}>{getShipmentStatus(shipment_status)}</Text>
						</View>
					)}
				</View>
				{error ? (
					<ErrorComponent // Error component if api fails.
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.onRefresh}
					/>
				) : (
					<>
						<ScrollViewComponent
							showsVerticalScrollIndicator={false}
							style={[
								styles.headerContainer,
								isDriver &&
									this.onCheckShipmentStatus(shipment_status) &&
									isShowMarkDeliveredButton &&
									styles.scrollView,
								!isDriver &&
									shipment_status !== shipmentStatus.unassigned &&
									styles.shipmentScrollView,
							]}
							onRefresh={this.onRefresh}
							componentType={constants.scrollView}>
							{!isDriver &&
								this.role !== accountManager &&
								this.role !== salesExecutive && (
									<View style={styles.deliveryCodeView}>
										<Text style={styles.textDeliveryCode}>
											{localeString(keyConstants.DELIVERY_CODE)}
										</Text>
										<Text style={styles.textDeliveryCode}>{delivery_code}</Text>
									</View>
								)}
							{isDriver && (
								<View style={styles.mapView}>
									<SmallMapComponent
										region={{
											latitude: customer && parseFloat(customer.latitude),
											longitude: customer && parseFloat(customer.longitude),
											latitudeDelta: 0.005,
											longitudeDelta: 0.005,
										}}
										mapStyle={styles.mapStyle}
										isRTL={isRTL}
										addressLine1={
											customer &&
											`${customer.address_one}, ${customer.address_two}`
										}
										notExistsInputFields
									/>
									<View style={styles.buttonView}>
										<Input
											value={customer && customer.address_one}
											height={verticalScale(64)}
											width={normalScale(242)}
											label={`${localeString(keyConstants.ADDRESS_LINE_1)}*`}
											placeholder={localeString(keyConstants.ADDRESS_LINE_1)}
											isRTL={isRTL}
											editable={false}
											hasNoShadow
											textInputStyle={styles.textStyle}
											multiline
											textAlignVertical="center"
										/>
										<TouchableOpacity
											style={styles.navigateView}
											activeOpacity={0.8}
											onPress={() =>
												this.onNavigate(
													customer && customer.latitude,
													customer && customer.longitude,
												)
											}>
											<ImageLoadComponent
												source={IMAGES.iconNavigate}
												style={styles.iconNavigate}
											/>
										</TouchableOpacity>
									</View>
								</View>
							)}
							<View style={styles.innerContainer}>
								{isDriver ? (
									<>
										<View style={styles.statusView}>
											<ImageLoadComponent
												source={
													shipment_status === shipmentStatus.failed
														? IMAGES.iconCrossRed
														: IMAGES.iconOrderStatusFilled
												}
												style={styles.orderImage}
											/>
											<View style={styles.innerDateView}>
												<Text style={styles.status}>
													{shipment_status === shipmentStatus.failed
														? localeString(keyConstants.FAILED)
														: localeString(keyConstants.ASSIGNED)}
												</Text>
												<Text style={styles.date}>
													{this.getFormatedDateAndTime(
														timestamps && timestamps.assigned,
													)}
												</Text>
											</View>
										</View>
										<View
											style={
												shipment_status === shipmentStatus.failed
													? styles.greyLine
													: styles.greenLine
											}
										/>
										<View style={styles.statusView}>
											<ImageLoadComponent
												source={
													this.getDriverSecondStageStatus(shipment_status)
														.image
												}
												style={styles.orderImage}
											/>
											<View style={styles.innerDateView}>
												<Text style={styles.status}>
													{shipment_status === shipmentStatus.failed
														? localeString(keyConstants.FAILED)
														: localeString(keyConstants.STARTED)}
												</Text>
												<Text style={styles.date}>
													{timestamps &&
													this.getStartedDate(timestamps, shipment_status)
														? this.getFormatedDateAndTime(
																this.getStartedDate(
																	timestamps,
																	shipment_status,
																),
														  )
														: dash}
												</Text>
											</View>
										</View>
									</>
								) : (
									<>
										<View style={styles.statusView}>
											<ImageLoadComponent
												source={
													shipment_status === shipmentStatus.failed
														? IMAGES.iconCrossRed
														: IMAGES.iconOrderStatusFilled
												}
												style={styles.orderImage}
											/>
											<View style={styles.innerDateView}>
												<Text style={styles.status}>
													{shipment_status === shipmentStatus.failed
														? localeString(keyConstants.FAILED)
														: localeString(keyConstants.PLACED)}
												</Text>
												<Text style={styles.date}>
													{this.getFormatedDateAndTime(placed_on)}
												</Text>
											</View>
										</View>
										<View
											style={
												shipment_status === shipmentStatus.failed
													? styles.greyLine
													: styles.greenLine
											}
										/>
										<View style={styles.statusView}>
											<ImageLoadComponent
												source={
													this.getSecondStageStatus(shipment_status).image
												}
												style={styles.orderImage}
											/>
											<View style={styles.innerDateView}>
												<Text style={styles.status}>
													{shipment_status === shipmentStatus.failed
														? localeString(keyConstants.FAILED)
														: localeString(keyConstants.ASSIGNED)}
												</Text>
												<Text style={styles.date}>
													{timestamps &&
													this.getAssignedDate(
														timestamps,
														shipment_status,
													)
														? this.getFormatedDateAndTime(
																this.getAssignedDate(
																	timestamps,
																	shipment_status,
																),
														  )
														: dash}
												</Text>
											</View>
										</View>
									</>
								)}
								<View
									style={[
										this.getSecondStageStatus(shipment_status).style,
										styles.line,
									]}
								/>
								<View style={styles.statusView}>
									<ImageLoadComponent
										source={this.getThirdStageStatus(shipment_status).image}
										style={styles.orderImage}
									/>
									<View style={styles.innerDateView}>
										<Text style={styles.status}>
											{shipment_status === shipmentStatus.failed
												? localeString(keyConstants.FAILED)
												: localeString(keyConstants.IN_PROGRESS)}
										</Text>
										<Text style={styles.date}>
											{timestamps &&
											this.getInProgressDate(timestamps, shipment_status)
												? this.getFormatedDateAndTime(
														this.getInProgressDate(
															timestamps,
															shipment_status,
														),
												  )
												: dash}
										</Text>
									</View>
								</View>
								<View
									style={[
										this.getThirdStageStatus(shipment_status).style,
										styles.lastLine,
									]}
								/>
								<View style={styles.statusView}>
									<ImageLoadComponent
										source={this.getLastStageStatus(shipment_status).image}
										style={styles.orderImage}
									/>
									<View style={styles.innerDateView}>
										<Text style={styles.status}>
											{shipment_status === shipmentStatus.failed
												? localeString(keyConstants.FAILED)
												: localeString(keyConstants.SUCCESSFUL)}
										</Text>
										<Text style={styles.date}>
											{timestamps && timestamps.successful
												? this.getFormatedDateAndTime(timestamps.successful)
												: dash}
										</Text>
									</View>
								</View>
							</View>
							<View style={styles.topView}>
								<Text style={styles.item}>
									{`${localeString(keyConstants.SHIPPED_ITEMS)}`}
								</Text>
								<FlatList
									data={shipmentDetail && shipmentDetail.shipment_items}
									inverted={isRTL}
									horizontal
									showsHorizontalScrollIndicator={false}
									renderItem={({ item }) => {
										return (
											<ProductCardComponent
												subtitle={`${item.quantity} x ${getValueInDecimal(
													item.offer_price
														? item.offer_price
														: item.price,
												)} ${localeString(keyConstants.SAR)}`}
												title={isRTL ? item.name_ar : item.name}
												discountedPrice={
													item.quantity *
													(item.offer_price
														? item.offer_price
														: item.price)
												}
												image={item && item.images && item.images.small}
												containerStyle={styles.containerStyle}
												isDiscountedPrice
												discountedPriceStyle={styles.discountedPriceStyle}
												titleStyle={styles.titleStyle}
											/>
										);
									}}
									keyExtractor={this.keyExtractor}
								/>
							</View>
							<View style={styles.paymentDetails}>
								<Text style={styles.item}>
									{localeString(keyConstants.PAYMENT_DETAILS)}
								</Text>
								<View style={styles.detail}>
									<Text style={styles.text}>
										{localeString(keyConstants.ITEM_TOTAL)}
									</Text>
									<Text style={styles.text}>
										{`${getValueInDecimal(item_total)} ${localeString(
											keyConstants.SAR,
										)}`}
									</Text>
								</View>
								<View style={styles.total}>
									<Text style={styles.text}>
										{localeString(keyConstants.DELIVERY_FEE)}
									</Text>
									<Text style={styles.text}>
										{`${getValueInDecimal(delivery_fee)} ${localeString(
											keyConstants.SAR,
										)}`}
									</Text>
								</View>
								<View style={styles.total}>
									<Text style={styles.text}>
										{localeString(keyConstants.VAT)}
									</Text>
									<Text style={styles.text}>
										{`${getValueInDecimal(vat_amount)} ${localeString(
											keyConstants.SAR,
										)}`}
									</Text>
								</View>
								<View style={styles.pay}>
									<Text style={styles.text}>
										{localeString(keyConstants.TOTAL_AMOUNT)}
									</Text>
									<Text style={styles.totalAmount}>
										{`${getValueInDecimal(total_amount)} ${localeString(
											keyConstants.SAR,
										)}`}
									</Text>
								</View>
							</View>
						</ScrollViewComponent>
						<>
							{isDriver &&
								this.onCheckShipmentStatus(shipment_status) &&
								isShowMarkDeliveredButton && (
									<View style={styles.driverButtonView}>
										<ButtonComponent
											text={localeString(keyConstants.MARK_DELIVERED)}
											onPress={this.onPressMarkDelivered}
										/>
									</View>
								)}
							{!isDriver &&
								shipment_status !== shipmentStatus.unassigned &&
								shipment_status !== shipmentStatus.failed && (
									<DownloadSalesInvoice
										isRTL={isRTL}
										title={localeString(keyConstants.DOWNLOAD_INVOICE)}
										salesInvoiceId={sales_invoice_id}
										hasButton
									/>
								)}
						</>
					</>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		shipmentDetailInfo: state.ShipmentDetailScreenReducer,
		salesInvoiceInfo: state.SalesInvoiceScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		userDetails: state.HomeScreenReducer.userDetails,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		shipmentDetailActions: bindActionCreators({ ...ShipmentDetailActions }, dispatch),
		salesInvoiceActions: bindActionCreators({ ...SalesInvoiceActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

ShipmentDetailScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	shipmentDetailInfo: PropTypes.object.isRequired,
	salesInvoiceInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	shipmentDetailActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(ShipmentDetailScreen);
