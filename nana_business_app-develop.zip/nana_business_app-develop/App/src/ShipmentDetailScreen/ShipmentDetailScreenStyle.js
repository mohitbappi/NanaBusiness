import { StyleSheet, Dimensions } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();
const { width } = Dimensions.get('window');

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginHorizontal: normalScale(16),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			justifyContent: 'space-between',
		},
		codeView: {
			justifyContent: 'center',
		},
		statusText: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.darkBlack,
		},
		paymentStatus: {
			color: colors.red,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		shipmentPaid: {
			color: colors.green,
		},
		code: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.boldItalic),
			fontSize: normalize(12),
		},
		headerContainer: {
			marginBottom: verticalScale(8),
		},
		scrollView: {
			marginBottom: verticalScale(55),
		},
		shipmentScrollView: {
			marginBottom: verticalScale(55),
		},
		innerContainer: {
			flexDirection: 'column',
			marginBottom: verticalScale(14),
			marginHorizontal: normalScale(16),
		},
		mapView: {
			borderBottomWidth: normalScale(4),
			borderBottomColor: colors.grey,
			paddingHorizontal: normalScale(16),
		},
		mapStyle: {
			marginTop: 0,
		},
		textStyle: {
			color: colors.black,
			paddingVertical: verticalScale(5),
			borderWidth: 0,
			paddingHorizontal: 0,
			width: normalScale(242),
		},
		navigateView: {
			alignSelf: 'flex-end',
		},
		iconNavigate: {
			height: normalScale(30),
			width: normalScale(30),
		},
		buttonView: {
			marginBottom: verticalScale(24),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		statusView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			marginVertical: verticalScale(4),
			alignItems: 'center',
		},
		orderImage: {
			height: verticalScale(16),
			width: normalScale(16),
		},
		innerDateView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			borderBottomWidth: normalScale(1),
			borderBottomColor: colors.greenShadow,
			marginLeft: isRTL ? 0 : normalScale(13),
			flex: 1,
			alignItems: 'center',
			paddingVertical: verticalScale(13),
		},
		status: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginRight: isRTL ? normalScale(13) : 0,
		},
		date: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
		},
		greenLine: {
			borderLeftColor: colors.lightBlueShadowGrey,
			borderLeftWidth: normalScale(1),
			height: normalScale(37),
			position: 'absolute',
			top: verticalScale(31),
			left: isRTL ? width - normalScale(40) : normalScale(8),
		},
		greyLine: {
			borderLeftColor: colors.grey,
			borderLeftWidth: normalScale(1),
			height: normalScale(37),
			position: 'absolute',
			top: verticalScale(31),
			left: isRTL ? width - normalScale(40) : normalScale(8),
		},
		line: {
			top: verticalScale(81),
			left: isRTL ? width - normalScale(40) : normalScale(8),
		},
		lastLine: {
			top: verticalScale(131),
			left: isRTL ? width - normalScale(40) : normalScale(8),
		},
		topView: {
			borderBottomWidth: normalScale(4),
			borderBottomColor: colors.grey,
			borderTopColor: colors.grey,
			borderTopWidth: normalScale(4),
			paddingTop: verticalScale(16),
			paddingBottom: verticalScale(4),
			paddingHorizontal: normalScale(16),
		},
		item: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			marginBottom: verticalScale(9),
		},
		titleStyle: {
			width: normalScale(120),
			height: verticalScale(29),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		containerStyle: {
			width: normalScale(215),
			backgroundColor: colors.whitishGrey,
			paddingHorizontal: normalScale(8),
			paddingVertical: verticalScale(8),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 10),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 10),
			borderRadius: moderateScale(8),
		},
		discountedPriceStyle: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		paymentDetails: {
			paddingVertical: verticalScale(16),
			paddingHorizontal: normalScale(16),
		},
		detail: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingVertical: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			marginTop: verticalScale(4),
			borderRadius: moderateScale(4),
		},
		text: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		total: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingVertical: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			borderRadius: moderateScale(4),
		},
		pay: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(8),
		},
		totalAmount: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
		},
		driverButtonView: {
			left: normalScale(8),
			right: normalScale(8),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalScale(8),
			justifyContent: 'space-between',
			position: 'absolute',
		},
		deliveryCodeView: {
			paddingVertical: verticalScale(3),
			paddingHorizontal: normalScale(16),
			backgroundColor: colors.skyBlue,
			alignItems: 'center',
			justifyContent: 'space-between',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		textDeliveryCode: {
			color: colors.lightBlueShadowGrey,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
	});
};

export default createStyleSheet;
