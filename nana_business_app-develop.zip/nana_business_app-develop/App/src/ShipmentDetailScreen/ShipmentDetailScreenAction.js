import { actions } from '@libapi/APIActionsBuilder';
import GetShipmentDetailService from '@Orders/GetShipmentDetailService';
import MarkShipmentDeliveredService from '@Shipment/MarkShipmentDeliveredService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to call shipment deetail api
 * @param {object} props
 */
export const onGetShipmentDetail = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.GET_SHIPMENT_ITEMS_SUCCESS,
		ActionTypes.GET_SHIPMENT_ITEMS_FAILURE,
		ActionTypes.GET_SHIPMENT_ITEMS_LOADER,
	);
	const getShipmentDetailService = new GetShipmentDetailService(dispatchedActions);
	addBasicInterceptors(getShipmentDetailService);
	getShipmentDetailService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getShipmentDetailService.makeRequest(props));
};

/**
 * Action to call mark delivered api
 * @param {object} props
 */
export const onMarkDelivered = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.MARK_SHIPMENT_DELIVERED_SUCCESS,
		ActionTypes.MARK_SHIPMENT_DELIVERED_FAILURE,
		ActionTypes.MARK_SHIPMENT_DELIVERED_LOADER,
	);
	const markShipmentDeliveredService = new MarkShipmentDeliveredService(dispatchedActions);
	addBasicInterceptors(markShipmentDeliveredService);
	markShipmentDeliveredService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(markShipmentDeliveredService.makeRequest(props));
};

// Action to reset shipment screen
export const onResetShipmentState = () => ({ type: ActionTypes.RESET_SHIPMENT_STATE });
