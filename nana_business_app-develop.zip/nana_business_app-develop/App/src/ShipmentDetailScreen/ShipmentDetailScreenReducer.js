import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	shipmentDetail: null,
	isShipmentDelivered: false,
	markDeliveredData: null,
};

const ShipmentDetailScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_SHIPMENT_ITEMS_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				shipmentDetail: action.payload,
				isShipmentDelivered: false,
			};
		case ActionTypes.GET_SHIPMENT_ITEMS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isShipmentDelivered: false,
			};
		case ActionTypes.GET_SHIPMENT_ITEMS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isShipmentDelivered: false,
			};
		case ActionTypes.MARK_SHIPMENT_DELIVERED_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isShipmentDelivered: true,
			};
		case ActionTypes.MARK_SHIPMENT_DELIVERED_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isShipmentDelivered: true,
				markDeliveredData: action.payload,
			};
		case ActionTypes.MARK_SHIPMENT_DELIVERED_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isShipmentDelivered: true,
			};
		case ActionTypes.RESET_SHIPMENT_STATE:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
				isShipmentDelivered: false,
				markDeliveredData: null,
			};
		default:
			return state;
	}
};

export default ShipmentDetailScreenReducer;
