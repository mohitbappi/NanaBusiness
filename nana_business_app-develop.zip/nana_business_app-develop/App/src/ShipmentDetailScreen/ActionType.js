export const GET_SHIPMENT_ITEMS_SUCCESS = 'get_shipment_items_success';
export const GET_SHIPMENT_ITEMS_FAILURE = 'get_shipment_items_failure';
export const GET_SHIPMENT_ITEMS_LOADER = 'get_shipment_items_loader';
export const MARK_SHIPMENT_DELIVERED_SUCCESS = 'mark_shipment_delivered_success';
export const MARK_SHIPMENT_DELIVERED_FAILURE = 'mark_shipment_delivered_failure';
export const MARK_SHIPMENT_DELIVERED_LOADER = 'mark_shipment_delivered_loader';
export const RESET_SHIPMENT_STATE = 'reset_shipment_state';
