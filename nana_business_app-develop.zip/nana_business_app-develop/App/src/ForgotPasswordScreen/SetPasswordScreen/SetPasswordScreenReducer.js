import * as ActionTypes from './ActionType';

const initialState = {
	code: '',
	newPassword: '',
	confirmNewPassword: '',
	success: false,
	error: false,
	errorCode: null,
	loader: false,
};

const SetPasswordScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.RESET_FORGOT_PASSWORD_STATE:
			return {
				...state,
				code: '',
				newPassword: '',
				confirmNewPassword: '',
				success: false,
				error: false,
				errorCode: null,
				loader: false,
			};
		case ActionTypes.SET_PASSWORD_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
			};
		case ActionTypes.SET_PASSWORD_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.SET_PASSWORD_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default SetPasswordScreenReducer;
