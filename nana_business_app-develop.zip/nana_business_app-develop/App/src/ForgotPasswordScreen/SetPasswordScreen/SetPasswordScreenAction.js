import { actions } from '@libapi/APIActionsBuilder';
import SetNewPasswordService from '@ForgotPassword/SetNewPasswordService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import * as ActionTypes from './ActionType';

export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_TEXT,
		payload: text,
		field,
	};
};

export const onResetForgotPasswordState = () => ({ type: ActionTypes.RESET_FORGOT_PASSWORD_STATE });

export const onSetNewPassword = passwordDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SET_PASSWORD_SUCCESS,
		ActionTypes.SET_PASSWORD_FAILURE,
		ActionTypes.SET_PASSWORD_LOADER,
	);
	const setNewPasswordService = new SetNewPasswordService(dispatchedActions);
	addBasicInterceptors(setNewPasswordService);
	dispatch(setNewPasswordService.makeRequest(passwordDetails));
};
