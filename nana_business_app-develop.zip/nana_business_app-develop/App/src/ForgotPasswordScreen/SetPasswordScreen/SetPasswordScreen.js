import React, { Component } from 'react';
import { connect } from 'react-redux';
import { TouchableOpacity, Text, Keyboard, ScrollView } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import IMAGES from '@Images/index';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { toastShowTime, passwordRegexEx, spaceRegexEx, codeMaxLength } from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import navigations from '@routes/navigations';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import SetNewPasswordComponent from '@Components/SetNewPasswordComponent';
import * as SetPasswordActions from './SetPasswordScreenAction';
import { createStyleSheet } from './SetPasswordScreenStyle';

class SetPasswordScreen extends Component {
	constructor(props) {
		super(props);
		this.newPassword = React.createRef(null);
		this.confirmPassword = React.createRef(null);
		this.state = {
			errorPasswordValidationMessage: false,
			errorConfirmPasswordValidationMessage: false,
			isApiError: false,
			toastMessage: '',
			isShowPasswordInfo: false,
		};
	}

	componentDidUpdate(prevProps) {
		const { setPasswordInfo, navigation } = this.props;
		const { newPassword, error, errorCode, confirmNewPassword, success } = setPasswordInfo;
		if (error && prevProps.setPasswordInfo.error !== error) {
			this.setState({
				toastMessage: localeString(`${errorCode.error}`),
				isApiError: true,
				errorPasswordValidationMessage: false,
				errorConfirmPasswordValidationMessage: false,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
		if (prevProps.setPasswordInfo !== setPasswordInfo) {
			if (passwordRegexEx.test(String(newPassword).toLowerCase())) {
				this.setState({
					errorPasswordValidationMessage: false,
				});
			}
			if (newPassword === confirmNewPassword) {
				this.setState({
					errorConfirmPasswordValidationMessage: false,
				});
			}
			if (success) {
				navigation.navigate(navigations.SIGNIN_NAVIGATION);
			}
		}
	}

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeText = (text, field) => {
		const { setPasswordActions } = this.props;
		setPasswordActions.onChangeText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = () => {
		const { setPasswordInfo } = this.props;
		const { newPassword } = setPasswordInfo;
		if (!passwordRegexEx.test(newPassword)) {
			this.setState({
				errorPasswordValidationMessage: true,
			});
		}
	};

	showPasswordInformation = value => {
		this.setState({
			isShowPasswordInfo: value,
		});
	};

	onMatchPassword = () => {
		const { setPasswordInfo } = this.props;
		const { newPassword, confirmNewPassword } = setPasswordInfo;
		if (confirmNewPassword !== newPassword) {
			this.setState({
				errorConfirmPasswordValidationMessage: true,
			});
		}
	};

	onSubmit = () => {
		const { setPasswordInfo, route, setPasswordActions } = this.props;
		const { newPassword, confirmNewPassword, code } = setPasswordInfo;
		const { email } = route.params;
		this.onDissmissKeyboard();
		const passwordDetails = {
			code,
			password1: newPassword,
			password2: confirmNewPassword,
			email,
		};
		setPasswordActions.onSetNewPassword(passwordDetails);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	render() {
		const {
			errorConfirmPasswordValidationMessage,
			errorPasswordValidationMessage,
			toastMessage,
			isApiError,
			isShowPasswordInfo,
		} = this.state;
		const { setPasswordInfo, languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const { code, newPassword, confirmNewPassword, loader } = setPasswordInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<KeyboardAwareScrollView
				keyboardShouldPersistTaps="handled"
				contentContainerStyle={styles.container}>
				{loader && <Spinner size="large" />}
				<TouchableOpacity
					activeOpacity={0.8}
					hitSlop={styles.hitSlop}
					style={styles.backButton}
					onPress={this.onGoBack}>
					<ImageLoadComponent source={IMAGES.iconCross} style={styles.image} />
				</TouchableOpacity>
				<ScrollView
					contentContainerStyle={styles.scrollView}
					showsVerticalScrollIndicator={false}
					keyboardShouldPersistTaps="handled">
					<Text style={styles.chooseText}>
						{localeString(keyConstants.SET_NEW_PASSWORD)}
					</Text>
					<Text style={styles.defaultText}>
						{localeString(keyConstants.SET_A_NEW_PASSWORD)}
					</Text>
					<Input
						maxLength={codeMaxLength}
						value={code}
						width={normalScale(260)}
						label={`${localeString(keyConstants.ENTER_CODE)}*`}
						placeholder={localeString(keyConstants.ENTER_CODE)}
						blurOnSubmit={false}
						returnKeyType="next"
						isRTL={isRTL}
						keyboardType="number-pad"
						onChangeText={text =>
							(spaceRegexEx.test(String(text).toLocaleLowerCase()) || text === '') &&
							this.onChangeText(text, 'code')
						}
						onSubmitEditing={() => this.onSubmitRef(this.newPassword)}
						autoCapitalize="none"
						hasIconPassword
					/>
					<SetNewPasswordComponent
						isRTL={isRTL}
						isShowPasswordInformation={isShowPasswordInfo}
						newPassword={newPassword}
						errorPasswordValidationMessage={errorPasswordValidationMessage}
						confirmNewPassword={confirmNewPassword}
						errorConfirmPasswordValidationMessage={
							errorConfirmPasswordValidationMessage
						}
						onChangeText={this.onChangeText}
						showPasswordInformation={this.showPasswordInformation}
						onBlur={this.onBlur}
						onMatchPassword={this.onMatchPassword}
						onSubmitRef={this.onSubmitRef}
						refCallback={this.refCallback}
						newPasswordRef={this.newPassword}
						confirmPasswordRef={this.confirmPassword}
					/>
				</ScrollView>
				<ButtonComponent
					viewStyle={styles.viewStyle}
					onPress={this.onSubmit}
					text={localeString(keyConstants.SET_NEW_PASSWORD)}
					isButtonDisable={
						!(
							passwordRegexEx.test(String(newPassword).toLowerCase()) &&
							newPassword === confirmNewPassword &&
							code
						)
					}
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		setPasswordInfo: state.SetPasswordScreenReducer,
		languageInfo: state.LanguageScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		setPasswordActions: bindActionCreators({ ...SetPasswordActions }, dispatch),
	};
};

SetPasswordScreen.propTypes = {
	setPasswordInfo: PropTypes.object.isRequired,
	setPasswordActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SetPasswordScreen);
