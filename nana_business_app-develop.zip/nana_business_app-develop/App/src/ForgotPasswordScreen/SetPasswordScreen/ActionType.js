export const ON_CHANGE_TEXT = 'on_change_text';
export const RESET_FORGOT_PASSWORD_STATE = 'reset_forgot_password_state';
export const SET_PASSWORD_SUCCESS = 'set_password_success';
export const SET_PASSWORD_FAILURE = 'set_password_failure';
export const SET_PASSWORD_LOADER = 'set_password_loader';
