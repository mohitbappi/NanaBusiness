import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import { fontsConstants } from '@Constants/Constants';
import RTLFunctions from '@Util/RTLFunctions';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(22),
		},
		hitSlop: {
			top: verticalScale(15),
			bottom: verticalScale(15),
			right: normalScale(15),
			left: normalScale(15),
		},
		backButton: {
			marginTop: verticalScale(30),
			alignSelf: rtlFunctions.getAlignmentInFlex(isRTL),
		},
		image: {
			width: normalScale(12),
			height: verticalScale(12),
		},
		scrollView: {
			paddingHorizontal: normalScale(8),
			paddingBottom: verticalScale(87),
		},
		chooseText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(22),
			marginTop: verticalScale(20),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
		},
		defaultText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(11),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			lineHeight: verticalScale(17),
			marginBottom: verticalScale(44),
		},
		viewStyle: {
			position: 'absolute',
			left: normalScale(30),
			right: normalScale(30),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(24),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
