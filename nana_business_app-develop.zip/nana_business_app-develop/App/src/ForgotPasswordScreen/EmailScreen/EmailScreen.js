import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Text, Keyboard, ScrollView, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';
import IMAGES from '@Images/index';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import Input from '@Input/Input';
import { normalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import {
	emailRegexEx,
	toastShowTime,
	retailer,
	collector,
	vendor,
	customerAdmin,
	driver,
	accountManager,
	salesExecutive,
	cashier,
} from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import navigations from '@routes/navigations';
import * as SetPasswordActions from '@SetPasswordScreen/SetPasswordScreenAction';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import Header from '@Header/Header';
import * as ForgotEmailActions from './EmailScreenAction';
import { createStyleSheet } from './EmailScreenStyle';

class EmailScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			errorEmailValidationMessage: false,
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidUpdate(prevProps) {
		const { forgotEmailInfo } = this.props;
		const { email, error, errorCode } = forgotEmailInfo;
		if (error && prevProps.forgotEmailInfo.error !== error) {
			// Will show toast if any error occurs.
			if (keyConstants[errorCode.error]) {
				this.setState({
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
			} else {
				// Will show alert if api fails.
				ErrorAlertComponent(errorCode, this.onSubmit);
			}
		}
		if (prevProps.forgotEmailInfo !== forgotEmailInfo) {
			// Check email validation.
			if (emailRegexEx.test(String(email).toLowerCase())) {
				this.setState({
					errorEmailValidationMessage: false,
				});
			}
		}
	}

	componentWillUnmount() {
		// Reset the reducer and email value.
		const { forgotEmailActions, setPasswordActions } = this.props;
		forgotEmailActions.onResetForgotState();
		forgotEmailActions.onChangeEmail('');
		setPasswordActions.onResetForgotPasswordState();
	}

	onGoSignIn = () => {
		// Will navigate to the signin screen and reset the reducer.
		const { forgotEmailActions, navigation } = this.props;
		forgotEmailActions.onResetForgotState();
		navigation.navigate(navigations.SIGNIN_NAVIGATION);
	};

	onGoBack = () => {
		// Will navigate back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onChangeEmail = text => {
		// Will set email address in reducer.
		const { forgotEmailActions } = this.props;
		forgotEmailActions.onChangeEmail(text);
	};

	onBlur = () => {
		const { forgotEmailInfo } = this.props;
		const { email } = forgotEmailInfo;
		if (!emailRegexEx.test(String(email).toLowerCase())) {
			this.setState({
				errorEmailValidationMessage: true,
			});
		}
	};

	onSubmit = () => {
		// API call to send the password reset link on the given email address.
		const { forgotEmailInfo, forgotEmailActions } = this.props;
		const { email } = forgotEmailInfo;
		this.onDissmissKeyboard();
		const mailDetails = {
			email_address: email,
			role: [
				vendor,
				retailer,
				customerAdmin,
				accountManager,
				salesExecutive,
				collector,
				driver,
				cashier,
			],
		};
		forgotEmailActions.getOTPOnEmail(mailDetails);
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	render() {
		const { forgotEmailInfo, languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { errorEmailValidationMessage, isApiError, toastMessage } = this.state;
		const { loader, email, success } = forgotEmailInfo;
		return (
			<>
				{success && (
					<Modal transparent>
						<View style={styles.confirmationContainer}>
							<ImageLoadComponent
								source={IMAGES.iconEmailSent}
								style={styles.congratsImage}
							/>
							<Text style={styles.congratulationText}>
								{localeString(keyConstants.EMAIL_SENT)}
							</Text>
							<Text style={styles.confirmationText}>
								{localeString(keyConstants.RESET_EMAIL_MESSAGE)}
							</Text>
							<ButtonComponent
								viewStyle={styles.congratsButtonStyle}
								onPress={this.onGoSignIn}
								text={localeString(keyConstants.OKAY)}
								isButtonDisable={false}
							/>
						</View>
					</Modal>
				)}
				<KeyboardAwareScrollView
					keyboardShouldPersistTaps="handled"
					contentContainerStyle={styles.container}>
					{loader && <Spinner size="large" />}
					<Header
						headerStyle={styles.backButton}
						onPressBack={this.onGoBack}
						hasIconBack
					/>
					<ScrollView
						showsVerticalScrollIndicator={false}
						contentContainerStyle={styles.scrollView}
						keyboardShouldPersistTaps="handled">
						<Text style={styles.chooseText}>
							{`${localeString(keyConstants.FORGOT_PASSWORD)}${localeString(
								keyConstants.QUESTION_MARK,
							)}`}
						</Text>
						<Text style={styles.defaultText}>
							{localeString(keyConstants.ENTER_YOUR_EMAIL_ID)}
						</Text>
						<ImageLoadComponent
							source={IMAGES.iconForgotScreen}
							style={styles.forgotImage}
						/>
						<Input
							value={email}
							width={normalScale(260)}
							label={`${localeString(keyConstants.EMAIL)}*`}
							placeholder={localeString(keyConstants.EMAIL_ID)}
							blurOnSubmit
							returnKeyType="done"
							isRTL={isRTL}
							onChangeText={text => this.onChangeEmail(text)}
							isError={errorEmailValidationMessage}
							onSubmitEditing={this.onBlur}
							autoCapitalize="none"
							errorMessage={localeString(keyConstants.EMAIL_VALIDATION_MESSAGE)}
							keyboardType="email-address"
						/>
					</ScrollView>
					<ButtonComponent
						viewStyle={styles.viewStyle}
						onPress={this.onSubmit}
						text={localeString(keyConstants.SEND_LINK)}
						isButtonDisable={!emailRegexEx.test(String(email).toLowerCase())}
					/>
					<ToastComponent
						isRTL={isRTL}
						isApiError={isApiError}
						toastMessage={toastMessage}
					/>
				</KeyboardAwareScrollView>
			</>
		);
	}
}

const mapStateToProps = state => {
	return {
		forgotEmailInfo: state.EmailScreenReducer,
		languageInfo: state.LanguageScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		forgotEmailActions: bindActionCreators(
			{
				...ForgotEmailActions,
			},
			dispatch,
		),
		setPasswordActions: bindActionCreators(
			{
				...SetPasswordActions,
			},
			dispatch,
		),
	};
};

EmailScreen.propTypes = {
	forgotEmailInfo: PropTypes.object.isRequired,
	forgotEmailActions: PropTypes.object.isRequired,
	setPasswordActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EmailScreen);
