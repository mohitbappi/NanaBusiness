export const ON_CHANGE_EMAIL_TEXT = 'on_change_email_text';
export const RESET_FORGOT_EMAIL_STATE = 'reset_forgot_email_state';
export const FORGOT_PASSWORD_SUCCESS = 'forgot_password_success';
export const FORGOT_PASSWORD_FAILURE = 'forgot_password_failure';
export const FORGOT_PASSWORD_LOADER = 'forgot_password_loader';
