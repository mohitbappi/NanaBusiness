import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, lineHeightScale } from '@device/normalize';
import fonts from '@assets/fonts';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		confirmationContainer: {
			backgroundColor: colors.white,
			zIndex: 100,
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			justifyContent: 'center',
			alignItems: 'center',
		},
		congratsImage: {
			width: normalScale(160),
			height: verticalScale(94),
		},
		congratulationText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(18),
			marginTop: verticalScale(14),
		},
		confirmationText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(16),
			paddingBottom: verticalScale(16),
			paddingHorizontal: normalize(18),
		},
		congratsButtonStyle: {
			position: 'absolute',
			left: normalScale(30),
			right: normalScale(30),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(20),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(10),
			paddingTop: verticalScale(20),
		},
		backButton: {
			paddingBottom: verticalScale(20),
			paddingHorizontal: normalScale(20),
		},
		scrollView: {
			paddingHorizontal: normalScale(20),
			paddingBottom: verticalScale(87),
		},
		chooseText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(22),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		defaultText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
			marginTop: verticalScale(11),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			lineHeight: lineHeightScale(17),
		},
		forgotImage: {
			width: normalScale(251),
			height: verticalScale(198),
			alignSelf: 'center',
			marginTop: verticalScale(31),
			marginBottom: verticalScale(14),
		},
		viewStyle: {
			position: 'absolute',
			left: normalScale(30),
			right: normalScale(30),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(24),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
