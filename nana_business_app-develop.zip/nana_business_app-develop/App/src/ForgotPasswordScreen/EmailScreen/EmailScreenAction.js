import { actions } from '@libapi/APIActionsBuilder';
import GetOTPOnEmailService from '@ForgotPassword/GetOTPOnEmailService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import * as ActionTypes from './ActionType';

/**
 * Action to set the email address.
 * @param {string} text
 * @returns
 */

export const onChangeEmail = text => {
	return {
		type: ActionTypes.ON_CHANGE_EMAIL_TEXT,
		payload: text,
	};
};

// Will reset the reducer.
export const onResetForgotState = () => ({ type: ActionTypes.RESET_FORGOT_EMAIL_STATE });

/**
 * Action to send the reset password link on the given email.
 * @param {object} mailDetails
 * @returns
 */

export const getOTPOnEmail = mailDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.FORGOT_PASSWORD_SUCCESS,
		ActionTypes.FORGOT_PASSWORD_FAILURE,
		ActionTypes.FORGOT_PASSWORD_LOADER,
	);
	const getOTPOnEmailService = new GetOTPOnEmailService(dispatchedActions);
	addBasicInterceptors(getOTPOnEmailService);
	dispatch(getOTPOnEmailService.makeRequest(mailDetails));
};
