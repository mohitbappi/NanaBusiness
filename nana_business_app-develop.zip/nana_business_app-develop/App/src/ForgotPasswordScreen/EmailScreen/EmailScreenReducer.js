import * as ActionTypes from './ActionType';

const initialState = {
	email: '',
	success: false,
	error: false,
	errorCode: null,
	loader: false,
};

const EmailScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_EMAIL_TEXT:
			return {
				...state,
				email: action.payload,
			};
		case ActionTypes.RESET_FORGOT_EMAIL_STATE:
			return {
				...state,
				success: false,
				error: false,
				errorCode: null,
				loader: false,
			};
		case ActionTypes.FORGOT_PASSWORD_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
			};
		case ActionTypes.FORGOT_PASSWORD_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.FORGOT_PASSWORD_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default EmailScreenReducer;
