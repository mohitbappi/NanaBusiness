import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		iconWishlist: {
			height: normalScale(24),
			width: normalScale(24),
		},
		iconDelete: {
			height: normalScale(14),
			width: normalScale(14),
		},
		cardContainer: {
			paddingVertical: verticalScale(20),
			marginHorizontal: normalScale(24),
			borderBottomColor: colors.grey,
			borderBottomWidth: moderateScale(1),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
		},
		noBorder: {
			borderBottomWidth: moderateScale(0),
			paddingBottom: verticalScale(0),
		},
		title: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		header: {
			marginHorizontal: normalScale(16),
		},
		cartUpdateBanner: {
			paddingVertical: verticalScale(3),
			paddingHorizontal: normalScale(6),
			backgroundColor: colors.skyBlue,
			alignItems: 'center',
			justifyContent: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		textCartUpdated: {
			color: colors.lightBlueShadowGrey,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		iconCartUpdated: {
			height: verticalScale(16),
			width: normalScale(16),
			marginHorizontal: normalScale(4),
		},
		scrollView: {
			borderTopColor: colors.grey,
			borderTopWidth: normalScale(1),
			borderRadius: moderateScale(8),
			marginTop: verticalScale(8),
			marginBottom: verticalScale(61),
		},
		paymentContainer: {
			paddingHorizontal: normalScale(16),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(4),
			borderTopColor: colors.grey,
			borderTopWidth: normalScale(4),
			marginTop: verticalScale(12),
		},
		totalView: {
			height: verticalScale(31),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			alignItems: 'center',
			marginTop: verticalScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		labelHeading: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			color: colors.black,
		},
		label: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.black,
		},
		amount: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.lightBlack,
		},
		totalAmount: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		detailView: {
			height: verticalScale(31),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			alignItems: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		greenAmount: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.green,
		},
		bottomView: {
			height: verticalScale(31),
			alignItems: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginBottom: verticalScale(5),
		},
		addressContainer: {
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(10),
		},
		addressView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(12),
			alignItems: 'center',
		},
		addressLabelHeading: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			color: colors.black,
		},
		iconEdit: {
			width: normalScale(27),
			height: verticalScale(30),
			resizeMode: 'contain',
		},
		userInfoContainer: {
			borderBottomWidth: verticalScale(1),
			borderColor: colors.greenShadow,
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingVertical: verticalScale(12),
		},
		mapImage: {
			width: normalScale(60),
			height: normalScale(60),
			borderRadius: normalScale(8),
		},
		addressDetailView: {
			marginLeft: isRTL ? 0 : normalScale(10),
			marginRight: isRTL ? normalScale(10) : 0,
			width: normalScale(200),
		},
		branch: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		address: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(6),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		viewStyle: {
			position: 'absolute',
			left: normalScale(16),
			right: normalScale(16),
			bottom: verticalScale(0),
			paddingTop: verticalScale(10),
			paddingBottom: verticalScale(11),
			backgroundColor: colors.white,
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
		},
		finalAmount: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			color: colors.darkBlue,
			marginLeft: -normalScale(2),
		},
		grandTotal: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			color: colors.black,
			marginTop: verticalScale(4),
		},
		footerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			marginTop: verticalScale(4),
		},
		finalLabel: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			color: colors.black,
			maxWidth: normalScale(100),
		},
		iconArrowDown: {
			width: normalScale(10),
			height: verticalScale(6),
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 8),
			marginRight: rtlFunctions.getMarginRight(isRTL, 8),
		},
		buttonStyle: {
			paddingHorizontal: normalScale(31),
		},
		viewDeliveryDate: {
			marginHorizontal: normalScale(16),
			marginTop: normalScale(8),
			paddingVertical: verticalScale(5),
			paddingHorizontal: normalScale(8),
			backgroundColor: colors.orange,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		textDeliveryDate: {
			flex: 1,
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		iconDeliveryDate: {
			height: verticalScale(16),
			width: normalScale(16),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 4),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 4),
		},
	});
};

export default createStyleSheet;
