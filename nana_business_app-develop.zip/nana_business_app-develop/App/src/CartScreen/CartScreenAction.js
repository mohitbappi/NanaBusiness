import { actions } from '@libapi/APIActionsBuilder';
import GetCartService from '@Cart/GetCartService';
import PlaceOrderService from '@Orders/PlaceOrderService';
import UpdateCartService from '@Cart/UpdateCartService';
import DeleteCartService from '@Cart/DeleteCartService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import EndPointHeaderInterceptor from '@interceptor/EndPointHeaderInterceptor';
import { endpointAddCart } from '@assets/Constants/Constants';
import * as ActionTypes from './ActionType';

export const onGetCartDetail = () => dispatch => {
	// Action to get the cart details.
	const dispatchedActions = actions(
		ActionTypes.GET_CART_SUCCESS,
		ActionTypes.GET_CART_FAILURE,
		ActionTypes.GET_CART_LOADER,
	);
	const getCartService = new GetCartService(dispatchedActions);
	addBasicInterceptors(getCartService);
	getCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCartService.makeRequest());
};

/**
 * Action to place the order.
 * @param {object} props
 * @returns
 */

export const onPlaceOrder = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.PLACE_ORDER_SUCCESS,
		ActionTypes.PLACE_ORDER_FAILURE,
		ActionTypes.PLACE_ORDER_LOADER,
	);
	const placeOrderService = new PlaceOrderService(dispatchedActions);
	addBasicInterceptors(placeOrderService);
	placeOrderService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(placeOrderService.makeRequest(props));
};

export const onResetCartState = () => ({ type: ActionTypes.RESET_CART_STATE });

export const onUpdateItem = index => {
	// Action to modify the quantity of the item at a given index.
	return {
		type: ActionTypes.UPDATE_CART,
		payload: index,
	};
};

export const onCartChanged = data => {
	// Action to set the updated data if cart modifies.
	return {
		type: ActionTypes.CART_CHANGED,
		payload: data,
	};
};

/**
 * Action to update the cart after modifying the quantity of any item.
 * @param {object} addCartItemDetail
 * @returns
 */

export const onUpdateCart = addCartItemDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.UPDATE_CART_SUCCESS,
		ActionTypes.UPDATE_CART_FAILURE,
		ActionTypes.UPDATE_CART_LOADER,
	);
	const updateCartService = new UpdateCartService(dispatchedActions);
	addBasicInterceptors(updateCartService);
	updateCartService.addRequestInterceptor(
		new EndPointHeaderInterceptor(endpointAddCart.cartScreen),
	);
	updateCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(updateCartService.makeRequest(addCartItemDetail));
};

/**
 * Action to delete the item from the cart.
 * @param {object} itemDetail
 * @returns
 */

export const onDeleteItem = itemDetail => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.DELETE_CART_ITEM_SUCCESS,
		ActionTypes.DELETE_CART_ITEM_FAILURE,
		ActionTypes.DELETE_CART_ITEM_LOADER,
	);
	const deleteCartService = new DeleteCartService(dispatchedActions);
	addBasicInterceptors(deleteCartService);
	deleteCartService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(deleteCartService.makeRequest(itemDetail));
};
