import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	errorData: null,
	loader: false,
	cartDetail: null,
	isPlacedOrder: false,
	isCartChanged: false,
	successCart: false,
	errorCart: false,
	errorCodeCart: '',
	cartLoader: false,
	orderDetails: null,
	deleteLoader: false,
	paymentDetail: null,
};

const CartScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_CART_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				cartDetail: action.payload,
				isPlacedOrder: false,
				isCartChanged: false,
			};
		case ActionTypes.GET_CART_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isPlacedOrder: false,
			};
		case ActionTypes.GET_CART_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isPlacedOrder: false,
				isCartChanged: false,
			};
		case ActionTypes.PLACE_ORDER_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isPlacedOrder: true,
				isCartChanged: false,
				orderDetails: action.payload.order_details ? action.payload.order_details[0] : null,
				paymentDetail: action.payload.payment,
			};
		case ActionTypes.PLACE_ORDER_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isPlacedOrder: true,
			};
		case ActionTypes.PLACE_ORDER_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload.error,
				errorData: action.payload,
				success: false,
				loader: false,
				isPlacedOrder: true,
				isCartChanged: false,
			};
		case ActionTypes.RESET_CART_STATE:
			return initialState;
		case ActionTypes.UPDATE_CART: {
			const cartDetailCopy = state.cartDetail;
			const index = action.payload;
			if (cartDetailCopy.items) {
				cartDetailCopy.items.splice(index, 1);
			}
			return {
				...state,
				cartDetail: cartDetailCopy,
			};
		}
		case ActionTypes.CART_CHANGED:
			return {
				...state,
				cartDetail: action.payload,
				isCartChanged: true,
			};
		case ActionTypes.UPDATE_CART_SUCCESS:
			return {
				...state,
				successCart: true,
				cartLoader: false,
				cartDetail: action.payload,
			};
		case ActionTypes.UPDATE_CART_LOADER:
			return {
				...state,
				successCart: false,
				cartLoader: true,
			};
		case ActionTypes.UPDATE_CART_FAILURE:
			return {
				...state,
				successCart: false,
				cartLoader: false,
				errorCart: true,
				errorCodeCart: '',
			};
		case ActionTypes.DELETE_CART_ITEM_SUCCESS:
			return {
				...state,
				successCart: true,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: false,
				deleteLoader: false,
				cartDetail: action.payload,
			};
		case ActionTypes.DELETE_CART_ITEM_LOADER:
			return {
				...state,
				successCart: false,
				errorCart: false,
				errorCodeCart: '',
				cartLoader: true,
				deleteLoader: false,
			};
		case ActionTypes.DELETE_CART_ITEM_FAILURE:
			return {
				...state,
				errorCart: true,
				errorCodeCart: action.payload,
				successCart: false,
				cartLoader: false,
				deleteLoader: false,
			};
		default:
			return state;
	}
};

export default CartScreenReducer;
