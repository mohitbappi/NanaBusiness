import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { View, FlatList, Text, Image, TouchableOpacity, Alert } from 'react-native';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import MapView, { Marker } from 'react-native-maps';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import CartItemCardComponent from '@CartItemCardComponent/CartItemCardComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import {
	toastShowTime,
	productMaxQuantity,
	fetchDataWithPagination,
	cartUpdated,
	notEligibleForCheckout,
	accountManager,
	salesExecutive,
	locatorConstants,
} from '@Constants/Constants';
import * as ItemListScreenAction from '@ItemListScreen/ItemListScreenAction';
import Loader from '@Loader/Loader';
import ListEmpty from '@ListEmpty/ListEmpty';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import navigations from '@routes/navigations';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import IMAGES from '@Images/index';
import OverlayComponent from '@OverlayComponent/OverlayComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import BranchPicker from '@HomeScreen/BranchPicker';
import * as HomeScreenActions from '@HomeScreen/HomeScreenAction';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import * as SelectPaymentModeActions from '@SelectPaymentModeScreen/SelectPaymentModeScreenAction';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import { constants } from '@RefreshControlComponent/Constants';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import AlertComponent from '@Util/AlertComponent';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import * as OrdersListingActions from '@OrdersScreen/OrdersScreenAction';
import getTestIdProps from '@Util/GetTestIdProps';
import { createStyleSheet } from './CartScreenStyle';
import * as CartDetailActions from './CartScreenAction';

class CartScreen extends Component {
	constructor(props) {
		super(props);
		this.branchLimit = fetchDataWithPagination.limit;
		this.branchPage = fetchDataWithPagination.page;
		this.state = {
			isApiError: false,
			toastMessage: '',
			isFocused: [],
			selectedIndex: null,
			updatedQuantity: 0,
			isVisible: false,
			isShowBranchPicker: false,
			isPlaceButtonEnable: false,
			isCartUpdated: false,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.getCartDetail();
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const {
			cartDetailInfo,
			itemListScreenInfo,
			pullToRefreshActions,
			homeScreenActions,
			cartDetailActions,
			selectPaymentModeActions,
			navigation,
			itemListScreenAction,
			ordersListingActions,
		} = this.props;
		const {
			isPlacedOrder,
			success,
			cartDetail,
			orderDetails,
			error,
			errorCode,
			errorData,
			isCartChanged,
			successCart,
			errorCart,
			errorCodeCart,
		} = cartDetailInfo;
		const { selectedIndex } = this.state;
		const { items } = cartDetail || {};
		const {
			isUpdateList,
			isDeletedFromWishList,
			isAddedToWishList,
			success: successAddWishlist,
			error: errorWishList,
			errorCode: errorCodeWishList,
		} = itemListScreenInfo;
		if (success && prevProps.cartDetailInfo.success !== success) {
			// Will hide the pull to refresh loader.
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (successCart && items && items.length === 0) {
			// API call to get the cart count.
			homeScreenActions.onGetCartCount();
		}
		if (success && isPlacedOrder && prevProps.cartDetailInfo !== cartDetailInfo) {
			cartDetailActions.onResetCartState();
			selectPaymentModeActions.onSetPaymentMode(localeString(keyConstants.ONLINE_PAYMENT), 0);
			// The payment mode is offline payment (cash on delivery). After placing order user will navigate to order details.
			navigation.navigate(navigations.ORDER_DETAIL_NAVIGATION, {
				id: orderDetails && orderDetails.id,
				orderData: orderDetails,
				isNavigateBack: false,
				isShowAlert: false,
			});
			ordersListingActions.onHandleApiCall(true);
			logCustomEventOnBraze('orderPlaced', {
				orderId: orderDetails?.id,
				userId: orderDetails?.user_id,
				price: orderDetails?.total_amount,
				date: new Date(),
			});
		}
		if (success && !isPlacedOrder && prevProps.cartDetailInfo.success !== success) {
			// Will check if any item is out of stock.
			const tempArray = items ? Array(items.length).fill(false) : [];
			this.setState({
				isFocused: tempArray,
			});
			if (items) {
				this.isPlaceOrderEnabled(items);
			}
		}
		if (isCartChanged && prevProps.cartDetailInfo !== cartDetailInfo) {
			// Will check the price or available quantity of any of the item is changed.
			if (items) {
				this.isPlaceOrderEnabled(items);
			}
		}
		if (
			successAddWishlist &&
			(isDeletedFromWishList || isAddedToWishList) &&
			isUpdateList &&
			prevProps.itemListScreenInfo.success !== success
		) {
			// Will show toast after adding/removing the item from the wishlist.
			this.setState(
				{
					toastMessage: isDeletedFromWishList
						? `${localeString(keyConstants.REMOVED_FROM_WISHLIST)}`
						: `${localeString(keyConstants.ADDED_TO_WISHLIST)}`,
					isApiError: true,
				},
				() => {
					setTimeout(() => {
						this.setState({
							isApiError: false,
						});
					}, toastShowTime);
					itemListScreenAction.onResetItemListState();
				},
			);
			cartDetailActions.onUpdateItem(selectedIndex);
			this.getCartDetail();
		}
		if (error && isPlacedOrder && prevProps.cartDetailInfo.error !== error) {
			if (errorCode === notEligibleForCheckout) {
				setTimeout(() => {
					this.getAlert();
				}, 200);
			} else if (errorCode === cartUpdated) {
				this.setState(
					{
						isCartUpdated: true,
					},
					() => {
						setTimeout(() => {
							this.getCartUpdationAlert(errorData);
						}, 200);
					},
				);
			} else {
				ErrorAlertComponent(errorData, this.onPlaceOrder);
			}
		}
		if (errorWishList && prevProps.itemListScreenInfo.error !== error) {
			const retryMethod = () =>
				items[selectedIndex] && items[selectedIndex].is_wishlisted
					? this.onDeleteFromWishlist(items[selectedIndex], selectedIndex)
					: this.onAddToWishlist(selectedIndex, items[selectedIndex].id);
			ErrorAlertComponent(errorCodeWishList, retryMethod);
		}
		if (errorCart && prevProps.cartDetailInfo.errorCart !== errorCart) {
			// Will show alert if delete item api fails.
			if (errorCodeCart.error === keyConstants.ADD_ITEM_ERROR) {
				this.setState(
					{
						toastMessage: localeString(keyConstants.ADD_ITEM_ERROR),
						isApiError: true,
					},
					() => {
						setTimeout(() => {
							this.setState({
								isApiError: false,
							});
						}, toastShowTime);
					},
				);
			}
			const retryMethod = () =>
				this.onDeleteItem(
					selectedIndex,
					items[selectedIndex].vendor_organization_id,
					items[selectedIndex].id,
				);
			ErrorAlertComponent(errorCodeCart, retryMethod);
		}
	}

	isPlaceOrderEnabled = items => {
		// Function to enable/disable the place order button.
		items.map(element => {
			if (
				element.is_available &&
				!element.status_out_of_stock &&
				(element.in_stock !== undefined ? element.in_stock : true)
			) {
				this.setState({
					isPlaceButtonEnable: true,
				});
				return;
			}
			this.setState({
				isPlaceButtonEnable: false,
			});
		});
	};

	getAlert = () => {
		// Will show alert if error is NOT_ELIGIBLE_FOR_CHECKOUT.
		const { homeScreenActions } = this.props;
		return Alert.alert(
			'',
			localeString(keyConstants.NOT_ELIGIBLE_FOR_CHECKOUT),
			[
				{
					text: localeString(keyConstants.OK),
					onPress: () => {
						homeScreenActions.onGetCartCount();
						this.getCartDetail();
					},
				},
			],
			{ cancelable: false },
		);
	};

	getCartUpdationAlert = data => {
		const { cartDetailActions } = this.props;
		return Alert.alert(
			'',
			localeString(keyConstants.CART_ITEM_UPDATED_ALERT),
			[
				{
					text: localeString(keyConstants.OK),
					onPress: () => {
						cartDetailActions.onCartChanged(data);
					},
				},
			],
			{ cancelable: false },
		);
	};

	getCartDetail = () => {
		// API call to get the cart detail.
		const { cartDetailActions } = this.props;
		cartDetailActions.onGetCartDetail();
	};

	checkItemsExist = (items, error, isPlacedOrder) => {
		if (error && !isPlacedOrder) {
			return false;
		}
		// else if (items && items.length !== 0) {
		return true;
		// }
	};

	onSelectBranch = index => {
		// Function to select the delivery address.
		const { homeScreenInfo, homeScreenActions, ordersListingActions } = this.props;
		const { branchListing } = homeScreenInfo;
		const onPerformAction = () => {
			homeScreenActions.onSetSelectedBranch(branchListing[index], index);
			this.setState(
				{
					isShowBranchPicker: false,
				},
				() => {
					this.onUpdateBranch();
					this.getCartDetail();
					homeScreenActions.onGetCartCount();
					ordersListingActions.onHandleApiCall(true);
				},
			);
		};
		if (branchListing?.[index]?.zone_id) {
			onPerformAction();
		} else {
			// If zone id is null the alert will come.
			const alertOptions = {
				message: localeString(keyConstants.ZONE_ERROR),
				onPressYes: onPerformAction,
				onPressNo: () =>
					this.setState({
						isShowBranchPicker: false,
					}),
			};
			AlertComponent(alertOptions);
		}
	};

	onUpdateBranch = () => {
		const { homeScreenInfo, userDetails, homeScreenActions } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization || {};
		const queryParams = { id };
		homeScreenActions.onUpdateBranch(queryParams);
	};

	onEndReached = () => {
		this.branchPage += 1;
		this.onGetBranches(true);
	};

	onCloseBranch = () => {
		this.setState({
			isShowBranchPicker: false,
		});
	};

	onClose = (value, index) => {
		this.setState({
			isVisible: value,
			selectedIndex: index,
		});
	};

	getActionItems = (isRTL, cartData) => {
		// Popup to show the options delete item from cart and removed from or add to wishlist.
		const styles = createStyleSheet(isRTL);
		return cartData.map((item, index) => {
			return (
				<TouchableOpacity
					activeOpacity={0.8}
					onPress={item.action}
					style={[styles.cardContainer, index === cartData.length - 1 && styles.noBorder]}
					{...item.extraProps}>
					<Image source={item.image} style={styles.image} />
					<Text style={styles.title}>{item.title}</Text>
				</TouchableOpacity>
			);
		});
	};

	onPressClose = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onPressGoToHome = () => {
		// Will navigate to the home screen and reset the reducer.
		const { cartDetailActions, navigation } = this.props;
		cartDetailActions.onResetCartState();
		navigation.navigate(navigations.HOME_NAVIGATION);
	};

	onFocus = (index, updatedQuantity) => {
		const { isFocused } = this.state;
		const isFocusedCopy = isFocused;
		isFocusedCopy[index] = true;
		this.setState({
			isFocused: isFocusedCopy,
			selectedIndex: index,
			updatedQuantity,
		});
	};

	onBlur = (vendorId, warehouseId, id, minQuantity) => {
		const { isFocused, selectedIndex, updatedQuantity } = this.state;
		const isFocusedCopy = isFocused;
		isFocusedCopy[selectedIndex] = false;
		this.setState({
			isFocused: isFocusedCopy,
			updatedQuantity: 0,
		});
		this.onUpdateQuantity(
			updatedQuantity,
			2,
			selectedIndex,
			vendorId,
			warehouseId,
			id,
			minQuantity,
			true,
		);
	};

	onChangeText = text => {
		// Function to modify the item quantity.
		this.setState({
			updatedQuantity: text === '' ? '' : parseInt(text, 10),
		});
	};

	onUpdateQuantity = (
		itemQuantity,
		actionType,
		index,
		vendorId,
		warehouseId,
		id,
		minQuantity,
		isCheckError,
	) => {
		const { isConnected, cartDetailActions } = this.props;
		const { isFocused } = this.state;
		const updatedQuantity = this.getUpdatedQuantity(itemQuantity, actionType);
		if (parseInt(updatedQuantity, 10) < parseInt(minQuantity, 10) && isCheckError) {
			// Will show alert if updated quantity is less than minimum quantity.
			const isFocusedCopy = isFocused;
			isFocusedCopy[index] = false;
			this.setState({
				isFocused: isFocusedCopy,
			});
			this.onShowAlert(index, vendorId, id);
		} else if (parseInt(updatedQuantity, 10) > productMaxQuantity && isCheckError) {
			// Will show toast if updated quantity is greater than product maximum quantity.
			this.setState({
				toastMessage: `${localeString(
					keyConstants.MAXIMUM_QUANTITY,
				)} ${productMaxQuantity}`,
				isApiError: true,
			});
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		} else {
			// Will modify the existing quantity with the new one.
			this.setState({
				updatedQuantity,
				selectedIndex: index,
			});
			const queryparam = {};
			queryparam.item_id = id;
			queryparam.quantity = updatedQuantity;
			queryparam.warehouse_id = warehouseId;
			queryparam.vendor_id = vendorId;
			if (isConnected) {
				cartDetailActions.onUpdateCart(queryparam);
			} else {
				const isFocusedCopy = isFocused;
				isFocusedCopy[index] = false;
				this.setState({
					isFocused: isFocusedCopy,
				});
			}
		}
	};

	getUpdatedQuantity = (itemQuantity, actionType) => {
		switch (actionType) {
			case 0: // To decrease item quantity.
				return itemQuantity - 1;
			case 1: // To increase item quantity.
				return itemQuantity + 1;
			default:
				// To replace item quantity.
				return itemQuantity;
		}
	};

	onShowAlert = (index, vendorId, id) => {
		this.onClose(false, null);
		const alertOptions = {
			message: localeString(keyConstants.DELETE_FROM_CART),
			yesText: localeString(keyConstants.YES),
			noText: localeString(keyConstants.NO),
			onPressYes: () => this.onDeleteItem(index, vendorId, id),
		};
		setTimeout(() => {
			AlertComponent(alertOptions);
		}, 200);
	};

	onDeleteItem = (index, vendorId, id) => {
		// API call to delete the item from the cart.
		const { cartDetailActions } = this.props;
		this.setState({
			updatedQuantity: 0,
			selectedIndex: index,
		});
		const itemDetail = {
			item_id: id,
			vendor_organization_id: vendorId,
		};
		cartDetailActions.onDeleteItem(itemDetail);
	};

	onAddToWishlist = (index, id) => {
		// API call to add the item to the wishlist.
		const { itemListScreenAction } = this.props;
		const queryparam = {
			id,
		};
		itemListScreenAction.onAddToWishlist(queryparam, index);
		this.onClose(false, index);
	};

	onDeleteFromWishlist = (item, index) => {
		// API call to remove the item from the wishlist.
		const { itemListScreenAction } = this.props;
		const queryparam = {
			id: item.id,
		};
		itemListScreenAction.onDeleteFromWishlist(queryparam);
		this.onClose(false, index);
	};

	navigateTo = item => {
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_DETAILS_NAVIGATION, { id: item.id });
	};

	keyExtractor = (item, index) => {
		return index.toString();
	};

	getFinalAmount = (total_amount, total_vat_amount, delivery_fee) => {
		return getValueInDecimal(total_vat_amount + total_amount + delivery_fee);
	};

	onEditBranch = () => {
		const { userDetails, navigation } = this.props;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		if (role === accountManager || role === salesExecutive) {
			// Will navigate to the screen to select customer organization if role is customerSuperAdmin or sales Executive.
			navigation.navigate(navigations.SELECT_CUSTOMER_USER_NAVIGATION);
		} else {
			// Will get the branches if role is customer or customerAdmin.
			this.branchPage = fetchDataWithPagination.page;
			this.setState({
				isShowBranchPicker: true,
			});
			this.onGetBranches(false);
		}
	};

	onGetBranches = isOverwriteExistingList => {
		// API call to get the branches.
		const { homeScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.branchLimit;
		queryParams.page = this.branchPage;
		homeScreenActions.onGetBranches(queryParams, isOverwriteExistingList);
	};

	onSelectPaymentMode = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.SELECT_PAYMENT_MODE_NAVIGATION);
	};

	onPlaceOrder = () => {
		// API call to place the order.
		const { cartDetailInfo, cartDetailActions, homeScreenInfo, userDetails } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { cartDetail } = cartDetailInfo;
		const { items } = cartDetail || {};
		const { id } = branchDetail || userDetails.user.organization || {};
		const itemDetails = {};
		items.forEach(item => {
			const details = {};
			details.item_price = item.offer_price ? item.offer_price : item.price;
			details.quantity = item.count_in_cart;
			itemDetails[item.id] = details;
		});
		const queryparams = {
			items: itemDetails,
			branch_id: id,
		};
		cartDetailActions.onPlaceOrder(queryparams);
	};

	onRefresh = () => {
		// API call to get the cart detail while pull to refresh.
		this.getCartDetail();
	};

	render() {
		const {
			languageInfo,
			cartDetailInfo,
			itemListScreenInfo,
			homeScreenInfo,
			userDetails,
			refreshControlComponentInfo,
			configurableFileInfo,
		} = this.props;
		const {
			isApiError,
			toastMessage,
			isFocused,
			updatedQuantity,
			isVisible,
			selectedIndex,
			isShowBranchPicker,
			isPlaceButtonEnable,
			isCartUpdated,
		} = this.state;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { loader, cartDetail, isPlacedOrder, cartLoader, error, errorCode } = cartDetailInfo;
		const { isUpdateList, loader: wishListLoader } = itemListScreenInfo;
		const {
			items,
			total_amount,
			total_vat_amount,
			discount,
			delivery_fee,
			expected_delivery,
			expected_delivery_ar,
		} = cartDetail || {};
		const {
			branchDetail,
			branchListing,
			branchCount,
			activeBranchIndex,
			cartCount,
			error: branchError,
			errorCode: branchErrorCode,
			isDashboard,
		} = homeScreenInfo;
		const { remoteConfigData } = configurableFileInfo;
		const branchLoader = homeScreenInfo.loader;
		const { latitude, longitude, name, address_one, address_two, id, name_ar } =
			branchDetail || userDetails.user.organization || {};
		let cartData = [];
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		if (items && items.length !== 0) {
			cartData = [
				{
					title:
						items[selectedIndex] && items[selectedIndex].is_wishlisted
							? localeString(keyConstants.REMOVE_FROM_WISHLIST)
							: localeString(keyConstants.ADD_TO_WISHLIST),
					image:
						items[selectedIndex] && items[selectedIndex].is_wishlisted
							? IMAGES.iconWishlistFilled
							: IMAGES.iconWishlist,
					style: styles.iconWishlist,
					action: () =>
						items[selectedIndex] && items[selectedIndex].is_wishlisted
							? this.onDeleteFromWishlist(items[selectedIndex], selectedIndex)
							: this.onAddToWishlist(selectedIndex, items[selectedIndex].id),
					extraProps: getTestIdProps(
						`${locatorConstants.addWishlist}${selectedIndex + 1}`,
					),
				},
				{
					title: localeString(keyConstants.DELETE),
					image: IMAGES.iconDeleteRed,
					style: styles.iconDelete,
					action: () =>
						this.onShowAlert(
							selectedIndex,
							items[selectedIndex].vendor_organization_id,
							items[selectedIndex].id,
						),
					extraProps: getTestIdProps(
						`${locatorConstants.deleteItem}${selectedIndex + 1}`,
					),
				},
			];
		}
		if (!cartCount && !loader) {
			// Will show empty cart screen if cart is empty.
			return (
				<ConfimationModal
					title={localeString(keyConstants.EMPTY_CART)}
					description={`${localeString(keyConstants.YOUR_CART_EMPTY)}`}
					onPress={this.onPressGoToHome}
					buttonTitle={localeString(keyConstants.GO_TO_HOME)}
					hasButton
					hasIconCross
					onGoBack={this.onPressClose}
					imageSource={IMAGES.iconCartEmpty}
				/>
			);
		}
		return (
			<View style={styles.container}>
				<BranchPicker
					isRTL={isRTL}
					branchArray={branchListing}
					isShowBranchPicker={isShowBranchPicker}
					activeBranchIndex={activeBranchIndex}
					onPress={this.onSelectBranch}
					loader={branchLoader}
					onEndReached={() => branchListing.length !== branchCount && this.onEndReached()}
					onPressClose={this.onCloseBranch}
					placeholder={name}
					branchId={id}
					error={branchError && !isDashboard}
					errorCode={branchErrorCode}
					onReload={this.onEditBranch}
				/>
				<OverlayComponent
					isRTL={isRTL}
					isVisible={isVisible}
					onClose={() => this.onClose(false, null)}
					component={this.getActionItems(isRTL, cartData)}
				/>
				{loader &&
					!isFetchingForPullToRefresh &&
					(isPlacedOrder ? <Spinner size="large" /> : <Loader size="large" />)}
				{(cartLoader || (wishListLoader && isUpdateList)) && <Spinner size="large" />}
				<View style={styles.header}>
					<Header
						text={`${localeString(keyConstants.CART)} (${items ? items.length : 0})`}
						hasIconClose
						hasIconCart
						onPressClose={this.onPressClose}
						extraProps={{ closeIcon: getTestIdProps(locatorConstants.closeCheckout) }}
					/>
				</View>
				{error && !isPlacedOrder ? (
					<ErrorComponent
						isRTL={isRTL}
						errorCode={errorCode}
						onCallApi={this.getCartDetail}
					/>
				) : items && items.length !== 0 ? (
					<ScrollViewComponent
						showsVerticalScrollIndicator={false}
						style={styles.scrollView}
						onRefresh={this.onRefresh}
						componentType={constants.scrollView}>
						<>
							{isCartUpdated && (
								<View style={styles.cartUpdateBanner}>
									<ImageLoadComponent
										source={IMAGES.iconHistory}
										style={styles.iconCartUpdated}
									/>
									<Text style={styles.textCartUpdated}>
										{localeString(keyConstants.CART_ITEM_UPDATED)}
									</Text>
								</View>
							)}
							{(!isRTL && expected_delivery) || (isRTL && expected_delivery_ar) ? (
								<View style={styles.viewDeliveryDate}>
									<ImageLoadComponent
										source={IMAGES.iconExpectedDelivery}
										style={styles.iconDeliveryDate}
									/>
									<Text style={styles.textDeliveryDate}>
										{`${localeString(keyConstants.EXPECTED_DELIVERY)}: ${
											isRTL ? expected_delivery_ar : expected_delivery
										}`}
									</Text>
								</View>
							) : null}
							<FlatList
								data={items}
								showsVerticalScrollIndicator={false}
								renderItem={({ item, index }) => {
									const subTitleText = `${
										isRTL ? item.brand_name_ar : item.brand_name
									}${
										item.sub_category_name
											? ` | ${
													isRTL
														? item.sub_category_name_ar
														: item.sub_category_name
											  }`
											: ''
									}`;
									return (
										<CartItemCardComponent
											image={item.images && item.images['x-small']}
											itemName={isRTL ? item.name_ar : item.name}
											category={`${subTitleText}`}
											price={`${currencyFormatter(
												getValueInDecimal(item.offer_price_with_vat),
											)} ${localeString(keyConstants.SAR)}`}
											originalPrice={`${currencyFormatter(
												getValueInDecimal(item.price_with_vat),
											)} ${localeString(keyConstants.SAR)}`}
											isSourceUri
											value={
												isFocused[index]
													? `${updatedQuantity}`
													: `${item.count_in_cart}`
											}
											quantity={
												isFocused[index]
													? `${updatedQuantity}`
													: `${item.count_in_cart}`
											}
											onFocus={() => this.onFocus(index, item.count_in_cart)}
											onBlur={() =>
												this.onBlur(
													item.vendor_organization_id,
													item.warehouse_id,
													item.id,
													item.minimum_quantity,
												)
											}
											onChangeText={this.onChangeText}
											onPressDecrease={() =>
												this.onUpdateQuantity(
													item.count_in_cart,
													0,
													index,
													item.vendor_organization_id,
													item.warehouse_id,
													item.id,
													item.minimum_quantity,
													true,
												)
											}
											onPressIncrease={() =>
												this.onUpdateQuantity(
													item.count_in_cart,
													1,
													index,
													item.vendor_organization_id,
													item.warehouse_id,
													item.id,
													item.minimum_quantity,
													true,
												)
											}
											onDeleteProduct={() => this.onClose(true, index)}
											onGetProductDetail={() => this.navigateTo(item)}
											hasFooterView
											isDelete
											isAvailable={
												item.is_available &&
												!item.status_out_of_stock &&
												(item.in_stock !== undefined ? item.in_stock : true)
											}
											priceCheck={parseFloat(item.offer_price_with_vat)}
											originalPriceCheck={parseFloat(item.price_with_vat)}
											itemsPerPacket={item.items_per_packet}
											valueOfItem={item.value_of_item}
											unit={isRTL ? item.unit_ar : item.unit}
											pricePerItem={item.price_per_item}
											isUpdated={item.is_updated}
											minimumQuantity={item.minimum_quantity}
											extraProps={{
												openWishDelete: getTestIdProps(
													`${locatorConstants.openWishDelete}${
														index + 1
													}`,
												),
												increaseItem: getTestIdProps(
													`${locatorConstants.increaseItem}${index + 1}`,
												),
												decreaseItem: getTestIdProps(
													`${locatorConstants.decreaseItem}${index + 1}`,
												),
												addSpecificAmount: getTestIdProps(
													`${locatorConstants.addSpecificAmount}${
														index + 1
													}`,
												),
											}}
										/>
									);
								}}
								keyExtractor={this.keyExtractor}
							/>
							<View style={styles.paymentContainer}>
								<View style={styles.totalView}>
									<Text style={styles.labelHeading}>
										{localeString(keyConstants.PAYMENT_DETAILS)}
									</Text>
								</View>
								<View style={styles.totalView}>
									<Text style={styles.label}>
										{localeString(keyConstants.ITEM_TOTAL)}
									</Text>
									<Text style={styles.amount}>
										{`${currencyFormatter(
											getValueInDecimal(total_amount),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
								</View>
								<View style={styles.detailView}>
									<Text style={styles.label}>
										{localeString(keyConstants.DELIVERY_FEE)}
									</Text>
									<Text style={styles.amount}>
										{`${currencyFormatter(
											getValueInDecimal(delivery_fee),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
								</View>
								<View style={styles.detailView}>
									<Text style={styles.label}>
										{localeString(keyConstants.VAT)}
									</Text>
									<Text style={styles.amount}>
										{`${currencyFormatter(
											getValueInDecimal(total_vat_amount),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
								</View>
								<View style={styles.detailView}>
									<Text style={styles.label}>
										{localeString(keyConstants.GRAND_TOTAL)}
									</Text>
									<Text style={styles.totalAmount}>
										{`${currencyFormatter(
											this.getFinalAmount(
												total_amount,
												total_vat_amount,
												delivery_fee,
											),
										)} ${localeString(keyConstants.SAR)}`}
									</Text>
								</View>
								{discount > 0 ? (
									<View style={styles.bottomView}>
										<Text style={styles.label}>
											{localeString(keyConstants.YOUR_SAVINGS)}
										</Text>
										<Text style={styles.greenAmount}>
											{`- ${currencyFormatter(
												getValueInDecimal(discount),
											)} ${localeString(keyConstants.SAR)}`}
										</Text>
									</View>
								) : null}
							</View>
							<View style={styles.addressContainer}>
								<View style={styles.addressView}>
									<Text style={styles.addressLabelHeading}>
										{localeString(keyConstants.DELIVERY_ADDRESS)}
									</Text>
									<TouchableOpacity
										onPress={this.onEditBranch}
										activeOpacity={0.8}>
										<Image source={IMAGES.iconEdit} style={styles.iconEdit} />
									</TouchableOpacity>
								</View>
								{latitude && longitude && (
									<View style={styles.userInfoContainer}>
										<MapView
											style={styles.mapImage}
											initialRegion={{
												latitude: parseFloat(latitude),
												longitude: parseFloat(longitude),
												latitudeDelta: 0.005,
												longitudeDelta: 0.005,
											}}
											zoomEnabled={false}>
											<Marker
												coordinate={{
													latitude: parseFloat(latitude),
													longitude: parseFloat(longitude),
												}}
												draggable={false}
												onLoad={() => this.forceUpdate()}
												image={IMAGES.iconSmallPin}
											/>
										</MapView>
										<View style={styles.addressDetailView}>
											<Text style={styles.branch}>
												{isRTL ? name_ar || name : name}
											</Text>
											<Text style={styles.address}>
												{`${address_one}${
													address_two ? `, ${address_two}` : ''
												}`}
											</Text>
										</View>
									</View>
								)}
							</View>
						</>
					</ScrollViewComponent>
				) : (
					<ListEmpty text={localeString(keyConstants.CART_IS_EMPTY)} />
				)}
				{items && items.length !== 0 && (
					<View style={styles.viewStyle}>
						{/* Total amount of the cart including delivery fee and vat. */}
						<View>
							<Text style={styles.finalAmount}>
								{`${currencyFormatter(
									this.getFinalAmount(
										total_amount,
										total_vat_amount,
										delivery_fee,
									),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
							<Text style={styles.grandTotal}>
								{localeString(keyConstants.GRAND_TOTAL)}
							</Text>
						</View>
						{remoteConfigData?.placeOrder ? (
							<ButtonComponent
								buttonStyle={styles.buttonStyle}
								onPress={this.onPlaceOrder}
								text={localeString(keyConstants.PLACE_ORDER)}
								isButtonDisable={!isPlaceButtonEnable}
								extraProps={getTestIdProps(locatorConstants.placeOrder)}
							/>
						) : null}
					</View>
				)}
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		cartDetailInfo: state.CartScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		homeScreenInfo: state.HomeScreenReducer,
		itemListScreenInfo: state.ItemListScreenReducer,
		selectPaymentModeInfo: state.SelectPaymentModeScreenReducer,
		isConnected: state.NoConnectionHandleReducer.isConnected,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		cartDetailActions: bindActionCreators({ ...CartDetailActions }, dispatch),
		itemListScreenAction: bindActionCreators({ ...ItemListScreenAction }, dispatch),
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		selectPaymentModeActions: bindActionCreators({ ...SelectPaymentModeActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		ordersListingActions: bindActionCreators({ ...OrdersListingActions }, dispatch),
	};
};

CartScreen.propTypes = {
	pullToRefreshActions: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	cartDetailActions: PropTypes.object.isRequired,
	selectPaymentModeActions: PropTypes.object.isRequired,
	itemListScreenAction: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	cartDetailInfo: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	itemListScreenInfo: PropTypes.object.isRequired,
	userDetails: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	isConnected: PropTypes.bool.isRequired,
	ordersListingActions: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(CartScreen);
