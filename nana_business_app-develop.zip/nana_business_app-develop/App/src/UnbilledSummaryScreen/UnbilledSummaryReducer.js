import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	unbilledSummary: [],
	count: 0,
};

const UnbilledSummaryReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_UNBILLED_SUMMARY_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			const { total_amount, payments } = action.payload;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				unbilledSummary: isOverwriteExistingList
					? [...state.unbilledSummary, ...payments]
					: payments,
				total_amount,
				count: action.payload.count,
			};
		}
		case ActionTypes.GET_UNBILLED_SUMMARY_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_UNBILLED_SUMMARY_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		default:
			return state;
	}
};

export default UnbilledSummaryReducer;
