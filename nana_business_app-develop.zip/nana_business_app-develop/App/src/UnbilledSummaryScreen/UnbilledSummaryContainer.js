/* import libraries */
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as UnbilledSummaryActions from './UnbilledSummaryAction';

/* import components */
import UnbilledSummaryComponent from './UnbilledSummaryComponent';

const UnbilledSummaryContainer = props => {
	const customProps = { ...props }; // Will store all the props.
	return <UnbilledSummaryComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		unbilledSummaryInfo: state.UnbilledSummaryReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		unbilledSummaryActions: bindActionCreators({ ...UnbilledSummaryActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(UnbilledSummaryContainer);
