/* import libraries */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';

/* import utils */
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

/* import components */
import Header from '@Header/Header';
import Loader from '@Loader/Loader';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ListEmpty from '@ListEmpty/ListEmpty';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import CardComponent from '@TransactionCard/CardComponent';

// import constants
import { creditLineConstants, fetchDataWithPagination } from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

/* import styles */
import { createStyleSheet } from './UnbilledSummaryScreenStyle';

class UnbilledSummaryUI extends Component {
	keyExtractor = (item, index) => {
		return index.toString();
	};

	listFooterComponent = () => {
		const { isRTL, unbilledSummary, count } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached = count === unbilledSummary.length || count < unbilledSummary.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	render() {
		const {
			isRTL,
			loader,
			onGoBack,
			unbilledSummary,
			count,
			error,
			errorCode,
			onEndReached,
			onCallApi,
			getTransactionDetail,
			onRefresh,
			totalAmount,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.UNBILLED_AMOUNT)}
						onPressBack={onGoBack}
						hasIconBack
					/>
				</View>
				{loader && <Loader size="large" />}
				{/* Error component if error occurs. */}
				{error ? (
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onCallApi} />
				) : (
					<>
						<View style={styles.amountContainer}>
							<Text style={styles.title}>
								{localeString(keyConstants.TOTAL_UNBILLED_AMOUNT)}
							</Text>
							<Text style={styles.amount}>
								{`${currencyFormatter(
									getValueInDecimal(totalAmount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						{unbilledSummary.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_TRANSACTIONS_AMOUNT)} />
						) : (
							<FlatListComponent
								keyboardShouldPersistTaps="handled"
								data={unbilledSummary}
								showsVerticalScrollIndicator={false}
								renderItem={({ item }) => {
									return (
										<CardComponent
											isRTL={isRTL}
											item={item}
											onPress={() => getTransactionDetail(item)}
											creditDebitType={
												item.type === creditLineConstants.credit
											} // return true if transaction type is credit and false if debit.
											isShowTimeDate // Will show date and time.
											date={item.created_at}
										/>
									);
								}}
								keyExtractor={this.keyExtractor}
								onEndReached={() =>
									unbilledSummary.length !== count && onEndReached()
								}
								ListFooterComponent={
									unbilledSummary.length !== 0 &&
									count > fetchDataWithPagination.limit &&
									this.listFooterComponent()
								}
								onEndReachedThreshold={0.5}
								componentType={constants.flatList}
								onRefresh={onRefresh}
							/>
						)}
					</>
				)}
			</View>
		);
	}
}

UnbilledSummaryUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	unbilledSummary: PropTypes.array.isRequired,
	count: PropTypes.number.isRequired,
	loader: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onCallApi: PropTypes.func.isRequired,
	getTransactionDetail: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	totalAmount: PropTypes.number.isRequired,
};

export default UnbilledSummaryUI;
