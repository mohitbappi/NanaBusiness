// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { fetchDataWithPagination } from '@Constants/Constants';

// import utils
import navigations from '@routes/navigations';

// import components
import UnbilledSummaryUI from './UnbilledSummaryUI';

class UnbilledSummaryComponent extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onFetchData(false);
			pullToRefreshActions.onHandlePullToRefresh(false);
		});
	}

	componentDidUpdate(prevProps) {
		const { unbilledSummaryInfo, pullToRefreshActions } = this.props;
		const { success } = unbilledSummaryInfo;
		if (success && prevProps.unbilledSummaryInfo.success !== unbilledSummaryInfo.success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onFetchData = isOverwriteExistingList => {
		// API call to get the unbilled summary.
		const { unbilledSummaryActions } = this.props;
		const queryParams = {
			limit: this.limit,
			page: this.page,
		};
		unbilledSummaryActions.onGetUnbilledSummary(queryParams, isOverwriteExistingList);
	};

	onGoBack = () => {
		// Will go back to the previous screen.
		const { navigation } = this.props;
		navigation.goBack();
	};

	onEndReached = () => {
		// Will call the API for the next page with limit 10.
		const { unbilledSummaryInfo } = this.props;
		const { loader } = unbilledSummaryInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	getTransactionDetail = transactionDetail => {
		// Will navigate to the transaction detail screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.TRANSACTION_DETAIL_NAVIGATION, {
			transactionDetail,
			date: transactionDetail.created_at,
			hasNote: true,
		});
	};

	onRefresh = () => {
		// Will call api while pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	render() {
		const { languageInfo, unbilledSummaryInfo, refreshControlComponentInfo } = this.props;
		const { bottomLoader } = this.state;
		const { isRTL } = languageInfo;
		const {
			loader,
			unbilledSummary,
			count,
			error,
			errorCode,
			total_amount,
		} = unbilledSummaryInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<UnbilledSummaryUI
				isRTL={isRTL}
				loader={loader && !bottomLoader && !isFetchingForPullToRefresh}
				onGoBack={this.onGoBack}
				unbilledSummary={unbilledSummary} // object contains unbilled summary details.
				count={count}
				error={error}
				errorCode={errorCode}
				onEndReached={this.onEndReached}
				onCallApi={() => this.onFetchData(false)}
				getTransactionDetail={this.getTransactionDetail}
				onRefresh={this.onRefresh}
				totalAmount={total_amount}
			/>
		);
	}
}

UnbilledSummaryComponent.propTypes = {
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	unbilledSummaryInfo: PropTypes.object.isRequired,
	unbilledSummaryActions: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
};

export default UnbilledSummaryComponent;
