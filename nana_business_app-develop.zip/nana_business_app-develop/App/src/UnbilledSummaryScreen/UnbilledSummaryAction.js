import APIActionsBuilder from '@libapi/APIActionsBuilder';
import GetUnbilledSummaryService from '@BalanceDetails/GetUnbilledSummaryService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import * as ActionTypes from './ActionType';

/**
 * Action to fetch the unbilled summary.
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetUnbilledSummary = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_UNBILLED_SUMMARY_SUCCESS,
		ActionTypes.GET_UNBILLED_SUMMARY_FAILURE,
		ActionTypes.GET_UNBILLED_SUMMARY_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getUnbilledSummaryService = new GetUnbilledSummaryService(dispatchedActions);
	addBasicInterceptors(getUnbilledSummaryService);
	getUnbilledSummaryService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getUnbilledSummaryService.makeRequest(props));
};

export default onGetUnbilledSummary;
