import * as ActionTypes from './ActionType';

const initialState = {
	isModalVisible: false,
};

const RoleScreenReducer = (state = initialState, action = {}) => {
	if (action.type === ActionTypes.SET_MODAL_VISIBILITY) {
		return {
			...state,
			isModalVisible: action.payload,
		};
	}
	return state;
};

export default RoleScreenReducer;
