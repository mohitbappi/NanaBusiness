import * as ActionTypes from './ActionType';

export const onSetModalVisibility = value => {
	return {
		type: ActionTypes.SET_MODAL_VISIBILITY,
		payload: value,
	};
};

export default onSetModalVisibility;
