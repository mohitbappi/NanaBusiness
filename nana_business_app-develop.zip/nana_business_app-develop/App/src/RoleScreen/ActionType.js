export const SET_MODAL_VISIBILITY = 'set_modal_visibility';

export default SET_MODAL_VISIBILITY;
