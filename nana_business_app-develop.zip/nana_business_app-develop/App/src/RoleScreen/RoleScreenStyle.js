import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale } from '@device/normalize';
import fonts from '@assets/fonts';

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingHorizontal: normalScale(10),
		},
		scrollView: {
			paddingHorizontal: normalScale(20),
			paddingBottom: verticalScale(10),
		},
		chooseText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(22),
			marginTop: verticalScale(60),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
		},
		defaultText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalRegular : fonts.LatoRegular,
			fontSize: normalize(12),
			marginTop: verticalScale(11),
			alignSelf: isRTL ? 'flex-end' : 'flex-start',
			lineHeight: verticalScale(17),
		},
		roleView: {
			marginTop: verticalScale(52),
		},
		boxStyle: {
			height: verticalScale(87),
			width: '100%',
			paddingTop: isRTL ? verticalScale(4) : 0,
		},
		boxStyleOne: {
			height: verticalScale(91),
		},
		boxStyleTwo: {
			height: verticalScale(75),
		},
		buttonStyle: {
			justifyContent: 'flex-end',
			paddingHorizontal: normalScale(20),
			marginBottom: verticalScale(24),
			paddingTop: verticalScale(10),
			backgroundColor: colors.white,
		},
	});
};

export default createStyleSheet;
