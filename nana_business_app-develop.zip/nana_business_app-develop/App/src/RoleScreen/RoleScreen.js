import React, { Component } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import SelectComponent from '@SelectComponent/SelectComponent';
import { normalScale, verticalScale } from '@device/normalize';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { keyConstants } from '@Constants/KeyConstants';
import navigations from '@routes/navigations';
import { USER_TYPE } from '@Constants/Constants';
import * as RoleScreenActions from './RoleScreenAction';
import { createStyleSheet } from './RoleScreenStyle';

class RoleScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			activeIndex: 0,
			roleArray: [],
		};
	}

	static getDerivedStateFromProps() {
		return {
			roleArray: [
				{
					label: localeString(keyConstants.CUSTOMER),
					detail: localeString(keyConstants.CUSTOMER_DETAIL_INFO),
				},
				{
					label: localeString(keyConstants.VENDOR),
					detail: localeString(keyConstants.VENDOR_DETAIL_INFO),
				},
				{
					label: localeString(keyConstants.COLLECTOR),
					detail: localeString(keyConstants.COLLECTOR_DETAIL_INFO),
				},
			],
		};
	}

	onSelectRole = index => {
		this.setState({
			activeIndex: index,
		});
	};

	onSubmit = () => {
		const { activeIndex } = this.state;
		const { navigation } = this.props;
		let userType;
		if (activeIndex === 0) {
			userType = USER_TYPE.CUSTOMER;
		} else if (activeIndex === 1) {
			userType = USER_TYPE.VENDOR;
		} else {
			userType = USER_TYPE.COLLECTOR;
		}
		navigation.navigate(navigations.INTRO_NAVIGATION, { userType });
	};

	render() {
		const { activeIndex, roleArray } = this.state;
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				<ScrollView
					contentContainerStyle={styles.scrollView}
					showsVerticalScrollIndicator={false}>
					<Text style={styles.chooseText}>
						{localeString(keyConstants.CHOOSE_YOUR_ROLE)}
					</Text>
					<Text style={styles.defaultText}>
						{localeString(keyConstants.DEFAULT_ROLE)}
					</Text>
					<View style={styles.roleView}>
						{roleArray.map((item, index) => {
							return (
								<SelectComponent
									top={verticalScale(24)}
									boxStyle={[
										styles.boxStyle,
										index === 1 && styles.boxStyleOne,
										index === 2 && styles.boxStyleTwo,
									]}
									onPress={() => this.onSelectRole(index)}
									width={normalScale(260)}
									height={
										index === 0
											? verticalScale(87)
											: index === 1
											? verticalScale(91)
											: verticalScale(75)
									}
									isSelected={activeIndex === index}
									isRTL={isRTL}
									caption={item.label}
									detail={item.detail}
								/>
							);
						})}
					</View>
				</ScrollView>
				<ButtonComponent
					viewStyle={styles.buttonStyle}
					text={localeString(keyConstants.SUBMIT)}
					onPress={this.onSubmit}
				/>
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		roleInfo: state.RoleScreenReducer,
		languageInfo: state.LanguageScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		roleScreenActions: bindActionCreators({ ...RoleScreenActions }, dispatch),
	};
};

RoleScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(RoleScreen);
