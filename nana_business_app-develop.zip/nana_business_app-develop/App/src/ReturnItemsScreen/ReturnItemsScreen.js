import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, Text, FlatList, ScrollView } from 'react-native';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import * as SalesInvoiceActions from '@SalesInvoiceScreen/SalesInvoiceScreenAction';
import { toastShowTime } from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import Header from '@Header/Header';
import { localeString } from '@assets/Localization';
import { keyConstants } from '@Constants/KeyConstants';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { downloadFile } from '@Util/DownloadFile';
import ToastComponent from '@ToastComponent/ToastComponent';
import { removeSpaces } from '@Util/GetFormattedString';
import DownloadSalesInvoice from '@Components/DownloadSalesInvoice';
import ProductCardComponent from '@Products/ProductCardComponent';
import { createStyleSheet } from './ReturnItemsScreenStyle';

class ReturnItemsScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidUpdate(prevProps) {
		const { salesInvoiceInfo, route } = this.props;
		const { success, isDownload, downloadUrl } = salesInvoiceInfo;
		const { shipment_id, customer_organization } = route.params;
		if (
			success &&
			isDownload &&
			prevProps.salesInvoiceInfo.success !== salesInvoiceInfo.success
		) {
			// if sales invoice download api return success
			const downloadFileName = `${removeSpaces(
				customer_organization && customer_organization.name,
			)}-${shipment_id}`;
			downloadFile(
				downloadUrl,
				downloadFileName,
				() => {
					this.onShowFileStatus(`${localeString(keyConstants.DOWNLOADING)}...`);
				},
				() => {
					this.onShowFileStatus(localeString(keyConstants.SUCCESSFULLY_DOWNLOADED));
				},
				() => {
					this.onShowFileStatus(localeString(keyConstants.FAILED_DOWNLOADING));
				},
			);
		}
	}

	getHeader = isRTL => {
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.header}>
				<Header
					onPressBack={this.onGoBack}
					hasIconBack
					text={localeString(keyConstants.INVOICE_DETAIL)}
				/>
			</View>
		);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	getReturnedItems = (isRTL, items) => {
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.topViewStyle}>
				<Text style={styles.item}>{`${localeString(keyConstants.RETURNED_ITEMS)}`}</Text>
				<FlatList
					data={items}
					showsHorizontalScrollIndicator={false}
					horizontal
					inverted={isRTL}
					renderItem={({ item }) => {
						return (
							<ProductCardComponent
								title={isRTL ? item.name_ar : item.name}
								image={item && item.images && item.images.small}
								subtitle={`${item.quantity} x ${getValueInDecimal(
									item.offer_price ? item.offer_price : item.price,
								)} ${localeString(keyConstants.SAR)}`}
								discountedPrice={
									item.quantity *
									(item.offer_price ? item.offer_price : item.price)
								}
								isDiscountedPrice
								containerStyle={styles.containerStyle}
								titleStyle={styles.titleStyle}
								discountedPriceStyle={styles.discountedPriceStyle}
							/>
						);
					}}
					keyExtractor={this.keyExtractor}
				/>
			</View>
		);
	};

	getPaymentDetails = isRTL => {
		const styles = createStyleSheet(isRTL);
		const { route } = this.props;
		const { item_total, vat_amount, total_amount, items } = route.params;
		return (
			<View style={styles.paymentView}>
				<Text style={styles.item}>{localeString(keyConstants.PAYMENT_DETAILS)}</Text>
				<View style={styles.detailView}>
					<Text style={styles.textStyle}>{localeString(keyConstants.ITEM_TOTAL)}</Text>
					<Text style={styles.textStyle}>
						{`${getValueInDecimal(item_total)} ${localeString(keyConstants.SAR)}`}
					</Text>
				</View>
				<View style={styles.totalView}>
					<Text style={styles.textStyle}>{localeString(keyConstants.VAT)}</Text>
					<Text style={styles.textStyle}>
						{`${getValueInDecimal(vat_amount)} ${localeString(keyConstants.SAR)}`}
					</Text>
				</View>
				<View style={styles.totalView}>
					<Text style={styles.textStyle}>{localeString(keyConstants.DELIVERY_FEE)}</Text>
					<Text style={styles.textStyle}>
						{`${getValueInDecimal(
							items[0]?.delivery_fee + items[0]?.delivery_fee_vat,
						)} ${localeString(keyConstants.SAR)}`}
					</Text>
				</View>
				<View style={styles.pay}>
					<Text style={styles.textStyle}>{localeString(keyConstants.TOTAL_AMOUNT)}</Text>
					<Text style={styles.totalAmount}>
						{`${getValueInDecimal(
							total_amount + items[0]?.delivery_fee + items[0]?.delivery_fee_vat,
						)} ${localeString(keyConstants.SAR)}`}
					</Text>
				</View>
			</View>
		);
	};

	onShowFileStatus = message => {
		this.setState({
			toastMessage: message,
			isApiError: true,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	render() {
		const { isApiError, toastMessage } = this.state;
		const { languageInfo, route, salesInvoiceInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { return_si_id, items } = route.params;
		const { loader } = salesInvoiceInfo;
		return (
			<View style={styles.container}>
				{loader && <Spinner size="large" />}
				{this.getHeader(isRTL)}
				<ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
					{this.getReturnedItems(isRTL, items)}
					{this.getPaymentDetails(isRTL)}
				</ScrollView>
				<DownloadSalesInvoice
					isRTL={isRTL}
					title={localeString(keyConstants.DOWNLOAD_INVOICE)}
					salesInvoiceId={return_si_id}
					hasButton
				/>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		salesInvoiceInfo: state.SalesInvoiceScreenReducer,
	};
};

const mapDispacthToProps = dispatch => {
	return {
		salesInvoiceActions: bindActionCreators({ ...SalesInvoiceActions }, dispatch),
	};
};

ReturnItemsScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	salesInvoiceInfo: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispacthToProps)(ReturnItemsScreen);
