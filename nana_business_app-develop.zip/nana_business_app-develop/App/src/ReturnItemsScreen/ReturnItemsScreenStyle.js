import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		header: {
			marginHorizontal: normalScale(16),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
			justifyContent: 'space-between',
		},
		scrollView: {
			marginBottom: verticalScale(55),
		},
		topViewStyle: {
			borderBottomWidth: normalScale(4),
			borderBottomColor: colors.grey,
			paddingTop: verticalScale(8),
			paddingBottom: verticalScale(4),
			paddingHorizontal: normalScale(16),
		},
		item: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			marginBottom: verticalScale(9),
		},
		containerStyle: {
			width: normalScale(215),
			backgroundColor: colors.whitishGrey,
			paddingHorizontal: normalScale(8),
			paddingVertical: verticalScale(8),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 10),
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 10),
			borderRadius: moderateScale(8),
		},
		titleStyle: {
			width: normalScale(120),
			height: verticalScale(29),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
		},
		discountedPriceStyle: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		paymentView: {
			paddingVertical: verticalScale(16),
			paddingHorizontal: normalScale(16),
		},
		detailView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			paddingVertical: verticalScale(8),
			borderBottomColor: colors.grey,
			borderBottomWidth: normalScale(1),
			marginTop: verticalScale(4),
			borderRadius: moderateScale(4),
		},
		textStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		totalView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			paddingVertical: verticalScale(8),
			borderBottomColor: colors.grey,
			justifyContent: 'space-between',
			borderBottomWidth: normalScale(1),
			borderRadius: moderateScale(4),
		},
		pay: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(8),
		},
		totalAmount: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
		},
	});
};

export default createStyleSheet;
