import GetCollectorDetailsService from '@CashierServices/GetCollectorDetailsService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import APIActionsBuilder from '@libapi/APIActionsBuilder';
import * as ActionTypes from './ActionType';

/**
 * Action to get the collector detail.
 * @param {object} props
 * @returns
 */

export const onGetCollectorDetail = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_COLLECTOR_DETAIL_SUCCESS,
		ActionTypes.GET_COLLECTOR_DETAIL_FAILURE,
		ActionTypes.GET_COLLECTOR_DETAIL_LOADER,
	)
		.addSuccessExtra({ isAppendInExistingList })
		.build();
	const getCollectorDetailsService = new GetCollectorDetailsService(dispatchedActions);
	addBasicInterceptors(getCollectorDetailsService);
	getCollectorDetailsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCollectorDetailsService.makeRequest(props));
};

export default onGetCollectorDetail;
