import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { moderateScale, normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		cardView: {
			marginHorizontal: normalScale(16),
			marginTop: verticalScale(8),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			paddingVertical: verticalScale(16),
			justifyContent: 'space-between',
			borderBottomColor: colors.greenShadow,
			borderRadius: moderateScale(8),
			borderBottomWidth: normalScale(1),
		},
		date: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		amount: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
		},
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.light),
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		container: {
			backgroundColor: colors.white,
			flex: 1,
		},
		headerContainer: {
			marginHorizontal: normalScale(16),
			marginBottom: verticalScale(8),
		},
		amountContainer: {
			borderRadius: normalScale(8),
			marginHorizontal: normalScale(16),
			paddingVertical: verticalScale(12),
			backgroundColor: colors.skyBlue,
			alignItems: 'center',
			marginBottom: verticalScale(16),
		},
		title: {
			color: colors.blackGreyWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
		},
		totalAmount: {
			color: colors.black,
			fontSize: normalize(16),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			marginTop: verticalScale(4),
		},
		subTitle: {
			color: colors.darkBlue,
			paddingHorizontal: normalScale(16),
			paddingVertical: verticalScale(3),
			backgroundColor: colors.lightGreen,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
		},
		scrollViewStyle: {
			flex: 1,
		},
	});
};

export default createStyleSheet;
