// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Text, View } from 'react-native';

// import components
import Header from '@Header/Header';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ListEmpty from '@ListEmpty/ListEmpty';
import Loader from '@Loader/Loader';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@assets/Constants/KeyConstants';
import { fetchDataWithPagination, plus } from '@assets/Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import utils
import { getFormattedDate } from '@Util/GetFormattedDate';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';

// import styles
import { createStyleSheet } from './ReceivablesDetailScreenStyle';

class ReceivablesDetailUI extends Component {
	keyExtractor = (item, index) => index.toString();

	renderItem = ({ item }) => {
		const { created_at, amount } = item;
		const { isRTL } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<Text style={styles.date}>{getFormattedDate(created_at)}</Text>
				<Text style={styles.amount}>
					{`${plus}${currencyFormatter(getValueInDecimal(amount))} ${localeString(
						keyConstants.SAR,
					)}`}
				</Text>
			</View>
		);
	};

	listFooterComponent = () => {
		// Will show loader while pagination.
		const { isRTL, collectorDeposits, count } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached = count === collectorDeposits.length || count < collectorDeposits.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	render() {
		const {
			isRTL,
			onGoBack,
			loader,
			collectorDeposits,
			count,
			error,
			errorCode,
			onEndReached,
			onRefresh,
			totalDepositAmount,
			collectorName,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<View style={styles.headerContainer}>
					<Header text={collectorName} hasIconBack onPressBack={onGoBack} />
				</View>
				{error ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.amountContainer}>
							<Text style={styles.title}>
								{localeString(keyConstants.TOTAL_AMOUNT)}
							</Text>
							<Text style={styles.totalAmount}>
								{`${currencyFormatter(
									getValueInDecimal(totalDepositAmount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<Text style={styles.subTitle}>
							{localeString(keyConstants.RECEIVED_DATE)}
						</Text>
						<FlatListComponent
							keyboardShouldPersistTaps="handled"
							data={collectorDeposits}
							keyExtractor={this.keyExtractor}
							renderItem={this.renderItem}
							showsVerticalScrollIndicator={false}
							onEndReached={() =>
								collectorDeposits.length !== count && onEndReached()
							}
							ListFooterComponent={
								collectorDeposits.length !== 0 &&
								count > fetchDataWithPagination.limit &&
								this.listFooterComponent()
							}
							onEndReachedThreshold={0.5}
							ListEmptyComponent={() => (
								<ListEmpty text={localeString(keyConstants.NO_DEPOSITS_FOUND)} />
							)}
							contentContainerStyle={
								collectorDeposits.length === 0 ? styles.scrollViewStyle : null
							}
							onRefresh={onRefresh}
							componentType={constants.flatList}
						/>
					</>
				)}
			</View>
		);
	}
}

ReceivablesDetailUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onGoBack: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	collectorDeposits: PropTypes.array.isRequired,
	onEndReached: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	count: PropTypes.any.isRequired,
	loader: PropTypes.bool.isRequired,
	totalDepositAmount: PropTypes.number.isRequired,
	collectorName: PropTypes.string.isRequired,
};

export default ReceivablesDetailUI;
