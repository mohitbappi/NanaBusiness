// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { fetchDataWithPagination } from '@assets/Constants/Constants';

// import components
import ReceivablesDetailUI from './ReceivablesDetailUI';

class ReceivablesDetailComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			bottomLoader: false,
		};
	}

	componentDidMount() {
		const { pullToRefreshActions } = this.props;
		this.onFetchData(false);
		pullToRefreshActions.onHandlePullToRefresh(false); // Will hide the pull to refresh loader
	}

	componentDidUpdate(prevProps) {
		const { receivablesDetailInfo, pullToRefreshActions } = this.props;
		const { success } = receivablesDetailInfo;
		if (success && prevProps.receivablesDetailInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onFetchData = isAppendInExistingList => {
		// API call to get the cashier listing.
		const { onGetCollectorDetail, route } = this.props;
		const { collectorDetail } = route.params;
		const data = {
			id: collectorDetail?.collector_user_id,
			queryParams: {
				limit: this.limit,
				page: this.page,
			},
		};
		onGetCollectorDetail(data, isAppendInExistingList);
	};

	onGoBack = () => {
		const { navigation } = this.props;
		navigation.goBack();
	};

	onEndReached = () => {
		const { receivablesDetailInfo } = this.props;
		const { loader } = receivablesDetailInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onRefresh = () => {
		// Will call api after pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	render() {
		const { bottomLoader } = this.state;
		const {
			languageInfo,
			refreshControlComponentInfo,
			receivablesDetailInfo,
			route,
		} = this.props;
		const {
			collectorDeposits,
			count,
			loader,
			error,
			errorCode,
			totalDepositAmount,
		} = receivablesDetailInfo;
		const { collectorDetail } = route.params;
		const { isRTL } = languageInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<ReceivablesDetailUI
				isRTL={isRTL}
				onGoBack={this.onGoBack}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader}
				collectorDeposits={collectorDeposits}
				count={count}
				error={error}
				errorCode={errorCode}
				onEndReached={this.onEndReached}
				onRefresh={this.onRefresh}
				totalDepositAmount={totalDepositAmount}
				collectorName={collectorDetail?.collector_name}
			/>
		);
	}
}

ReceivablesDetailComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	onGetCollectorDetail: PropTypes.func.isRequired,
	receivablesDetailInfo: PropTypes.object.isRequired,
	route: PropTypes.object.isRequired,
};

export default ReceivablesDetailComponent;
