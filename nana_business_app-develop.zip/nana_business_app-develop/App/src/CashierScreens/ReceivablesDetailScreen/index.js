export { default } from './ReceivablesDetailContainer';
