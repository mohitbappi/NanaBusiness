export const GET_COLLECTOR_DETAIL_SUCCESS = 'get_collector_detail_success';
export const GET_COLLECTOR_DETAIL_LOADER = 'get_collector_detail_loader';
export const GET_COLLECTOR_DETAIL_FAILURE = 'get_collector_detail_failure';
