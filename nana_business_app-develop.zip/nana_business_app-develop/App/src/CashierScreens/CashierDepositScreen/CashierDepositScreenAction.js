import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetCashierDepositService from '@CashierServices/GetCashierDepositService';
import CreateDepositRequestService from '@CashierServices/CreateDepositRequestService';
import * as ActionTypes from './ActionType';

/**
 * Function to call API for fetching the list of pending deposits.
 * @param {object} props
 * @param {boolean} appendToExistingList
 * @returns
 */

export const onGetCashierDeposits = (props, appendToExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_CASHIER_PENDING_DEPOSITS_SUCCESS,
		ActionTypes.GET_CASHIER_PENDING_DEPOSITS_FAILURE,
		ActionTypes.GET_CASHIER_PENDING_DEPOSITS_LOADER,
	)
		.addSuccessExtra(appendToExistingList)
		.build();
	const getCashierDepositService = new GetCashierDepositService(dispatchedActions);
	addBasicInterceptors(getCashierDepositService);
	getCashierDepositService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCashierDepositService.makeRequest(props));
};

/**
 * Function to call API for create deposit.
 * @param {object} props
 * @param {boolean} appendToExistingList
 * @returns
 */

export const onCreateCashierDeposit = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.CREATE_DEPOSIT_REQUEST_SUCCESS,
		ActionTypes.CREATE_DEPOSIT_REQUEST_FAILURE,
		ActionTypes.CREATE_DEPOSIT_REQUEST_LOADER,
	);
	const createDepositRequestService = new CreateDepositRequestService(dispatchedActions);
	addBasicInterceptors(createDepositRequestService);
	createDepositRequestService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(createDepositRequestService.makeRequest(props));
};

// Will reset the reducer.
export const onResetState = () => ({ type: ActionTypes.RESET_CASHIER_DEPOSIT_STATE });
