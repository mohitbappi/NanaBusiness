import * as ActionTypes from './ActionType';

const initialState = {
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	pendingDepositListing: [],
	totalAmount: 0,
	count: 0,
	isCreateDeposit: false,
};

const CashierDepositScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.GET_CASHIER_PENDING_DEPOSITS_SUCCESS: {
			// Action will call if api call succeed.
			const appendToExistingList = action.extra; // boolean to append data in the existing list.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				pendingDepositListing: appendToExistingList
					? [...state.pendingDepositListing, ...action.payload.pending_deposits]
					: action.payload.pending_deposits,
				count: action.payload.count, // count of the pending deposit list
				totalAmount: action.payload.total_pending_deposits, // total pending amount
				isCreateDeposit: false,
			};
		}
		case ActionTypes.GET_CASHIER_PENDING_DEPOSITS_LOADER:
			// Action will call if api calling is in progress.
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCreateDeposit: false,
			};
		case ActionTypes.GET_CASHIER_PENDING_DEPOSITS_FAILURE:
			// Action will call if api calling is failed.
			return {
				...state,
				error: true,
				errorCode: action.payload, // Will store error reason
				success: false,
				loader: false,
				isCreateDeposit: false,
			};
		case ActionTypes.CREATE_DEPOSIT_REQUEST_SUCCESS: {
			// Action will call if api call succeed.
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCreateDeposit: true,
			};
		}
		case ActionTypes.CREATE_DEPOSIT_REQUEST_LOADER:
			// Action will call if api calling is in progress.
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
				isCreateDeposit: true,
			};
		case ActionTypes.CREATE_DEPOSIT_REQUEST_FAILURE:
			// Action will call if api calling is failed.
			return {
				...state,
				error: true,
				errorCode: action.payload, // Will store error reason
				success: false,
				loader: false,
				isCreateDeposit: true,
			};
		case ActionTypes.RESET_CASHIER_DEPOSIT_STATE:
			return initialState;
		default:
			return state;
	}
};

export default CashierDepositScreenReducer;
