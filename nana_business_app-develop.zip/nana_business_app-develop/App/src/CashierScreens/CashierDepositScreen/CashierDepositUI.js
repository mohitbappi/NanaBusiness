// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Text, View } from 'react-native';

// import components
import Header from '@Header/Header';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ImageInputComponent from '@ImageInputComponent/ImageInputComponent';
import ListEmpty from '@ListEmpty/ListEmpty';
import Search from '@Search/Search';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import PopupConfirmationComponent from '@PopupConfirmationComponent/PopupConfirmationComponent';
import ConfimationModal from '@ConfimationModal/ConfimationModal';
import Loader from '@Loader/Loader';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import Spinner from '@Spinner/Spinner';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@assets/Constants/KeyConstants';
import { constants } from '@RefreshControlComponent/Constants';
import { fetchDataWithPagination, invoiceImg, paymentReceivedStatus } from '@Constants/Constants';

// import utils
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDate } from '@Util/GetFormattedDate';

// import styles
import { createStyleSheet } from './CashierDepositScreenStyle';

class CashierDepositUI extends Component {
	keyExtractor = (item, index) => index.toString();

	listFooterComponent = () => {
		const { isRTL, pendingDepositListing, pendingDepositCount } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached =
			pendingDepositCount === pendingDepositListing.length ||
			pendingDepositCount < pendingDepositListing.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return <Text style={styles.noData}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>;
	};

	renderItem = ({ item }) => {
		const { collector_name, date, amount, id, status } = item;
		const { isRTL, onGetDetail, selectedItem, onSelectItem } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<InvoiceCardComponent
					name={collector_name}
					dateLabel={`${localeString(keyConstants.CREATED_DATE)}: `}
					date={getFormattedDate(date)}
					amount={`${currencyFormatter(getValueInDecimal(amount))} ${localeString(
						keyConstants.SAR,
					)}`}
					isShowStatus // Boolean to show status
					status={status}
					isDisable
					onPress={() => onGetDetail()}
					showCheckBox={
						status !== paymentReceivedStatus.deposited &&
						status !== paymentReceivedStatus.approved
					} // Boolean to show radio button to select value.
					selectedItem={selectedItem}
					id={id}
					onSelect={() => onSelectItem(id, amount)}
				/>
			</View>
		);
	};

	onUpload = () => this.onUploadImage.onClickAddImage();

	onPressAccept = () => {
		// Will open image upload popup.
		const { onPressNo } = this.props;
		this.onUpload();
		onPressNo();
	};

	render() {
		const {
			isRTL,
			onSearch,
			searchText,
			onRefresh,
			onDeposit,
			onPressNo,
			onPressClose,
			isPopupVisible,
			onCloseConfirmationPopup,
			pendingDepositListing,
			pendingDepositCount,
			onEndReached,
			amount,
			loader,
			totalAmount,
			isButtonDisable,
			error,
			errorCode,
			isConfirmationModalVisible,
			imageLoader,
			isCreateDeposit,
			onImageUploaded,
			notificationCount,
			onPressNotification,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && !isCreateDeposit && <Loader size="large" />}
				{imageLoader && <Spinner size="large" />}
				<PopupConfirmationComponent
					isRTL={isRTL}
					isPopupVisible={isPopupVisible}
					rejectText={localeString(keyConstants.NO)}
					onPressReject={onPressNo}
					acceptText={localeString(keyConstants.YES)}
					onPressAccept={this.onPressAccept}
					message={`${localeString(
						keyConstants.SURE_DEPOSIT_REQUEST,
					)} ${currencyFormatter(getValueInDecimal(amount))} ${localeString(
						keyConstants.SAR,
					)}`}
					title={localeString(keyConstants.DEPOSIT_REQUEST)}
					onPressClose={onPressClose}
				/>
				<ImageInputComponent
					selectedImageTitle={invoiceImg}
					hideInput
					isRTL={isRTL}
					onRef={ref => {
						this.onUploadImage = ref;
					}}
					onImageUploaded={onImageUploaded}
				/>
				{isConfirmationModalVisible && (
					<ConfimationModal
						title={localeString(keyConstants.MONEY_DEPOSITED)}
						description={`${currencyFormatter(
							getValueInDecimal(amount),
						)} ${localeString(keyConstants.SAR)} ${localeString(
							keyConstants.MONEY_DEPOSITED_BANK,
						)}`}
						hasIconCross
						onGoBack={onCloseConfirmationPopup}
					/>
				)}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.DEPOSITS)}
						hasIconNotification
						onPressNotification={onPressNotification}
						hasIconPendingDeposists
						notificationCount={notificationCount}
					/>
				</View>
				{error && !isCreateDeposit ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.amountContainer}>
							<Text style={styles.title}>
								{localeString(keyConstants.AMOUNT_TO_BE_DEPOSITED)}
							</Text>
							<Text style={styles.amount}>
								{`${currencyFormatter(
									getValueInDecimal(totalAmount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<View style={styles.searchContainer}>
							<Search
								hasSearchIcon
								placeholder={localeString(keyConstants.SEARCH_BY_COLLECTOR_NAME)}
								onChangeText={text => onSearch(text)}
								value={searchText}
							/>
						</View>
						<FlatListComponent
							keyboardShouldPersistTaps="handled"
							data={pendingDepositListing}
							keyExtractor={this.keyExtractor}
							renderItem={this.renderItem}
							showsVerticalScrollIndicator={false}
							onEndReached={() =>
								pendingDepositListing.length !== pendingDepositCount &&
								onEndReached()
							}
							ListFooterComponent={
								pendingDepositListing.length !== 0 &&
								pendingDepositCount > fetchDataWithPagination.limit &&
								this.listFooterComponent()
							}
							onEndReachedThreshold={0.5}
							ListEmptyComponent={() => (
								<ListEmpty text={localeString(keyConstants.NO_SHIPMENTS_FOUND)} />
							)}
							contentContainerStyle={
								pendingDepositListing.length === 0
									? styles.scrollViewStyle
									: styles.margin
							}
							onRefresh={onRefresh}
							componentType={constants.flatList}
						/>
						<View style={styles.buttonView}>
							<ButtonComponent
								buttonStyle={styles.depositButtonStyle}
								text={`${localeString(
									keyConstants.DEPOSIT_TO_BANK,
								)} (${currencyFormatter(getValueInDecimal(amount))}${localeString(
									keyConstants.SAR,
								)})`}
								onPress={onDeposit}
								isButtonDisable={isButtonDisable}
							/>
						</View>
					</>
				)}
			</View>
		);
	}
}

CashierDepositUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onPressNotification: PropTypes.func.isRequired,
	searchText: PropTypes.string.isRequired,
	onSearch: PropTypes.func.isRequired,
	onGetDetail: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	onSelectItem: PropTypes.func.isRequired,
	onDeposit: PropTypes.func.isRequired,
	onPressNo: PropTypes.func.isRequired,
	onPressClose: PropTypes.func.isRequired,
	isPopupVisible: PropTypes.bool.isRequired,
	onCloseConfirmationPopup: PropTypes.func.isRequired,
	pendingDepositListing: PropTypes.object.isRequired,
	pendingDepositCount: PropTypes.number.isRequired,
	onEndReached: PropTypes.func.isRequired,
	selectedItem: PropTypes.array.isRequired,
	amount: PropTypes.number.isRequired,
	loader: PropTypes.bool.isRequired,
	totalAmount: PropTypes.number.isRequired,
	isButtonDisable: PropTypes.bool.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	isConfirmationModalVisible: PropTypes.bool.isRequired,
	imageLoader: PropTypes.bool.isRequired,
	isCreateDeposit: PropTypes.bool.isRequired,
	onImageUploaded: PropTypes.func.isRequired,
	notificationCount: PropTypes.number.isRequired,
};

export default CashierDepositUI;
