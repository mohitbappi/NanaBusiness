// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// import constants
import { APIConstants, fetchDataWithPagination, paymentReceivedStatus } from '@Constants/Constants';

// import navigations
import cashierNavigations from '@config/routes/cashierNavigations';

// import components
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import CashierDepositUI from './CashierDepositUI';

class CashierDepositComponent extends Component {
	constructor(props) {
		super(props);
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.props = props.customProps;
		this.state = {
			searchText: '',
			bottomLoader: false,
			selectedItem: null,
			amount: 0,
			isPopupVisible: false,
			isButtonDisable: true,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onGetNotificationCount();
			this.page = fetchDataWithPagination.page; // resetting the page to 1
			this.onFetchData(false);
			pullToRefreshActions.onHandlePullToRefresh(false); // Will hide the pull to refresh loader
		});
	}

	componentDidUpdate(prevProps) {
		const { pendingDepositInfo, pullToRefreshActions } = this.props;
		const { success, error, errorCode, isCreateDeposit } = pendingDepositInfo;
		if (success && prevProps.pendingDepositInfo.success !== success) {
			// Will hide the bottom loader if pagination occurs and pull to refresh loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (error && isCreateDeposit && errorCode && prevProps.pendingDepositInfo.error !== error) {
			// Will show popup in case of error.
			ErrorAlertComponent(errorCode, this.onCreateDeposit);
		}
	}

	onGetNotificationCount = () => {
		const { receivablesActions } = this.props;
		receivablesActions.onGetNotificationCount();
	};

	onFetchData = appendToExistingList => {
		const { cashierDepositActions } = this.props;
		const { searchText } = this.state;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			// Will call API using search value if user enters it.
			queryParams.name = searchText;
		}
		cashierDepositActions.onGetCashierDeposits(queryParams, appendToExistingList);
	};

	onCreateDeposit = () => {
		// Will create deposit request.
		const { selectedItem } = this.state;
		const { pendingDepositInfo, imageInputInfo, cashierDepositActions } = this.props;
		const { pendingDepositListing } = pendingDepositInfo;
		const { image } = imageInputInfo;
		const index = pendingDepositListing.findIndex(ele => ele.id === selectedItem);
		const { id, reference_id, status, deposit_id } = pendingDepositListing[index] || {};
		let endPoint = '';
		const body = {
			image,
		};
		if (reference_id) {
			body.reference_id = reference_id;
		}
		if (status === paymentReceivedStatus.rejected) {
			endPoint = APIConstants.resubmitDeposit;
			body.deposit_id = deposit_id;
		} else {
			endPoint = APIConstants.createDeposit;
			body.cash_deposit_id = id;
		}
		const depositDetail = {
			body,
			endPoint,
		};
		cashierDepositActions.onCreateCashierDeposit(depositDetail);
	};

	onSearch = text => {
		// Will set the search value and call the API.
		this.page = fetchDataWithPagination.page; // resetting the page to 1
		this.setState(
			{
				searchText: text,
			},
			() => {
				this.onFetchData(false);
			},
		);
	};

	onSelectItem = (id, amount) => {
		this.setState({
			selectedItem: id,
			amount,
			isButtonDisable: false,
		});
	};

	onEndReached = () => {
		// Will call the API for the next page with limit 10.
		const { pendingDepositInfo } = this.props;
		const { loader } = pendingDepositInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onRefresh = () => {
		// Will call the API's if user do the PTR.
		this.page = fetchDataWithPagination.page; // resetting the page to 1
		this.onFetchData(false);
		this.setState({
			selectedItem: null,
		});
	};

	onDeposit = () => {
		// Will show confirmation modal.
		this.setState({
			isPopupVisible: true,
		});
	};

	closeConfirmationModal = () => {
		// Will close confirmation modal and reset the state.
		const { cashierDepositActions } = this.props;
		cashierDepositActions.onResetState();
		this.setState({
			searchText: '',
			bottomLoader: false,
			selectedItem: null,
			amount: 0,
			isPopupVisible: false,
			isButtonDisable: true,
		});
		this.onRefresh();
	};

	closePopup = () => {
		this.setState({
			isPopupVisible: false,
		});
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { receivablesInfo, navigation } = this.props;
		const { notificationCount } = receivablesInfo;
		navigation.navigate(cashierNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	render() {
		const {
			languageInfo,
			refreshControlComponentInfo,
			pendingDepositInfo,
			imageInputInfo,
			receivablesInfo,
		} = this.props;
		const {
			pendingDepositListing,
			count,
			loader,
			totalAmount,
			isCreateDeposit,
			error,
			errorCode,
			success,
		} = pendingDepositInfo;
		const { notificationCount } = receivablesInfo;
		const { isRTL } = languageInfo;
		const {
			searchText,
			bottomLoader,
			selectedItem,
			amount,
			isPopupVisible,
			isButtonDisable,
		} = this.state;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { imageLoader } = imageInputInfo;
		return (
			<CashierDepositUI
				isRTL={isRTL}
				pendingDepositListing={pendingDepositListing}
				pendingDepositCount={count}
				onEndReached={this.onEndReached}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				searchText={searchText}
				onSearch={this.onSearch}
				onSelectItem={this.onSelectItem}
				selectedItem={[selectedItem]}
				amount={amount}
				onRefresh={this.onRefresh}
				totalAmount={totalAmount}
				onDeposit={this.onDeposit}
				isPopupVisible={isPopupVisible}
				onCloseConfirmationPopup={this.closeConfirmationModal}
				onPressNo={this.closePopup}
				onPressClose={this.closePopup}
				isButtonDisable={isButtonDisable}
				error={error}
				errorCode={errorCode}
				isConfirmationModalVisible={success && isCreateDeposit}
				imageLoader={(isCreateDeposit && loader) || imageLoader}
				isCreateDeposit={isCreateDeposit}
				onImageUploaded={this.onCreateDeposit}
				notificationCount={notificationCount}
				onPressNotification={this.onPressNotification}
			/>
		);
	}
}

CashierDepositComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	cashierDepositActions: PropTypes.object.isRequired,
	pendingDepositInfo: PropTypes.object.isRequired,
	imageInputInfo: PropTypes.object.isRequired,
	receivablesActions: PropTypes.object.isRequired,
	receivablesInfo: PropTypes.object.isRequired,
};

export default CashierDepositComponent;
