export const GET_CASHIER_PENDING_DEPOSITS_SUCCESS = 'get_cashier_pending_deposits_success';
export const GET_CASHIER_PENDING_DEPOSITS_FAILURE = 'get_cashier_pending_deposits_failure';
export const GET_CASHIER_PENDING_DEPOSITS_LOADER = 'get_cashier_pending_deposits_loader';

export const CREATE_DEPOSIT_REQUEST_SUCCESS = 'create_deposit_request_success';
export const CREATE_DEPOSIT_REQUEST_FAILURE = 'create_deposit_request_failure';
export const CREATE_DEPOSIT_REQUEST_LOADER = 'create_deposit_request_loader';

export const RESET_CASHIER_DEPOSIT_STATE = 'reset_cashier_deposit_state';
