import GetCollectorDepositsService from '@libservices/CashierServices/GetCollectorDepositsService';
import GetNotificationCountService from '@Notification/GetNotificationCountService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import * as ActionTypes from './ActionType';

export const onStoreUserDetails = userDetails => {
	// Action to store the user details into the reducer.
	return {
		type: ActionTypes.STORE_USER_DETAILS,
		payload: userDetails,
	};
};

/**
 * Action to get the collector deposits listing.
 * @param {object} props
 * @param {boolean} isAppendInExistingList
 * @returns
 */
export const onGetCollectorDeposits = (props, isAppendInExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_COLLECTOR_DEPOSITS_SUCCESS,
		ActionTypes.GET_COLLECTOR_DEPOSITS_FAILURE,
		ActionTypes.GET_COLLECTOR_DEPOSITS_LOADER,
	)
		.addSuccessExtra({ isAppendInExistingList })
		.build();
	const getCollectorDepositsService = new GetCollectorDepositsService(dispatchedActions);
	addBasicInterceptors(getCollectorDepositsService);
	getCollectorDepositsService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCollectorDepositsService.makeRequest(props));
};

export const onGetNotificationCount = () => dispatch => {
	// Action to fetch the unread notification count.
	const dispatchedActions = actions(
		ActionTypes.GET_CASHIER_NOTIFICATION_COUNT_SUCCESS,
		ActionTypes.GET_CASHIER_NOTIFICATION_COUNT_FAILURE,
		ActionTypes.GET_CASHIER_NOTIFICATION_COUNT_LOADER,
	);
	const getNotificationCountService = new GetNotificationCountService(dispatchedActions);
	addBasicInterceptors(getNotificationCountService);
	getNotificationCountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getNotificationCountService.makeRequest());
};
