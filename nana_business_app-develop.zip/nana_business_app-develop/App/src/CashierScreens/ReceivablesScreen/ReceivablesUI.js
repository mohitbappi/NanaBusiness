// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Text, View } from 'react-native';

// import components
import Header from '@Header/Header';
import FlatListComponent from '@RefreshControlComponent/RefreshControlComponent';
import ListEmpty from '@ListEmpty/ListEmpty';
import Search from '@Search/Search';
import InvoiceCardComponent from '@InvoiceCardComponent/InvoiceCardComponent';
import Loader from '@Loader/Loader';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

// import constants
import { localeString } from '@assets/Localization';
import { keyConstants } from '@assets/Constants/KeyConstants';
import { constants } from '@RefreshControlComponent/Constants';
import { fetchDataWithPagination } from '@assets/Constants/Constants';

// import utils
import { currencyFormatter } from '@Util/CurrencyFormatter';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import { getFormattedDate } from '@Util/GetFormattedDate';

// import styles
import { createStyleSheet } from './ReceivablesScreenStyle';

class ReceivablesUI extends Component {
	keyExtractor = (item, index) => index.toString();

	renderItem = ({ item, index }) => {
		const { isRTL, onGetDetail } = this.props;
		const { collector_name, updated_at, sum } = item;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.cardView}>
				<InvoiceCardComponent
					name={collector_name}
					dateLabel={`${localeString(keyConstants.LAST_UPDATED)}: `}
					date={getFormattedDate(updated_at)}
					amount={`${currencyFormatter(getValueInDecimal(sum))} ${localeString(
						keyConstants.SAR,
					)}`}
					isDisable={false}
					onPress={() => onGetDetail(index)}
				/>
			</View>
		);
	};

	listFooterComponent = () => {
		// Will show loader while pagination.
		const { isRTL, collectorDeposits, count } = this.props;
		const styles = createStyleSheet(isRTL);
		const endReached = count === collectorDeposits.length || count < collectorDeposits.length;
		if (!endReached) {
			return <Loader isSmallLoader />;
		}
		return (
			<Text style={styles.noDataText}>{localeString(keyConstants.NO_MORE_DATA_FOUND)}</Text>
		);
	};

	render() {
		const {
			isRTL,
			loader,
			collectorDeposits,
			count,
			error,
			errorCode,
			searchText,
			onRefresh,
			onSearch,
			onEndReached,
			onPressNotification,
			totalDepositAmount,
			notificationCount,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.container}>
				{loader && <Loader size="large" />}
				<View style={styles.headerContainer}>
					<Header
						text={localeString(keyConstants.RECEIVABLES)}
						hasIconNotification
						onPressNotification={onPressNotification}
						hasIconReceivables
						notificationCount={notificationCount}
					/>
				</View>
				{error ? (
					// Will show error component if api fails.
					<ErrorComponent isRTL={isRTL} errorCode={errorCode} onCallApi={onRefresh} />
				) : (
					<>
						<View style={styles.amountContainer}>
							<Text style={styles.title}>
								{localeString(keyConstants.AMOUNT_TO_BE_DEPOSITED)}
							</Text>
							<Text style={styles.amount}>
								{`${currencyFormatter(
									getValueInDecimal(totalDepositAmount),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
						</View>
						<View style={styles.searchContainer}>
							<Search
								hasSearchIcon
								placeholder={localeString(keyConstants.SEARCH_BY_COLLECTOR_NAME)}
								onChangeText={text => onSearch(text)}
								value={searchText}
							/>
						</View>
						<FlatListComponent
							keyboardShouldPersistTaps="handled"
							data={collectorDeposits}
							keyExtractor={this.keyExtractor}
							renderItem={this.renderItem}
							showsVerticalScrollIndicator={false}
							onEndReached={() =>
								collectorDeposits.length !== count && onEndReached()
							}
							ListFooterComponent={
								collectorDeposits.length !== 0 &&
								count > fetchDataWithPagination.limit &&
								this.listFooterComponent()
							}
							onEndReachedThreshold={0.5}
							ListEmptyComponent={() => (
								<ListEmpty text={localeString(keyConstants.NO_DEPOSITS_FOUND)} />
							)}
							contentContainerStyle={
								collectorDeposits.length === 0 && styles.scrollViewStyle
							}
							onRefresh={onRefresh}
							componentType={constants.flatList}
						/>
					</>
				)}
			</View>
		);
	}
}

ReceivablesUI.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onPressNotification: PropTypes.func.isRequired,
	searchText: PropTypes.string.isRequired,
	onSearch: PropTypes.func.isRequired,
	onGetDetail: PropTypes.func.isRequired,
	onRefresh: PropTypes.func.isRequired,
	collectorDeposits: PropTypes.array.isRequired,
	onEndReached: PropTypes.func.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	count: PropTypes.any.isRequired,
	loader: PropTypes.bool.isRequired,
	totalDepositAmount: PropTypes.number.isRequired,
	notificationCount: PropTypes.number.isRequired,
};

export default ReceivablesUI;
