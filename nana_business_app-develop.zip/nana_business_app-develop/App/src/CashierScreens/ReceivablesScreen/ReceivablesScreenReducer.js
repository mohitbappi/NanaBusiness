import * as ActionTypes from './ActionType';

const initialState = {
	userDetails: null,
	collectorDeposits: [],
	count: 0,
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	totalDepositAmount: 0,
	notificationCount: 0,
};

const ReceivablesScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.STORE_USER_DETAILS:
			return {
				...state,
				userDetails: action.payload,
			};
		case ActionTypes.GET_COLLECTOR_DEPOSITS_SUCCESS: {
			const { isAppendInExistingList } = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				collectorDeposits: isAppendInExistingList
					? [...state.collectorDeposits, ...action.payload.cashier_deposits]
					: action.payload.cashier_deposits,
				count: action.payload.count,
				totalDepositAmount: action.payload.total_deposits,
			};
		}
		case ActionTypes.GET_COLLECTOR_DEPOSITS_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_COLLECTOR_DEPOSITS_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.GET_CASHIER_NOTIFICATION_COUNT_SUCCESS:
			return {
				...state,
				notificationCount: action.payload.pending_notifications,
			};
		default:
			return state;
	}
};

export default ReceivablesScreenReducer;
