export const STORE_USER_DETAILS = 'store_user_details';

export const GET_COLLECTOR_DEPOSITS_SUCCESS = 'get_collector_deposits_success';
export const GET_COLLECTOR_DEPOSITS_FAILURE = 'get_collector_deposits_failure';
export const GET_COLLECTOR_DEPOSITS_LOADER = 'get_collector_deposits_loader';

export const GET_CASHIER_NOTIFICATION_COUNT_SUCCESS = 'get_cashier_notification_count_success';
export const GET_CASHIER_NOTIFICATION_COUNT_FAILURE = 'get_cashier_notification_count_failure';
export const GET_CASHIER_NOTIFICATION_COUNT_LOADER = 'get_cashier_notification_count_loader';
