// import libraries
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import AsyncStorage from '@react-native-async-storage/async-storage';

// import navigations
import cashierNavigations from '@config/routes/cashierNavigations';

// import constants
import { fetchDataWithPagination, userDetails } from '@assets/Constants/Constants';

// import components
import ReceivablesUI from './ReceivablesUI';

class ReceivablesComponent extends Component {
	constructor(props) {
		super(props);
		this.props = props.customProps;
		this.limit = fetchDataWithPagination.limit;
		this.page = fetchDataWithPagination.page;
		this.state = {
			searchText: '',
			bottomLoader: false,
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.onStoreUserDetails();
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onGetNotificationCount();
			this.page = fetchDataWithPagination.page;
			this.onFetchData(false);
			pullToRefreshActions.onHandlePullToRefresh(false); // Will hide the pull to refresh loader
		});
	}

	componentDidUpdate(prevProps) {
		const { receivablesInfo, pullToRefreshActions } = this.props;
		const { success } = receivablesInfo;
		if (success && prevProps.receivablesInfo.success !== success) {
			// Will hide the bottom loader.
			this.setState({
				bottomLoader: false,
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
	}

	onStoreUserDetails = async () => {
		// Will user user details to reducer.
		const { receivablesActions } = this.props;
		const userDetail = await AsyncStorage.getItem(userDetails);
		receivablesActions.onStoreUserDetails(JSON.parse(userDetail));
	};

	onGetNotificationCount = () => {
		const { receivablesActions } = this.props;
		receivablesActions.onGetNotificationCount();
	};

	onFetchData = isAppendInExistingList => {
		// API call to get the collector deposits listing.
		const { receivablesActions } = this.props;
		const { searchText } = this.state;
		const queryParams = {};
		queryParams.limit = this.limit;
		queryParams.page = this.page;
		if (searchText) {
			queryParams.name = searchText; // If search is done by name.
		}
		receivablesActions.onGetCollectorDeposits(queryParams, isAppendInExistingList);
	};

	onGetDetail = index => {
		// Will navigate to the receivables detail screen.
		const { navigation, receivablesInfo } = this.props;
		const { collectorDeposits } = receivablesInfo;
		navigation.navigate(cashierNavigations.RECEIVABLES_DETAIL_NAVIGATION, {
			collectorDetail: collectorDeposits[index],
		});
	};

	onEndReached = () => {
		const { receivablesInfo } = this.props;
		const { loader } = receivablesInfo;
		if (!loader) {
			this.setState({
				bottomLoader: true,
			});
			this.page += 1;
			this.onFetchData(true);
		}
	};

	onRefresh = () => {
		// Will call api after pull to refresh.
		this.page = fetchDataWithPagination.page;
		this.onFetchData(false);
	};

	onSearch = text => {
		// Will search customer using name.
		this.page = fetchDataWithPagination.page;
		this.setState(
			{
				searchText: text,
			},
			() => this.onFetchData(false),
		);
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { receivablesInfo, navigation } = this.props;
		const { notificationCount } = receivablesInfo;
		navigation.navigate(cashierNavigations.NOTIFICATION_NAVIGATION, {
			notificationCount,
		});
	};

	render() {
		const { searchText, bottomLoader } = this.state;
		const { languageInfo, refreshControlComponentInfo, receivablesInfo } = this.props;
		const {
			collectorDeposits,
			count,
			loader,
			error,
			errorCode,
			totalDepositAmount,
			notificationCount,
		} = receivablesInfo;
		const { isRTL } = languageInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		return (
			<ReceivablesUI
				isRTL={isRTL}
				loader={loader && !isFetchingForPullToRefresh && !bottomLoader && searchText === ''}
				onGetDetail={this.onGetDetail}
				collectorDeposits={collectorDeposits}
				count={count}
				error={error}
				errorCode={errorCode}
				searchText={searchText}
				onEndReached={this.onEndReached}
				onRefresh={this.onRefresh}
				onSearch={this.onSearch}
				totalDepositAmount={totalDepositAmount}
				notificationCount={notificationCount}
				onPressNotification={this.onPressNotification}
			/>
		);
	}
}

ReceivablesComponent.propTypes = {
	customProps: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	languageInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	receivablesActions: PropTypes.object.isRequired,
	receivablesInfo: PropTypes.object.isRequired,
};

export default ReceivablesComponent;
