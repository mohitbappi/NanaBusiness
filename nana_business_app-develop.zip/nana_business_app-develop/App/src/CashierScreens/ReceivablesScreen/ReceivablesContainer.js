// import libraries
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

// import actions
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as ReceivablesActions from './ReceivablesScreenAction';

// import components
import ReceivablesComponent from './ReceivablesComponent';

const ReceivablesContainer = props => {
	const customProps = { ...props }; // Will store all the props like navigation, reducer state and actions.
	return <ReceivablesComponent {...customProps} />;
};

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer, // Language screen reducer
		refreshControlComponentInfo: state.RefreshControlComponentReducer, // Pull to refresh screen reducer
		receivablesInfo: state.ReceivablesScreenReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch), // Pull to refresh actions
		receivablesActions: bindActionCreators({ ...ReceivablesActions }, dispatch), // Pull to refresh actions
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(ReceivablesContainer);
