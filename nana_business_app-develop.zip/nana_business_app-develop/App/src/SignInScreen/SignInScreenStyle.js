import { StyleSheet } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { moderateScale, normalScale, verticalScale } from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			flex: 1,
			backgroundColor: colors.white,
			paddingTop: verticalScale(6),
		},
		header: {
			marginBottom: verticalScale(8),
			alignSelf: rtlFunctions.getAlignmentInFlex(isRTL),
			paddingHorizontal: normalScale(16),
		},
		iconLanguagePurple: {
			height: normalScale(55),
			width: normalScale(55),
		},
		signup: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			textTransform: 'uppercase',
		},
		image: {
			width: normalScale(288),
			height: verticalScale(122),
			alignSelf: 'center',
			marginBottom: verticalScale(20),
		},
		innerContainer: {
			shadowColor: colors.lightPurpleBlue,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(2),
			},
			shadowRadius: moderateScale(8),
			shadowOpacity: 0.09,
			elevation: verticalScale(2),
			paddingHorizontal: normalScale(24),
			paddingTop: verticalScale(8),
			backgroundColor: colors.white,
			marginHorizontal: normalScale(16),
			borderRadius: normalScale(8),
			paddingBottom: verticalScale(24),
		},
		textInputStyle: {
			height: verticalScale(44),
		},
		signView: {
			alignSelf: 'flex-end',
		},
		signText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(10),
		},
		forgotView: {
			alignSelf: 'flex-end',
		},
		forgotText: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(8),
		},
		acceptView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignSelf: rtlFunctions.getAlignmentInFlexOpposite(isRTL),
			alignItems: 'center',
			marginTop: verticalScale(16),
		},
		viewStyle: {
			marginTop: verticalScale(22),
		},
		register: {
			alignSelf: 'center',
			marginTop: verticalScale(10),
		},
		accountLabel: {
			color: colors.blackGreyWhite,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(14),
		},
		registerLabel: {
			color: colors.darkBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(14),
		},
	});
};

export default createStyleSheet;
