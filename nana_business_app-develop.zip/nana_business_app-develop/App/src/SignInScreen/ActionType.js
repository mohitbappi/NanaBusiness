export const ON_CHANGE_TEXT = 'on_change_text';
export const RESET_SIGNIN_STATE = 'reset_sign_in_state';
export const SIGNIN_SUCCESS = 'signin_success';
export const SIGNIN_FAILURE = 'signin_failure';
export const SIGNIN_LOADER = 'signin_loader';
export const ADD_LAT_LONG = 'add_lat_long';
export const SET_TOKEN = 'set_token';
export const SET_SIGN_IN_VIA_PASSWORD = 'set_sign_in_via_password';
