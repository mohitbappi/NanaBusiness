import { saveMasterLoginData } from '@Util/SaveMasterLoginData';
import * as ActionTypes from './ActionType';

const initialState = {
	mobileNumber: '',
	password: '',
	success: false,
	error: false,
	errorCode: null,
	loader: false,
	token: null,
	lat: '',
	long: '',
	role: '',
	isSignInViaPassword: false,
};

const SignInScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.ON_CHANGE_TEXT:
			return {
				...state,
				[action.field]: action.payload,
			};
		case ActionTypes.SET_SIGN_IN_VIA_PASSWORD:
			return {
				...state,
				isSignInViaPassword: action.payload,
			};
		case ActionTypes.SET_TOKEN:
			return {
				...state,
				token: action.payload.token,
				role: action.payload.role,
			};
		case ActionTypes.RESET_SIGNIN_STATE:
			return {
				...state,
				mobileNumber: '',
				password: '',
				success: false,
				error: false,
				errorCode: '',
				loader: false,
				isSignInViaPassword: false,
			};
		case ActionTypes.SIGNIN_SUCCESS:
			if (action.payload.access_token) {
				saveMasterLoginData(action.payload); // Save master data if user logged in successfully.
			}
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				token: action.payload.access_token ? action.payload.access_token : null,
				role:
					action.payload.user && action.payload.user.role ? action.payload.user.role : '',
			};
		case ActionTypes.SIGNIN_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.SIGNIN_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
			};
		case ActionTypes.ADD_LAT_LONG:
			return {
				...state,
				lat: action.payload.lat,
				long: action.payload.long,
			};
		default:
			return state;
	}
};

export default SignInScreenReducer;
