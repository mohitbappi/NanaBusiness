import React, { Component } from 'react';
import { Text, TouchableOpacity, Keyboard, ScrollView, View, Platform } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { localeString } from '@assets/Localization';
import Input from '@Input/Input';
import { normalScale, verticalScale } from '@config/device/normalize';
import IMAGES from '@Images/index';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import {
	passwordMaxLength,
	toastShowTime,
	retailer,
	vendor,
	collector,
	customerAdmin,
	noSpaceAtStartRegexEx,
	customMobileRegex,
	mobileNumberLength,
	mobilePrefix,
	numericRegexExp,
	driver,
	languageConstants,
	accountManager,
	locatorConstants,
	cashier,
	salesExecutive,
} from '@Constants/Constants';
import Spinner from '@Spinner/Spinner';
import ToastComponent from '@ToastComponent/ToastComponent';
import { keyConstants } from '@Constants/KeyConstants';
import navigations from '@routes/navigations';
import * as SetPasswordActions from '@SetPasswordScreen/SetPasswordScreenAction';
import * as ForgotEmailActions from '@EmailScreen/EmailScreenAction';
import * as RoleScreenActions from '@RoleScreen/RoleScreenAction';
import LanguageScreen from '@LanguageScreen/LanguageScreen';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import * as OtpScreenActions from '@OTPScreen/OTPScreenAction';
import AlertComponent from '@Util/AlertComponent';
import ErrorAlertComponent from '@ErrorAlertComponent/ErrorAlertComponent';
import getTestIdProps from '@Util/GetTestIdProps';
import * as SignInScreenActions from './SignInScreenAction';
import { createStyleSheet } from './SignInScreenStyle';

class SignInScreen extends Component {
	constructor(props) {
		super(props);
		this.password = React.createRef(null);
		this.state = {
			errorEmailValidationMessage: false,
			errorValidationMessage: false,
			errorMessage: '',
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation } = this.props;
		this.willFocusListener = navigation.addListener('blur', () => {
			const { signInScreenActions } = this.props;
			this.setState({
				errorEmailValidationMessage: false,
				errorValidationMessage: false,
				errorMessage: '',
				isApiError: false,
				toastMessage: '',
			});
			signInScreenActions.onResetSignInState();
		});
		this.willFocusListener = navigation.addListener('focus', () => {
			const { setPasswordInfo, setPasswordActions, forgotEmailActions } = this.props;
			const { success } = setPasswordInfo;
			if (success) {
				this.setState({
					toastMessage: localeString(keyConstants.PASSWORD_CHANGED_SUCCESSFULLY),
					isApiError: true,
				});
				setTimeout(() => {
					this.setState({
						isApiError: false,
					});
				}, toastShowTime);
				setPasswordActions.onResetForgotPasswordState();
				forgotEmailActions.onChangeEmail('');
				forgotEmailActions.onResetForgotState();
			}
		});
	}

	componentDidUpdate(prevProps) {
		const { signInInfo, otpScreenInfo, navigation, otpScreenActions } = this.props;
		const { mobileNumber, error, errorCode } = signInInfo;
		const { success } = otpScreenInfo;
		const { error: otpError, errorCode: otpErrorCode } = otpScreenInfo;
		if (success && prevProps.otpScreenInfo.success !== otpScreenInfo.success) {
			// if send otp api return success
			navigation.navigate(navigations.OTP_SCREEN_NAVIGATION, {
				mobileNumber,
				isSignIn: true,
				isDriver: false,
			});
			otpScreenActions.onResetOtpScreenState();
		}
		if (error && prevProps.signInInfo.error !== error) {
			if (errorCode.error === keyConstants.USER_NOT_FOUND) {
				// If user does not exist.
				setTimeout(() => {
					this.getAlert();
				}, 200);
			} else if (keyConstants[errorCode.error]) {
				// If user exists and entered incorrect password.
				this.onShowToast(keyConstants.USERNAME_OR_PASSWORD_INCORRECT);
			} else {
				// Will show alert if login api fails.
				ErrorAlertComponent(errorCode, this.onSubmit);
			}
		}
		if (otpError && prevProps.otpScreenInfo.error !== otpError) {
			if (otpErrorCode.error === keyConstants.USER_NOT_FOUND) {
				// If user does not exist.
				setTimeout(() => {
					this.getAlert();
				}, 200);
			} else if (keyConstants[otpErrorCode.error]) {
				this.onShowToast(otpErrorCode.error);
			} else {
				// Will show alert if send otp api fails.
				ErrorAlertComponent(otpErrorCode, this.onSubmit);
			}
		}
		if (prevProps.signInInfo !== signInInfo) {
			if (customMobileRegex.test(String(mobileNumber).toLowerCase())) {
				this.setState({
					errorEmailValidationMessage: false,
				});
			}
		}
	}

	componentWillUnmount() {
		// Will reset Signin screen reducer on unmounting
		const { signInScreenActions } = this.props;
		signInScreenActions.onResetSignInState();
	}

	getAlert = () => {
		// Will show alert.
		const alertOptions = {
			message: localeString(keyConstants.DO_YOU_WANT_TO_REGISTER),
			noText: localeString(keyConstants.NO),
			yesText: localeString(keyConstants.YES),
			onPressYes: this.onPressSignUp,
		};
		AlertComponent(alertOptions);
	};

	onShowToast = message => {
		this.setState({
			toastMessage: localeString(message),
			isApiError: true,
			errorValidationMessage: false,
		});
		setTimeout(() => {
			this.setState({
				isApiError: false,
			});
		}, toastShowTime);
	};

	onRequestClose = () => {
		const { roleScreenActions } = this.props;
		roleScreenActions.onSetModalVisibility(false);
	};

	onChangeLanguage = () => {
		// Will show the language screen to change the language of the app.
		const { roleScreenActions } = this.props;
		roleScreenActions.onSetModalVisibility(true);
	};

	onPressSignUp = () => {
		// Will navigate to register user process
		const { signInInfo, navigation, signInScreenActions } = this.props;
		const { mobileNumber } = signInInfo;
		navigation.navigate(navigations.PERSONAL_INFO_NAVIGATION, { mobileNumber });
		signInScreenActions.onResetSignInState();
	};

	onChangeText = (text, field) => {
		const { signInScreenActions } = this.props;
		signInScreenActions.onChangeText(text, field);
	};

	onSubmitRef = textRef => {
		textRef.current.focus();
	};

	refCallback = textInputRef => node => {
		const ref = textInputRef;
		ref.current = node;
	};

	onBlur = () => {
		const { signInInfo } = this.props;
		const { mobileNumber } = signInInfo;
		if (!customMobileRegex.test(String(mobileNumber).toLowerCase())) {
			this.setState({
				errorEmailValidationMessage: true,
			});
		}
	};

	onSwitchSignInOption = () => {
		const { signInInfo, signInScreenActions } = this.props;
		signInScreenActions.onSetSignInViaPassword(!signInInfo.isSignInViaPassword);
		this.onChangeText('', 'password');
	};

	onPressForgotPassword = () => {
		// Will navigate to Forgot password screen
		const { navigation, signInScreenActions } = this.props;
		signInScreenActions.onResetSignInState();
		navigation.navigate(navigations.FORGOT_EMAIL_NAVIGATION);
	};

	onSubmit = () => {
		const { signInInfo, languageInfo, signInScreenActions, otpScreenActions } = this.props;
		const { mobileNumber, password, isSignInViaPassword } = signInInfo;
		const { isRTL } = languageInfo;
		this.onDissmissKeyboard();
		if (isSignInViaPassword) {
			// if user is signing in using password
			const signInDetails = {
				mobile: mobileNumber,
				password,
				role: [
					vendor,
					retailer,
					customerAdmin,
					accountManager,
					salesExecutive,
					collector,
					driver,
					cashier,
				],
				country_code: mobilePrefix,
			};
			signInScreenActions.onPerformLogin(signInDetails);
		} else {
			// if user is signing in using otp
			const otpDetails = {
				phone: mobileNumber,
				country_code: mobilePrefix,
				for_login: 'true',
				language: isRTL ? languageConstants.ar : languageConstants.en,
				platform: Platform.OS,
			};
			otpScreenActions.onResendOtp(otpDetails);
		}
	};

	onDissmissKeyboard = () => {
		Keyboard.dismiss();
	};

	render() {
		const {
			errorEmailValidationMessage,
			errorMessage,
			errorValidationMessage,
			toastMessage,
			isApiError,
		} = this.state;
		const {
			signInInfo,
			languageInfo,
			roleInfo,
			otpScreenInfo,
			configurableFileInfo,
		} = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const { mobileNumber, password, loader, isSignInViaPassword } = signInInfo;
		const styles = createStyleSheet(isRTL);
		const { isModalVisible } = roleInfo;
		const otpLoader = otpScreenInfo.loader;
		if (isModalVisible) {
			return (
				<LanguageScreen
					isModalVisible={isModalVisible}
					onRequestClose={this.onRequestClose}
				/>
			);
		}
		return (
			<KeyboardAwareScrollView
				contentContainerStyle={styles.container}
				keyboardShouldPersistTaps="handled">
				{(loader || otpLoader) && <Spinner size="large" />}
				<ScrollView
					showsVerticalScrollIndicator={false}
					contentContainerStyle={styles.scrollView}
					keyboardShouldPersistTaps="handled">
					<View style={styles.header}>
						<TouchableOpacity activeOpacity={0.8} onPress={this.onChangeLanguage}>
							<ImageLoadComponent
								source={IMAGES.iconLanguagePurple}
								style={styles.iconLanguagePurple}
							/>
						</TouchableOpacity>
					</View>
					<ImageLoadComponent
						source={
							isRTL ? IMAGES.iconSignInScreenArabic : IMAGES.iconSignInScreenEnglish
						}
						style={styles.image}
					/>
					<View style={styles.innerContainer}>
						<Input
							value={mobileNumber}
							width={normalScale(240)}
							label={`${localeString(keyConstants.MOBILE_NUMBER)}*`}
							placeholder={localeString(keyConstants.MOBILE_NUMBER_PLACEHOLDER)}
							blurOnSubmit={!isSignInViaPassword}
							returnKeyType="done"
							isRTL={isRTL}
							onChangeText={text =>
								(numericRegexExp.test(String(text).toLocaleLowerCase()) ||
									text === '') &&
								this.onChangeText(text, 'mobileNumber')
							}
							onSubmitEditing={() => {
								if (isSignInViaPassword) {
									this.onSubmitRef(this.password);
								}
								this.onBlur();
							}}
							isError={errorEmailValidationMessage}
							autoCapitalize="none"
							errorMessage={localeString(
								keyConstants.MOBILE_NUMBER_VALIDATION_MESSAGE,
							)}
							maxLength={mobileNumberLength}
							keyboardType="number-pad"
							hasMobilePrefixFlag
							height={verticalScale(44)}
							textInputStyle={styles.textInputStyle}
							extraProps={getTestIdProps(locatorConstants.phoneNumber)}
						/>
						{isSignInViaPassword && (
							<>
								<TouchableOpacity
									style={styles.signView}
									activeOpacity={0.8}
									onPress={this.onSwitchSignInOption}
									{...getTestIdProps(locatorConstants.signInViaCode)}>
									<Text style={styles.signText}>
										{`${localeString(
											isSignInViaPassword
												? keyConstants.SIGN_IN_VIA_CODE
												: keyConstants.SIGN_IN_VIA_PASSWORD,
										)}${localeString(keyConstants.QUESTION_MARK)}`}
									</Text>
								</TouchableOpacity>
								<Input
									maxLength={passwordMaxLength}
									value={password}
									width={normalScale(240)}
									label={`${localeString(keyConstants.PASSWORD)}*`}
									placeholder={localeString(keyConstants.PASSWORD)}
									blurOnSubmit
									returnKeyType="done"
									isRTL={isRTL}
									onChangeText={text =>
										(noSpaceAtStartRegexEx.test(
											String(text).toLocaleLowerCase(),
										) ||
											text === '') &&
										this.onChangeText(text, 'password')
									}
									refs={this.refCallback(this.password)}
									isError={errorValidationMessage}
									autoCapitalize="none"
									errorMessage={errorMessage}
									hasIconPassword
									extraProps={getTestIdProps(locatorConstants.password)}
								/>
								<TouchableOpacity
									style={styles.forgotView}
									activeOpacity={0.8}
									onPress={this.onPressForgotPassword}
									{...getTestIdProps(locatorConstants.forgetPassword)}>
									<Text style={styles.forgotText}>
										{`${localeString(
											keyConstants.FORGOT_PASSWORD,
										)}${localeString(keyConstants.QUESTION_MARK)}`}
									</Text>
								</TouchableOpacity>
							</>
						)}
						<View style={styles.viewStyle}>
							<ButtonComponent
								onPress={this.onSubmit}
								text={localeString(
									isSignInViaPassword ? keyConstants.SIGN_IN : keyConstants.NEXT,
								)}
								isButtonDisable={
									!(
										customMobileRegex.test(
											String(mobileNumber).toLowerCase(),
										) && (isSignInViaPassword ? password : true)
									)
								}
								extraProps={getTestIdProps(locatorConstants.loginButton)}
							/>
						</View>
					</View>
					{remoteConfigData?.signupButtonOnLogin ? (
						<TouchableOpacity
							style={styles.register}
							activeOpacity={0.8}
							{...getTestIdProps(locatorConstants.registerButton)}
							onPress={this.onPressSignUp}>
							<Text style={styles.accountLabel}>
								{`${localeString(keyConstants.DONT_HAVE_AN_ACCOUNT)}${localeString(
									keyConstants.QUESTION_MARK,
								)} `}
								<Text style={styles.registerLabel}>
									{localeString(keyConstants.REGISTER_NOW)}
								</Text>
							</Text>
						</TouchableOpacity>
					) : null}
				</ScrollView>
				<ToastComponent isRTL={isRTL} isApiError={isApiError} toastMessage={toastMessage} />
			</KeyboardAwareScrollView>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		signInInfo: state.SignInScreenReducer,
		setPasswordInfo: state.SetPasswordScreenReducer,
		roleInfo: state.RoleScreenReducer,
		otpScreenInfo: state.OTPScreenReducer,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		signInScreenActions: bindActionCreators({ ...SignInScreenActions }, dispatch),
		setPasswordActions: bindActionCreators({ ...SetPasswordActions }, dispatch),
		forgotEmailActions: bindActionCreators({ ...ForgotEmailActions }, dispatch),
		roleScreenActions: bindActionCreators({ ...RoleScreenActions }, dispatch),
		otpScreenActions: bindActionCreators({ ...OtpScreenActions }, dispatch),
	};
};

SignInScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	signInInfo: PropTypes.object.isRequired,
	setPasswordInfo: PropTypes.object.isRequired,
	roleInfo: PropTypes.object.isRequired,
	otpScreenInfo: PropTypes.object.isRequired,
	signInScreenActions: PropTypes.object.isRequired,
	setPasswordActions: PropTypes.object.isRequired,
	forgotEmailActions: PropTypes.object.isRequired,
	roleScreenActions: PropTypes.object.isRequired,
	otpScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(SignInScreen);
