import { actions } from '@libapi/APIActionsBuilder';
import SignInService from '@Login/SignInService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import * as ActionTypes from './ActionType';

/**
 * Action to set entered textfield text in respective values in reducer
 * @param {string} text
 * @param {string} field
 */
export const onChangeText = (text, field) => {
	return {
		type: ActionTypes.ON_CHANGE_TEXT,
		payload: text,
		field,
	};
};

/**
 * Action to set if user signing in using password or not
 * @param {boolean} value
 */
export const onSetSignInViaPassword = value => {
	return {
		type: ActionTypes.SET_SIGN_IN_VIA_PASSWORD,
		payload: value,
	};
};

/**
 * Action to set token after successful login
 * @param {string} token
 * @param {string} role
 */
export const onSetToken = (token, role) => {
	return {
		type: ActionTypes.SET_TOKEN,
		payload: { token, role },
	};
};

// Action to reset signin reducer
export const onResetSignInState = () => ({ type: ActionTypes.RESET_SIGNIN_STATE });

/**
 * Action to call login api
 * @param {object} signInDetails
 */
export const onPerformLogin = signInDetails => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.SIGNIN_SUCCESS,
		ActionTypes.SIGNIN_FAILURE,
		ActionTypes.SIGNIN_LOADER,
	);
	const signInService = new SignInService(dispatchedActions);
	addBasicInterceptors(signInService);
	dispatch(signInService.makeRequest(signInDetails));
};

/**
 * Action to set latitude and longitude
 * @param {float} lat
 * @param {float} long
 */
export const onAddLatLong = (lat, long) => {
	return {
		type: ActionTypes.ADD_LAT_LONG,
		payload: { lat, long },
	};
};
