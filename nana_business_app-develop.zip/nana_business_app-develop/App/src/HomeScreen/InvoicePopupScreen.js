import React, { Component } from 'react';
import { StyleSheet, Modal, View, Text, TouchableOpacity } from 'react-native';
import SwiperFlatList from 'react-native-swiper-flatlist';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import normalize, {
	verticalScale,
	normalScale,
	moderateScale,
	lineHeightScale,
} from '@device/normalize';
import RTLFunctions from '@Util/RTLFunctions';
import IMAGES from '@Images/index';
import { fontsConstants, salesInvoice, IMAGE_TYPE } from '@Constants/Constants';
import { localeString } from '@Localization/index';
import { keyConstants } from '@Constants/KeyConstants';
import ButtonComponent from '@ButtonComponent/ButtonComponent';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import Spinner from '@Spinner/Spinner';
import { getFormattedDate } from '@Util/GetFormattedDate';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import { currencyFormatter } from '@Util/CurrencyFormatter';

const rtlFunctions = new RTLFunctions();

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		pagination: {
			height: verticalScale(8),
			width: normalScale(8),
			marginHorizontal: normalScale(4),
			marginBottom: verticalScale(84),
		},
		containerPopup: {
			backgroundColor: colors.opacityGrey,
			justifyContent: 'center',
			alignItems: 'center',
			paddingHorizontal: normalScale(41),
		},
		innerContainerPopup: {
			backgroundColor: colors.white,
			paddingVertical: verticalScale(16),
			width: '100%',
			borderRadius: moderateScale(8),
		},
		headerPopup: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			borderBottomColor: colors.grey,
			paddingHorizontal: normalScale(12),
			borderBottomWidth: normalScale(1),
			paddingBottom: verticalScale(12),
			justifyContent: 'center',
		},
		titlePopup: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.darkBlue,
		},
		detailContainerPopup: {
			marginTop: verticalScale(26),
			justifyContent: 'center',
			alignItems: 'center',
		},
		iconDefaultPersonCirclePopup: {
			height: normalScale(40),
			width: normalScale(40),
			borderRadius: normalScale(20),
		},
		name: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(14),
			color: colors.black,
			lineHeight: lineHeightScale(18),
			marginTop: verticalScale(6),
		},
		invoiceId: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.blackGreyWhite,
			marginTop: verticalScale(22),
		},
		amount: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(18),
			color: colors.darkBlue,
			marginTop: verticalScale(4),
		},
		sar: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			color: colors.darkBlue,
		},
		dateView: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.blackGreyWhite,
			marginTop: verticalScale(18),
		},
		date: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
		},
		buttonView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			paddingHorizontal: normalScale(14),
			justifyContent: 'space-between',
			marginTop: verticalScale(22),
			backgroundColor: colors.white,
		},
		backButton: {
			paddingHorizontal: normalScale(4),
			backgroundColor: colors.white,
			alignItems: 'center',
			borderRadius: moderateScale(8),
			height: verticalScale(32),
			justifyContent: 'center',
			borderColor: colors.lightGrey,
			borderWidth: normalScale(1),
			shadowColor: colors.shadowColor,
			shadowOffset: {
				width: normalScale(0),
				height: verticalScale(0),
			},
			shadowRadius: moderateScale(0),
			elevation: verticalScale(0),
			marginRight: isRTL ? 0 : normalScale(10),
			marginLeft: isRTL ? normalScale(10) : 0,
			width: normalScale(100),
		},
		backText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
		},
		addButton: {
			paddingHorizontal: normalScale(4),
			width: normalScale(100),
			height: verticalScale(32),
		},
		payLater: {
			marginTop: verticalScale(16),
			alignSelf: 'center',
		},
		pay: {
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(14),
			color: colors.lightBlack,
			textDecorationLine: 'underline',
		},
	});
};

class InvoicePopupScreen extends Component {
	renderItem = (item, index) => {
		const { isRTL, onReject, onApprove, onPayLater } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.containerPopup}>
				<View style={styles.innerContainerPopup}>
					<View style={styles.headerPopup}>
						<Text style={styles.titlePopup}>
							{localeString(keyConstants.REQUESTED_BY)}
						</Text>
					</View>
					<View style={styles.detailContainerPopup}>
						<ImageLoadComponent
							imageType={IMAGE_TYPE.account}
							isUrl={item.type !== salesInvoice && item.image_name}
							source={
								item.type !== salesInvoice
									? item.image_name
										? item.image_name
										: IMAGES.iconProfileDefault
									: IMAGES.iconNana
							}
							style={styles.iconDefaultPersonCirclePopup}
						/>
						<Text style={styles.name}>
							{item.type === salesInvoice
								? localeString(keyConstants.NANA_BUSINESS)
								: item.vendor_org_name}
						</Text>
						<Text style={styles.invoiceId}>{`#${item.invoice_no}`}</Text>
						<Text style={styles.amount}>
							{`${currencyFormatter(getValueInDecimal(item.invoice_total))} `}
							<Text style={styles.sar}>{localeString(keyConstants.SAR)}</Text>
						</Text>
						<Text style={styles.dateView}>
							{`${localeString(keyConstants.DUE_DATE)}: `}
							<Text style={styles.date}>{getFormattedDate(item.due)}</Text>
						</Text>
					</View>
					<View style={styles.buttonView}>
						<ButtonComponent
							buttonStyle={styles.backButton}
							text={localeString(keyConstants.REJECT)}
							textStyle={styles.backText}
							onPress={() => onReject(item.id, index)}
						/>
						<ButtonComponent
							buttonStyle={styles.addButton}
							text={localeString(keyConstants.APPROVE)}
							onPress={() => onApprove(item.id, index)}
						/>
					</View>
					<TouchableOpacity
						activeOpacity={0.8}
						onPress={() => onPayLater(index)}
						style={styles.payLater}>
						<Text style={styles.pay}>{localeString(keyConstants.LATER)}</Text>
					</TouchableOpacity>
				</View>
			</View>
		);
	};

	render() {
		const { isRTL, isVisible, entries, loader } = this.props;
		const styles = createStyleSheet(isRTL);
		return isVisible ? (
			<Modal transparent>
				{loader && <Spinner size="large" />}
				<SwiperFlatList
					showPagination
					paginationStyleItem={styles.pagination}
					paginationActiveColor={colors.white}
					paginationDefaultColor={colors.grey}>
					{entries.map((item, index) => this.renderItem(item, index))}
				</SwiperFlatList>
			</Modal>
		) : null;
	}
}

InvoicePopupScreen.propTypes = {
	isRTL: PropTypes.bool.isRequired,
	onReject: PropTypes.func.isRequired,
	onApprove: PropTypes.func.isRequired,
	onPayLater: PropTypes.func.isRequired,
	isVisible: PropTypes.bool.isRequired,
	entries: PropTypes.array.isRequired,
	loader: PropTypes.bool.isRequired,
};

export default InvoicePopupScreen;
