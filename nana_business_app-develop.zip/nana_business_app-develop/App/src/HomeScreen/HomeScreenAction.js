import APIActionsBuilder, { actions } from '@libapi/APIActionsBuilder';
import GetBranchesService from '@Branch/GetBranchesService';
import { addBasicInterceptors } from '@interceptor/makeInterceptedRequest';
import AuthenticationHeaderInterceptor from '@interceptor/AuthenticationHeaderInterceptor';
import GetCartCountService from '@Cart/GetCartCountService';
import UpdateBranchService from '@Branch/UpdateBranchService';
import DashboardService from '@Home/DashboardService';
import GetItemsDataService from '@Home/GetItemsDataService';
import GetNotificationCountService from '@Notification/GetNotificationCountService';
import * as ActionTypes from './ActionType';

/**
 * Action method to store user details
 * @param {object} userDetails
 * @returns
 */

export const onStoreUserDetails = userDetails => {
	return {
		type: ActionTypes.STORE_USER_DETAILS,
		payload: userDetails,
	};
};

/**
 * Action method to get branches
 * @param {object} props
 * @param {boolean} isOverwriteExistingList
 * @returns
 */

export const onGetBranches = (props, isOverwriteExistingList) => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_BRANCH_LISTING_SUCCESS,
		ActionTypes.GET_BRANCH_LISTING_FAILURE,
		ActionTypes.GET_BRANCH_LISTING_LOADER,
	)
		.addSuccessExtra(isOverwriteExistingList)
		.build();
	const getBranchesService = new GetBranchesService(dispatchedActions);
	addBasicInterceptors(getBranchesService);
	getBranchesService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getBranchesService.makeRequest(props));
};

export const onGetCartCount = () => dispatch => {
	// Action method to get cart count
	const dispatchedActions = actions(
		ActionTypes.GET_CART_COUNT_SUCCESS,
		ActionTypes.GET_CART_COUNT_FAILURE,
		ActionTypes.GET_CART_COUNT_LOADER,
	);
	const getCartCountService = new GetCartCountService(dispatchedActions);
	addBasicInterceptors(getCartCountService);
	getCartCountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getCartCountService.makeRequest());
};

export const onGetNotificationCount = () => dispatch => {
	// Action method to get notification count
	const dispatchedActions = actions(
		ActionTypes.GET_NOTIFICATION_COUNT_SUCCESS,
		ActionTypes.GET_NOTIFICATION_COUNT_FAILURE,
		ActionTypes.GET_NOTIFICATION_COUNT_LOADER,
	);
	const getNotificationCountService = new GetNotificationCountService(dispatchedActions);
	addBasicInterceptors(getNotificationCountService);
	getNotificationCountService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getNotificationCountService.makeRequest());
};

/**
 * Action method to set selected branch
 * @param {object} branchDetail
 * @param {int} index
 * @returns
 */

export const onSetSelectedBranch = (branchDetail, index) => {
	return {
		type: ActionTypes.SET_SELECTED_BRANCH,
		payload: { branchDetail, index },
	};
};

/**
 * Action method to update branch
 * @param {onject} props
 * @returns
 */

export const onUpdateBranch = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.UPDATE_BRANCH_SUCCESS,
		ActionTypes.UPDATE_BRANCH_FAILURE,
		ActionTypes.UPDATE_BRANCH_LOADER,
	);
	const updateBranchService = new UpdateBranchService(dispatchedActions);
	addBasicInterceptors(updateBranchService);
	updateBranchService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(updateBranchService.makeRequest(props));
};

/**
 * Action method to get Dashboard
 * @param {object} props
 * @returns
 */

export const onGetDashboard = props => dispatch => {
	const dispatchedActions = actions(
		ActionTypes.DASHBOARD_SUCCESS,
		ActionTypes.DASHBOARD_FAILURE,
		ActionTypes.DASHBOARD_LOADER,
	);
	const dashboardService = new DashboardService(dispatchedActions);
	addBasicInterceptors(dashboardService);
	dashboardService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(dashboardService.makeRequest(props));
};

/**
 * Action method to get home screen item data
 * @param {object} props
 * @returns
 */

export const onGetItemsData = props => dispatch => {
	const dispatchedActions = new APIActionsBuilder(
		ActionTypes.GET_ITEMS_DATA_SUCCESS,
		ActionTypes.GET_ITEMS_DATA_FAILURE,
		ActionTypes.GET_ITEMS_DATA_LOADER,
	)
		.addSuccessExtra(props.key)
		.addInprogressExtra(props.key)
		.addFailureExtra(props.key)
		.build();
	const getItemsDataService = new GetItemsDataService(dispatchedActions);
	addBasicInterceptors(getItemsDataService);
	getItemsDataService.addRequestInterceptor(new AuthenticationHeaderInterceptor());
	dispatch(getItemsDataService.makeRequest(props));
};

/**
 * Action to set the selected customer organization and it's respective user.
 * @param {object} userDetails
 * @returns
 */

export const onSetCustomerOrgAndUser = userDetails => {
	return {
		type: ActionTypes.SET_CUSTOMER_ORG_AND_USER,
		payload: userDetails,
	};
};
