import React, { Component } from 'react';
import {
	StyleSheet,
	Modal,
	View,
	Text,
	FlatList,
	TouchableOpacity,
	ActivityIndicator,
} from 'react-native';
import PropTypes from 'prop-types';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';
import IMAGES from '@Images/index';
import { localeString } from '@Localization/index';
import { keyConstants } from '@Constants/KeyConstants';
import ListEmpty from '@ListEmpty/ListEmpty';
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';

const createStyleSheet = isRTL => {
	return StyleSheet.create({
		container: {
			backgroundColor: colors.opacityGrey,
			zIndex: 100,
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
		},
		innerContainer: {
			backgroundColor: colors.white,
			height: verticalScale(240),
			paddingTop: verticalScale(20),
			paddingBottom: verticalScale(5),
		},
		header: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			alignItems: 'center',
			height: verticalScale(36),
			paddingHorizontal: normalScale(16),
		},
		branchView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		iconPin: {
			width: normalScale(14),
			height: verticalScale(16),
		},
		dropdownText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
		},
		hitSlop: {
			top: verticalScale(15),
			bottom: verticalScale(15),
			right: normalScale(15),
			left: normalScale(15),
		},
		iconClose: {
			width: normalScale(12),
			height: verticalScale(12),
		},
		addBranchView: {
			height: verticalScale(36),
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingLeft: isRTL ? normalScale(28) : normalScale(30),
			paddingRight: isRTL ? normalScale(30) : normalScale(28),
			backgroundColor: colors.lightGreen,
			justifyContent: 'space-between',
		},
		iconPlus: {
			width: normalScale(14),
			height: verticalScale(14),
		},
		activityIndicator: {
			flex: 1,
		},
		branchesView: {
			height: verticalScale(36),
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			paddingLeft: isRTL ? normalScale(12) : normalScale(26),
			paddingRight: isRTL ? normalScale(26) : normalScale(12),
			backgroundColor: colors.white,
			justifyContent: 'space-between',
			borderBottomColor: colors.greenShadow,
			borderRadius: moderateScale(8),
			borderBottomWidth: normalScale(1),
			marginHorizontal: verticalScale(16),
		},
		labelText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(14),
		},
		activeLabelText: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
		},
		iconRight: {
			width: normalScale(12),
			height: verticalScale(9),
		},
	});
};

class BranchPicker extends Component {
	// Component to show the branch listing and select the branch.

	keyExtractor = (item, index) => {
		return index.toString();
	};

	renderItem = ({ item, index }) => {
		const { isRTL, activeBranchIndex, onPress, branchId } = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				onPress={() => onPress(index)}
				style={styles.branchesView}>
				<Text
					style={[
						styles.labelText,
						(activeBranchIndex ? activeBranchIndex === index : branchId === item.id) &&
							styles.activeLabelText,
					]}>
					{isRTL ? item.name_ar : item.name}
				</Text>
				{(activeBranchIndex ? activeBranchIndex === index : branchId === item.id) && (
					<ImageLoadComponent source={IMAGES.iconRight} style={styles.iconRight} />
				)}
			</TouchableOpacity>
		);
	};

	render() {
		const {
			isRTL,
			branchArray,
			isShowBranchPicker,
			onPressAdd,
			loader,
			onEndReached,
			onPressClose,
			placeholder,
			hasAddNewBranch,
			error,
			errorCode,
			onReload,
		} = this.props;
		const styles = createStyleSheet(isRTL);
		return (
			<Modal visible={isShowBranchPicker} transparent>
				<View style={styles.container}>
					<View style={styles.innerContainer}>
						<View style={styles.header}>
							<View style={styles.branchView}>
								<ImageLoadComponent
									source={IMAGES.iconPin}
									style={styles.iconPin}
								/>
								<Text style={styles.dropdownText}>{placeholder}</Text>
							</View>
							<TouchableOpacity
								activeOpacity={0.8}
								hitSlop={styles.hitSlop}
								onPress={onPressClose}>
								<ImageLoadComponent
									source={IMAGES.iconCross}
									style={styles.iconClose}
								/>
							</TouchableOpacity>
						</View>
						{hasAddNewBranch && (
							<View style={styles.addBranchView}>
								<Text style={styles.dropdownText}>
									{localeString(keyConstants.ADD_NEW_BRANCH)}
								</Text>
								<TouchableOpacity activeOpacity={0.8} onPress={onPressAdd}>
									<ImageLoadComponent
										source={IMAGES.iconPlusBlack}
										style={styles.iconPlus}
									/>
								</TouchableOpacity>
							</View>
						)}
						{loader && branchArray.length === 0 ? (
							<ActivityIndicator
								style={styles.activityIndicator}
								size="small"
								color={colors.darkBlue}
							/>
						) : error ? (
							<ErrorComponent
								isRTL={isRTL}
								errorCode={errorCode}
								onCallApi={onReload}
							/>
						) : branchArray.length === 0 ? (
							<ListEmpty text={localeString(keyConstants.NO_BRANCHES_FOUND)} />
						) : (
							<FlatList
								data={branchArray}
								keyExtractor={this.keyExtractor}
								renderItem={this.renderItem}
								onEndReached={onEndReached}
								onEndReachedThreshold={0.5}
							/>
						)}
					</View>
				</View>
			</Modal>
		);
	}
}

BranchPicker.propTypes = {
	branchArray: PropTypes.array.isRequired,
	isShowBranchPicker: PropTypes.bool.isRequired,
	onPressAdd: PropTypes.func.isRequired,
	loader: PropTypes.bool.isRequired,
	onEndReached: PropTypes.func.isRequired,
	onPressClose: PropTypes.func.isRequired,
	placeholder: PropTypes.string.isRequired,
	hasAddNewBranch: PropTypes.bool.isRequired,
	error: PropTypes.bool.isRequired,
	errorCode: PropTypes.object.isRequired,
	onReload: PropTypes.func.isRequired,
	isRTL: PropTypes.bool.isRequired,
	activeBranchIndex: PropTypes.element.isRequired,
	onPress: PropTypes.func.isRequired,
	branchId: PropTypes.element.isRequired,
};

export default BranchPicker;
