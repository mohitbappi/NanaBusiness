// import libraries
import React from 'react';
import { Dimensions } from 'react-native';
import ContentLoader, { Circle, Rect } from 'react-content-loader/native';
import PropTypes from 'prop-types';

// import colors
import * as colors from '@assets/colors';

// import utils
import { normalScale, verticalScale } from '@device/normalize';

const windowWidth = Dimensions.get('window').width;

export const TextShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(40)}>
			<Rect
				x={normalScale(16)}
				y={verticalScale(16)}
				width={normalScale(140)}
				height={verticalScale(16)}
			/>
		</ContentLoader>
	);
};

export const ItemsShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={normalScale(120)}
			height={verticalScale(150)}>
			<Rect
				x={normalScale(0)}
				y={verticalScale(0)}
				rx={normalScale(8)}
				ry={normalScale(8)}
				width={normalScale(110)}
				height={verticalScale(90)}
			/>
			<Rect
				x={normalScale(0)}
				y={verticalScale(100)}
				rx={normalScale(8)}
				ry={normalScale(8)}
				width={normalScale(110)}
				height={verticalScale(16)}
			/>
			<Rect
				x={normalScale(0)}
				y={verticalScale(128)}
				rx={normalScale(8)}
				ry={normalScale(8)}
				width={normalScale(110)}
				height={verticalScale(16)}
			/>
		</ContentLoader>
	);
};

export const LineShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			height={verticalScale(8)}>
			<Rect
				x={normalScale(16)}
				width={windowWidth - normalScale(32)}
				height={verticalScale(3)}
			/>
		</ContentLoader>
	);
};

export const BrandsShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			height={verticalScale(60)}>
			<Circle cx={normalScale(44)} cy={normalScale(28)} r={normalScale(28)} />
			<Circle cx={normalScale(116)} cy={normalScale(28)} r={normalScale(28)} />
			<Circle cx={normalScale(188)} cy={normalScale(28)} r={normalScale(28)} />
			<Circle cx={normalScale(260)} cy={normalScale(28)} r={normalScale(28)} />
		</ContentLoader>
	);
};

export const BannerShimmer = props => {
	const { isRTL } = props;
	return (
		<ContentLoader
			backgroundColor={colors.grey}
			speed={1}
			rtl={isRTL}
			width={windowWidth}
			height={verticalScale(100)}>
			<Rect
				x={normalScale(16)}
				width={windowWidth - normalScale(32)}
				height={verticalScale(120)}
			/>
		</ContentLoader>
	);
};

TextShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

ItemsShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

LineShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

BrandsShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};

BannerShimmer.propTypes = {
	isRTL: PropTypes.bool.isRequired,
};
