/** action types for storing user details */
export const STORE_USER_DETAILS = 'store_user_details';

/** action types for branch listing */
export const GET_BRANCH_LISTING_SUCCESS = 'get_branch_listing_success';
export const GET_BRANCH_LISTING_FAILURE = 'get_branch_listing_failure';
export const GET_BRANCH_LISTING_LOADER = 'get_branch_listing_loader';

/** action types for cart count */
export const GET_CART_COUNT_SUCCESS = 'get_cart_count_success';
export const GET_CART_COUNT_FAILURE = 'get_cart_count_failure';
export const GET_CART_COUNT_LOADER = 'get_cart_count_loader';

/** action types for notification count */
export const GET_NOTIFICATION_COUNT_SUCCESS = 'get_notification_count_success';
export const GET_NOTIFICATION_COUNT_FAILURE = 'get_notification_count_failure';
export const GET_NOTIFICATION_COUNT_LOADER = 'get_notification_count_loader';

/** action types for setting selected branch */
export const SET_SELECTED_BRANCH = 'set_selected_branch';

/** action types for branch update */
export const UPDATE_BRANCH_SUCCESS = 'update_branch_success';
export const UPDATE_BRANCH_FAILURE = 'update_branch_failure';
export const UPDATE_BRANCH_LOADER = 'update_branch_loader';

/** action types for dashoard-data */
export const DASHBOARD_SUCCESS = 'dashboard_success';
export const DASHBOARD_FAILURE = 'dashboard_failure';
export const DASHBOARD_LOADER = 'dashboard_loader';

/** action types for get Item Data */
export const GET_ITEMS_DATA_SUCCESS = 'get_items_data_success';
export const GET_ITEMS_DATA_FAILURE = 'get_items_data_failure';
export const GET_ITEMS_DATA_LOADER = 'get_items_data_loader';

/** action types for resetting home reducer */
export const RESET_HOME_SCREEN_REDUCER = 'reset_home_screen_reducer';

export const SET_CUSTOMER_ORG_AND_USER = 'set_customer_org_and_user';
