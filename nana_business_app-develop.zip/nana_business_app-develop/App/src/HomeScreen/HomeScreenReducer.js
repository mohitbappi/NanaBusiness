// import constants
import { ApiCall } from '@Constants/Constants';

// import action types
import * as ActionTypes from './ActionType';

const initialState = {
	userDetails: null,
	branchListing: [],
	success: false,
	error: false,
	errorCode: '',
	loader: false,
	cartCount: 0,
	cartAmount: 0,
	notificationCount: 0,
	branchDetail: null,
	activeBranchIndex: null,
	dashboardData: null,
	isBranchLoader: false,
	isDashboard: false,
	zoneId: null,
};

const initialDataItem = {
	isSuccess: false,
	isLoading: false,
	isError: false,
	data: null,
};

const HomeScreenReducer = (state = initialState, action = {}) => {
	switch (action.type) {
		case ActionTypes.STORE_USER_DETAILS:
			return {
				...state,
				userDetails: action.payload,
			};
		case ActionTypes.GET_BRANCH_LISTING_SUCCESS: {
			const isOverwriteExistingList = action.extra;
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				branchListing: isOverwriteExistingList
					? [...state.branchListing, ...action.payload.branch_list]
					: action.payload.branch_list,
				isCategory: false,
				branchCount: action.payload.count,
			};
		}
		case ActionTypes.GET_BRANCH_LISTING_LOADER:
			return {
				...state,
				error: false,
				errorCode: '',
				success: false,
				isCategory: false,
				isBranchLoader: true,
			};
		case ActionTypes.GET_BRANCH_LISTING_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isDashboard: false,
			};
		case ActionTypes.DASHBOARD_FAILURE:
			return {
				...state,
				error: true,
				errorCode: action.payload,
				success: false,
				loader: false,
				isDashboard: true,
			};
		case ActionTypes.DASHBOARD_SUCCESS: {
			const data = [];
			action?.payload?.sections.forEach(element => {
				const key = Object.keys(element)[0];
				if (element[key] && element[key].to_show) {
					if (element[key].data === ApiCall) {
						data.push({ [key]: initialDataItem });
					} else if (element[key].data !== null) {
						data.push({
							[key]: { ...initialDataItem, isSuccess: true, data: element[key].data },
						});
					}
				}
			});
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				dashboardData: data,
				zoneId: action?.payload?.zone_id,
				isDashboard: true,
			};
		}
		case ActionTypes.DASHBOARD_LOADER:
			return {
				...state,
				loader: true,
				error: false,
				errorCode: '',
				success: false,
			};
		case ActionTypes.GET_CART_COUNT_SUCCESS:
			return {
				...state,
				cartCount: action.payload.count,
				cartAmount: action.payload.total_amount,
			};
		case ActionTypes.GET_NOTIFICATION_COUNT_SUCCESS:
			return {
				...state,
				notificationCount: action.payload.pending_notifications,
			};
		case ActionTypes.GET_ITEMS_DATA_SUCCESS: {
			const successData =
				action.payload.items !== undefined
					? action.payload.items
					: action.payload.data !== undefined
					? action.payload.data
					: action.payload.result !== undefined
					? action.payload.result
					: null;
			const index = state.dashboardData.findIndex(
				object => Object.keys(object)[0] === action.extra,
			);
			if (successData) {
				state.dashboardData.splice(index, 1, {
					[action.extra]: { ...initialState, isSuccess: true, data: successData },
				});
			} else {
				state.dashboardData.splice(index, 1);
			}
			return {
				...state,
				dashboard: state.dashboardData,
				isDashboard: false,
				success: false,
			};
		}
		case ActionTypes.GET_ITEMS_DATA_FAILURE: {
			const failureIndex = state.dashboardData.findIndex(
				pobj => Object.keys(pobj)[0] === action.extra,
			);
			state.dashboardData.splice(failureIndex, 1, {
				[action.extra]: { ...initialState, data: action.payload, isError: true },
			});
			return {
				...state,
				dashboard: state.dashboardData,
			};
		}
		case ActionTypes.GET_ITEMS_DATA_LOADER: {
			const loadingIndex = state.dashboardData.findIndex(
				pobj => Object.keys(pobj)[0] === action.extra,
			);
			state.dashboardData.splice(loadingIndex, 1, {
				[action.extra]: { ...initialState, isLoading: true },
			});
			return {
				...state,
				dashboard: state.dashboardData,
			};
		}
		case ActionTypes.SET_SELECTED_BRANCH:
			return {
				...state,
				branchDetail: action.payload.branchDetail,
				activeBranchIndex: action.payload.index,
			};
		case ActionTypes.UPDATE_BRANCH_SUCCESS:
			return {
				...state,
				success: true,
				error: false,
				errorCode: '',
				loader: false,
				isCategory: false,
				invoiceLoader: false,
			};
		case ActionTypes.RESET_HOME_SCREEN_REDUCER: // Reset the home screen data.
			return {
				...state,
				branchListing: [],
				success: false,
				error: false,
				errorCode: '',
				loader: false,
				cartCount: 0,
				cartAmount: 0,
				notificationCount: 0,
				branchDetail: null,
				activeBranchIndex: null,
				dashboardData: null,
				isBranchLoader: false,
				zoneId: null,
			};
		case ActionTypes.SET_CUSTOMER_ORG_AND_USER: {
			const { organization, defaultUserId, defaultUserName } = action.payload;
			const userPayload = state.userDetails.user;
			userPayload.organization = organization;
			userPayload.default_user_id = defaultUserId;
			userPayload.default_user_name = defaultUserName;
			return {
				...state,
				userDetails: { ...state.userDetails, userPayload },
			};
		}
		default:
			return state;
	}
};

export default HomeScreenReducer;
