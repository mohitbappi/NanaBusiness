import { StyleSheet, Dimensions } from 'react-native';
import * as colors from '@assets/colors';
import normalize, { normalScale, verticalScale, moderateScale } from '@device/normalize';
import fonts from '@assets/fonts';
import RTLFunctions from '@Util/RTLFunctions';
import { fontsConstants } from '@Constants/Constants';

const rtlFunctions = new RTLFunctions();
const brandWidth = Dimensions.get('window').width / 1.1;
const categoryWidth = Dimensions.get('window').width / 5.3;
const { width } = Dimensions.get('window');

export const createStyleSheet = isRTL => {
	return StyleSheet.create({
		noDataText: {
			alignSelf: 'center',
			color: colors.lightWhite,
			fontFamily: isRTL ? fonts.TajawalLight : fonts.LatoLight,
			fontSize: normalize(14),
			marginTop: verticalScale(5),
			marginBottom: verticalScale(10),
		},
		separator: {
			height: verticalScale(4),
			backgroundColor: colors.whitishGrey,
			marginTop: verticalScale(6),
		},
		container: {
			flex: 1,
			backgroundColor: colors.white,
		},
		header: {
			height: verticalScale(40),
			backgroundColor: colors.white,
			alignItems: 'center',
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			paddingHorizontal: normalScale(16),
		},
		locationView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		iconPin: {
			width: normalScale(15),
			height: verticalScale(18),
		},
		dropdownView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			marginLeft: isRTL ? 0 : normalScale(12),
			marginRight: isRTL ? normalScale(12) : 0,
			alignItems: 'center',
		},
		dropdownText: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
		},
		iconArrowDown: {
			height: verticalScale(6),
			width: normalScale(10),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		iconsView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
		},
		iconCartHome: {
			height: verticalScale(30),
			width: normalScale(30),
		},
		notificationContainerHomeStyle: {
			position: 'absolute',
			top: -verticalScale(1),
			left: normalScale(20),
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: colors.red,
			borderRadius: normalScale(6),
			width: normalScale(12),
			height: normalScale(12),
			borderColor: colors.white,
			borderWidth: normalScale(1),
		},
		notificationCountHomeStyle: {
			fontSize: normalize(8),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.white,
		},
		iconNotification: {
			height: verticalScale(28),
			width: normalScale(28),
			marginLeft: isRTL ? 0 : normalScale(8),
			marginRight: isRTL ? normalScale(8) : 0,
		},
		scrollView: {
			marginBottom: verticalScale(18),
		},
		zoneContainer: {
			marginTop: verticalScale(30),
			justifyContent: 'center',
			alignItems: 'center',
			paddingHorizontal: normalScale(30),
			paddingBottom: verticalScale(10),
		},
		iconOOZ: {
			height: normalScale(141),
			width: normalScale(141),
		},
		oozTitle: {
			color: colors.lightPurpleBlue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			marginTop: verticalScale(8),
			textAlign: 'center',
		},
		oozDesc: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			marginTop: verticalScale(6),
			textAlign: 'center',
		},
		searchView: {
			position: 'absolute',
			bottom: -verticalScale(10),
			right: isRTL ? null : 0,
			left: isRTL ? 0 : null,
		},
		iconSearchGreen: {
			height: verticalScale(89),
			width: normalScale(88),
		},
		card: {
			paddingVertical: verticalScale(12),
			borderRadius: moderateScale(8),
			backgroundColor: colors.lightGreen,
			paddingHorizontal: verticalScale(16),
			marginTop: verticalScale(16),
		},
		availableBalance: {
			color: colors.lightBlack,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(12),
			alignSelf: 'center',
		},
		amount: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(16),
			marginTop: verticalScale(4),
			alignSelf: 'center',
		},
		applyView: {
			marginBottom: verticalScale(6),
		},
		apply: {
			color: colors.blue,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(12),
			marginTop: verticalScale(4),
			alignSelf: 'center',
		},
		orangeCard: {
			paddingVertical: verticalScale(16),
			borderRadius: moderateScale(8),
			backgroundColor: colors.skyBlue,
			paddingHorizontal: verticalScale(16),
			marginTop: verticalScale(8),
			marginBottom: verticalScale(16),
		},
		dueAmountView: {
			paddingVertical: verticalScale(2),
			paddingHorizontal: verticalScale(8),
			borderColor: colors.darkOrange,
			borderWidth: normalScale(1),
			borderRadius: moderateScale(4),
			marginBottom: verticalScale(6),
			alignSelf: 'center',
			marginLeft: normalScale(90),
		},
		dueText: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		label: {
			fontSize: normalize(12),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			marginTop: verticalScale(16),
			textAlign: 'center',
		},
		progressBar: {
			width: width - normalScale(64),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			height: verticalScale(4),
			borderRadius: moderateScale(4.5),
			backgroundColor: colors.white,
		},
		usedAmount: {
			backgroundColor: colors.lightBlueShadowGrey,
			borderTopLeftRadius: moderateScale(4.5),
			borderBottomLeftRadius: moderateScale(4.5),
		},
		dueAmount: {
			backgroundColor: colors.darkOrange,
		},
		detailView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(4),
		},
		text: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			fontSize: normalize(10),
		},
		amountStyle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(10),
		},
		recentView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginTop: verticalScale(16),
		},
		itemView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginBottom: verticalScale(12),
			marginTop: verticalScale(16),
			marginHorizontal: normalScale(16),
			alignItems: 'center',
		},
		sectionTitle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
			width: normalScale(240),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		sectionErrorTitle: {
			width: normalScale(200),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		categoryHorizontalView: {
			width: categoryWidth,
			flexDirection: 'row',
		},
		inactiveImageView: {
			width: normalScale(48),
			height: normalScale(48),
			backgroundColor: colors.lightGreen,
			borderRadius: normalScale(27),
			justifyContent: 'center',
			alignItems: 'center',
		},
		defaultImage: {
			width: normalScale(17),
			height: verticalScale(17),
		},
		creditLineContainer: {
			backgroundColor: colors.lightSkyBlue,
			borderRadius: normalScale(4),
			paddingHorizontal: normalScale(12),
			paddingVertical: verticalScale(8),
			marginTop: verticalScale(12),
			marginHorizontal: normalScale(16),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		creditInnerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			alignItems: 'center',
		},
		applyCreditView: {
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 12),
			marginRight: rtlFunctions.getMarginRight(isRTL, 12),
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.blue,
		},
		creditLineView: {
			paddingHorizontal: normalScale(16),
			marginTop: verticalScale(16),
		},
		tryAgainView: {
			paddingHorizontal: normalScale(16),
		},
		innerContainer: {
			paddingHorizontal: normalScale(16),
		},
		brandView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginTop: verticalScale(16),
		},
		brandsContainer: {
			alignItems: 'center',
			marginLeft: isRTL ? normalScale(25) : 0,
			marginRight: isRTL ? 0 : normalScale(25),
			width: normalScale(53),
		},
		inactiveView: {
			marginTop: verticalScale(12),
			marginLeft: isRTL ? normalScale(15) : 0,
			marginRight: isRTL ? 0 : normalScale(15),
			alignItems: 'center',
			width: categoryWidth,
		},
		brandCategoryTitle: {
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			fontSize: normalize(12),
		},
		viewBrands: {
			color: colors.darkBlue,
			fontFamily: isRTL ? fonts.TajawalMedium : fonts.LatoMedium,
			fontSize: normalize(11),
		},
		horizontalView: {
			width: brandWidth,
			flexDirection: 'row',
		},
		brandImage: {
			width: normalScale(60),
			height: normalScale(60),
			marginTop: verticalScale(12),
		},
		brandViewNoImage: {
			width: normalScale(50),
			height: normalScale(50),
			marginTop: verticalScale(12),
			backgroundColor: colors.lightGreen,
			justifyContent: 'center',
			borderRadius: normalScale(24),
		},
		brandLabel: {
			fontSize: normalize(10),
			color: colors.black,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			textAlign: 'center',
			paddingHorizontal: normalScale(3),
		},
		offers: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginTop: verticalScale(8),
			marginBottom: verticalScale(12),
		},
		image: {
			width: normalScale(60),
			height: normalScale(60),
			borderRadius: normalScale(30),
		},
		offersView: {
			marginBottom: verticalScale(15),
		},
		activityIndicator: {
			marginTop: verticalScale(80),
		},
		pendingView: {
			flexDirection: isRTL ? 'row-reverse' : 'row',
			justifyContent: 'space-between',
			marginBottom: verticalScale(8),
			marginTop: verticalScale(16),
		},
		pending: {
			color: colors.black,
			fontFamily: isRTL ? fonts.TajawalBold : fonts.LatoBold,
			fontSize: normalize(14),
			marginTop: verticalScale(16),
			marginBottom: verticalScale(12),
		},
		hitSlop: {
			top: verticalScale(30),
			bottom: verticalScale(30),
			right: normalScale(30),
			left: normalScale(30),
		},
		iconRightArrow: {
			height: normalScale(10),
			width: normalScale(12),
			transform: isRTL ? [{ rotate: '180deg' }] : [{ rotate: '360deg' }],
		},
		containerStyle: {
			width: normalScale(170),
			backgroundColor: colors.whitishGrey,
			paddingHorizontal: normalScale(8),
			paddingVertical: verticalScale(8),
			marginRight: isRTL ? 0 : normalScale(10),
			marginLeft: isRTL ? normalScale(10) : 0,
			borderRadius: moderateScale(8),
		},
		subtitleStyle: {
			width: normalScale(100),
		},
		titleStyle: {
			width: normalScale(90),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			height: verticalScale(29),
		},
		priceDetailsContainerStyle: {
			marginTop: 0,
		},
		balanceView: {
			backgroundColor: colors.orange,
			borderRadius: normalScale(4),
			paddingHorizontal: normalScale(12),
			paddingVertical: verticalScale(8),
			marginTop: verticalScale(12),
			marginHorizontal: normalScale(16),
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			alignItems: 'center',
		},
		innerView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		iconHomeWallet: {
			width: normalScale(30),
			height: verticalScale(30),
		},
		balanceContainer: {
			marginLeft: rtlFunctions.getMarginLeft(isRTL, 12),
			marginRight: rtlFunctions.getMarginRight(isRTL, 12),
		},
		balanceAmount: {
			fontSize: normalize(14),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.bold),
			color: colors.black,
			marginLeft: -rtlFunctions.getMarginLeft(isRTL, 4),
			marginRight: -rtlFunctions.getMarginRight(isRTL, 4),
			textAlign: rtlFunctions.getTextAlign(isRTL),
		},
		balanceLabel: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.blackGreyWhite,
			marginTop: verticalScale(4),
		},
		addMoney: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			color: colors.blue,
		},
		mainContainer: {
			paddingHorizontal: normalScale(16),
		},
		searchButtonContainer: {
			marginBottom: normalScale(0),
		},
		carouselView: {
			marginHorizontal: normalScale(16),
		},
		hotDealContainer: {
			alignItems: 'center',
			marginLeft: rtlFunctions.getMarginLeftRTL(isRTL, 8),
			marginRight: rtlFunctions.getMarginRightRTL(isRTL, 8),
			width: normalScale(122),
		},
		hotDealImage: {
			width: normalScale(122),
			height: normalScale(106),
			marginTop: verticalScale(12),
		},
		subCatHeadView: {
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
			justifyContent: 'space-between',
			marginVertical: verticalScale(16),
		},
		subCategoryView: {
			backgroundColor: colors.greenShadow,
			marginRight: normalScale(12),
			paddingHorizontal: normalScale(12),
			paddingVertical: verticalScale(6),
			borderColor: colors.greenShadow,
			borderWidth: normalize(1),
			borderRadius: moderateScale(15),
		},
		subCategoryText: {
			fontSize: normalize(12),
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.regular),
			color: colors.darkBlue,
		},
		viewSubCatRow: {
			marginVertical: verticalScale(4),
		},
		viewRetry: {
			paddingHorizontal: normalScale(6),
			alignItems: 'center',
			flexDirection: rtlFunctions.getFlexDirection(isRTL),
		},
		iconRetry: {
			height: verticalScale(16),
			width: normalScale(16),
			marginHorizontal: normalScale(4),
		},
		textRetry: {
			color: colors.lightBlueShadowGrey,
			fontFamily: rtlFunctions.getFont(isRTL, fontsConstants.medium),
			fontSize: normalize(11),
		},
	});
};

export default createStyleSheet;
