// import libraries
import React, { Component } from 'react';
import { Text, View, TouchableOpacity, FlatList } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PropTypes from 'prop-types';
import Config from 'react-native-config';
import ReactAppboy from 'react-native-appboy-sdk';

// import utils
import IMAGES from '@Images/index';
import { localeString } from '@Localization/index';
import { keyConstants } from '@Constants/KeyConstants';
import { currencyFormatter } from '@Util/CurrencyFormatter';
import navigations from '@routes/navigations';
import { getValueInDecimal } from '@Util/GetValueInDecimal';
import logCustomEventOnBraze from '@Util/LogCustomEventOnBraze';
import getTestIdProps from '@Util/GetTestIdProps';

// import constants
import {
	fetchDataWithPagination,
	ninePlus,
	splitOrganizationLength,
	stretch,
	IMAGE_TYPE,
	customerAdmin,
	paymentType,
	navigationType,
	toastShowTime,
	toggleFeatureConstants,
	isToggleFeatureEnable,
	homeScreenDataPoints,
	numberOfSubcategoryInRow,
	numberOfLinesForHomeLabel,
	accountManager,
	salesExecutive,
	APIConstants,
	locatorConstants,
} from '@Constants/Constants';
import { constants } from '@RefreshControlComponent/Constants';

// import components
import ImageLoadComponent from '@ImageLoadComponent/ImageLoadComponent';
import HomeItemComponent from '@HomeItemComponent/HomeItemComponent';
import CreditLineInformation from '@CreditLineInformation/CreditLineInformation';
import PopupButtonComponent from '@PopupButtonComponent/PopupButtonComponent';
import CarouselComponent from '@CarouselComponent/CarouselComponent';
import CreditLineDueComponent from '@CreditLineDueComponent/CreditLineDueComponent';
import Spinner from '@Spinner/Spinner';
import ScrollViewComponent from '@RefreshControlComponent/RefreshControlComponent';
import ToastComponent from '@ToastComponent/ToastComponent';
import ErrorComponent from '@ErrorComponent/ErrorComponent';
import ProductCardComponent from '@Products/ProductCardComponent';
import ToggleFeatureScreen from '@ToggleFeatureScreen/ToggleFeatureScreen';
import { SearchShimmer } from '@OrdersScreen/OrdersScreenShimmer';
import AlertComponent from '@Util/AlertComponent';

// import actions
import * as InvoicesScreenAction from '@InvoicesScreen/InvoicesScreenAction';
import * as AddMoneyActions from '@AddMoneyScreen/AddMoneyScreenAction';
import * as PullToRefreshActions from '@RefreshControlComponent/RefreshControlComponentAction';
import * as ToggleFeaturesActions from '@ToggleFeatureScreen/ToggleFeatureScreenAction';
import * as SelectCustomerOrganizationActions from '@SelectCustomerOrganizationScreen/SelectCustomerOrganizationAction';
import * as OrdersListingActions from '@OrdersScreen/OrdersScreenAction';
import * as HomeScreenActions from './HomeScreenAction';

// import HomeScreen Component
import BranchPicker from './BranchPicker';
import {
	BannerShimmer,
	BrandsShimmer,
	ItemsShimmer,
	LineShimmer,
	TextShimmer,
} from './HomeScreenShimmer';

// import styles
import { createStyleSheet } from './HomeScreenStyle';

class HomeScreen extends Component {
	constructor(props) {
		super(props);
		this.branchLimit = fetchDataWithPagination.limit;
		this.branchPage = fetchDataWithPagination.page;
		this.state = {
			activeCategoryIndex: 0,
			isShowBranchPicker: false,
			emptySkeltonArray: ['', '', ''],
			isApiError: false,
			toastMessage: '',
		};
	}

	componentDidMount() {
		const { navigation, pullToRefreshActions } = this.props;
		this.onSetOrganization();
		this.onboardUserToBraze();
		logCustomEventOnBraze('appLaunch', null);
		this.willFocusListener = navigation.addListener('focus', () => {
			this.onStoreUserDetails();
			pullToRefreshActions.onHandlePullToRefresh(false);
			this.onCallAPIs();
		});
		if (!isToggleFeatureEnable) {
			// Won't call toggle feature API if return false
			this.getDashboardData();
		}
	}

	componentDidUpdate(prevProps) {
		const {
			homeScreenInfo,
			toggleFeaturesInfo,
			addMoneyInfo,
			pullToRefreshActions,
			navigation,
			toggleFeaturesActions,
			userDetails,
		} = this.props;
		const { dashboardData, success, zoneId } = homeScreenInfo;
		const { success: toggleApiSuccess } = toggleFeaturesInfo;
		const {
			success: addMoneySuccess,
			paymentDetail,
			isCalledfromHomeScreen,
			error,
			errorCode,
		} = addMoneyInfo;
		// Error handling if there is no data in the object.
		const { id } = (userDetails && userDetails.user && userDetails.user.organization) || {};
		if (
			toggleApiSuccess &&
			prevProps.toggleFeaturesInfo.success !== toggleFeaturesInfo.success &&
			isToggleFeatureEnable
		) {
			// If toggle API returns success.
			this.getDashboardData(); // Function to call the dashboard API.
		}
		if (
			success &&
			dashboardData &&
			prevProps.homeScreenInfo.isDashboard !== homeScreenInfo.isDashboard
		) {
			dashboardData.map(element => {
				const key = Object.keys(element)[0];
				if (zoneId && element[key] && !element[key].isSuccess) {
					this.getItemsData(key);
				}
			});
			pullToRefreshActions.onHandlePullToRefresh(false);
		}
		if (
			addMoneySuccess &&
			isCalledfromHomeScreen &&
			prevProps.addMoneyInfo.success !== addMoneyInfo.success
		) {
			// After getting successful response from the api it will navigate to payment screen page.
			navigation.navigate(navigations.PAYMENT_NAVIGATION, {
				paymentDetail,
				type: navigationType.creditLine,
				extraParams: { organizationId: id },
			});
		}
		if (error && isToggleFeatureEnable && prevProps.addMoneyInfo.error !== addMoneyInfo.error) {
			// Will update the online payment value to false because user is not authorized.
			this.setState(
				{
					toastMessage: localeString(`${errorCode.error}`),
					isApiError: true,
				},
				() => {
					toggleFeaturesActions.onUpdateSpecificToggleFeature(
						toggleFeatureConstants.onlinePayment,
						false,
					);
				},
			);
			setTimeout(() => {
				this.setState({
					isApiError: false,
				});
			}, toastShowTime);
		}
	}

	onCallAPIs = async () => {
		this.onGetCartCount();
		this.onGetNotificationCount();
	};

	onStoreUserDetails = async () => {
		// Will store the user details in async storage.
		const { homeScreenActions } = this.props;
		const userDetail = await AsyncStorage.getItem('user_details');
		homeScreenActions.onStoreUserDetails(JSON.parse(userDetail));
	};

	onSetOrganization = async () => {
		// Will set the organization after launching the application.
		const { selectCustomerOrganizationActions, languageInfo } = this.props;
		const { isRTL } = languageInfo;
		let userDetail = await AsyncStorage.getItem('user_details');
		userDetail = JSON.parse(userDetail);
		const { organization, default_user_id, default_user_name, role } = userDetail.user || {};
		const {
			zone_id,
			zone,
			zone_ar,
			id,
			name,
			name_ar,
			branch_id,
			branch_name,
			branch_name_ar,
		} = organization;
		if (role === accountManager || role === salesExecutive) {
			selectCustomerOrganizationActions.onSetDetails({
				selectedZoneId: zone_id,
				zoneName: zone,
				zoneArabicName: zone_ar,
				selectedCustomerOrganizationId: id,
				customerOrganizationName: isRTL ? name_ar : name,
				selectedBranchId: branch_id,
				branchName: branch_name,
				branchArabicName: branch_name_ar,
				selectedUserId: default_user_id,
				userName: default_user_name,
				isBranchDropdownVisible: branch_id !== null,
			});
		}
	};

	onboardUserToBraze = async () => {
		// Will save the user details on the braze dashboard.
		const url = Config.SERVER_URL;
		if (url.includes('app.nana.business')) {
			let userDetail = await AsyncStorage.getItem('user_details');
			userDetail = JSON.parse(userDetail);
			const { user } = userDetail || {};
			if (user) {
				ReactAppboy.changeUser(`${user?.id}`);
				ReactAppboy.setEmail(user?.email_address);
				ReactAppboy.setPhoneNumber(user?.mobile);
				ReactAppboy.setFirstName(user?.name);
				ReactAppboy.setCustomUserAttribute('city', user?.organization?.city);
				ReactAppboy.setCustomUserAttribute('zoneId', user?.organization?.zone_id);
			}
		}
	};

	getDashboardData = async () => {
		// API call to get the dashboard data.
		const { homeScreenInfo, homeScreenActions } = this.props;
		const { branchListing, activeBranchIndex } = homeScreenInfo;
		let userDetail = await AsyncStorage.getItem('user_details');
		userDetail = JSON.parse(userDetail);
		const id =
			activeBranchIndex !== null
				? branchListing &&
				  branchListing[activeBranchIndex] &&
				  branchListing[activeBranchIndex].id
				: userDetail &&
				  userDetail.user &&
				  userDetail.user.organization &&
				  userDetail.user.organization.id;
		const queryParams = {};
		queryParams.branch_id = id;
		homeScreenActions.onGetDashboard(queryParams);
	};

	onGetCartCount = () => {
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetCartCount();
	};

	onGetNotificationCount = () => {
		const { homeScreenActions } = this.props;
		homeScreenActions.onGetNotificationCount();
	};

	getItemsData = key => {
		// API call to get the data of all the dashboard sections.
		const { homeScreenInfo, homeScreenActions, userDetails } = this.props;
		const { branchListing, activeBranchIndex } = homeScreenInfo;
		const id =
			activeBranchIndex !== null
				? branchListing &&
				  branchListing[activeBranchIndex] &&
				  branchListing[activeBranchIndex].id
				: userDetails &&
				  userDetails.user &&
				  userDetails.user.organization &&
				  userDetails.user.organization.id;
		const requestPayload = {
			key,
			endPoint:
				key === homeScreenDataPoints.discountItems
					? APIConstants.customer
					: APIConstants.retailer,
			queryParams: {
				branch: id,
			},
		};
		homeScreenActions.onGetItemsData(requestPayload);
	};

	onSelectBranch = index => {
		// Will select the branch from the branch listing.
		const { homeScreenInfo, homeScreenActions, ordersListingActions } = this.props;
		const { branchListing } = homeScreenInfo;
		const onPerformAction = () => {
			homeScreenActions.onSetSelectedBranch(branchListing[index], index);
			this.setState({ isShowBranchPicker: false }, () => {
				this.getDashboardData();
				this.updateBranch();
				ordersListingActions.onHandleApiCall(true);
			});
		};
		if (branchListing?.[index]?.zone_id) {
			onPerformAction();
		} else {
			// If zone id is null the alert will come.
			const alertOptions = {
				message: localeString(keyConstants.ZONE_ERROR),
				onPressYes: onPerformAction,
				onPressNo: () =>
					this.setState({
						isShowBranchPicker: false,
					}),
			};
			AlertComponent(alertOptions);
		}
	};

	onAddBranch = () => {
		// Will navigate to the add new branch screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.ADD_NEW_BRANCH_NAVIGATION);
		this.onPressClose();
	};

	onPressClose = () => this.setState({ isShowBranchPicker: false });

	onEndReached = () => {
		this.branchPage += 1;
		this.onGetBranches(true);
	};

	keyExtractor = (item, index) => {
		return index.toString();
	};

	onPressOption = (index, id) => {
		const { navigation } = this.props;
		this.setState({ activeCategoryIndex: index }, () => {
			navigation.navigate(navigations.PRODUCT_LIST_NAVIAGTION, {
				category_id: id,
				activeCategoryIndex: index,
			});
		});
	};

	onPressSubCategory = (index, item) => {
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_LIST_NAVIAGTION, {
			category_id: item.category_id,
			subCategoryId: item.id,
		});
	};

	onGetCategoryDefaultImage = (index, activeCategoryIndex) => {
		if (index === activeCategoryIndex) {
			return IMAGES.iconDefaultCategoryActive;
		}
		return IMAGES.iconDefaultCategoryInactive;
	};

	onPressBrand = item => {
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_LIST_NAVIAGTION, { brand_id: item.id });
	};

	onClickDropdown = () => {
		const { userDetails, navigation } = this.props;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		if (role === accountManager || role === salesExecutive) {
			// Will navigate to the screen to select customer organization if role is account manager or sales executive.
			navigation.navigate(navigations.SELECT_CUSTOMER_USER_NAVIGATION);
		} else {
			// Will get the branches if role is customer or customerAdmin.
			this.branchPage = 1;
			this.setState({ isShowBranchPicker: true });
			this.onGetBranches(false);
		}
	};

	onPressCart = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.CART_NAVIGATION);
	};

	onPressApplyForCreditLine = () => {
		// Navigate to Increase Credit Line screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.INCREASE_CREDIT_LINENAVIGATION);
	};

	onPressNotification = () => {
		// Will navigate to the notification screen.
		const { navigation, homeScreenInfo } = this.props;
		const { notificationCount } = homeScreenInfo;
		navigation.navigate(navigations.NOTIFICATION_NAVIGATION, { notificationCount });
	};

	onGetBranches = isOverwriteExistingList => {
		// API call to get the branches.
		const { homeScreenActions } = this.props;
		const queryParams = {};
		queryParams.limit = this.branchLimit;
		queryParams.page = this.branchPage;
		homeScreenActions.onGetBranches(queryParams, isOverwriteExistingList);
	};

	updateBranch = () => {
		const { homeScreenActions, homeScreenInfo, userDetails } = this.props;
		const { branchDetail } = homeScreenInfo;
		const { id } = branchDetail || userDetails.user.organization;
		const queryParams = { id };
		homeScreenActions.onUpdateBranch(queryParams);
	};

	viewAllCategories = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.VIEW_ALL_CATEGORIES_NAVIGATION);
	};

	viewAllDiscountItems = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ITEM_LIST_NAVIGATION, {
			title: keyConstants.DISCOUNTS,
		});
	};

	viewAllBrands = catId => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ALL_BRANDS_NAVIGATION, { catId });
	};

	goToReports = () => {
		// Will navigate to the credit line report screen.
		const { navigation, userDetails } = this.props;
		const { id } = userDetails && userDetails.user && userDetails.user.organization;
		navigation.navigate(navigations.CREDIT_LINE_REPORT_NAVIGATION, {
			organizationId: id,
		});
	};

	renderHomeItems = dashboardData => {
		const homeViewArray = [];
		if (dashboardData)
			dashboardData.map((element, index) => {
				this.fetchViewData(element, homeViewArray, index + 1 === dashboardData.length);
			});
		return homeViewArray;
	};

	fetchViewData = (object, viewArray, isLastElement) => {
		if (object) {
			const key = Object.keys(object)[0];
			const value = object[key];
			const obj = this.fetchComponent(key, value.data, value.isSuccess, isLastElement);
			if (obj) {
				viewArray.push(
					obj.label // If label exists.
						? this.labelUI(obj.label, obj.isHyperLink, obj.onPress, key, value.isError)
						: null,
				);
				if (value.isSuccess) {
					// If success then only show the data.
					viewArray.push(obj.component);
				} else if (value.isError) {
					// If error then show error component
					viewArray.push(this.getTryAgainView(key, value.data, isLastElement));
				} else {
					// Will show loading view while api calling.
					viewArray.push(this.getLoadingView(isLastElement));
				}
			}
		}
	};

	labelUI = (title, isHyperLink, onPress, key, isError) => {
		// Function to return the label of the section.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.itemView}>
				<Text
					numberOfLines={numberOfLinesForHomeLabel}
					style={[styles.sectionTitle, isError ? styles.sectionErrorTitle : null]}>
					{title}
				</Text>
				{isHyperLink ? (
					<TouchableOpacity
						activeOpacity={0.8}
						hitSlop={styles.hitSlop}
						onPress={onPress}>
						<ImageLoadComponent
							source={IMAGES.iconRightArrow}
							style={styles.iconRightArrow}
						/>
					</TouchableOpacity>
				) : null}
			</View>
		);
	};

	fetchComponent = (key, object, isSuccess, isLastElement) => {
		/**
		 * Function to return the section with the UI by using key.
		 * Each object contains some keys:-
		 * 1. label: Title of the section.
		 * 2. isHyperLink: Boolean to show iconArrow.
		 * 3. component: Component of the section.
		 * 4. onPress: Action that will perform by click on iconArrow.
		 */
		const { userDetails, homeScreenInfo } = this.props;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		const { toggleFeaturesInfo } = this.props;
		const { toggleFeatures } = toggleFeaturesInfo;
		const { zoneId } = homeScreenInfo;
		let data = {
			[homeScreenDataPoints.creditLine]: {
				label: null,
				isHyperLink: false,
				component:
					role === accountManager || role === salesExecutive // Will return null if role is account manager or sales executive.
						? null
						: this.renderCreditLine(object, toggleFeatures, isLastElement),
				onPress: null,
			},
			[homeScreenDataPoints.balanceAvailable]: {
				label: null,
				isHyperLink: false,
				component:
					role === accountManager || role === salesExecutive // Will return null if role is account manager or sales executive.
						? null
						: this.renderBalanceSection(object, isLastElement),
				onPress: null,
			},
		};
		if (zoneId) {
			data = {
				...data,
				[homeScreenDataPoints.mostSellingItems]: {
					label: localeString(keyConstants.MOST_SELLING_ITEMS),
					isHyperLink: isSuccess || false,
					component: this.renderMostSellingItems(object, isLastElement),
					onPress: this.viewAllMostSellingItems,
				},
				[homeScreenDataPoints.recentlyOrdered]: {
					label: localeString(keyConstants.RECENTLY_ORDERED),
					isHyperLink: isSuccess || false,
					component: this.renderRecentOrders(object, isLastElement),
					onPress: this.viewAllOrders,
				},
				[homeScreenDataPoints.specialBanner]: {
					label: null,
					isHyperLink: false,
					component: this.renderBannerComponent(object, isLastElement),
					onPress: null,
				},
				[homeScreenDataPoints.promotionalBanner]: {
					label: null,
					isHyperLink: false,
					component: this.renderBannerComponent(object, isLastElement),
					onPress: null,
				},
				[homeScreenDataPoints.topSellingSubCategoryItems]: {
					label: localeString(keyConstants.EXPLORE_TOP_SUBCATEGORIES),
					isHyperLink: false,
					component: this.renderTopSubCategories(object, isLastElement),
					onPress: null,
				},
				[homeScreenDataPoints.recentlyAddedItems]: {
					label: isSuccess ? null : localeString(keyConstants.NEWLY_ADDED_ITEMS),
					isHyperLink: isSuccess || false,
					component: this.renderNewlyAddedItems(object, isLastElement),
					onPress: this.viewAllNewlyItems,
				},
				[homeScreenDataPoints.topSellingItemsForCategories]: {
					label: isSuccess ? null : localeString(keyConstants.TOP_ITEMS_IN_CATEGORIES),
					isHyperLink: false,
					component: this.renderTopSellingItemCategories(object, isLastElement),
					onPress: this.viewAllCategories,
				},
				[homeScreenDataPoints.categories]: {
					label: localeString(keyConstants.CATEGORIES),
					isHyperLink: true,
					component: this.renderCategories(object, isLastElement),
					onPress: this.viewAllCategories,
				},
				[homeScreenDataPoints.brands]: {
					label: isSuccess ? null : localeString(keyConstants.BRANDS),
					isHyperLink: true,
					component: this.renderBrands(object, isLastElement),
					onPress: null,
				},
				[homeScreenDataPoints.topSellingBrandsForCategories]: {
					label: isSuccess ? null : localeString(keyConstants.TOP_BRANDS_IN_CATEGORIES),
					isHyperLink: false,
					component: this.renderTopSellingBrandsCategories(object, isLastElement),
					onPress: null,
				},
				[homeScreenDataPoints.discountItems]: {
					label: localeString(keyConstants.DISCOUNTS),
					isHyperLink: isSuccess || false,
					component: this.renderDiscountItems(object, isLastElement),
					onPress: this.viewAllDiscountItems,
				},
			};
		}
		return data[key];
	};

	getTryAgainView = (key, data, isLastElement) => {
		// Will show the error component if api fails.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<View style={styles.tryAgainView}>
				<ErrorComponent
					isRTL={isRTL}
					errorCode={data}
					onCallApi={() => this.getItemsData(key)}
					isSectionComponent
				/>
				{!isLastElement && this.getSeparator()}
			</View>
		);
	};

	getLoadingView = isLastElement => {
		// Will show shimmer while loading.
		const { emptySkeltonArray } = this.state;
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<>
				<View style={styles.innerContainer}>
					<FlatList
						data={emptySkeltonArray}
						horizontal
						inverted={isRTL}
						showsHorizontalScrollIndicator={false}
						renderItem={() => {
							return <ItemsShimmer isRTL={isRTL} />;
						}}
						keyExtractor={this.keyExtractor}
					/>
				</View>
				{!isLastElement && this.getSeparator()}
			</>
		);
	};

	renderTopSellingItemCategories = (topSellingItemCategories, isLastElement) => {
		// Will return top selling items based on categories.
		const topSellingItemsArray = [];
		if (topSellingItemCategories && topSellingItemCategories.length) {
			topSellingItemCategories.forEach(element => {
				topSellingItemsArray.push(this.renderNewlyAddedItems(element, isLastElement));
			});
			return topSellingItemsArray;
		}
		return null;
	};

	renderTopSellingBrandsCategories = (topSellingBrandsCategories, isLastElement) => {
		// Will return top selling items based on brands.
		const topSellingBrandsArray = [];
		if (topSellingBrandsCategories && topSellingBrandsCategories.length) {
			topSellingBrandsCategories.forEach(element => {
				topSellingBrandsArray.push(this.renderBrands(element, isLastElement));
			});
			return topSellingBrandsArray;
		}
		return null;
	};

	renderCreditLine = (credit_line, toggleFeatures, isLastElement) => {
		// Will return credit line card.
		const { online_payment } = toggleFeatures; // Will return toggleFeatures key value pair.
		const { languageInfo, configurableFileInfo } = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (credit_line) {
			const {
				credit_limit,
				used_balance,
				remaining_balance,
				due_balance,
				paid_balance,
				credit_refresh_date,
			} = credit_line;
			if (credit_limit === 0 && remoteConfigData?.creditLine?.applyForCreditLine) {
				return (
					<>
						<TouchableOpacity
							activeOpacity={0.8}
							style={styles.creditLineContainer}
							onPress={this.onPressApplyForCreditLine}>
							<View style={styles.creditInnerView}>
								<ImageLoadComponent
									source={IMAGES.iconHomeCredit}
									style={styles.iconHomeWallet}
								/>
								<TouchableOpacity
									activeOpacity={0.8}
									onPress={this.onPressApplyForCreditLine}>
									<Text style={styles.applyCreditView}>
										{localeString(keyConstants.APPLY_FOR_CREDIT_LINE)}
									</Text>
								</TouchableOpacity>
							</View>
							<TouchableOpacity
								activeOpacity={0.8}
								onPress={this.onPressApplyForCreditLine}>
								<ImageLoadComponent
									source={IMAGES.iconRightArrow}
									style={styles.iconRightArrow}
								/>
							</TouchableOpacity>
						</TouchableOpacity>
					</>
				);
			}
			return (
				<>
					{this.canPay(new Date(), credit_refresh_date).isShowAvailableBalance && (
						<TouchableOpacity
							activeOpacity={0.8}
							style={styles.creditLineView}
							onPress={() => this.goToReports()}>
							<CreditLineInformation
								isRTL={isRTL}
								amount={remaining_balance}
								usedAmount={used_balance}
								totalCreditAmount={credit_limit}
								paidAmount={paid_balance} // Paid amount of the credit line
								isCreditLine={paid_balance > 0} // Boolean to show amount paid popup on credit line card.
								hasHyperlink={remoteConfigData?.creditLine?.applyForCreditLine}
								onPressHyperlink={this.onPressApplyForCreditLine} // on Pressing Apply for credit Line
								hyperlinkTitle={localeString(keyConstants.APPLY_FOR_CREDIT_LINE)}
							/>
						</TouchableOpacity>
					)}
					{
						/*
							Will return true if
							1. the due has not been cleared in the existing month
							2. Due balance must be > 0
						*/
						this.canPay(new Date(), credit_refresh_date).canPay && due_balance > 0 && (
							<TouchableOpacity
								activeOpacity={0.8}
								style={styles.creditLineView}
								onPress={() => this.goToReports()}>
								<CreditLineDueComponent
									isRTL={isRTL}
									dueAmount={due_balance}
									onPayNow={() => this.onPayDue(due_balance)}
									isPayNowEnable={
										online_payment && remoteConfigData?.creditLine?.payNow
									} // Boolean to check the online payment feature is enable for the user.
								/>
							</TouchableOpacity>
						)
					}
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	renderBannerComponent = (bannerData, isLastElement) => {
		// Will return banners.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (bannerData && bannerData.length) {
			return (
				<>
					<View style={styles.carouselView}>
						<CarouselComponent entries={bannerData} isAutoPlay isSourceUri />
					</View>
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	renderTopSubCategories = (subCategoryListing, isLastElement) => {
		// Will return top subcategories.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (subCategoryListing && subCategoryListing.length) {
			const subCatArray = this.getTopSubCategoriesArray(subCategoryListing);
			return (
				<>
					<View style={styles.innerContainer}>
						{subCatArray.map(row => {
							return (
								<View style={styles.viewSubCatRow}>
									<FlatList
										data={row}
										horizontal
										inverted={isRTL}
										showsHorizontalScrollIndicator={false}
										renderItem={({ item, index }) => {
											return (
												<TouchableOpacity
													onPress={() =>
														this.onPressSubCategory(index, item)
													}
													style={styles.subCategoryView}
													activeOpacity={0.8}
													hitSlop={styles.hitSlop}>
													<Text style={styles.subCategoryText}>
														{isRTL ? item.name_ar : item.name}
													</Text>
												</TouchableOpacity>
											);
										}}
										keyExtractor={this.keyExtractor}
									/>
								</View>
							);
						})}
					</View>
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	getTopSubCategoriesArray = subCategoryListing => {
		// Function to create the rows that contains 4 subcategories each.
		const subCatArray = [];
		const arrayLength = subCategoryListing.length;
		let numOfRows = 0;
		let rowLength = 0;
		if (arrayLength % numberOfSubcategoryInRow === 0) {
			numOfRows = parseInt(arrayLength / numberOfSubcategoryInRow, 10);
		} else {
			numOfRows = parseInt(arrayLength / numberOfSubcategoryInRow, 10) + 1;
		}
		for (let index = 1; index <= numOfRows; index += 1) {
			const rowData = [];
			rowLength += numberOfSubcategoryInRow;
			if (rowLength > arrayLength) {
				rowLength = arrayLength;
			}
			for (
				let index1 = numberOfSubcategoryInRow * (index - 1);
				index1 < rowLength;
				index1 += 1
			) {
				rowData.push(subCategoryListing[index1]);
			}
			subCatArray.push(rowData);
		}
		return subCatArray;
	};

	canPay = (selectedDate, creditLimitRefreshDate) => {
		// Function to check the validation to  show the credit line card.
		if (selectedDate && creditLimitRefreshDate) {
			const currentMonth = selectedDate.getMonth(); // Extract current month from current date.
			const creditLimitRefreshMonth = new Date(creditLimitRefreshDate).getMonth(); // Extract month from the last credit limit refresh date.
			return {
				canPay: currentMonth > creditLimitRefreshMonth, // If true then it will show due on the home screen.
				isShowAvailableBalance: currentMonth === creditLimitRefreshMonth, // If true it will show available balance, Due balance, paid amount & used amount on the home screen.
			};
		}
		return {
			canPay: false,
			isShowAvailableBalance: true, // If credit limit is not assigned to the user then the available balance, Due balance, paid amount & used amount will still show as 0.
		};
	};

	onPayDue = dueAmount => {
		// API call to pay all the dues.
		const { addMoneyActions } = this.props;
		const paymentDetails = {
			payment_type: paymentType.creditLine,
			amount: dueAmount, // Due amount getting from backend.
		};
		addMoneyActions.onAddMoney(paymentDetails, true);
	};

	renderBrands = (brands, isLastElement) => {
		// Will return brand listing.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (brands) {
			const items = Array.isArray(brands) ? brands : brands.brands || [];
			const title = Array.isArray(brands)
				? localeString(keyConstants.BRANDS)
				: `${localeString(keyConstants.TOP_BRANDS_IN)} ${
						isRTL ? brands.name_ar : brands.name
				  }`;
			const catId = Array.isArray(brands) ? null : brands.cat_id;
			if (items.length) {
				return (
					<View>
						{this.labelUI(title, true, () => this.viewAllBrands(catId))}
						<View style={styles.innerContainer}>
							<FlatList
								data={items || []}
								horizontal
								inverted={isRTL}
								showsHorizontalScrollIndicator={false}
								renderItem={({ item }) => {
									return (
										<TouchableOpacity
											style={styles.brandsContainer}
											onPress={() => this.onPressBrand(item)}
											activeOpacity={0.8}>
											{item.images && item.images.medium ? (
												<ImageLoadComponent
													imageType={IMAGE_TYPE.brand}
													isUrl={item.images}
													source={item.images.medium}
													style={styles.brandImage}
												/>
											) : (
												<View style={styles.brandViewNoImage}>
													<Text
														numberOfLines={2}
														style={styles.brandLabel}>
														{isRTL ? item.name_ar : item.name}
													</Text>
												</View>
											)}
										</TouchableOpacity>
									);
								}}
								keyExtractor={this.keyExtractor}
							/>
						</View>
						{!isLastElement && this.getSeparator()}
					</View>
				);
			}
		}
		return null;
	};

	renderCategories = (categories, isLastElement) => {
		// Will return category listing.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { activeCategoryIndex } = this.state;
		if (categories && categories.length) {
			return (
				<>
					<View style={styles.innerContainer}>
						<FlatList
							data={categories || []}
							horizontal
							inverted={isRTL}
							showsHorizontalScrollIndicator={false}
							renderItem={({ item, index }) => {
								return (
									<TouchableOpacity
										onPress={() => this.onPressOption(index, item.id)}
										activeOpacity={0.8}
										style={styles.inactiveView}>
										<View style={styles.inactiveImageView}>
											<ImageLoadComponent
												imageType={IMAGE_TYPE.category}
												isUrl={item && item.images}
												resizeMode={stretch}
												source={
													item && item.images && item.images.medium
														? item.images.medium
														: this.onGetCategoryDefaultImage(
																index,
																activeCategoryIndex,
														  )
												}
												style={
													item && item.images && item.images.medium
														? styles.image
														: styles.defaultImage
												}
											/>
										</View>
										<Text style={styles.label}>
											{isRTL ? item.name_ar : item.name}
										</Text>
									</TouchableOpacity>
								);
							}}
						/>
					</View>
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	renderNewlyAddedItems = (newlyAddedItems, isLastElement) => {
		// Will return newly added items listing.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (newlyAddedItems) {
			const items = Array.isArray(newlyAddedItems)
				? newlyAddedItems
				: newlyAddedItems.items || [];
			const title = Array.isArray(newlyAddedItems)
				? localeString(keyConstants.NEWLY_ADDED_ITEMS)
				: `${localeString(keyConstants.TOP_ITEMS_IN)} ${
						isRTL ? newlyAddedItems.name_ar : newlyAddedItems.name
				  }`;
			const onPressViewAll = () =>
				Array.isArray(newlyAddedItems)
					? this.viewAllNewlyItems()
					: this.onPressOption(0, newlyAddedItems.cat_id);
			if (items.length) {
				return (
					<View>
						{this.labelUI(title, true, onPressViewAll)}
						<View style={styles.innerContainer}>
							<FlatList
								data={items}
								horizontal
								inverted={isRTL}
								showsHorizontalScrollIndicator={false}
								renderItem={this.renderItem}
							/>
						</View>
						{!isLastElement && this.getSeparator()}
					</View>
				);
			}
			return null;
		}
		return null;
	};

	renderItem = ({ item }) => {
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		return (
			<HomeItemComponent
				onPress={() => this.onGetProductDetail(item)}
				isRTL={isRTL}
				image={item.images && item.images.large}
				name={isRTL ? item.name_ar : item.name}
				price={item.price_with_vat}
				offerPrice={item.offer_price_with_vat}
				itemsPerPacket={item.items_per_packet}
				valueOfItem={item.value_of_item}
				unit={isRTL ? item.unit_ar : item.unit}
			/>
		);
	};

	renderMostSellingItems = (mostSellingItems, isLastElement) => {
		// Will return most selling items listing.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (mostSellingItems && mostSellingItems.length) {
			return (
				<>
					<View style={styles.innerContainer}>
						<FlatList
							data={mostSellingItems}
							horizontal
							inverted={isRTL}
							showsHorizontalScrollIndicator={false}
							renderItem={this.renderItem}
						/>
					</View>
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	renderDiscountItems = (discountItems, isLastElement) => {
		// Will return discount items listing.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (discountItems && discountItems.length) {
			return (
				<>
					<View style={styles.innerContainer}>
						<FlatList
							data={discountItems}
							horizontal
							inverted={isRTL}
							showsHorizontalScrollIndicator={false}
							renderItem={this.renderItem}
						/>
					</View>
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	getSubString = (string, length) => {
		// Function to append ... if string exceeds its maximum length.
		return length < string && string.length ? `${string.substr(0, length - 3)}...` : string;
	};

	renderRecentOrders = (recentOrders, isLastElement) => {
		// Will return recently ordered items listing.
		const { languageInfo } = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		if (recentOrders && recentOrders.length) {
			return (
				<>
					<View style={styles.innerContainer}>
						<FlatList
							data={recentOrders}
							showsHorizontalScrollIndicator={false}
							horizontal
							inverted={isRTL}
							renderItem={({ item }) => {
								return (
									<TouchableOpacity
										activeOpacity={0.8}
										onPress={() => this.onGetProductDetail(item)}>
										<ProductCardComponent
											image={item.images && item.images.small}
											title={isRTL ? item.name_ar : item.name}
											subtitle={this.getSubString(
												isRTL ? item.brand_name_ar : item.brand_name,
												15,
											)}
											containerStyle={styles.containerStyle}
											subtitleStyle={styles.subtitleStyle}
											titleStyle={styles.titleStyle}
											priceDetailsContainerStyle={
												styles.priceDetailsContainerStyle
											}
										/>
									</TouchableOpacity>
								);
							}}
						/>
					</View>
					{!isLastElement && this.getSeparator()}
				</>
			);
		}
		return null;
	};

	renderBalanceSection = (balanceDetails, isLastElement) => {
		// Will return balance details card.
		const { total_balance } = balanceDetails || {};
		const { languageInfo, configurableFileInfo } = this.props;
		const { remoteConfigData } = configurableFileInfo;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		return (
			<>
				<TouchableOpacity
					activeOpacity={0.8}
					style={styles.balanceView}
					onPress={this.goToBalance}>
					<View style={styles.innerView}>
						<ImageLoadComponent
							source={IMAGES.iconHomeWallet}
							style={styles.iconHomeWallet}
						/>
						<View style={styles.balanceContainer}>
							<Text style={styles.balanceAmount}>
								{`${currencyFormatter(
									getValueInDecimal(total_balance),
								)} ${localeString(keyConstants.SAR)}`}
							</Text>
							<Text style={styles.balanceLabel}>
								{localeString(keyConstants.WALLET_BALANCE)}
							</Text>
						</View>
					</View>
					{remoteConfigData?.wallet?.addMoney ? (
						<TouchableOpacity activeOpacity={0.8} onPress={this.onAddMoney}>
							<Text style={styles.addMoney}>
								{localeString(keyConstants.ADD_MONEY)}
							</Text>
						</TouchableOpacity>
					) : null}
				</TouchableOpacity>
				{!isLastElement && this.getSeparator()}
			</>
		);
	};

	viewAllNewlyItems = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ITEM_LIST_NAVIGATION, {
			title: keyConstants.NEWLY_ADDED_ITEMS,
		});
	};

	onGetProductDetail = item => {
		const { navigation } = this.props;
		navigation.navigate(navigations.PRODUCT_DETAILS_NAVIGATION, { id: item.id });
	};

	viewAllMostSellingItems = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ITEM_LIST_NAVIGATION, {
			title: keyConstants.MOST_SELLING_ITEMS,
		});
	};

	viewAllOrders = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.ORDERS_NAVIGATION);
	};

	onSearch = () => {
		const { navigation } = this.props;
		navigation.navigate(navigations.SEARCH_NAVIGATION);
	};

	getSeparator = () => {
		// Separator to add after every section.
		return null;
	};

	goToBalance = () => {
		// Will navigate balance details screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.BALANCE_DETAILS_NAVIGATION);
	};

	onAddMoney = () => {
		// Will navigate to the add money screen.
		const { navigation } = this.props;
		navigation.navigate(navigations.ADD_MONEY_NAVIGATION, {
			type: navigationType.home,
		});
	};

	getBranchName = (isRTL, branchListing, activeBranchIndex) => {
		if (isRTL && branchListing[activeBranchIndex].name_ar) {
			return branchListing[activeBranchIndex].name_ar &&
				branchListing[activeBranchIndex].name_ar.length > splitOrganizationLength
				? `${branchListing[activeBranchIndex].name_ar
						.split('', splitOrganizationLength)
						.join('')}...`
				: branchListing[activeBranchIndex].name_ar;
		}
		return branchListing[activeBranchIndex].name &&
			branchListing[activeBranchIndex].name.length > splitOrganizationLength
			? `${branchListing[activeBranchIndex].name
					.split('', splitOrganizationLength)
					.join('')}...`
			: branchListing[activeBranchIndex].name;
	};

	onRefresh = () => {
		if (isToggleFeatureEnable) {
			// Will call toggle feature API.
			this.toggleFeature.getToggleFeatures();
		} else {
			this.getDashboardData(); // Will call dashboard API.
			this.onCallAPIs();
		}
	};

	render() {
		const {
			languageInfo,
			homeScreenInfo,
			addMoneyInfo,
			refreshControlComponentInfo,
			toggleFeaturesInfo,
			navigation,
			userDetails,
		} = this.props;
		const { isRTL } = languageInfo;
		const styles = createStyleSheet(isRTL);
		const { isShowBranchPicker, isApiError, toastMessage, emptySkeltonArray } = this.state;
		const {
			loader,
			branchListing,
			branchCount,
			cartCount,
			notificationCount,
			activeBranchIndex,
			dashboardData,
			isBranchLoader,
			error,
			errorCode,
			isDashboard,
			zoneId,
		} = homeScreenInfo;
		const { name, name_ar } =
			(userDetails &&
				userDetails.user &&
				userDetails.user.organization &&
				userDetails.user.organization) ||
			{};
		const id =
			activeBranchIndex !== null
				? branchListing &&
				  branchListing[activeBranchIndex] &&
				  branchListing[activeBranchIndex].id
				: userDetails &&
				  userDetails.user &&
				  userDetails.user.organization &&
				  userDetails.user.organization.id;
		const { role } = userDetails && userDetails.user ? userDetails.user : {};
		const { loader: addMoneyLoader } = addMoneyInfo;
		const { isFetchingForPullToRefresh } = refreshControlComponentInfo;
		const { loader: toggleApiLoader } = toggleFeaturesInfo;
		const { isConnected } = this.props;
		return (
			<View style={styles.container}>
				{addMoneyLoader && <Spinner size="large" />}
				<BranchPicker
					isRTL={isRTL}
					branchArray={branchListing}
					isShowBranchPicker={isShowBranchPicker}
					activeBranchIndex={activeBranchIndex}
					onPress={this.onSelectBranch}
					onPressAdd={this.onAddBranch}
					loader={isBranchLoader}
					onEndReached={() => branchListing.length !== branchCount && this.onEndReached()}
					onPressClose={this.onPressClose}
					placeholder={isRTL ? name_ar : name}
					branchId={id}
					hasAddNewBranch={role === customerAdmin}
					error={error && !isDashboard}
					errorCode={errorCode}
					onReload={this.onClickDropdown}
				/>
				<View style={styles.header}>
					<View style={styles.locationView}>
						<ImageLoadComponent source={IMAGES.iconPin} style={styles.iconPin} />
						<TouchableOpacity
							style={styles.dropdownView}
							activeOpacity={0.8}
							onPress={this.onClickDropdown}>
							<Text style={styles.dropdownText}>
								{branchListing.length !== 0 && activeBranchIndex !== null
									? branchListing[activeBranchIndex] &&
									  this.getBranchName(isRTL, branchListing, activeBranchIndex)
									: isRTL
									? name_ar || name
									: name}
							</Text>
							<ImageLoadComponent
								source={IMAGES.iconArrowDown}
								style={styles.iconArrowDown}
							/>
						</TouchableOpacity>
					</View>
					<View style={styles.iconsView}>
						<TouchableOpacity activeOpacity={0.8} onPress={this.onPressCart}>
							<ImageLoadComponent
								source={IMAGES.iconCart}
								style={styles.iconCartHome}
							/>
							{cartCount ? (
								<View style={styles.notificationContainerHomeStyle}>
									<Text style={styles.notificationCountHomeStyle}>
										{cartCount > 9 ? ninePlus : cartCount}
									</Text>
								</View>
							) : null}
						</TouchableOpacity>
						<TouchableOpacity activeOpacity={0.8} onPress={this.onPressNotification}>
							{role !== accountManager && role !== salesExecutive ? (
								<ImageLoadComponent
									source={IMAGES.iconNotification}
									style={styles.iconNotification}
								/>
							) : null}
							{notificationCount !== 0 && (
								<View style={styles.notificationContainerHomeStyle}>
									<Text style={styles.notificationCountHomeStyle}>
										{notificationCount > 9 ? ninePlus : notificationCount}
									</Text>
								</View>
							)}
						</TouchableOpacity>
					</View>
				</View>
				{(loader || toggleApiLoader) && !isFetchingForPullToRefresh ? (
					<View>
						<SearchShimmer isRTL={isRTL} />
						<TextShimmer isRTL={isRTL} />
						<View style={styles.mainContainer}>
							<FlatList
								data={emptySkeltonArray}
								showsHorizontalScrollIndicator={false}
								horizontal
								renderItem={() => {
									return <ItemsShimmer isRTL={isRTL} />;
								}}
								keyExtractor={this.keyExtractor}
							/>
						</View>
						<LineShimmer isRTL={isRTL} />
						<TextShimmer isRTL={isRTL} />
						<BrandsShimmer isRTL={isRTL} />
						<LineShimmer isRTL={isRTL} />
						<TextShimmer isRTL={isRTL} />
						<BannerShimmer isRTL={isRTL} />
					</View>
				) : (
					<>
						{zoneId ? (
							<PopupButtonComponent
								isRTL={isRTL}
								title={localeString(keyConstants.SEARCH_BY_CATEGORY_BRAND_OR_ITEM)}
								handlePicker={this.onSearch}
								containerStyle={styles.searchButtonContainer}
								extraProps={getTestIdProps(locatorConstants.searchButton)}
							/>
						) : null}
						{error && isDashboard ? (
							<ErrorComponent
								isRTL={isRTL}
								errorCode={errorCode}
								onCallApi={this.getDashboardData}
							/>
						) : (
							<ScrollViewComponent
								componentType={constants.scrollView}
								showsVerticalScrollIndicator={false}
								contentContainerStyle={styles.scrollView}
								onRefresh={this.onRefresh}>
								{/* render home screen data elements */}
								{this.renderHomeItems(dashboardData)}
								{/* Component to show the OOZ information if current address is out of zone. */}
								{!zoneId && dashboardData ? (
									<View style={styles.zoneContainer}>
										<ImageLoadComponent
											source={IMAGES.iconOOZ}
											style={styles.iconOOZ}
										/>
										<Text style={styles.oozTitle}>
											{localeString(keyConstants.OOZ_TITLE)}
										</Text>
										<Text style={styles.oozDesc}>
											{localeString(keyConstants.OOZ_DESC)}
										</Text>
									</View>
								) : null}
							</ScrollViewComponent>
						)}
						<ToggleFeatureScreen
							navigation={navigation}
							onRef={ref => {
								this.toggleFeature = ref;
							}}
							isDefaultApiCalling={isToggleFeatureEnable} // Boolean to call the toggle feature API.
							isConnected={isConnected}
						/>
						<ToastComponent
							isRTL={isRTL}
							isApiError={isApiError}
							toastMessage={toastMessage}
						/>
					</>
				)}
			</View>
		);
	}
}

const mapStateToProps = state => {
	return {
		languageInfo: state.LanguageScreenReducer,
		homeScreenInfo: state.HomeScreenReducer,
		invoiceScreenInfo: state.InvoicesScreenReducer,
		userDetails: state.HomeScreenReducer.userDetails,
		addMoneyInfo: state.AddMoneyScreenReducer,
		refreshControlComponentInfo: state.RefreshControlComponentReducer,
		toggleFeaturesInfo: state.ToggleFeatureScreenReducer, // Will provide access to all the data of the toggle feature reducer.
		isConnected: state.NoConnectionHandleReducer.isConnected,
		configurableFileInfo: state.ConfigurableReducer,
	};
};

const mapDispatchToProps = dispatch => {
	return {
		homeScreenActions: bindActionCreators({ ...HomeScreenActions }, dispatch),
		invoicesScreenActions: bindActionCreators({ ...InvoicesScreenAction }, dispatch),
		addMoneyActions: bindActionCreators({ ...AddMoneyActions }, dispatch),
		pullToRefreshActions: bindActionCreators({ ...PullToRefreshActions }, dispatch),
		toggleFeaturesActions: bindActionCreators({ ...ToggleFeaturesActions }, dispatch),
		selectCustomerOrganizationActions: bindActionCreators(
			{ ...SelectCustomerOrganizationActions },
			dispatch,
		),
		ordersListingActions: bindActionCreators({ ...OrdersListingActions }, dispatch),
	};
};

HomeScreen.propTypes = {
	languageInfo: PropTypes.object.isRequired,
	homeScreenInfo: PropTypes.object.isRequired,
	addMoneyInfo: PropTypes.object.isRequired,
	refreshControlComponentInfo: PropTypes.object.isRequired,
	toggleFeaturesInfo: PropTypes.object.isRequired,
	homeScreenActions: PropTypes.object.isRequired,
	navigation: PropTypes.object.isRequired,
	addMoneyActions: PropTypes.object.isRequired,
	pullToRefreshActions: PropTypes.object.isRequired,
	toggleFeaturesActions: PropTypes.object.isRequired,
	isConnected: PropTypes.bool.isRequired,
	userDetails: PropTypes.object.isRequired,
	selectCustomerOrganizationActions: PropTypes.object.isRequired,
	ordersListingActions: PropTypes.object.isRequired,
	configurableFileInfo: PropTypes.object.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen);
