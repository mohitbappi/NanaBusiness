const fonts = {
	LatoBold: 'Lato-Bold',
	LatoRegular: 'Lato-Regular',
	LatoLight: 'Lato-Light',
	LatoSemiBold: 'Lato-SemiBold',
	LatoMedium: 'Lato-Medium',
	LatoItalic: 'Lato-Italic',
	LatoBoldItalic: 'Lato-BoldItalic',
	TajawalBold: 'Tajawal-Bold',
	TajawalRegular: 'Tajawal-Regular',
	TajawalLight: 'Tajawal-Light',
	TajawalMedium: 'Tajawal-Medium',
};

export default fonts;
