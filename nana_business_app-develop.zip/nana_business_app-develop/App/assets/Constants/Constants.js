import Config from 'react-native-config';

export const noSpaceAtStartRegexEx = /^[^-\s\u0600-\u06FF][~`@$!%"^()*?&#,.';:{}/><|=a-zA-Z0-9_\s-]*$/;
export const noSpaceAtStartRegexExArabic = /^([^-\sA-Za-z\u0660-\u0669\u06F0-\u06F9])([~`@$!%"^()*?&#,.';:{}/><|=_\s-]|[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF0-9])*$/;
export const emailRegexEx = /^([a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*)@((?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)$/;
export const passwordMaxLength = 20;
export const toastShowTime = 2000;
export const orderDetailsToastShowTime = 10000;
export const errorCodeForIncorrectPassword = 'PASSWORD_INCORRECT';
export const passwordRegexEx = /^(?=.*[0-9])(?=.*[@$!%*?&#~`^*()_=+{}[|'";:<>,./])([a-zA-Z0-9@$!%*?&#~`^*()_=+{}{}[|'";:<>,./]{6,})$/;
export const spaceRegexEx = /^[A-za-z0-9@#~()-_=+{}|'";:?/.><!$%^&*]*[^\u0600-\u06FF\s]$/;
export const spaceRegexExArabic = /^([0-9@#~()-_=+{}|'";:?/.><!$%^&*]|[\u0600-\u065F\u066A-\u06EF\u06FA-\u06FF])*[^\sa-zA-Z\u0660-\u0669\u06F0-\u06F9]$/;
export const noSpecialCharacterRegexEx = /^[^\u0600-\u06FF\s]{0}[A-Za-z0-9]*$/;
export const noSpecialCharacterRegexExArabic = /^[^a-zA-Z\u0600-\u061F\u0660-\u0669\u06F0-\u06F9\s]{0}[\u0620-\u065F\u066A-\u06EF\u06FA-\u06FF0-9]*$/;
export const customMobileRegex = /^[0-9]{9}$/;
export const crNumberRegex = /^[0-9]{10,11}$/;
export const vatCertificateNumberRegex = /^[0-9]{15}$/;
export const mobileNumberLength = 9;
export const crNumberLength = 11;
export const vatCertificateNumberLength = 15;
export const numericRegexExp = /^(?!0)[0-9]+$/;
export const numericalRegexExp = /^[0-9]+$/;
export const numericRegexWithDecimalEx = /^\d+(\.\d{1,2})?$/;
export const otpRegex = /(\d{4})/g;
export const nameMaxLength = 50;
export const companyNameMaxLength = 50;
export const addressMaxLength = 200;
export const retailer = 'customer';
export const customerAdmin = 'customer_admin';
export const accountManager = 'account_manager';
export const salesExecutive = 'sales_executive';
export const vendor = 'vendor';
export const collector = 'collector';
export const driver = 'driver';
export const cashier = 'cashier';
export const numOfColumns = 3;
export const SAR = 'SAR';
export const dateFormat = 'MMM D, YYYY';
export const dateFormatWithoutHyphen = 'D MMM YYYY';
export const dateFormatWithoutYear = 'MMM D';
export const dateFormatWithTime = 'DD/MM/YYYY, hh:mm a';
export const autoPlayDelay = 4;
export const pending = 'pending';
export const approved = 'approved';
export const submitted = 'submitted';
export const canceled = 'canceled';
export const rejected = 'rejected';
export const dash = '---';
export const sevenDays = 7;
export const fourteenDays = 14;
export const twentyOneDays = 21;
export const nanaDirect = 'Nana Business';
export const hyphenDateFormat = 'DD-MM-YYYY';
export const day = 'day';
export const pendingInvoiceList = 'pending-invoice-list';
export const accountRequestList = 'account-request-list';
export const miles = 0.6214;
export const mi = 'mi';
export const userDetails = 'user_details';
export const invoiceImg = 'Invoice.jpg';
export const collectorLatitude = 24.713856087394973;
export const collectorLongitude = 46.67429901385262;
export const splitOrganizationLength = 20;
export const invoiceHeader = 35;
export const nanaDirectAddress = 'Kingdom of Saudi Arabia - Riyadh';
export const transactions = 'transactions';
export const toBeDeposit = 'toBeDeposit';
export const center = 'center';
export const ninePlus = '9+';
export const saudiLatitude = 23.8859;
export const saudiLongitude = 45.0792;
export const latitudeDelta = 0.05;
export const longitudeDelta = 0.05;
export const codeMaxLength = 8;
export const asterik = '*';
export const productMaxLength = 3;
export const productMaxQuantity = 999;
export const dataIntegrityError = 'DATA_INTEGRITY_ERROR';
export const ios = 'ios';
export const saudiMobilePrefix = '+966';
export const noOfDaysMaxLength = 2;
export const decimalValue = 2;
export const paid = 'paid';
export const accepted = 'accepted';
export const noOfMinCharToSearch = 2;
export const mapMovementDuration = 1000;
export const requireUserPrivacyConsent = false;
export const userLoggedOut = 'USER_LOGGED_OUT';
export const numberOfLineForNotifMessage = 1;
export const animationDuration = 1000;
export const animationTimeout = 3000;
export const interpolationValue = {
	inputRange: [0, 1],
	outputRange: [600, 0],
};
export const cash = 'cash';
export const hash = '#';
export const plus = '+';
export const minus = '-';
export const starRating = 5;
export const stretch = 'stretch';
export const cover = 'cover';
export const scorePlaceholderValue = 455;
export const salesInvoice = 'Sales Invoice';
export const pixelValue = 1.33;
export const bucketUrl = Config.BUCKET_URL;
export const invoicePopup = 'invoice_popup';
export const viewAllCategoryLmit = 4;
export const viewAllBrandLimit = 4;
export const otpLength = 4;
export const deliveryCodeLength = 6;
export const productListScrollTime = 10;
export const mobilePrefix = '966';
export const otpVerificationToken = 'otp_verification';
export const signUpCompleteToken = 'signup_complete';
export const signUpRequestType = 'signup_request_type';
export const mobileAsterik = '******';
export const crAlreadyExists = 'CR_ALREADY_EXISTS';
export const duplicateName = 'DUPLICATE_NAME';
export const duplicateArabicName = 'DUPLICATE_ARABIC_NAME';
export const crNotFound = 'CR_NOT_FOUND';
export const cartUpdated = 'CART_UPDATED';
export const notEligibleForCheckout = 'NOT_ELIGIBLE_FOR_CHECKOUT';
export const googleMaps = 'google-maps';
export const appleMaps = 'apple-maps';
export const setWalkthroughValue = 'set_walkthrough';
export const walkthroughCompleted = 'walkthroughCompleted';
export const refund = 'refund';
export const fullRefund = 'full_refund';
export const partialRefund = 'partial_refund';
export const minAmountToAddMoney = 1;
export const onlinePayment = 'online_payment';
export const bulletPoint = '\u2022';
export const multiplyString = 'x';
export const pipe = '|';
export const isToggleFeatureEnable = false;
export const numberOfSubcategoryInRow = 6;
export const isEnableReferenceNumberFeature = false;
export const ApiCall = 'API_CALL';
export const dateFormatWithHyphen = 'MM-YYYY';
export const dateMonthFormatWithoutHyphen = 'MMMM YYYY';
export const purchaseInvoiceSummaryDoc = 'PurchaseInvoiceSummary';
export const numberOfLinesForHomeLabel = 1;
export const playStoreUrl = 'https://play.google.com/store/apps/details?id=com.nanadirect';
export const appStoreUrl = 'https://apps.apple.com/us/app/nana-business/id1542758630';
export const notificationTitleLength = 25;
export const nationalIqamaIdLength = 10;
export const appVersion = '2.6.0';
export const promotionCash = 'promotion_cash';
export const xString = '\u2715';
export const userDisabled = 'USER_DISABLED';
export const palletCategoryId = 471;

export const IMAGE_TYPE = {
	account: 'account',
	item: 'item',
	category: 'category',
	brand: 'brand',
	itemDetail: 'itemDetail',
};

export const REQUEST_TYPE = {
	userRequest: 'user_request',
	registrationRequest: 'registration_request',
};

export const NOTIFICATION_ROUTE = {
	Collections: 'Collections',
	Home: 'Home',
	OrderDetails: 'OrderDetails',
	CustomerAdmin: 'CustomerAdmin',
	PurchaseReturns: 'PurchaseReturns',
	Shipments: 'Shipments',
	CreditLineDetails: 'CreditLineDetails',
	BalanceDetails: 'BalanceDetails',
	PurchaseInvoices: 'PurchaseInvoices',
	CreditLineRequest: 'CreditLineRequest',
	MadaTransactions: 'MadaTransactions',
	ReceivablesSection: 'ReceivablesSection',
	DepositsSection: 'DepositsSection',
};
export const USER_TYPE = {
	CUSTOMER: 'CUSTOMER',
	VENDOR: 'VENDOR',
	COLLECTOR: 'COLLECTOR',
};

export const TRANSACTION_STATUS = {
	APPROVED: 'approved',
	REJECTED: 'rejected',
};
export const BASE_DIMENSIONS = {
	mobile: {
		width: 320,
		height: 568,
	},
	tablet: {
		width: 600,
		height: 1024,
	},
};

export const fetchDataWithPagination = Object.freeze({
	limit: 10,
	page: 1,
});

export const fetchPendingRequestsData = Object.freeze({
	limit: 3,
	page: 1,
});

export const fetchCollectorPendingRequestsData = Object.freeze({
	limit: 5,
	page: 1,
});

export const CART_OPERATION = {
	ADD: 'ADD',
	REMOVE: 'REMOVE',
	UPDATE: 'UPDATE',
};

export const QUANTITY_MODIFICATION_OPERATION = {
	ADD: 'ADD',
	REMOVE: 'REMOVE',
	UPDATE: 'UPDATE',
};

export const CODEPUSH = {
	title: '',
	message: 'نرحب بك في نعناع أعمال،نسعد بخدمتكم دائماً',
	button: 'حسنًا',
};

export const APIConstants = {
	pendingInvoiceList: 'pending-invoice-list',
	accountRequestList: 'account-request-list',
	vendor: 'vendor',
	cancelButton: 'cancel-button',
	shared: 'shared',
	editProfile: 'edit-profile',
	collector: 'collector',
	collectorAccount: 'collector-account',
	retailer: 'retailer',
	resendLink: 'resend-link',
	wallet: 'wallet',
	transactions: 'transactions',
	credit: 'credit',
	update_transaction: 'update-transaction',
	invoices: 'invoices',
	approve_invoices: 'approve-invoices',
	approved_invoice_list: 'approved-invoice-list',
	pending_invoice_list: 'pending-invoice-list',
	None: 'None',
	reject_invoices: 'reject-invoices',
	retailers: 'retailers',
	customers: 'customers',
	user: 'user',
	transaction: 'transaction',
	debit: 'debit',
	createRetailerRequest: 'create-retailer-request',
	allApproveInvoices: 'all-approve-invoices',
	salesOrderListing: 'sales-order-listing',
	subCategories: 'sub-categories',
	items: 'items',
	cart: 'cart',
	locations: 'locations',
	orderItems: 'order-items',
	getCartCount: 'get-cart-count',
	checkout: 'checkout',
	pendingItems: 'pending-items',
	repeatOrder: 'repeat-order',
	shipmentDetail: 'shipment-detail',
	itemMetaDetails: 'item-meta-details',
	collectionStatus: 'collection-status',
	branchCartUpdate: 'branch-cart-update',
	termsAndConditions: 'terms_and_conditions',
	transactionDelete: 'transaction-delete',
	createPaymentReceived: 'create-payment-received',
	getNotificationCount: 'get-notifications-count',
	notifications: 'notifications',
	advancePayments: 'advance-payments',
	wishlist: 'wishlist',
	wishlistedItems: 'wishlisted-items',
	auth: 'auth',
	signup: 'signup',
	sendOtp: 'send-otp',
	validateOtp: 'validate-otp',
	validateOrganization: 'validate-organization',
	getOrganization: 'get-organization',
	userRequest: 'user-request',
	accountDetails: 'account-details',
	driver: 'driver',
	shipments: 'shipments',
	validateRequest: 'validate-request',
	refund: 'refund',
	full: 'full',
	dashboard: 'dashboard',
	topItems: 'top-items',
	recentlyOrdered: 'recently-ordered',
	recentlyAddedItems: 'recently-added-items',
	purchaseReturn: 'purchase-return',
	templates: 'templates',
	download: 'download',
	partial: 'partial',
	uploadInvoice: 'upload-invoice',
	branchUpdate: 'branch-update',
	ordeCancelledReasons: 'order-cancelled-reasons',
	salesOrder: 'sales-order',
	cancel: 'cancel',
	contact: 'contact',
	driverCanCollect: 'driver-can-collect',
	creditLogs: 'credit-logs',
	shipment: 'shipment',
	delivered: 'delivered',
	payment: 'payment',
	status: 'status',
	arb: 'arb',
	charge: 'charge',
	createCreditLineRequest: 'create-credit-line-request',
	getCreditLineOptions: 'credit-line-options',
	getToggleFeatures: 'get-toggle-features',
	purchaseInvoices: 'purchase-invoices',
	returns: 'returns',
	purchaseInvoiceReturn: 'purchase-invoice-return',
	creditReport: 'credit-report',
	resellItem: 'resell-item',
	markAllNotificationsRead: 'mark-all-notifications-read',
	item: 'item',
	getVersionValidity: 'get-version-validity',
	customer: 'customer',
	unbilledAmount: 'unbilled-amount',
	madaTransactionRequests: 'mada-transaction-requests',
	retailersList: 'retailers-list',
	madaTransactions: 'mada-transactions',
	createMadaTransactionRequest: 'create-mada-transaction-request',
	resubmitMadaTransactionRequest: 'resubmit-mada-transaction-request',
	zones: 'zones',
	customerOrganizations: 'customer-organizations',
	users: 'users',
	discountItems: 'discount-items',
	cashierList: 'cashier-list',
	sendOtpToCashier: 'send-otp-to-cashier',
	createCashierDeposit: 'create-cashier-deposit',
	cashier: 'cashier',
	pendingDeposits: 'pending-deposits',
	resubmitDeposit: 'resubmit-deposit',
	createDeposit: 'create-deposit',
	collectorCashierDeposits: 'collector-cashier-deposits',
};

export const fontsConstants = {
	light: 'light',
	bold: 'bold',
	regular: 'regular',
	medium: 'medium',
	italic: 'italic',
	boldItalic: 'boldItalic',
};

export const homeScreenDataPoints = {
	recentlyAddedItems: 'recently-added-items',
	recentlyOrdered: 'recently-ordered',
	mostSellingItems: 'top-items',
	creditLine: 'credit_line',
	topSellingItemsForCategories: 'top-selling-items-for-categories',
	topSellingBrandsForCategories: 'top-selling-brands-for-categories',
	topSellingSubCategoryItems: 'top-selling-sub-category-items',
	specialBanner: 'special_banner',
	promotionalBanner: 'promotional_banner',
	brands: 'brands',
	categories: 'categories',
	balanceAvailable: 'balance_available',
	discountItems: 'discount-items',
};

export const endpointAddCart = {
	cartScreen: 'cartscreen',
	productDetail: 'productdetail',
	productList: 'productlist',
	mostSelling: 'mostselling',
	recentlyAdded: 'recentlyadded',
	discount: 'discount',
	wishlist: 'wishlist',
};

export const orderStatus = {
	placed: 'Placed',
	approved: 'Approved',
	canceled: 'Canceled',
	completed: 'Completed',
	inProgress: 'In Progress',
	inProgressUnderscore: 'In_progress',
};

export const purchaseReturnInvoiceStatus = {
	pending: 'pending',
	open: 'open',
	approved: 'approved',
	rejected: 'rejected',
	resold: 'resold',
};

export const filterPurchaseInvoice = {
	assigned: 'assigned',
	pending: 'pending',
	approved: 'approved',
	rejected: 'rejected',
};

export const filterShipments = {
	assigned: 'assigned',
	started: 'started',
	inProgress: 'in_progress',
	successful: 'successful',
	failed: 'failed',
};

export const userStatus = {
	pending: 'Pending',
	approved: 'Approved',
	cancelled: 'Cancelled',
};

export const amountStatus = {
	paid: 'Paid',
	pending: 'Pending',
};

export const paymentReceivedStatus = {
	collected: 'collected',
	deposited: 'deposited',
	approved: 'approved',
	rejected: 'rejected',
	received: 'received',
};

export const shipmentStatus = {
	inProgress: 'in_progress',
	assigned: 'assigned',
	started: 'started',
	successful: 'successful',
	failed: 'failed',
	unassigned: 'unassigned',
	accepted: 'accepted',
	decline: 'decline',
	cancel: 'cancel',
	deleted: 'deleted',
};

export const walkthroughLabels = {
	skip: 'تخطى',
	walkthroughOne: {
		description: 'طلبياتك من الموردين توصل أسرع وبسعر أفضل',
	},
	walkthroughTwo: {
		description: 'أحصل على حد ائتماني مناسب لأعمالك',
	},
	walkthroughThree: {
		description: 'ريح بالك من الفواتير الورقية وإستخدم الإلكترونية',
	},
};

export const languageConstants = {
	en: 'en',
	ar: 'ar',
};

export const creditLineConstants = {
	credit: 'credit',
	debit: 'debit',
};

export const paymentModeConstants = {
	balance: 'balance',
	online: 'online',
};

export const paymentStatus = {
	waiting: 'waiting',
	failed: 'failed',
	success: 'success',
	approved: 'approved',
};

export const navigationType = {
	order: 'order',
	creditLine: 'creditLine',
	balance: 'balance',
	home: 'home',
};

export const paymentType = {
	creditLine: 'credit_line',
	advancePayment: 'advanced_payment',
};

export const toggleFeatureConstants = {
	onlinePayment: 'online_payment',
};

export const apiVersionConstants = {
	xApiVersion: 'x-api-version',
	apiVersionMissing: 'API_VERSION_MISSING',
	apiVersionInvalid: 'API_VERSION_INVALID',
	apiVersionUpgradeRequired: 'API_VERSION_UPGRADE_REQUIRED',
	apiVersionNotSupported: 'API_VERSION_NOT_SUPPORTED',
	apiEndpointDeleted: 'API_ENDPOINT_DELETED',
	apiEndpointNotFound: 'API_ENDPOINT_NOT_FOUND',
};

export const madaTransactionType = {
	request: 'request',
	txn: 'txn',
};

export const locatorConstants = {
	skipButton: 'skipButton',
	closeUpdateModal: 'closeUpdateModal',
	registerButton: 'registerButton',
	phoneNumber: 'phoneNumber',
	password: 'password',
	loginButton: 'loginButton',
	signInViaCode: 'signInViaCode',
	forgetPassword: 'forgetPassword',
	searchButton: 'searchButton',
	searchBox: 'searchBox',
	searchItem: 'searchItem',
	name: 'name',
	email: 'email',
	number: 'number',
	companyNum: 'companyNum',
	next: 'next',
	emailError: 'emailError',
	phoneError: 'phoneError',
	businessType: 'businessType',
	businessName: 'businessName',
	addItem: 'addItem',
	basket: 'basket',
	increase: 'increase',
	decrease: 'decrease',
	addSpecificItemAmount: 'addSpecificItemAmount',
	openWishDelete: 'openWishDelete',
	addWishlist: 'addWishlist',
	deleteItem: 'deleteItem',
	increaseItem: 'increaseItem',
	decreaseItem: 'decreaseItem',
	placeOrder: 'placeOrder',
	closeCheckout: 'closeCheckout',
	addSpecificAmount: 'addSpecificAmount',
	addItemWishList: 'addItemWishList',
};
