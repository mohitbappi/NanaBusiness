const iconNanaBusiness = require('./nanaBusinessIcon/nanaBusinessIcon.png');
const iconNanaBusinessMan = require('./nanaBusinessMan/nanaBusinessMan.png');
const iconCross = require('./iconCross/iconCross.png');
const iconBack = require('./iconBack/iconBack.png');
const iconCheckedCheckBox = require('./iconCheckedCheckBox/iconCheckedCheckBox.png');
const iconForgotScreen = require('./iconForgotScreen/iconForgotScreen.png');
const iconInformation = require('./iconInformation/iconInformation.png');
const iconUncheckedCheckBox = require('./iconUncheckedCheckBox/iconUncheckedCheckBox.png');
const iconAdd = require('./iconAdd/iconAdd.png');
const iconHomeGrey = require('./iconHomeGrey/iconHomeGrey.png');
const iconLanguage = require('./iconLanguage/iconLanguage.png');
const iconGreenHeart = require('./iconGreenHeart/iconGreenHeart.png');
const iconHeartGrey = require('./iconHeartGrey/iconHeartGrey.png');
const iconLocation = require('./iconLocation/iconLocation.png');
const iconProfileDefault = require('./iconProfileDefault/iconProfileDefault.png');
const iconSupport = require('./iconSupport/iconSupport.png');
const iconUsers = require('./iconUsers/iconUsers.png');
const iconWallet = require('./iconWallet/iconWallet.png');
const iconYellowBackground = require('./iconYellowBackground/iconYellowBackground.png');
const iconAccountGrey = require('./iconAccountGrey/iconAccountGrey.png');
const iconHomeGreen = require('./iconHomeGreen/iconHomeGreen.png');
const iconAccountGreen = require('./iconAccountGreen/iconAccountGreen.png');
const iconLogout = require('./iconLogout/iconLogout.png');
const iconCompany = require('./iconCompany/iconCompany.png');
const iconEmail = require('./iconEmail/iconEmail.png');
const iconPhone = require('./iconPhone/iconPhone.png');
const iconPassword = require('./iconPassword/iconPassword.png');
const iconPasswordCharacter = require('./iconPasswordCharacter/iconPasswordCharacter.png');
const iconGallery = require('./iconGallery/iconGallery.png');
const iconInvoicesGreen = require('./iconInvoicesGreen/iconInvoicesGreen.png');
const iconInvoicesGrey = require('./iconInvoicesGrey/iconInvoicesGrey.png');
const iconGreenBackground = require('./iconGreenBackground/iconGreenBackground.png');
const iconLoan = require('./iconLoan/iconLoan.png');
const iconAddGreen = require('./iconAddGreen/iconAddGreen.png');
const iconSearch = require('./iconSearch/iconSearch.png');
const iconTeam = require('./iconTeam/iconTeam.png');
const iconAddYellow = require('./iconAddYellow/iconAddYellow.png');
const iconShare = require('./iconShare/iconShare.png');
const iconArrowDown = require('./iconArrowDown/iconArrowDown.png');
const iconRight = require('./iconRight/iconRight.png');
const iconActive = require('./iconActive/iconActive.png');
const iconInActive = require('./iconInActive/iconInActive.png');
const iconPin = require('./iconPin/iconPin.png');
const iconCart = require('./iconCart/iconCart.png');
const iconNotification = require('./iconNotification/iconNotification.png');
const iconBell = require('./iconBell/iconBell.png');
const iconBanner = require('./iconBanner/iconBanner.png');
const iconPlus = require('./iconPlus/iconPlus.png');
const iconLocationPin = require('./iconLocationPin/iconLocationPin.png');
const iconCongratulations = require('./iconCongratulations/iconCongratulations.png');
const iconPlusGreen = require('./iconPlusGreen/iconPlusGreen.png');
const iconMinusGreen = require('./iconMinusGreen/iconMinusGreen.png');
const iconDelete = require('./iconDelete/iconDelete.png');
const iconDeleteRed = require('./iconDeleteRed/iconDeleteRed.png');
const iconSmallCart = require('./iconSmallCart/iconSmallCart.png');
const iconRedInfo = require('./iconRedInfo/iconRedInfo.png');
const iconGreenUpArrow = require('./iconGreenUpArrow/iconGreenUpArrow.png');
const iconRightArrow = require('./iconRightArrow/iconRightArrow.png');
const iconSort = require('./iconSort/iconSort.png');
const iconStore = require('./iconStore/iconStore.png');
const iconMinus = require('./iconMinus/iconMinus.png');
const iconSmallPin = require('./iconSmallPin/iconSmallPin.png');
const iconMap = require('./iconMap/iconMap.png');
const iconPlusBlack = require('./iconPlusBlack/iconPlusBlack.png');
const iconEdit = require('./iconEdit/iconEdit.png');
const iconBranchName = require('./iconBranchName/iconBranchName.png');
const iconCall = require('./iconCall/iconCall.png');
const iconDefaultBrand = require('./iconDefaultBrand/iconDefaultBrand.png');
const iconDefaultCategoryActive = require('./iconDefaultCategoryActive/iconDefaultCategoryActive.png');
const iconUnCheckCircle = require('./iconUnCheckCircle/iconUnCheckCircle.png');
const iconCheckCircle = require('./iconCheckCircle/iconCheckCircle.png');
const iconCustomerGreen = require('./iconCustomerGreen/iconCustomerGreen.png');
const iconCustomerGrey = require('./iconCustomerGrey/iconCustomerGrey.png');
const iconAbout = require('./iconAbout/iconAbout.png');
const iconTAndC = require('./iconTAndC/iconTAndC.png');
const iconMyCollection = require('./iconMyCollection/iconMyCollection.png');
const iconMyCollectionGreen = require('./iconMyCollectionGreen/iconMyCollectionGreen.png');
const iconCustomer = require('./iconCustomer/iconCustomer.png');
const iconLocationWithBackground = require('./iconLocationWithBackground/iconLocationWithBackground.png');
const iconInvoice = require('./iconInvoice/iconInvoice.png');
const iconList = require('./iconList/iconList.png');
const iconCrossRed = require('./iconCrossRed/iconCrossRed.png');
const iconCameraGreen = require('./iconCameraGreen/iconCameraGreen.png');
const iconCalendar = require('./iconCalendar/iconCalendar.png');
const iconNanaAccount = require('./iconNanaAccount/iconNanaAccount.png');
const iconHidePassword = require('./iconHidePassword/iconHidePassword.png');
const iconShowPassword = require('./iconShowPassword/iconShowPassword.png');
const iconOrderStatusHollow = require('./iconOrderStatusHollow/iconOrderStatusHollow.png');
const iconOrderStatusFilled = require('./iconOrderStatusFilled/iconOrderStatusFilled.png');
const iconOrderStatusHollowCheck = require('./iconOrderStatusHollowCheck/iconOrderStatusHollowCheck.png');
const iconOrderGrey = require('./iconOrderGrey/iconOrderGrey.png');
const iconOrderGreen = require('./iconOrderGreen/iconOrderGreen.png');
const iconBankTransfer = require('./iconBankTransfer/iconBankTransfer.png');
const iconApplePay = require('./iconApplePay/iconApplePay.png');
const iconMada = require('./iconMada/iconMada.png');
const iconArrowDownGreen = require('./iconArrowDownGreen/iconArrowDownGreen.png');
const iconDefaultCategoryInactive = require('./iconDefaultCategoryInactive/iconDefaultCategoryInactive.png');
const iconDefaultPersonCircle = require('./iconDefaultPersonCircle/iconDefaultPersonCircle.png');
const iconPlusBlue = require('./iconPlusBlue/iconPlusBlue.png');
const iconEmailSent = require('./iconEmailSent/iconEmailSent.png');
const iconWishlist = require('./iconWishlist/iconWishlist.png');
const iconCard = require('./iconCard/iconCard.png');
const iconCash = require('./iconCash/iconCash.png');
const iconTransaction = require('./iconTransaction/iconTransaction.png');
const iconSmallPhone = require('./iconSmallPhone/iconSmallPhone.png');
const iconPhoneWhite = require('./iconPhoneWhite/iconPhoneWhite.png');
const iconThreeDot = require('./iconThreeDot/iconThreeDot.png');
const iconHeaderCart = require('./iconHeaderCart/iconHeaderCart.png');
const iconWishlistFilled = require('./iconWishlistFilled/iconWishlistFilled.png');
const iconStarFilled = require('./iconStarFilled/iconStarFilled.png');
const iconStar = require('./iconStar/iconStar.png');
const iconInformationGreen = require('./iconInformationGreen/iconInformationGreen.png');
const iconNana = require('./iconNana/iconNana.png');
const iconItemDetailDefault = require('./iconItemDetailDefault/iconItemDetailDefault.png');
const iconItemDefault = require('./iconItemDefault/iconItemDefault.png');
const iconHeaderShipment = require('./iconHeaderShipment/iconHeaderShipment.png');
const iconSalesHeader = require('./iconSalesHeader/iconSalesHeader.png');
const iconDownload = require('./iconDownload/iconDownload.png');
const iconPurchaseHeader = require('./iconPurchaseHeader/iconPurchaseHeader.png');
const iconSalesGrey = require('./iconSalesGrey/iconSalesGrey.png');
const iconShipmentGrey = require('./iconShipmentGrey/iconShipmentGrey.png');
const iconPurchaseGrey = require('./iconPurchaseGrey/iconPurchaseGrey.png');
const iconSalesPurple = require('./iconSalesPurple/iconSalesPurple.png');
const iconShipmentPurple = require('./iconShipmentPurple/iconShipmentPurple.png');
const iconPurchasePurple = require('./iconPurchasePurple/iconPurchasePurple.png');
const iconStarHalfFilled = require('./iconStarHalfFilled/iconStarHalfFilled.png');
const iconReject = require('./iconReject/iconReject.png');
const iconApprove = require('./iconApprove/iconApprove.png');
const iconHistoryGreen = require('./iconHistoryGreen/iconHistoryGreen.png');
const iconHistory = require('./iconHistory/iconHistory.png');
const iconPlusWhite = require('./iconPlusWhite/iconPlusWhite.png');
const iconVAT = require('./iconVAT/iconVAT.png');
const iconSearchGreen = require('./iconSearchGreen/iconSearchGreen.png');
const iconWalkthroughOne = require('./iconWalkthroughOne/iconWalkthroughOne.png');
const iconWalkthroughTwo = require('./iconWalkthroughTwo/iconWalkthroughTwo.png');
const iconWalkthroughThree = require('./iconWalkthroughThree/iconWalkthroughThree.png');
const iconWalkthroughButtonOne = require('./iconWalkthroughButtonOne/iconWalkthroughButtonOne.png');
const iconWalkthroughButtonTwo = require('./iconWalkthroughButtonTwo/iconWalkthroughButtonTwo.png');
const iconWalkthroughButtonThree = require('./iconWalkthroughButtonThree/iconWalkthroughButtonThree.png');
const iconWalkthroughPaginationOne = require('./iconWalkthroughPaginationOne/iconWalkthroughPaginationOne.png');
const iconWalkthroughPaginationTwo = require('./iconWalkthroughPaginationTwo/iconWalkthroughPaginationTwo.png');
const iconWalkthroughPaginationThree = require('./iconWalkthroughPaginationThree/iconWalkthroughPaginationThree.png');
const iconMinusWhite = require('./iconMinusWhite/iconMinusWhite.png');
const iconContactUs = require('./iconContactUs/iconContactUs.png');
const iconNavigate = require('./iconNavigate/iconNavigate.png');
const iconCredit = require('./iconCredit/iconCredit.png');
const iconLeftArrow = require('./iconLeftArrow/iconLeftArrow.png');
const iconCartEmpty = require('./iconCartEmpty/iconCartEmpty.png');
const iconOrderDark = require('./iconOrderDark/iconOrderDark.png');
const iconFilterGrey = require('./iconFilterGrey/iconFilterGrey.png');
const iconMyCollectionGrey = require('./iconMyCollectionGrey/iconMyCollectionGrey.png');
const imageBackgroundGradient = require('./imageBackgroundGradient/imageBackgroundGradient.png');
const iconCameraGreenFilled = require('./iconCameraGreenFilled/iconCameraGreenFilled.png');
const iconProfileBorder = require('./iconProfileBorder/iconProfileBorder.png');
const iconCOD = require('./iconCOD/iconCOD.png');
const iconOnlinePayment = require('./iconOnlinePayment/iconOnlinePayment.png');
const iconFailed = require('./iconFailed/iconFailed.png');
const iconPending = require('./iconPending/iconPending.png');
const iconWarningWhite = require('./iconWarningWhite/iconWarningWhite.png');
const iconExpectedDelivery = require('./iconExpectedDelivery/iconExpectedDelivery.png');
const iconDownloadBlue = require('./iconDownloadBlue/iconDownloadBlue.png');
const iconLanguagePurple = require('./iconLanguagePurple/iconLanguagePurple.png');
const iconEmptyWishlist = require('./iconEmptyWishlist/iconEmptyWishlist.png');
const iconRetry = require('./iconRetry/iconRetry.png');
const iconNanaBusinessCircle = require('./iconNanaBusinessCircle/iconNanaBusinessCircle.png');
const iconTransactionDetailSuccess = require('./iconTransactionDetailSuccess/iconTransactionDetailSuccess.png');
const iconTransactionDetailPending = require('./iconTransactionDetailPending/iconTransactionDetailPending.png');
const iconTransactionDetailFailed = require('./iconTransactionDetailFailed/iconTransactionDetailFailed.png');
const iconSupportBlue = require('./iconSupportBlue/iconSupportBlue.png');
const iconCheckCircleBlue = require('./iconCheckCircleBlue/iconCheckCircleBlue.png');
const iconMadaGreen = require('./iconMadaGreen/iconMadaGreen.png');
const iconAppUpdate = require('./iconAppUpdate/iconAppUpdate.png');
const iconRetryBlue = require('./iconRetryBlue/iconRetryBlue.png');
const iconFilterWhite = require('./iconFilterWhite/iconFilterWhite.png');
const iconFilter = require('./iconFilter/filterIcon.png');
const iconCheckDot = require('./iconCheckDot/iconCheckDot.png');
const iconCircleDisable = require('./iconCircleDisable/iconCircleDisable.png');
const iconGradientBackground = require('./iconGradientBackground/iconGradientBackground.png');
const iconHomeWallet = require('./iconHomeWallet/iconHomeWallet.png');
const iconHomeCredit = require('./iconHomeCredit/iconHomeCredit.png');
const iconNote = require('./iconNote/iconNote.png');
const iconSignInScreenArabic = require('./iconSignInScreenArabic/iconSignInScreenArabic.png');
const iconSignInScreenEnglish = require('./iconSignInScreenEnglish/iconSignInScreenEnglish.png');
const iconFlag = require('./iconFlag/iconFlag.png');
const iconInvoicePurple = require('./iconInvoicePurple/iconInvoicePurple.png');
const iconPhoneBlack = require('./iconPhoneBlack/iconPhoneBlack.png');
const iconSms = require('./iconSms/iconSms.png');
const iconWhatsapp = require('./iconWhatsapp/iconWhatsapp.png');
const iconGreenCustomer = require('./iconGreenCustomer/iconGreenCustomer.png');
const iconGreenMyCollection = require('./iconGreenMyCollection/iconGreenMyCollection.png');
const iconOOZ = require('./iconOOZ/iconOOZ.png');
const iconPallet = require('./iconPallet/iconPallet.png');
const iconPalletSmall = require('./iconPalletSmall/iconPalletSmall.png');
const iconReceivablesGrey = require('./iconReceivablesGrey/iconReceivablesGrey.png');
const iconReceivablesPurple = require('./iconReceivablesPurple/iconReceivablesPurple.png');
const iconPendingDeposistsGrey = require('./iconPendingDeposistsGrey/iconPendingDeposistsGrey.png');
const iconPendingDeposistsPurple = require('./iconPendingDeposistsPurple/iconPendingDeposistsPurple.png');

export default {
	iconNanaBusiness,
	iconNanaBusinessMan,
	iconCross,
	iconBack,
	iconCheckedCheckBox,
	iconForgotScreen,
	iconInformation,
	iconUncheckedCheckBox,
	iconAdd,
	iconHomeGrey,
	iconLanguage,
	iconGreenHeart,
	iconHeartGrey,
	iconLocation,
	iconProfileDefault,
	iconSupport,
	iconUsers,
	iconWallet,
	iconYellowBackground,
	iconAccountGrey,
	iconHomeGreen,
	iconAccountGreen,
	iconLogout,
	iconCompany,
	iconEmail,
	iconPhone,
	iconPassword,
	iconPasswordCharacter,
	iconGallery,
	iconInvoicesGreen,
	iconInvoicesGrey,
	iconGreenBackground,
	iconLoan,
	iconAddGreen,
	iconSearch,
	iconTeam,
	iconAddYellow,
	iconShare,
	iconArrowDown,
	iconRight,
	iconActive,
	iconInActive,
	iconPin,
	iconCart,
	iconNotification,
	iconBell,
	iconBanner,
	iconPlus,
	iconLocationPin,
	iconCongratulations,
	iconPlusGreen,
	iconMinusGreen,
	iconDelete,
	iconDeleteRed,
	iconSmallCart,
	iconRedInfo,
	iconGreenUpArrow,
	iconRightArrow,
	iconSort,
	iconStore,
	iconMinus,
	iconSmallPin,
	iconMap,
	iconPlusBlack,
	iconEdit,
	iconBranchName,
	iconCall,
	iconDefaultBrand,
	iconDefaultCategoryActive,
	iconUnCheckCircle,
	iconCheckCircle,
	iconCustomerGreen,
	iconCustomerGrey,
	iconAbout,
	iconTAndC,
	iconMyCollection,
	iconMyCollectionGreen,
	iconCustomer,
	iconLocationWithBackground,
	iconInvoice,
	iconList,
	iconCrossRed,
	iconCameraGreen,
	iconCalendar,
	iconNanaAccount,
	iconHidePassword,
	iconShowPassword,
	iconOrderStatusHollow,
	iconOrderStatusFilled,
	iconOrderStatusHollowCheck,
	iconOrderGrey,
	iconOrderGreen,
	iconBankTransfer,
	iconApplePay,
	iconMada,
	iconArrowDownGreen,
	iconDefaultCategoryInactive,
	iconDefaultPersonCircle,
	iconPlusBlue,
	iconEmailSent,
	iconWishlist,
	iconCard,
	iconCash,
	iconTransaction,
	iconSmallPhone,
	iconPhoneWhite,
	iconThreeDot,
	iconHeaderCart,
	iconWishlistFilled,
	iconStarFilled,
	iconStar,
	iconInformationGreen,
	iconNana,
	iconItemDetailDefault,
	iconItemDefault,
	iconHeaderShipment,
	iconSalesHeader,
	iconDownload,
	iconPurchaseHeader,
	iconSalesGrey,
	iconShipmentGrey,
	iconPurchaseGrey,
	iconSalesPurple,
	iconShipmentPurple,
	iconPurchasePurple,
	iconStarHalfFilled,
	iconReject,
	iconApprove,
	iconHistoryGreen,
	iconHistory,
	iconPlusWhite,
	iconVAT,
	iconSearchGreen,
	iconWalkthroughOne,
	iconWalkthroughTwo,
	iconWalkthroughThree,
	iconWalkthroughButtonOne,
	iconWalkthroughButtonTwo,
	iconWalkthroughButtonThree,
	iconWalkthroughPaginationOne,
	iconWalkthroughPaginationTwo,
	iconWalkthroughPaginationThree,
	iconMinusWhite,
	iconContactUs,
	iconNavigate,
	iconCredit,
	iconLeftArrow,
	iconCartEmpty,
	iconOrderDark,
	iconFilterGrey,
	iconMyCollectionGrey,
	imageBackgroundGradient,
	iconCameraGreenFilled,
	iconProfileBorder,
	iconCOD,
	iconOnlinePayment,
	iconFailed,
	iconPending,
	iconWarningWhite,
	iconExpectedDelivery,
	iconDownloadBlue,
	iconLanguagePurple,
	iconEmptyWishlist,
	iconRetry,
	iconNanaBusinessCircle,
	iconTransactionDetailSuccess,
	iconTransactionDetailPending,
	iconTransactionDetailFailed,
	iconSupportBlue,
	iconCheckCircleBlue,
	iconMadaGreen,
	iconAppUpdate,
	iconRetryBlue,
	iconFilterWhite,
	iconFilter,
	iconCheckDot,
	iconCircleDisable,
	iconGradientBackground,
	iconHomeWallet,
	iconHomeCredit,
	iconNote,
	iconSignInScreenEnglish,
	iconSignInScreenArabic,
	iconFlag,
	iconInvoicePurple,
	iconPhoneBlack,
	iconSms,
	iconWhatsapp,
	iconGreenCustomer,
	iconGreenMyCollection,
	iconOOZ,
	iconPallet,
	iconPalletSmall,
	iconReceivablesGrey,
	iconReceivablesPurple,
	iconPendingDeposistsGrey,
	iconPendingDeposistsPurple,
};
