import LocalizedStrings from 'react-native-localization';
import ar from '@Strings/ar';
import en from '@Strings/en';

/**
 * Specifies locale to be used
 */
const locale = new LocalizedStrings({
	en,
	ar,
});

/**
 * Change Locale
 */
export function setLocale(val) {
	locale.setLanguage(val);
}

/**
 * Provides text in current locale
 */
export function localeString(text) {
	const str = locale[`${text}`];
	return str;
}

/**
 * Get current locale
 */
export function getLocale() {
	return locale.getLanguage();
}
