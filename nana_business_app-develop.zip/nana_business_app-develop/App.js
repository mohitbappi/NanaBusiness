import React, { Component } from 'react';
import { Provider } from 'react-redux';
import { SafeAreaView, StyleSheet, StatusBar, Platform } from 'react-native';
import codePush from 'react-native-code-push';
import Config from 'react-native-config';
import OneSignal from 'react-native-onesignal';
import { initFirebase } from '@config/firebase/config';
import store from './App/src/config/store';
import Route from './App/src/config/routes';
import * as colors from './App/assets/colors';
import { CODEPUSH, requireUserPrivacyConsent } from './App/assets/Constants/Constants';
import { setAppId, permissionObserver } from './App/src/Util/NotificationUtils';

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: colors.white,
	},
});

class App extends Component {
	codePushInterval;

	constructor(props) {
		super(props);
		this.codePushSync = this.codePushSync.bind(this);
		this.codePushSync();
		this.startCodePushTimer();
		initFirebase(); // initialize firebase
	}

	async componentDidMount() {
		/* O N E S I G N A L   S E T U P */
		setAppId(Config.ONESIGNAL_APP_ID);
		OneSignal.setLogLevel(6, 0);
		OneSignal.setRequiresUserPrivacyConsent(requireUserPrivacyConsent);
		OneSignal.promptForPushNotificationsWithUserResponse();
		/* O N E S I G N A L  H A N D L E R S */
		permissionObserver();
	}

	componentWillUnmount() {
		OneSignal.clearHandlers();
		clearInterval(this.codePushInterval);
	}

	startCodePushTimer = () => {
		// Calculating time remaining untill the next sync
		// Code sync will be done every 4 hours of the day (example: 04:00a.m. then 08:00a.m. then 12:00p.m.)
		const timeNow = new Date();
		const remainingHours = 3 - (timeNow.getHours() % 4);
		const remainingMinutes = 60 - timeNow.getMinutes();
		const remainingMS = remainingMinutes * 60 * 1000 + remainingHours * 60 * 60 * 1000;

		this.codePushInterval = setTimeout(() => {
			this.codePushSync();
			this.startCodePushTimer();
		}, remainingMS);
	};

	codePushSync() {
		codePush.sync(
			{
				updateDialog: {
					title: CODEPUSH.title,
					mandatoryUpdateMessage: CODEPUSH.message,
					mandatoryContinueButtonLabel: CODEPUSH.button,
				},
				installMode: codePush.InstallMode.IMMEDIATE,
				deploymentKey:
					Platform.OS === 'ios' ? Config.IOS_CODEPUSH_KEY : Config.ANDROID_CODEPUSH_KEY,
			},
			//   this.codePushStatusDidChange,
			// this.codePushDownloadDidProgress,
		);
	}

	render() {
		return (
			<Provider store={store}>
				<SafeAreaView style={styles.container}>
					<StatusBar backgroundColor={colors.white} barStyle="dark-content" />
					<Route />
				</SafeAreaView>
			</Provider>
		);
	}
}

const codePushOptions = {
	checkFrequency: codePush.CheckFrequency.MANUAL, // ON_APP_RESUME,
	installMode: codePush.InstallMode.IMMEDIATE,
};

export default codePush(codePushOptions)(App);
